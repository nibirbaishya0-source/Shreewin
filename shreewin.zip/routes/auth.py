from flask import Blueprint, request, session, redirect, url_for, Response, render_template_string
from database import get_db
from models import User, Referral
from utils import generate_uid, generate_invite_code, ensure_invite_code
from pages.register import register_html
from pages.login import login_html
from pages.splash import splash_html
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/")
def index_splash():
    session["splash_done"] = True
    resp = Response(splash_html, mimetype="text/html; charset=utf-8")
    resp.set_cookie("after_splash", "/login", max_age=60, path="/")
    return resp

@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    # Prefill invite code from URL: ?invite=XXXX or ?code=XXXX or ?ref=XXXX
    def _get_invite_prefill():
        return (
            (request.args.get("invite") or request.args.get("code") or request.args.get("ref") or "")
            .strip()
        )

    if request.method == "GET":
        if not session.get("splash_done") and request.args.get("s") != "1":
            session["splash_done"] = True
            q = request.query_string.decode() if request.query_string else ""
            target = "/register" + (("?" + q) if q else "")
            resp = redirect("/splash")
            resp.set_cookie("after_splash", target, max_age=60, path="/")
            return resp
        session["splash_done"] = True
        invite_code = _get_invite_prefill()
        html = render_template_string(register_html, invite_code=invite_code)
        return Response(html, mimetype="text/html; charset=utf-8")

    phone = (request.form.get("phone") or "").strip()
    password = (request.form.get("password") or "").strip()
    confirm = (request.form.get("confirm") or "").strip()
    invite = (request.form.get("invite") or "").strip()
    # Keep prefill on validation error
    invite_code = invite or _get_invite_prefill()

    if not phone or not password:
        html = render_template_string(register_html, invite_code=invite_code)
        return Response(html, mimetype="text/html; charset=utf-8")

    if password != confirm:
        html = render_template_string(register_html, invite_code=invite_code)
        return Response(html, mimetype="text/html; charset=utf-8")

    db = get_db()
    try:
        exists = db.query(User).filter_by(phone=phone).first()
        if exists:
            return redirect(url_for("auth.login"))

        uid = generate_uid(phone)
        new_invite_code = generate_invite_code()
        referred_by = None

        if invite:
            ref = db.query(User).filter(
                (User.invite_code == invite) | (User.uid == invite)
            ).first()
            if ref:
                referred_by = ref.uid

        user = User(
            phone=phone,
            password=generate_password_hash(password),
            uid=uid,
            invite_code=new_invite_code,
            referred_by=referred_by,
            balance=0.0,
            member_name=phone[-4:] if len(phone) >= 4 else phone,
        )
        db.add(user)

        if referred_by:
            db.add(Referral(
                referrer_uid=referred_by,
                referred_uid=uid,
                referred_phone=phone,
                bonus_given=False,
                time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            ))

        db.commit()
        session["uid"] = uid
        session["phone"] = phone
        return redirect(url_for("main.home"))
    except Exception as e:
        db.rollback()
        print("register error:", e)
        html = render_template_string(register_html, invite_code=invite_code)
        return Response(html, mimetype="text/html; charset=utf-8")
    finally:
        db.close()


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        if not session.get("splash_done") and request.args.get("s") != "1":
            session["splash_done"] = True
            from flask import make_response
            resp = redirect("/splash")
            resp.set_cookie("after_splash", "/login", max_age=60, path="/")
            return resp
        session["splash_done"] = True
        return Response(login_html, mimetype="text/html; charset=utf-8")

    phone = (request.form.get("phone") or "").strip()
    password = (request.form.get("password") or "").strip()

    db = get_db()
    try:
        user = db.query(User).filter_by(phone=phone).first()
        if not user:
            return Response(login_html, mimetype="text/html; charset=utf-8")
        stored = user.password or ""
        ok = False
        if stored.startswith(("pbkdf2:", "scrypt:", "argon2:")):
            ok = check_password_hash(stored, password)
        else:
            # legacy plain-text users — upgrade hash on successful login
            ok = (stored == password)
            if ok:
                try:
                    user.password = generate_password_hash(password)
                    db.commit()
                except Exception:
                    db.rollback()
        if not ok:
            return Response(login_html, mimetype="text/html; charset=utf-8")

        session["uid"] = user.uid
        session["phone"] = user.phone
        ensure_invite_code(user.uid)
        return redirect(url_for("main.home"))
    finally:
        db.close()


@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
