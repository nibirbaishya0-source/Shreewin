from flask import Blueprint, request, jsonify, render_template_string
from config import ADMIN_SECRET
from database import get_db
from models import User, Deposit, Withdrawal
from pages.admin import admin_html

admin_bp = Blueprint("admin", __name__)

def admin_ok():
    return (request.headers.get("X-Admin-Key") == ADMIN_SECRET or
            request.args.get("key") == ADMIN_SECRET)

def _value(obj, *names, default=None):
    for name in names:
        try:
            value = getattr(obj, name)
        except Exception:
            continue
        if value is not None:
            return value
    return default

def _status(value):
    return str(value or "").strip().lower()

def _all_rows(db, model):
    try:
        return db.query(model).order_by(model.id.desc()).all()
    except Exception:
        return db.query(model).all()

def _row_dict(row, kind):
    if kind == "deposit":
        rid = _value(row, "id", default="")
        return {
            "id": str(rid),
            "orderId": str(rid),
            "uid": str(_value(row, "uid", "user_id", "userid", default="")),
            "amount": float(_value(row, "amount", default=0) or 0),
            "utr": str(_value(row, "utr", "utr_no", "utrNumber", default="")),
            "status": _status(_value(row, "status", default="pending")),
            "channel": _value(row, "channel", "method", default="UPI-QR"),
            "method": _value(row, "channel", "method", default="UPI-QR"),
            "timestamp": str(_value(row, "created_at", "timestamp", "time", default="")),
            "raw_index": None,
        }
    return {
        "id": str(_value(row, "id", "order_id", "orderId", default="")),
        "uid": str(_value(row, "uid", "user_id", "userid", default="")),
        "amount": float(_value(row, "amount", default=0) or 0),
        "status": _status(_value(row, "status", default="pending")),
        "method": _value(row, "method", "channel", "type", default="Bank"),
        "vpa": _value(row, "vpa", "upi", "upi_id", default=""),
        "account": _value(row, "account", "account_no", "account_number", default=""),
        "name": _value(row, "name", "beneficiary_name", default=""),
        "bank": _value(row, "bank", "bank_name", default=""),
        "ifsc": _value(row, "ifsc", default=""),
        "timestamp": str(_value(row, "created_at", "timestamp", "time", default="")),
        "raw_index": None,
    }

def _find_row(db, model, data):
    rows = _all_rows(db, model)
    # 1) Prefer primary key id
    pk = data.get("id") or data.get("orderId") or data.get("order_id")
    if pk is not None and str(pk).strip() != "":
        pk_s = str(pk).strip()
        for row in rows:
            if str(_value(row, "id", default="")) == pk_s:
                return row
    # 2) UTR match (first pending preferred for deposits)
    utr = str(data.get("utr", "") or "").strip()
    if utr and model is Deposit:
        pending = None
        any_match = None
        for row in rows:
            if str(_value(row, "utr", default="")) == utr:
                any_match = row
                st = _status(_value(row, "status", default="pending"))
                if st in ("pending", "processing"):
                    pending = row
                    break
        if pending is not None:
            return pending
        if any_match is not None:
            return any_match
    # 3) raw_index fallback
    if data.get("raw_index") is not None:
        try:
            i = int(data["raw_index"])
            if 0 <= i < len(rows):
                return rows[i]
        except Exception:
            pass
    return None

@admin_bp.route("/admin")
@admin_bp.route("/master")
def admin_panel():
    return render_template_string(admin_html)

@admin_bp.route("/api/admin/dashboard", methods=["GET"])
def api_admin_dashboard():
    if not admin_ok():
        return jsonify({"ok": False, "msg": "Unauthorized"}), 401
    db = get_db()
    try:
        deposits = [_row_dict(r, "deposit") for r in _all_rows(db, Deposit)]
        withdrawals = [_row_dict(r, "withdrawal") for r in _all_rows(db, Withdrawal)]
        for i, r in enumerate(deposits): r["raw_index"] = i
        for i, r in enumerate(withdrawals): r["raw_index"] = i
        balances = {}
        for u in _all_rows(db, User):
            uid = _value(u, "uid", "id", "user_id", default="")
            if uid != "":
                try: balances[str(uid)] = float(_value(u, "balance", "wallet_balance", "wallet", default=0) or 0)
                except Exception: balances[str(uid)] = 0.0
        return jsonify({"ok": True, "deposits": deposits, "withdrawals": withdrawals,
                        "support": [], "balances": balances, "gifts": []})
    except Exception as e:
        return jsonify({"ok": False, "msg": f"Dashboard error: {e}"}), 500
    finally:
        db.close()

def _status_change(model, new_status, not_found):
    """Atomic status update + balance change in ONE db session."""
    if not admin_ok():
        return jsonify({"ok": False, "msg": "Unauthorized"}), 401
    data = request.get_json() or {}
    db = get_db()
    try:
        row = _find_row(db, model, data)
        if not row:
            return jsonify({"ok": False, "msg": not_found}), 404

        # Re-load by primary key so we update the exact row
        pk = getattr(row, "id", None)
        if pk is not None:
            row = db.query(model).filter_by(id=pk).first()
        if not row:
            return jsonify({"ok": False, "msg": not_found}), 404

        cur = _status(getattr(row, "status", None) or "pending")
        if cur not in ("pending", "processing"):
            return jsonify({
                "ok": False,
                "msg": "Already processed (" + cur + ")",
                "status": cur,
                "id": str(pk),
            }), 400

        uid = str(getattr(row, "uid", "") or "")
        try:
            amt = float(getattr(row, "amount", 0) or 0)
        except Exception:
            amt = 0.0

        # Same session: balance + status together
        if model is Deposit and new_status == "Approved" and uid and amt > 0:
            user = db.query(User).filter_by(uid=uid).first()
            if not user:
                return jsonify({"ok": False, "msg": "User not found for credit"}), 404
            user.balance = round(float(user.balance or 0) + amt, 2)

        if model is Withdrawal and new_status == "Rejected" and uid and amt > 0:
            user = db.query(User).filter_by(uid=uid).first()
            if user:
                user.balance = round(float(user.balance or 0) + amt, 2)

        row.status = new_status
        db.commit()
        try:
            db.refresh(row)
        except Exception:
            pass
        return jsonify({
            "ok": True,
            "msg": model.__name__ + " marked as " + new_status,
            "status": _status(new_status),
            "id": str(getattr(row, "id", "")),
        })
    except Exception as e:
        try:
            db.rollback()
        except Exception:
            pass
        return jsonify({"ok": False, "msg": str(e)}), 500
    finally:
        try:
            db.close()
        except Exception:
            pass


@admin_bp.route("/api/admin/deposit/approve", methods=["POST"])
def api_admin_deposit_approve(): return _status_change(Deposit, "Approved", "Deposit not found")

@admin_bp.route("/api/admin/deposit/reject", methods=["POST"])
def api_admin_deposit_reject(): return _status_change(Deposit, "Rejected", "Deposit not found")

@admin_bp.route("/api/admin/deposit/clear_pending", methods=["POST"])
def api_admin_deposit_clear_pending():
    if not admin_ok(): return jsonify({"ok": False, "msg": "Unauthorized"}), 401
    db = get_db()
    try:
        count = 0
        for row in _all_rows(db, Deposit):
            if _status(_value(row, "status", default="pending")) == "pending":
                row.status = "Rejected"; count += 1
        db.commit(); return jsonify({"ok": True, "msg": f"Cleared {count} pending deposits"})
    except Exception as e:
        db.rollback(); return jsonify({"ok": False, "msg": str(e)}), 500
    finally: db.close()

@admin_bp.route("/api/admin/withdraw/approve", methods=["POST"])
def api_admin_withdraw_approve(): return _status_change(Withdrawal, "Approved", "Withdrawal not found")

@admin_bp.route("/api/admin/withdraw/reject", methods=["POST"])
def api_admin_withdraw_reject(): return _status_change(Withdrawal, "Rejected", "Withdrawal not found")

@admin_bp.route("/api/admin/balance", methods=["POST"])
def api_admin_balance():
    if not admin_ok(): 
        return jsonify({"ok": False, "msg": "Unauthorized"}), 401
    
    data = request.get_json() or {}
    uid = str(data.get("uid", "")).strip()
    amount = data.get("amount")

    if not uid:
        return jsonify({"ok": False, "msg": "User ID is required"}), 400
    if amount is None:
        return jsonify({"ok": False, "msg": "Amount is required"}), 400

    db = get_db()
    try:
        # सुरक्षित तरीके से चेक करें कि मॉडल में कौन सा फ़ील्ड है
        filters = []
        if hasattr(User, 'uid'):
            filters.append(User.uid == uid)
        if hasattr(User, 'id'):
            filters.append(User.id == uid)
            
        if not filters:
            return jsonify({"ok": False, "msg": "No valid identifier column found in User model"}), 500

        # डायनामिक फ़िल्टर का उपयोग करके यूजर ढूंढें
        from sqlalchemy import or_
        user = db.query(User).filter(or_(*filters)).first()

        if not user:
            return jsonify({"ok": False, "msg": "User not found"}), 404

        # बैलेंस अपडेट करें
        if hasattr(user, 'balance'):
            user.balance = float(amount)
        elif hasattr(user, 'wallet_balance'):
            user.wallet_balance = float(amount)
        elif hasattr(user, 'wallet'):
            user.wallet = float(amount)
        else:
            return jsonify({"ok": False, "msg": "Balance field not found in User model"}), 500

        db.commit()
        return jsonify({"ok": True, "msg": f"Wallet balance updated successfully to {amount}"})
    except Exception as e:
        db.rollback()
        return jsonify({"ok": False, "msg": str(e)}), 500
    finally:
        db.close()

@admin_bp.route("/api/admin/gift/create", methods=["POST"])
def api_admin_gift_create():
    if not admin_ok(): return jsonify({"ok": False, "msg": "Unauthorized"}), 401
    return jsonify({"ok": False, "msg": "Gift-code storage is not present in the supplied backend."}), 501

@admin_bp.route("/api/admin/gift/delete", methods=["POST"])
def api_admin_gift_delete():
    if not admin_ok(): return jsonify({"ok": False, "msg": "Unauthorized"}), 401
    return jsonify({"ok": False, "msg": "Gift-code storage is not present in the supplied backend."}), 501

@admin_bp.route("/api/admin/support/reply", methods=["POST"])
def api_admin_support_reply():
    if not admin_ok(): return jsonify({"ok": False, "msg": "Unauthorized"}), 401
    return jsonify({"ok": False, "msg": "Support-message storage is not present in the supplied backend."}), 501
