from flask import Blueprint, request, session, jsonify
from utils import get_balance, add_balance

wallet_bp = Blueprint("wallet", __name__)

@wallet_bp.route("/account_balance")
def account_balance():
    uid = session.get("uid")
    if not uid:
        return jsonify({"ok": False, "msg": "Not logged in"}), 401
    return jsonify({"ok": True, "balance": get_balance(uid)})

@wallet_bp.route("/update_balance", methods=["POST"])
def update_balance():
    uid = session.get("uid")
    if not uid:
        return jsonify({"ok": False, "msg": "Not logged in"}), 401
    data = request.get_json() or {}
    action = data.get("action", "")
    try:
        amount = float(data.get("amount", 0) or 0)
    except (TypeError, ValueError):
        return jsonify({"ok": False, "msg": "Invalid amount"}), 400
    if amount < 0:
        return jsonify({"ok": False, "msg": "Invalid amount"}), 400
    if action in ("add", "win", "credit"):
        bal = add_balance(uid, amount)
    elif action in ("sub", "subtract", "bet", "debit"):
        if get_balance(uid) < amount:
            return jsonify({"ok": False, "msg": "Insufficient balance"}), 400
        bal = add_balance(uid, -amount)
    else:
        return jsonify({"ok": False, "msg": "Invalid action"}), 400
    if bal is None:
        return jsonify({"ok": False, "msg": "User not found"}), 404
    return jsonify({"ok": True, "balance": bal})
