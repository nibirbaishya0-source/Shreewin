def register_blueprints(app):
    from routes.auth import auth_bp
    from routes.main import main_bp
    from routes.games import games_bp
    from routes.wallet import wallet_bp
    from routes.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(games_bp)
    app.register_blueprint(wallet_bp)
    app.register_blueprint(admin_bp)
