from flask import Blueprint, session, redirect, url_for, Response, request, render_template_string
from pages.home import home_html
from pages.account import account_html
from pages.activity import activity_html
from pages.promotion import promotion_html
from utils import get_balance, get_user_by_uid, ensure_invite_code
from config import UPI_VPA, UPI_NAME, MIN_DEPOSIT, MAX_DEPOSIT, SUPPORT_TELEGRAM
from datetime import datetime

main_bp = Blueprint("main", __name__)


def _need_login():
    if not session.get("uid"):
        return redirect(url_for("auth.login"))
    return None


def _account_context():
    uid = session.get("uid")
    user = get_user_by_uid(uid) if uid else None
    balance = get_balance(uid) if uid else 0.0
    member_name = (user.member_name if user and user.member_name else (user.phone[-4:] if user and user.phone else "User"))
    last_login = datetime.now().strftime("%Y-%m-%d %H:%M")
    invite = ensure_invite_code(uid) if uid else ""
    return {
        "balance": f"{balance:.2f}",
        "uid": uid or "",
        "member_name": member_name,
        "last_login": last_login,
        "upi_vpa": UPI_VPA,
        "upi_name": UPI_NAME,
        "min_deposit": int(MIN_DEPOSIT),
        "max_deposit": int(MAX_DEPOSIT),
        "support_url": SUPPORT_TELEGRAM,
        "invite_code": invite,
    }


@main_bp.route("/home")
def home():
    r = _need_login()
    if r:
        return r
    return Response(home_html, mimetype="text/html; charset=utf-8")


@main_bp.route("/account")
@main_bp.route("/deposit")
@main_bp.route("/withdraw")
@main_bp.route("/deposit-history")
@main_bp.route("/withdraw-history")
@main_bp.route("/gift")
def account():
    r = _need_login()
    if r:
        return r
    ctx = _account_context()
    html = render_template_string(account_html, **ctx)
    return Response(html, mimetype="text/html; charset=utf-8")


@main_bp.route("/activity")
def activity():
    r = _need_login()
    if r:
        return r
    return Response(activity_html, mimetype="text/html; charset=utf-8")


@main_bp.route("/promotion")
def promotion():
    r = _need_login()
    if r:
        return r
    ctx = _account_context()
    html = render_template_string(promotion_html, **ctx)
    return Response(html, mimetype="text/html; charset=utf-8")
