from flask import Blueprint, session, redirect, url_for, Response, request
from pages.home import home_html
from pages.splash import splash_html
from pages.account import (
    account_html,
    support_html,
    deposit_html,
    withdraw_html,
    add_bank_html,
    deposit_history_html,
    withdraw_history_html,
)
from pages.activity import activity_html
from pages.promotion import promotion_html
from utils import get_balance, ensure_invite_code
from config import UPI_VPA, UPI_NAME, MIN_DEPOSIT, MAX_DEPOSIT
import re
from datetime import datetime

main_bp = Blueprint("main", __name__)

def html_response(content: str):
    return Response(content, mimetype="text/html; charset=utf-8")

def _member_name(uid):
    """Official-style name: membervip + digits (not raw phone)."""
    custom = session.get("member_name") or session.get("username") or session.get("name")
    if custom and not str(custom).isdigit() and "@" not in str(custom):
        return str(custom)
    digits = re.sub(r"\D", "", str(uid))[-4:] or "0120"
    try:
        n = int(digits) if digits else 120
    except ValueError:
        n = 120
    suffix = f"{(n * 7 + 13) % 10000:04d}"
    return f"membervip{suffix}"

def _last_login():
    return session.get("last_login") or datetime.now().strftime("%Y-%m-%d %H:%M")

def _fill_vars(html, uid, bal=None):
    if bal is None:
        bal = get_balance(uid)
    inv = ensure_invite_code(uid)
    html = html.replace("{{ balance }}", f"{bal:.2f}")
    html = html.replace("{{ invite_code }}", str(inv))
    html = html.replace("{{ uid }}", str(uid))
    html = html.replace("{{ member_name }}", str(_member_name(uid)))
    html = html.replace("{{ last_login }}", str(_last_login()))
    # UPI deposit details (from config / env)
    html = html.replace("{{ upi_vpa }}", str(UPI_VPA))
    html = html.replace("{{ upi_name }}", str(UPI_NAME))
    html = html.replace("{{ min_deposit }}", str(MIN_DEPOSIT))
    html = html.replace("{{ max_deposit }}", str(MAX_DEPOSIT))
    return html

def _need_login():
    if not session.get("uid"):
        return redirect(url_for("auth.login"))
    return None

def _render_home():
    html = home_html
    uid = session.get("uid")
    if uid:
        bal = get_balance(uid)
        logged_in = f"""
  <div class="auth-btns" style="gap:8px">
    <a href="/account" class="btn-register" style="max-width:100%;background:linear-gradient(180deg,#2a2150,#1a1435);border:1px solid rgba(124,77,255,.35)">
      ₹{bal:.2f} · Account
    </a>
  </div>
"""
        html = re.sub(
            r"<!--AUTH_SECTION-->.*?<!--/AUTH_SECTION-->",
            logged_in,
            html,
            count=1,
            flags=re.DOTALL,
        )
    return html_response(html)

@main_bp.route("/splash")
def splash():
    return html_response(splash_html)

@main_bp.route("/home")
def home():
    return _render_home()

@main_bp.route("/account")
def account():
    r = _need_login()
    if r: return r
    return html_response(_fill_vars(account_html, session["uid"]))

@main_bp.route("/deposit")
def deposit():
    r = _need_login()
    if r: return r
    return html_response(_fill_vars(deposit_html, session["uid"]))

@main_bp.route("/withdraw")
def withdraw():
    r = _need_login()
    if r: return r
    return html_response(_fill_vars(withdraw_html, session["uid"]))

@main_bp.route("/add-bank")
@main_bp.route("/add_bank")
def add_bank():
    r = _need_login()
    if r: return r
    return html_response(_fill_vars(add_bank_html, session["uid"]))

@main_bp.route("/deposit-history")
def deposit_history():
    r = _need_login()
    if r: return r
    return html_response(_fill_vars(deposit_history_html, session["uid"]))

@main_bp.route("/withdraw-history")
def withdraw_history():
    r = _need_login()
    if r: return r
    return html_response(_fill_vars(withdraw_history_html, session["uid"]))

@main_bp.route("/support")
@main_bp.route("/service")
def support():
    html = support_html
    uid = session.get("uid")
    if uid:
        html = _fill_vars(html, uid)
    else:
        for k, v in [
            ("{{ balance }}", "0.00"),
            ("{{ uid }}", ""),
            ("{{ member_name }}", "Guest"),
            ("{{ last_login }}", ""),
            ("{{ invite_code }}", ""),
        ]:
            html = html.replace(k, v)
    return html_response(html)

@main_bp.route("/activity")
def activity():
    r = _need_login()
    if r: return r
    return html_response(activity_html)

@main_bp.route("/promotion")
def promotion():
    r = _need_login()
    if r: return r
    inv = ensure_invite_code(session["uid"])
    return html_response(promotion_html.replace("{{ invite_code }}", str(inv)))


# ---- Wallet actions (deposit UTR / withdraw / save bank) ----
@main_bp.route("/submit_utr")
def submit_utr():
    r = _need_login()
    if r: return r
    uid = session["uid"]
    amount = request.args.get("amount", "0")
    utr = request.args.get("utr", "").strip()
    try:
        amt = float(amount)
    except Exception:
        amt = 0
    if len(utr) < 10 or amt < 1:
        return html_response(
            "<script>alert('Invalid UTR or amount');location.href='/deposit';</script>"
        )
    # Pending deposit — balance ONLY after admin approves
    from datetime import datetime as _dt
    pending = session.get("pending_deposits") or []
    order_id = "RC" + _dt.now().strftime("%Y%m%d%H%M%S") + str(uid)[-4:]
    pending.append({
        "id": order_id,
        "amount": amt,
        "utr": utr,
        "status": "Pending",
        "time": _dt.now().strftime("%Y-%m-%d %H:%M:%S"),
        "channel": "UPI-QR",
    })
    session["pending_deposits"] = pending
    # Try DB save if utils supports it
    try:
        from utils import save_pending_deposit
        save_pending_deposit(uid, amt, utr, order_id)
    except Exception:
        pass
    msg = (
        f"Deposit request submitted!\n"
        f"Amount: ₹{amt:.2f}\n"
        f"UTR: {utr}\n"
        f"Status: Pending admin approval\n"
        f"Balance will update after approval."
    )
    return html_response(
        f"<script>alert('{msg}');location.href='/deposit-history';</script>"
    )


@main_bp.route("/request_withdraw", methods=["POST"])
def request_withdraw():
    r = _need_login()
    if r: return r
    amount = request.form.get("amount", "0")
    try:
        amt = float(amount)
    except Exception:
        amt = 0
    if amt < 100:
        return html_response(
            "<script>alert('Minimum withdrawal is ₹100');location.href='/withdraw';</script>"
        )
    bal = get_balance(session["uid"])
    if amt > bal:
        return html_response(
            "<script>alert('Insufficient balance');location.href='/withdraw';</script>"
        )
    # TODO: deduct + create withdraw request in DB
    pending = session.get("pending_withdraws") or []
    pending.append({"amount": amt, "status": "Pending"})
    session["pending_withdraws"] = pending
    return html_response(
        f"<script>alert('Withdraw request of ₹{amt:.2f} submitted');location.href='/withdraw-history';</script>"
    )

@main_bp.route("/save_bank", methods=["POST"])
def save_bank():
    r = _need_login()
    if r: return r
    # Accept UPI or bank fields; store in session for demo
    data = {
        "type": request.form.get("type", "bank"),
        "bank": request.form.get("bank", ""),
        "name": request.form.get("name", ""),
        "account": request.form.get("account", ""),
        "phone": request.form.get("phone", ""),
        "ifsc": request.form.get("ifsc", ""),
        "upi": request.form.get("upi", "") or request.form.get("account", ""),
    }
    session["bound_payment"] = data
    return html_response(
        "<script>alert('Payment method saved');location.href='/withdraw';</script>"
    )

