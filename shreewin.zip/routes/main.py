from flask import Blueprint, session, redirect, url_for, Response, request
from pages.home import home_html
from pages.splash import splash_html
from pages.account import (
    account_html,
    support_html,
    deposit_html,
    withdraw_html,
    add_bank_html,
    deposit_history_html,
    withdraw_history_html,
)
from pages.activity import activity_html
from pages.promotion import promotion_html
from utils import get_balance, ensure_invite_code
import re
from datetime import datetime

main_bp = Blueprint("main", __name__)

def html_response(content: str):
    return Response(content, mimetype="text/html; charset=utf-8")

def _member_name(uid):
    """Official-style name: membervip + digits (not raw phone)."""
    custom = session.get("member_name") or session.get("username") or session.get("name")
    if custom and not str(custom).isdigit() and "@" not in str(custom):
        return str(custom)
    digits = re.sub(r"\D", "", str(uid))[-4:] or "0120"
    try:
        n = int(digits) if digits else 120
    except ValueError:
        n = 120
    suffix = f"{(n * 7 + 13) % 10000:04d}"
    return f"membervip{suffix}"

def _last_login():
    return session.get("last_login") or datetime.now().strftime("%Y-%m-%d %H:%M")

def _fill_vars(html, uid, bal=None):
    if bal is None:
        bal = get_balance(uid)
    inv = ensure_invite_code(uid)
    try:
        from config import UPI_VPA, UPI_NAME, MIN_DEPOSIT, MAX_DEPOSIT
    except Exception:
        UPI_VPA, UPI_NAME, MIN_DEPOSIT, MAX_DEPOSIT = "merchant@upi", "ShreeWin", 100, 50000
    html = html.replace("{{ balance }}", f"{bal:.2f}")
    html = html.replace("{{ invite_code }}", str(inv))
    html = html.replace("{{ uid }}", str(uid))
    html = html.replace("{{ member_name }}", str(_member_name(uid)))
    html = html.replace("{{ last_login }}", str(_last_login()))
    html = html.replace("{{ upi_vpa }}", str(UPI_VPA))
    html = html.replace("{{ upi_name }}", str(UPI_NAME))
    html = html.replace("{{ min_deposit }}", str(int(MIN_DEPOSIT)))
    html = html.replace("{{ max_deposit }}", str(int(MAX_DEPOSIT)))
    try:
        from config import SUPPORT_TELEGRAM
    except Exception:
        SUPPORT_TELEGRAM = "https://t.me/Shreewinofficial01_bot"
    html = html.replace("{{ support_url }}", str(SUPPORT_TELEGRAM))
    return html

def _need_login():
    if not session.get("uid"):
        return redirect(url_for("auth.login"))
    return None

def _render_home():
    html = home_html
    uid = session.get("uid")
    if uid:
        bal = get_balance(uid)
        logged_in = f"""
  <div class="auth-btns" style="gap:8px">
    <a href="/account" class="btn-register" style="max-width:100%;background:linear-gradient(180deg,#2a2150,#1a1435);border:1px solid rgba(124,77,255,.35)">
      ₹{bal:.2f} · Account
    </a>
  </div>
"""
        html = re.sub(
            r"<!--AUTH_SECTION-->.*?<!--/AUTH_SECTION-->",
            logged_in,
            html,
            count=1,
            flags=re.DOTALL,
        )
    return html_response(html)

@main_bp.route("/splash")
def splash():
    return html_response(splash_html)

@main_bp.route("/home")
def home():
    return _render_home()

@main_bp.route("/account")
def account():
    r = _need_login()
    if r: return r
    return html_response(_fill_vars(account_html, session["uid"]))

@main_bp.route("/deposit")
def deposit():
    r = _need_login()
    if r:
        return r
    try:
        return html_response(_fill_vars(deposit_html, session["uid"]))
    except Exception as e:
        return html_response(
            "<h3 style='color:#fff;background:#161239;padding:40px'>Deposit page error: "
            + str(e)[:200]
            + "</h3><a href='/account' style='color:#a78bfa'>Back</a>"
        )


@main_bp.route("/withdraw")
def withdraw():
    r = _need_login()
    if r: return r
    return html_response(_fill_vars(withdraw_html, session["uid"]))

@main_bp.route("/add-bank")
@main_bp.route("/add_bank")
def add_bank():
    r = _need_login()
    if r: return r
    return html_response(_fill_vars(add_bank_html, session["uid"]))


@main_bp.route("/deposit-history")
def deposit_history():
    r = _need_login()
    if r:
        return r
    uid = session["uid"]
    cards_html = ""
    try:
        from database import get_db
        from models import Deposit
        db = get_db()
        try:
            rows = (
                db.query(Deposit)
                .filter_by(uid=str(uid))
                .order_by(Deposit.id.desc())
                .limit(50)
                .all()
            )
        finally:
            db.close()
        for row in rows:
            try:
                amt = float(row.amount or 0)
            except Exception:
                amt = 0.0
            st = (row.status or "Pending").strip()
            st_l = st.lower()
            if st_l in ("approved", "complete", "completed"):
                color, label = "#22c55e", "Complete"
            elif st_l in ("rejected", "failed"):
                color, label = "#ef4444", "Rejected"
            else:
                color, label = "#f59e0b", "Processing"
            cards_html += (
                '<div style="background:#241d4c;border-radius:14px;padding:14px 16px;margin:0 0 12px;color:#fff">'
                '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">'
                '<span style="background:#22c55e;color:#fff;font-size:12px;font-weight:700;padding:4px 10px;border-radius:8px">Deposit</span>'
                '<span style="color:' + color + ';font-weight:700">' + label + '</span></div>'
                '<div style="display:flex;justify-content:space-between;font-size:13px;padding:4px 0;color:#b0a9d8">'
                '<span>Order amount</span><span style="color:#f59e0b;font-weight:700">Rs. ' + ("%.2f" % amt) + '</span></div>'
                '<div style="display:flex;justify-content:space-between;font-size:13px;padding:4px 0;color:#b0a9d8">'
                '<span>UTR</span><span style="color:#fff">' + str(row.utr or "-") + '</span></div>'
                '<div style="display:flex;justify-content:space-between;font-size:13px;padding:4px 0;color:#b0a9d8">'
                '<span>Time</span><span style="color:#fff">' + str(row.time or "") + '</span></div>'
                '<div style="display:flex;justify-content:space-between;font-size:13px;padding:4px 0;color:#b0a9d8">'
                '<span>Status</span><span style="color:' + color + '">' + st + '</span></div></div>'
            )
    except Exception as e:
        cards_html = '<p style="color:#f87171;text-align:center">Error loading history</p>'
        print("history error:", e)

    if not cards_html:
        cards_html = '<p style="text-align:center;color:#9e97d8;padding:40px 16px">No deposit history yet</p>'

    page = (
        "<!DOCTYPE html><html><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1'>"
        "<title>Deposit history</title>"
        "<style>"
        "*{box-sizing:border-box;margin:0;padding:0}"
        "body{background:#161239;min-height:100vh;font-family:system-ui,sans-serif;color:#fff}"
        ".wrap{max-width:400px;margin:0 auto;padding:12px 14px 40px}"
        ".head{display:flex;align-items:center;gap:12px;padding:8px 0 16px}"
        ".back{color:#fff;text-decoration:none;font-size:20px;padding:4px 8px}"
        ".title{flex:1;text-align:center;font-size:18px;font-weight:700;margin-right:28px}"
        "</style></head><body><div class='wrap'>"
        "<div class='head'><a class='back' href='/deposit'>&larr;</a>"
        "<div class='title'>Deposit history</div></div>"
        + cards_html
        + "</div></body></html>"
    )
    return html_response(page)


@main_bp.route("/withdraw-history")
def withdraw_history():
    r = _need_login()
    if r: return r
    return html_response(_fill_vars(withdraw_history_html, session["uid"]))

@main_bp.route("/support")
@main_bp.route("/service")
def support():
    html = support_html
    uid = session.get("uid")
    if uid:
        html = _fill_vars(html, uid)
    else:
        try:
            from config import SUPPORT_TELEGRAM
        except Exception:
            SUPPORT_TELEGRAM = "https://t.me/Shreewinofficial01_bot"
        for k, v in [
            ("{{ balance }}", "0.00"),
            ("{{ uid }}", ""),
            ("{{ member_name }}", "Guest"),
            ("{{ last_login }}", ""),
            ("{{ invite_code }}", ""),
            ("{{ support_url }}", str(SUPPORT_TELEGRAM)),
        ]:
            html = html.replace(k, v)
    return html_response(html)

@main_bp.route("/activity")
def activity():
    r = _need_login()
    if r: return r
    return html_response(activity_html)

@main_bp.route("/promotion")
def promotion():
    r = _need_login()
    if r: return r
    inv = ensure_invite_code(session["uid"])
    return html_response(promotion_html.replace("{{ invite_code }}", str(inv)))


# ---- Wallet actions (deposit UTR / withdraw / save bank) ----

@main_bp.route("/submit_utr")
def submit_utr():
    """Save deposit as Pending. Balance added only after admin approves."""
    r = _need_login()
    if r:
        return r
    uid = session["uid"]
    amount = request.args.get("amount", "0")
    utr = (request.args.get("utr", "") or "").strip().replace(" ", "")
    try:
        amt = float(amount)
    except Exception:
        amt = 0.0

    try:
        from config import MIN_DEPOSIT, MAX_DEPOSIT
    except Exception:
        MIN_DEPOSIT, MAX_DEPOSIT = 100.0, 50000.0

    def _redir(msg, to="/deposit"):
        safe = str(msg).replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"')
        safe = safe.replace("\r", "").replace("\n", "\\n")
        html = (
            "<!DOCTYPE html><html><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width,initial-scale=1'></head>"
            "<body style='background:#161239;color:#fff;font-family:sans-serif;"
            "display:flex;align-items:center;justify-content:center;min-height:100vh'>"
            "<p>Please wait...</p>"
            "<script>alert('" + safe + "');location.replace('" + to + "');</script>"
            "</body></html>"
        )
        return html_response(html)

    if len(utr) < 10 or len(utr) > 22:
        return _redir("Please enter a valid UTR (10-22 digits)", "/deposit")
    if amt < MIN_DEPOSIT:
        return _redir("Minimum deposit is Rs.%.0f" % MIN_DEPOSIT, "/deposit")
    if amt > MAX_DEPOSIT:
        return _redir("Maximum deposit is Rs.%.0f" % MAX_DEPOSIT, "/deposit")

    from datetime import datetime as _dt
    from database import get_db
    from models import Deposit

    db = get_db()
    order_id = "RC" + _dt.now().strftime("%Y%m%d%H%M%S") + str(uid)[-4:]
    now_str = _dt.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        exists = db.query(Deposit).filter_by(utr=utr).first()
        if exists:
            return _redir("This UTR is already submitted", "/deposit")
        row = Deposit(
            uid=str(uid),
            amount=str(amt),
            utr=utr,
            status="Pending",
            time=now_str,
        )
        db.add(row)
        db.commit()
    except Exception as e:
        try:
            db.rollback()
        except Exception:
            pass
        return _redir("Deposit error: " + str(e)[:80], "/deposit")
    finally:
        try:
            db.close()
        except Exception:
            pass

    pending = session.get("pending_deposits") or []
    pending.insert(0, {
        "id": order_id,
        "amount": amt,
        "utr": utr,
        "status": "Pending",
        "time": now_str,
        "channel": "UPI-QR",
    })
    session["pending_deposits"] = pending[:50]

    return _redir(
        "Deposit submitted! Amount: Rs.%.2f UTR: %s Status: Pending" % (amt, utr),
        "/deposit-history",
    )


@main_bp.route("/request_withdraw", methods=["POST"])
def request_withdraw():
    """Hold balance immediately; admin approve/reject later."""
    r = _need_login()
    if r:
        return r
    uid = session["uid"]
    amount = request.form.get("amount", "0")
    try:
        amt = float(amount)
    except Exception:
        amt = 0.0
    if amt < 100:
        return html_response(
            "<script>alert('Minimum withdrawal is ₹100');location.href='/withdraw';</script>"
        )
    bal = get_balance(uid)
    if amt > bal:
        return html_response(
            "<script>alert('Insufficient balance');location.href='/withdraw';</script>"
        )

    from datetime import datetime as _dt
    from database import get_db
    from models import Withdrawal
    from utils import add_balance

    # Hold funds now so user cannot spend the same money twice
    new_bal = add_balance(uid, -amt)
    if new_bal is None:
        return html_response(
            "<script>alert('User not found');location.href='/withdraw';</script>"
        )

    bound = session.get("bound_payment") or {}
    method = bound.get("type") or ("UPI" if bound.get("upi") else "BANK")
    account_info = bound.get("upi") or bound.get("account") or ""
    now_str = _dt.now().strftime("%Y-%m-%d %H:%M:%S")

    db = get_db()
    try:
        row = Withdrawal(
            uid=str(uid),
            amount=float(amt),
            method=str(method),
            account_info=str(account_info),
            status="Pending",
            time=now_str,
        )
        db.add(row)
        db.commit()
    except Exception as e:
        try:
            db.rollback()
        except Exception:
            pass
        # refund hold if DB save failed
        add_balance(uid, amt)
        return html_response(
            f"<script>alert('Withdraw error: {str(e)[:80]}');location.href='/withdraw';</script>"
        )
    finally:
        try:
            db.close()
        except Exception:
            pass

    pending = session.get("pending_withdraws") or []
    pending.insert(0, {"amount": amt, "status": "Pending", "time": now_str})
    session["pending_withdraws"] = pending[:50]

    return html_response(
        f"<script>alert('Withdraw request of ₹{amt:.2f} submitted. Status: Pending');location.href='/withdraw-history';</script>"
    )

@main_bp.route("/save_bank", methods=["POST"])
def save_bank():
    r = _need_login()
    if r: return r
    # Accept UPI or bank fields; store in session for demo
    data = {
        "type": request.form.get("type", "bank"),
        "bank": request.form.get("bank", ""),
        "name": request.form.get("name", ""),
        "account": request.form.get("account", ""),
        "phone": request.form.get("phone", ""),
        "ifsc": request.form.get("ifsc", ""),
        "upi": request.form.get("upi", "") or request.form.get("account", ""),
    }
    session["bound_payment"] = data
    return html_response(
        "<script>alert('Payment method saved');location.href='/withdraw';</script>"
    )

