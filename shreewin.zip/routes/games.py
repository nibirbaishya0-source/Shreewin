from flask import Blueprint, session, redirect, url_for, Response, request, jsonify
from pages.game_5d import html_5d
from pages.game_k3 import html_k3
from pages.game_javelin import html_javelin
from pages.game_limbo import html_limbo
from pages.game_mines import html_mines
from pages.game_spinwheel import html_spinwheel
from pages.game_aviator import html_aviator
from pages.game_wingo import render_wingo
from utils import get_balance
from datetime import datetime, timezone

games_bp = Blueprint("games", __name__)

def _need_login():
    if not session.get("uid"):
        return redirect(url_for("auth.login"))
    return None

# TypeId mapping for official live API
WINGO_TYPE = {
    "30sec": 30,
    "1min": 1,
    "3min": 2,
    "5min": 3,
}



@games_bp.route("/api/wingo/live")
def wingo_live():
    """Proxy official WinGo results. Normalized list always in data[] when available."""
    mode = request.args.get("mode", "30sec")
    # Official TypeId map (verified live)
    type_map = {"30sec": 30, "1min": 1, "3min": 2, "5min": 3}
    type_id = type_map.get(mode, 30)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    import json as _json
    from urllib.request import Request, urlopen

    errors = []

    def _post_primary(tid, day):
        body = _json.dumps({
            "PageIndex": 1,
            "PageSize": 40,
            "Time": day,
            "TypeId": tid,
        }).encode()
        req = Request(
            "https://lotteryresultapi.22889.club/api/GetWinResult",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            },
            method="POST",
        )
        with urlopen(req, timeout=10) as resp:
            return _json.loads(resp.read().decode("utf-8", "replace"))

    # Try today, then yesterday; try primary TypeId then close alternates
    try_ids = [type_id]
    for alt in (1, 30, 2, 3):
        if alt not in try_ids:
            try_ids.append(alt)

    from datetime import timedelta
    days = [today]
    try:
        yday = (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%d")
        days.append(yday)
    except Exception:
        pass

    for day in days:
        for tid in try_ids:
            try:
                data = _post_primary(tid, day)
                rows = data.get("data") if isinstance(data, dict) else None
                if rows is None and isinstance(data, dict):
                    rows = data.get("Data") or data.get("list") or data.get("result")
                if isinstance(rows, list) and len(rows) > 0:
                    # Normalize field names for frontend
                    norm = []
                    for item in rows:
                        if not isinstance(item, dict):
                            continue
                        issue = str(item.get("issueNumber") or item.get("issue") or item.get("period") or "")
                        num = item.get("number")
                        if num is None:
                            num = item.get("num")
                        try:
                            num = int(num)
                        except Exception:
                            continue
                        colour = item.get("colour") or item.get("color") or ""
                        norm.append({
                            "issueNumber": issue,
                            "number": num,
                            "colour": colour,
                            "typeID": item.get("typeID") or tid,
                        })
                    if norm:
                        return jsonify({
                            "ok": True,
                            "mode": mode,
                            "typeId": tid,
                            "totalCount": len(norm),
                            "data": norm,
                        })
            except Exception as e:
                errors.append("%s/tid%s: %s" % (day, tid, str(e)[:80]))

    return jsonify({
        "ok": False,
        "error": "WinGo API unavailable",
        "details": errors[:8],
        "data": [],
    }), 502


@games_bp.route("/motorace")
@games_bp.route("/wingo")
@games_bp.route("/wingo/<mode>")
def game_wingo(mode="30sec"):
    r = _need_login()
    if r:
        return r
    uid = session.get("uid")
    bal = get_balance(uid)
    return Response(render_wingo(mode, bal), mimetype="text/html; charset=utf-8")

@games_bp.route("/5d")
def game_5d():
    r = _need_login()
    return r if r else Response(html_5d, mimetype="text/html; charset=utf-8")

@games_bp.route("/k3")
def game_k3():
    r = _need_login()
    return r if r else Response(html_k3, mimetype="text/html; charset=utf-8")

@games_bp.route("/javelin")
def game_javelin():
    r = _need_login()
    return r if r else Response(html_javelin, mimetype="text/html; charset=utf-8")

@games_bp.route("/limbo")
def game_limbo():
    r = _need_login()
    return r if r else Response(html_limbo, mimetype="text/html; charset=utf-8")

@games_bp.route("/mines")
@games_bp.route("/boom")
def game_mines():
    r = _need_login()
    return r if r else Response(html_mines, mimetype="text/html; charset=utf-8")

@games_bp.route("/spinwheel")
@games_bp.route("/spin")
def game_spinwheel():
    r = _need_login()
    return r if r else Response(html_spinwheel, mimetype="text/html; charset=utf-8")

@games_bp.route("/aviator")
def game_aviator():
    r = _need_login()
    return r if r else Response(html_aviator, mimetype="text/html; charset=utf-8")
