from flask import Blueprint, session, redirect, url_for, Response, request, jsonify
from pages.game_5d import html_5d
from pages.game_k3 import html_k3
from pages.game_javelin import html_javelin
from pages.game_limbo import html_limbo
from pages.game_mines import html_mines
from pages.game_spinwheel import html_spinwheel
from pages.game_aviator import html_aviator
from pages.game_wingo import render_wingo
from utils import get_balance
from datetime import datetime, timezone

games_bp = Blueprint("games", __name__)

def _need_login():
    if not session.get("uid"):
        return redirect(url_for("auth.login"))
    return None

# TypeId mapping for official live API
WINGO_TYPE = {
    "30sec": 30,
    "1min": 1,
    "3min": 2,
    "5min": 3,
}




@games_bp.route("/api/wingo/live")
def wingo_live():
    """Proxy official WinGo results. Uses IST calendar date (API day boundary)."""
    mode = request.args.get("mode", "30sec")
    type_map = {"30sec": 30, "1min": 1, "3min": 2, "5min": 3}
    type_id = type_map.get(mode, 30)

    from datetime import datetime, timezone, timedelta
    import json as _json
    from urllib.request import Request, urlopen

    # Official lottery day = Asia/Kolkata
    ist_now = datetime.now(timezone.utc) + timedelta(hours=5, minutes=30)
    days = [ist_now.strftime("%Y-%m-%d")]
    try:
        days.append((ist_now - timedelta(days=1)).strftime("%Y-%m-%d"))
    except Exception:
        pass

    errors = []

    def _post(tid, day):
        body = _json.dumps({
            "PageIndex": 1,
            "PageSize": 50,
            "Time": day,
            "TypeId": tid,
        }).encode()
        req = Request(
            "https://lotteryresultapi.22889.club/api/GetWinResult",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            },
            method="POST",
        )
        with urlopen(req, timeout=10) as resp:
            return _json.loads(resp.read().decode("utf-8", "replace"))

    best_rows = []
    used_tid = type_id
    for day in days:
        for tid in [type_id]:
            try:
                data = _post(tid, day)
                rows = data.get("data") if isinstance(data, dict) else None
                if not isinstance(rows, list) or not rows:
                    continue
                # Prefer day that has a live (state=0) or recent numbered results
                has_live = any(str(r.get("state", "")) in ("0", "0.0") or r.get("number") in ("", None) for r in rows[:3])
                has_nums = any(str(r.get("number") or "").strip() != "" for r in rows)
                if has_live or has_nums:
                    best_rows = rows
                    used_tid = tid
                    if has_live:
                        break
            except Exception as e:
                errors.append("%s/tid%s: %s" % (day, tid, str(e)[:80]))
        if best_rows and any(str(r.get("state", "")) in ("0", "0.0") for r in best_rows[:5]):
            break

    if not best_rows:
        return jsonify({"ok": False, "error": "WinGo API unavailable", "details": errors[:8], "data": []}), 502

    norm = []
    current = None
    for item in best_rows:
        if not isinstance(item, dict):
            continue
        issue = str(item.get("issueNumber") or item.get("issue") or item.get("period") or "")
        raw_num = item.get("number")
        if raw_num is None:
            raw_num = item.get("num")
        num = None
        try:
            if raw_num is not None and str(raw_num).strip() != "":
                num = int(raw_num)
        except Exception:
            num = None
        state = item.get("state")
        try:
            state_i = int(state) if state is not None else 1
        except Exception:
            state_i = 1
        row = {
            "issueNumber": issue,
            "number": num,
            "colour": item.get("colour") or item.get("color") or "",
            "typeID": item.get("typeID") or used_tid,
            "state": state_i,
            "startTime": item.get("startTime"),
            "endTime": item.get("endTime"),
            "expireSeconds": item.get("expireSeconds"),
        }
        norm.append(row)
        # First live (open) issue
        if current is None and state_i == 0:
            current = row

    return jsonify({
        "ok": True,
        "mode": mode,
        "typeId": used_tid,
        "data": norm,
        "current": current,
        "serverTimeIst": ist_now.strftime("%Y-%m-%d %H:%M:%S"),
        "totalCount": len(norm),
    })


@games_bp.route("/motorace")
@games_bp.route("/wingo")
@games_bp.route("/wingo/<mode>")
def game_wingo(mode="30sec"):
    r = _need_login()
    if r:
        return r
    uid = session.get("uid")
    bal = get_balance(uid)
    return Response(render_wingo(mode, bal), mimetype="text/html; charset=utf-8")

@games_bp.route("/5d")
def game_5d():
    r = _need_login()
    return r if r else Response(html_5d, mimetype="text/html; charset=utf-8")

@games_bp.route("/k3")
def game_k3():
    r = _need_login()
    return r if r else Response(html_k3, mimetype="text/html; charset=utf-8")

@games_bp.route("/javelin")
def game_javelin():
    r = _need_login()
    return r if r else Response(html_javelin, mimetype="text/html; charset=utf-8")

@games_bp.route("/limbo")
def game_limbo():
    r = _need_login()
    return r if r else Response(html_limbo, mimetype="text/html; charset=utf-8")

@games_bp.route("/mines")
@games_bp.route("/boom")
def game_mines():
    r = _need_login()
    return r if r else Response(html_mines, mimetype="text/html; charset=utf-8")

@games_bp.route("/spinwheel")
@games_bp.route("/spin")
def game_spinwheel():
    r = _need_login()
    return r if r else Response(html_spinwheel, mimetype="text/html; charset=utf-8")

@games_bp.route("/aviator")
def game_aviator():
    r = _need_login()
    return r if r else Response(html_aviator, mimetype="text/html; charset=utf-8")
