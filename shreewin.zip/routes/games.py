from flask import Blueprint, session, redirect, url_for, Response, request, jsonify
from pages.game_5d import html_5d
from pages.game_k3 import html_k3
from pages.game_javelin import html_javelin
from pages.game_limbo import html_limbo
from pages.game_mines import html_mines
from pages.game_spinwheel import html_spinwheel
from pages.game_aviator import html_aviator
from pages.game_wingo import render_wingo
from utils import get_balance
from datetime import datetime, timezone

games_bp = Blueprint("games", __name__)

def _need_login():
    if not session.get("uid"):
        return redirect(url_for("auth.login"))
    return None

# TypeId mapping for official live API
WINGO_TYPE = {
    "30sec": 30,
    "1min": 1,
    "3min": 2,
    "5min": 3,
}

@games_bp.route("/api/wingo/live")
def wingo_live():
    """Server-side WinGo result proxy with two upstream sources.

    The browser always receives the upstream JSON; the frontend decides which
    records are completed and renders the exact API issue/result pair.
    """
    mode = request.args.get("mode", "30sec")
    type_id = WINGO_TYPE.get(mode, 30)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    import json as _json
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode

    errors = []

    # Source 1: JSON POST API used by the existing backend.
    try:
        body = _json.dumps({
            "PageIndex": 1,
            "PageSize": 30,
            "Time": today,
            "TypeId": type_id,
        }).encode()
        req = Request(
            "https://lotteryresultapi.22889.club/api/GetWinResult",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "Mozilla/5.0",
            },
            method="POST",
        )
        with urlopen(req, timeout=8) as resp:
            raw = resp.read().decode("utf-8", "replace")
            data = _json.loads(raw)
        return jsonify(data)
    except Exception as e:
        errors.append("primary: " + str(e))

    # Source 2: WinGo draw-history JSON endpoint.  This is a fallback only;
    # no result is generated locally.
    draw_urls = {
        "30sec": "https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json",
        "1min": "https://draw.ar-lottery01.com/WinGo/WinGo_1M/GetHistoryIssuePage.json",
        "3min": "https://draw.ar-lottery01.com/WinGo/WinGo_3M/GetHistoryIssuePage.json",
        "5min": "https://draw.ar-lottery01.com/WinGo/WinGo_5M/GetHistoryIssuePage.json",
    }
    try:
        url = draw_urls.get(mode, draw_urls["30sec"]) + "?" + urlencode({"ts": int(datetime.now(timezone.utc).timestamp() * 1000)})
        req = Request(url, headers={"Accept": "application/json", "User-Agent": "Mozilla/5.0"})
        with urlopen(req, timeout=8) as resp:
            raw = resp.read().decode("utf-8", "replace")
            data = _json.loads(raw)
        return jsonify(data)
    except Exception as e:
        errors.append("fallback: " + str(e))

    return jsonify({"ok": False, "error": "WinGo API unavailable", "details": errors, "data": []}), 502


@games_bp.route("/motorace")
@games_bp.route("/wingo")
@games_bp.route("/wingo/<mode>")
def game_wingo(mode="30sec"):
    r = _need_login()
    if r:
        return r
    uid = session.get("uid")
    bal = get_balance(uid)
    return Response(render_wingo(mode, bal), mimetype="text/html; charset=utf-8")

@games_bp.route("/5d")
def game_5d():
    r = _need_login()
    return r if r else Response(html_5d, mimetype="text/html; charset=utf-8")

@games_bp.route("/k3")
def game_k3():
    r = _need_login()
    return r if r else Response(html_k3, mimetype="text/html; charset=utf-8")

@games_bp.route("/javelin")
def game_javelin():
    r = _need_login()
    return r if r else Response(html_javelin, mimetype="text/html; charset=utf-8")

@games_bp.route("/limbo")
def game_limbo():
    r = _need_login()
    return r if r else Response(html_limbo, mimetype="text/html; charset=utf-8")

@games_bp.route("/mines")
@games_bp.route("/boom")
def game_mines():
    r = _need_login()
    return r if r else Response(html_mines, mimetype="text/html; charset=utf-8")

@games_bp.route("/spinwheel")
@games_bp.route("/spin")
def game_spinwheel():
    r = _need_login()
    return r if r else Response(html_spinwheel, mimetype="text/html; charset=utf-8")

@games_bp.route("/aviator")
def game_aviator():
    r = _need_login()
    return r if r else Response(html_aviator, mimetype="text/html; charset=utf-8")
