from datetime import datetime
import random
from database import get_db
from models import User

REFERRAL_BONUS = 5.0

def generate_uid(phone=None):
    db = get_db()
    try:
        for _ in range(60):
            uid = f"{random.randint(100000, 999999)}"
            if not db.query(User).filter_by(uid=str(uid)).first():
                return str(uid)
        return str(int(datetime.now().timestamp()))[-6:]
    finally:
        db.close()

def generate_invite_code():
    db = get_db()
    try:
        for _ in range(60):
            code = f"{random.randint(10**10, 10**11 - 1)}"
            if not db.query(User).filter_by(invite_code=str(code)).first():
                if not db.query(User).filter_by(uid=str(code)).first():
                    return str(code)
        return str(int(datetime.now().timestamp() * 1000))[-11:].ljust(11, "0")
    finally:
        db.close()

def ensure_invite_code(uid):
    db = get_db()
    try:
        u = db.query(User).filter_by(uid=str(uid)).first()
        if not u:
            return str(uid)
        if u.invite_code and len(str(u.invite_code)) >= 10:
            return str(u.invite_code)
        code = generate_invite_code()
        u.invite_code = code
        db.commit()
        return code
    except Exception:
        try:
            db.rollback()
        except Exception:
            pass
        return str(uid)
    finally:
        try:
            db.close()
        except Exception:
            pass

def get_user_by_phone(phone):
    db = get_db()
    try:
        return db.query(User).filter_by(phone=str(phone)).first()
    finally:
        db.close()

def get_user_by_uid(uid):
    db = get_db()
    try:
        return db.query(User).filter_by(uid=str(uid)).first()
    finally:
        db.close()

def get_balance(uid):
    u = get_user_by_uid(uid)
    return float(u.balance or 0) if u else 0.0

def set_balance(uid, amount):
    db = get_db()
    try:
        u = db.query(User).filter_by(uid=str(uid)).first()
        if u:
            u.balance = round(float(amount), 2)
            db.commit()
            return u.balance
        return None
    finally:
        db.close()

def add_balance(uid, amount):
    db = get_db()
    try:
        u = db.query(User).filter_by(uid=str(uid)).first()
        if u:
            u.balance = round(float(u.balance or 0) + float(amount), 2)
            db.commit()
            return u.balance
        return None
    finally:
        db.close()
