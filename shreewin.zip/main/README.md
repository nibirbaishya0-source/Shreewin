================================================================================
SHREEWIN - MODULAR PROJECT STRUCTURE
================================================================================

FOLDER STRUCTURE
----------------
shreewin/
├── app.py                 # Main entry point (run this)
├── config.py              # Settings, secrets, DB URL
├── database.py            # SQLAlchemy engine + session
├── models.py              # All DB tables (User, Deposit, etc.)
├── utils.py               # Helpers (UID, invite, balance)
├── requirements.txt
├── routes/
│   ├── __init__.py        # Registers all blueprints
│   ├── auth.py            # Register / Login / Logout
│   ├── main.py            # Home / Account
│   ├── games.py           # 5D, K3, Mines, Aviator, Spin...
│   ├── wallet.py          # Balance APIs
│   └── admin.py           # Admin panel + approve/reject
├── pages/
│   ├── register.py        # Register HTML
│   ├── login.py           # Login HTML
│   ├── home.py            # Home HTML
│   ├── account.py         # Account HTML
│   ├── admin.py           # Admin HTML
│   ├── game_5d.py
│   ├── game_k3.py
│   ├── game_mines.py
│   ├── game_aviator.py
│   ├── game_spinwheel.py
│   ├── game_limbo.py
│   └── game_javelin.py
├── templates/             # (future Jinja templates)
└── static/
    ├── css/
    ├── js/
    └── img/

HOW TO RUN
----------
1. cd shreewin
2. pip install -r requirements.txt
3. python app.py
4. Open http://127.0.0.1:5000

WHAT WAS SPLIT
--------------
- Old single flask_app.py (3.7MB) broken into clean modules
- Models separate
- Routes by feature (auth, games, wallet, admin)
- HTML pages each in own file under pages/
- Config centralised

NEXT IMPROVEMENTS
-----------------
- Move more deposit/withdraw UI routes into wallet.py
- Convert pages/*.py HTML into real templates/*.html
- Add more admin APIs
- Add Win Go game page

================================================================================
