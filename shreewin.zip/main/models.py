from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Text, Boolean
from database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    phone = Column(String(20), unique=True, nullable=False, index=True)
    password = Column(String(128), nullable=False)
    uid = Column(String(20), unique=True, nullable=False, index=True)
    invite_code = Column(String(20), unique=True, nullable=True, index=True)  # 11-digit invitation code
    member_name = Column(String(50), default="")
    balance = Column(Float, default=0.0)
    referred_by = Column(String(20), nullable=True)  # stores referrer's uid
    created_at = Column(DateTime, default=datetime.now)

class Deposit(Base):
    __tablename__ = "deposits"
    id = Column(Integer, primary_key=True)
    uid = Column(String(20), index=True, nullable=False)
    amount = Column(String(20), nullable=False)
    utr = Column(String(50), nullable=False)
    status = Column(String(20), default="Processing")  # Processing / Approved / Rejected
    time = Column(String(30), default="")
    created_at = Column(DateTime, default=datetime.now)

class Withdrawal(Base):
    __tablename__ = "withdrawals"
    id = Column(Integer, primary_key=True)
    uid = Column(String(20), index=True, nullable=False)
    amount = Column(Float, nullable=False)
    method = Column(String(30), default="")
    account_info = Column(Text, default="")
    status = Column(String(20), default="Pending")  # Pending / Approved / Rejected
    time = Column(String(30), default="")
    created_at = Column(DateTime, default=datetime.now)

class BankAccount(Base):
    __tablename__ = "bank_accounts"
    id = Column(Integer, primary_key=True)
    uid = Column(String(20), index=True, nullable=False)
    bank_name = Column(String(100), default="")
    account_number = Column(String(50), default="")
    ifsc = Column(String(30), default="")
    holder_name = Column(String(100), default="")
    upi_id = Column(String(100), default="")
    created_at = Column(DateTime, default=datetime.now)

class SupportMessage(Base):
    __tablename__ = "support_messages"
    id = Column(Integer, primary_key=True)
    msg_id = Column(String(30), unique=True, nullable=False)
    uid = Column(String(20), index=True, nullable=False)
    member = Column(String(50), default="")
    message = Column(Text, default="")
    reply = Column(Text, default="")
    status = Column(String(20), default="New")  # New / Replied
    time = Column(String(30), default="")
    created_at = Column(DateTime, default=datetime.now)

class Referral(Base):
    __tablename__ = "referrals"
    id = Column(Integer, primary_key=True)
    referrer_uid = Column(String(20), index=True, nullable=False)
    referred_uid = Column(String(20), nullable=False)
    referred_phone = Column(String(20), default="")
    bonus_given = Column(Boolean, default=False)
    time = Column(String(30), default="")
    created_at = Column(DateTime, default=datetime.now)


class GiftCode(Base):
    __tablename__ = "gift_codes"
    id = Column(Integer, primary_key=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    amount = Column(Float, default=0.0)
    max_uses = Column(Integer, default=1)  # how many users can claim
    used_count = Column(Integer, default=0)
    active = Column(Boolean, default=True)
    min_deposit = Column(Float, default=0.0)  # min total approved deposits required
    min_turnover = Column(Float, default=0.0)  # reserved for future
    created_at = Column(DateTime, default=datetime.now)

class GiftClaim(Base):
    __tablename__ = "gift_claims"
    id = Column(Integer, primary_key=True)
    uid = Column(String(20), index=True, nullable=False)
    code = Column(String(50), index=True, nullable=False)
    amount = Column(Float, default=0.0)
    time = Column(String(30), default="")
    created_at = Column(DateTime, default=datetime.now)

class TransactionLog(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True)
    uid = Column(String(20), index=True, nullable=False)
    type = Column(String(30), default="")  # deposit / withdraw / bonus / game
    amount = Column(Float, default=0.0)
    balance_after = Column(Float, default=0.0)
    note = Column(String(200), default="")
    time = Column(String(30), default="")
    created_at = Column(DateTime, default=datetime.now)
