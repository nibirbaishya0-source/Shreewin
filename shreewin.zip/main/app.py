"""
ShreeWin - Modular Flask Application
Run: python app.py
"""
from flask import Flask
from config import SECRET_KEY
from database import init_db

def create_app():
    app = Flask(__name__)
    app.secret_key = SECRET_KEY
    app.config["JSON_AS_ASCII"] = False

    @app.after_request
    def _force_utf8(resp):
        if resp.content_type and "text/html" in resp.content_type:
            resp.headers["Content-Type"] = "text/html; charset=utf-8"
        return resp

    # Init DB
    init_db()

    # Register blueprints
    from routes import register_blueprints
    register_blueprints(app)

    return app


app = create_app()

if __name__ == "__main__":
    print("Open → http://127.0.0.1:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)
