from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker, scoped_session
from config import DATABASE_URL

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
)
Base = declarative_base()
SessionLocal = scoped_session(
    sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)
)

def get_db():
    return SessionLocal()

def init_db():
    from models import User, Deposit, Withdrawal, BankAccount, SupportMessage, Referral, GiftCode, GiftClaim, TransactionLog
    Base.metadata.create_all(engine)
