import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

SECRET_KEY = os.environ.get("SECRET_KEY", "shreewin_secret_key_123")
ADMIN_SECRET = os.environ.get("ADMIN_SECRET", "shreewin_admin_2024")

DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    f"sqlite:///{os.path.join(BASE_DIR, 'shreewin.db')}"
)

REFERRAL_BONUS = float(os.environ.get("REFERRAL_BONUS", "5.0"))

# ---- UPI Deposit (set these on Render Environment) ----
# Example: merchant@okaxis  /  yourname@paytm
UPI_VPA = os.environ.get("UPI_VPA", "jatinbaishya260@okhdfcbank")
UPI_NAME = os.environ.get("UPI_NAME", "ShreeWin")
MIN_DEPOSIT = float(os.environ.get("MIN_DEPOSIT", "100"))
MAX_DEPOSIT = float(os.environ.get("MAX_DEPOSIT", "50000"))

# Customer support (Telegram bot)
SUPPORT_TELEGRAM = os.environ.get("SUPPORT_TELEGRAM", "https://t.me/Shreewinofficial01_bot")
