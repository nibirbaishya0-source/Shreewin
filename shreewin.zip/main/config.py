import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

SECRET_KEY = os.environ.get("SECRET_KEY", "shreewin_secret_key_123")
ADMIN_SECRET = os.environ.get("ADMIN_SECRET", "shreewin_admin_2024")

DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    f"sqlite:///{os.path.join(BASE_DIR, 'shreewin.db')}"
)

REFERRAL_BONUS = 5.0
