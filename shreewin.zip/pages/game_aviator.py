html_aviator = r'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Aviator - Spribe Official Replica</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            user-select: none;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #0b0e11;
            color: #ffffff;
            display: flex;
            justify-content: center;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Mobile Wrapper */
        .app-wrapper {
            width: 100%;
            max-width: 480px;
            min-height: 100vh;
            background: #0d1013;
            display: flex;
            flex-direction: column;
            position: relative;
            box-shadow: 0 0 40px rgba(0,0,0,0.9);
        }

        /* 1. Top App Bar */
        .casino-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 12px;
            background: #121519;
            border-bottom: 1px solid #1a1e24;
        }
        .header-left, .header-right {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .back-arrow {
            font-size: 18px;
            color: #aaa;
            cursor: pointer;
        }
        .balance-pill {
            background: #1b2838;
            border: 1px solid #233b5d;
            border-radius: 20px;
            display: flex;
            align-items: center;
            padding: 3px 10px 3px 4px;
            gap: 6px;
            cursor: pointer;
        }
        .coin-icon {
            width: 22px;
            height: 22px;
            background: radial-gradient(circle, #ffd700 0%, #ff8800 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 900;
            color: #593300;
            font-size: 12px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.4);
        }
        .balance-text {
            color: #ffffff;
            font-size: 14px;
            font-weight: 700;
        }
        .btn-add {
            width: 28px;
            height: 28px;
            background: #252b33;
            border-radius: 50%;
            border: none;
            color: #4a90e2;
            font-size: 18px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform 0.1s;
        }
        .btn-add:active {
            transform: scale(0.9);
        }
        .user-globe {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: radial-gradient(circle, #38ef7d 0%, #11998e 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            cursor: pointer;
        }

        /* 2. Aviator Game Bar */
        .aviator-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 14px;
            background: #0d1013;
        }
        .aviator-logo {
            color: #e51b24;
            font-size: 22px;
            font-weight: 900;
            font-style: italic;
            letter-spacing: 0.5px;
        }
        .nav-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .currency-balance {
            color: #28a745;
            font-weight: 700;
            font-size: 13px;
        }
        .currency-balance span {
            color: #7d8b99;
            font-size: 11px;
            margin-left: 2px;
        }
        .menu-btn {
            color: #7d8b99;
            font-size: 20px;
            cursor: pointer;
        }

        /* 3. Multiplier History Bar */
        .history-row {
            display: flex;
            align-items: center;
            padding: 4px 10px;
            background: #0a0c0e;
            border-bottom: 1px solid #161a20;
            overflow: hidden;
            position: relative;
        }
        .history-chips {
            display: flex;
            gap: 6px;
            overflow-x: auto;
            scrollbar-width: none;
            flex: 1;
            padding-right: 30px;
        }
        .history-chips::-webkit-scrollbar {
            display: none;
        }
        .chip {
            font-size: 11px;
            padding: 2px 7px;
            border-radius: 12px;
            font-weight: 800;
            white-space: nowrap;
        }
        .chip-blue { color: #3b99fc; background: rgba(59, 153, 252, 0.12); }
        .chip-purple { color: #9c60ff; background: rgba(156, 96, 255, 0.14); }
        .chip-pink { color: #ff3b69; background: rgba(255, 59, 105, 0.15); }
        .history-more {
            position: absolute;
            right: 8px;
            width: 24px;
            height: 20px;
            background: #161a20;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            color: #778494;
            cursor: pointer;
        }

        /* 4. Game Canvas Stage */
        .stage-box {
            position: relative;
            width: 100%;
            height: 220px;
            background: radial-gradient(circle at 50% 50%, #161b22 0%, #090a0d 100%);
            overflow: hidden;
            border-bottom: 2px solid #000;
        }
        canvas {
            width: 100%;
            height: 100%;
            display: block;
        }
        .watermark-ufc {
            position: absolute;
            top: 25px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            flex-direction: column;
            align-items: center;
            opacity: 0.15;
            pointer-events: none;
        }
        .watermark-ufc .ufc-text {
            font-size: 32px;
            font-weight: 900;
            letter-spacing: 2px;
            color: #fff;
        }
        .watermark-ufc .partner-text {
            font-size: 8px;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: #fff;
        }
        .spribe-badge {
            position: absolute;
            top: 85px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(18, 22, 28, 0.85);
            border: 1px solid #29323d;
            border-radius: 8px;
            padding: 4px 14px;
            display: flex;
            flex-direction: column;
            align-items: center;
            pointer-events: none;
            opacity: 0.35;
        }
        .spribe-badge span:first-child {
            font-size: 11px;
            font-weight: 800;
            color: #ccc;
            letter-spacing: 1px;
        }
        .spribe-badge span:last-child {
            font-size: 8px;
            color: #28a745;
            font-weight: bold;
        }

        /* Multiplier Overlay */
        .multiplier-overlay {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 48px;
            font-weight: 900;
            color: #ffffff;
            text-shadow: 0 0 20px rgba(255,255,255,0.2);
            text-align: center;
            z-index: 5;
        }
        .waiting-text {
            font-size: 13px;
            color: #798696;
            font-weight: 700;
            letter-spacing: 1px;
            margin-top: 6px;
        }
        .waiting-progress-bar {
            width: 140px;
            height: 4px;
            background: #202731;
            border-radius: 4px;
            margin: 6px auto 0 auto;
            overflow: hidden;
        }
        .waiting-fill {
            height: 100%;
            background: #e51b24;
            width: 0%;
            transition: width 0.05s linear;
        }
        .crash-state {
            color: #e51b24 !important;
            font-size: 20px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }

        .live-count-pill {
            position: absolute;
            bottom: 8px;
            right: 10px;
            background: rgba(14, 18, 24, 0.8);
            border: 1px solid #232a34;
            border-radius: 12px;
            padding: 2px 8px;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 11px;
            color: #94a3b8;
            font-weight: bold;
        }
        .live-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: #28a745;
            box-shadow: 0 0 6px #28a745;
        }

        /* 5. Dual Betting Panels */
        .controls-wrapper {
            padding: 8px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            background: #0b0d10;
        }
        .bet-card {
            background: #14171b;
            border-radius: 12px;
            padding: 8px 10px;
            border: 1px solid #1c222a;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .bet-tab-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .tab-switch {
            display: flex;
            background: #0d0f13;
            border-radius: 20px;
            padding: 2px;
            width: 140px;
        }
        .tab-btn {
            flex: 1;
            padding: 3px 0;
            text-align: center;
            font-size: 11px;
            font-weight: 700;
            color: #798696;
            border-radius: 18px;
            cursor: pointer;
            border: none;
            background: transparent;
            transition: all 0.2s;
        }
        .tab-btn.active {
            background: #252c36;
            color: #ffffff;
        }
        .panel-close-btn {
            background: none;
            border: none;
            color: #556270;
            font-size: 14px;
            cursor: pointer;
        }

        .bet-main-row {
            display: flex;
            gap: 8px;
        }
        .stepper-side {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .stepper-box {
            display: flex;
            align-items: center;
            background: #0d0f13;
            border-radius: 20px;
            border: 1px solid #202630;
            padding: 2px 4px;
        }
        .step-btn {
            width: 26px;
            height: 26px;
            border-radius: 50%;
            background: #212832;
            border: none;
            color: #8f9ba8;
            font-size: 16px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }
        .step-input {
            flex: 1;
            background: transparent;
            border: none;
            color: #ffffff;
            text-align: center;
            font-size: 14px;
            font-weight: 800;
            outline: none;
            width: 100%;
        }
        .quick-chips-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 4px;
        }
        .quick-chip-btn {
            background: #1b2129;
            border: 1px solid #242c38;
            border-radius: 12px;
            color: #8c9ba8;
            font-size: 10px;
            font-weight: 700;
            padding: 3px 0;
            cursor: pointer;
            text-align: center;
        }
        .quick-chip-btn:active {
            background: #2e3846;
        }

        /* Action Button */
        .btn-action {
            width: 125px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 2px;
            transition: transform 0.05s ease;
            font-weight: 800;
        }
        .btn-action {
            transition: transform 0.15s ease, filter 0.2s ease, background 0.2s ease, box-shadow 0.2s ease;
        }
        .btn-action:active {
            transform: scale(0.97);
        }
        
        .btn-action.state-bet {
            background: #00c238;
            color: #ffffff;
            box-shadow: 0 4px 14px rgba(0, 194, 56, 0.4);
        }
        .btn-action.state-bet .action-label {
            font-size: 17px;
            font-weight: 900;
        }
        .btn-action.state-bet .action-sub {
            font-size: 11px;
            opacity: 0.9;
        }

        .btn-action.state-cashout {
            background: #ff7700;
            color: #ffffff;
            box-shadow: 0 4px 14px rgba(255, 119, 0, 0.45);
            animation: pulse 1s infinite alternate;
        }
        .btn-action.state-cashout .action-label {
            font-size: 14px;
            font-weight: 900;
        }
        .btn-action.state-cashout .action-sub {
            font-size: 12px;
            font-weight: 800;
        }

        .btn-action.state-cancel {
            background: #e51b24;
            color: #ffffff;
            box-shadow: 0 4px 14px rgba(229, 27, 36, 0.3);
        }
        .btn-action.state-cancel .action-label {
            font-size: 15px;
            font-weight: 900;
        }

        .auto-settings-row {
            display: none;
            align-items: center;
            justify-content: space-between;
            background: #0d0f13;
            padding: 6px 10px;
            border-radius: 8px;
            border: 1px solid #1f252f;
            font-size: 11px;
            color: #8c9ba8;
        }
        .auto-settings-row.show {
            display: flex;
        }
        .auto-cash-input {
            width: 55px;
            background: #1b2129;
            border: 1px solid #2a3442;
            border-radius: 6px;
            color: #fff;
            padding: 2px 4px;
            text-align: center;
            font-size: 11px;
            font-weight: bold;
            outline: none;
        }

        /* 6. Live Players Table */
        .live-bets-section {
            flex: 1;
            background: #111418;
            border-radius: 12px 12px 0 0;
            padding: 10px 12px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            min-height: 380px;
        }
        
        .tab-filter-bar {
            display: flex;
            background: #0d0f12;
            border-radius: 20px;
            padding: 3px;
        }
        .tab-filter-btn {
            flex: 1;
            text-align: center;
            padding: 5px 0;
            font-size: 12px;
            font-weight: 700;
            color: #798696;
            border-radius: 16px;
            cursor: pointer;
            border: none;
            background: transparent;
        }
        .tab-filter-btn.active {
            background: #252b34;
            color: #fff;
        }

        .bets-stats-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 4px 2px;
            font-size: 12px;
            color: #798696;
            font-weight: 700;
        }
        .stats-left {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .stats-avatars {
            display: flex;
        }
        .stats-avatars span {
            width: 18px;
            height: 18px;
            border-radius: 50%;
            border: 1px solid #111418;
            margin-left: -5px;
            display: inline-block;
            font-size: 10px;
            text-align: center;
            line-height: 18px;
            background-color: #333;
        }
        .stats-avatars span:first-child { margin-left: 0; }
        .stats-right {
            color: #798696;
            font-size: 11px;
        }
        .stats-right strong {
            color: #ffffff;
            font-size: 13px;
            margin-right: 2px;
        }

        .table-header {
            display: grid;
            grid-template-columns: 2.2fr 2fr 1.2fr 2fr;
            padding: 4px 6px;
            font-size: 10px;
            font-weight: 700;
            color: #556270;
            text-transform: uppercase;
        }
        .player-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
            max-height: 320px;
            overflow-y: auto;
            scrollbar-width: thin;
        }
        .player-row {
            display: grid;
            grid-template-columns: 2.2fr 2fr 1.2fr 2fr;
            align-items: center;
            padding: 6px 8px;
            background: #15191e;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 700;
            transition: all 0.3s;
        }
        .player-row.cashed-out {
            background: #11281e;
            border: 1px solid #1f5e38;
        }
        .player-user {
            display: flex;
            align-items: center;
            gap: 6px;
            color: #c9d1d9;
        }
        .p-avatar {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #252b34;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
        }
        .p-bet { color: #ffffff; }
        .p-mult { color: #28a745; font-weight: 800; }
        .p-win { color: #28a745; font-weight: 800; text-align: right; }

        /* ==========================================
           REALISTIC UPI PAYMENT GATEWAY MODAL
           ========================================== */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.85);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            backdrop-filter: blur(5px);
        }
        .deposit-modal {
            width: 92%;
            max-width: 400px;
            background: #15191f;
            border-radius: 16px;
            padding: 20px;
            border: 1px solid #283340;
            box-shadow: 0 10px 40px rgba(0,0,0,0.9);
            display: flex;
            flex-direction: column;
            gap: 12px;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #232b36;
            padding-bottom: 10px;
        }
        .modal-head h3 {
            font-size: 16px;
            font-weight: 800;
            color: #fff;
        }
        .close-modal {
            background: none;
            border: none;
            color: #8b98a5;
            font-size: 22px;
            cursor: pointer;
        }
        
        /* Step 1: Select Amount & App */
        .deposit-amounts {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
        }
        .dep-chip {
            background: #202731;
            border: 1px solid #2c3848;
            border-radius: 8px;
            color: #fff;
            padding: 8px 0;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            text-align: center;
        }
        .dep-chip.selected {
            background: #1e382b;
            border-color: #00c238;
            color: #00c238;
        }
        .custom-dep-input {
            background: #0d0f12;
            border: 1px solid #2c3848;
            border-radius: 8px;
            color: #fff;
            padding: 10px;
            font-size: 14px;
            font-weight: bold;
            outline: none;
            width: 100%;
        }
        .btn-proceed-pay {
            background: #00c238;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 12px;
            font-size: 15px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 4px 14px rgba(0,194,56,0.3);
            text-align: center;
        }

        /* Step 2: UPI QR Gateway Screen */
        .gateway-box {
            display: none;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            background: #0e1115;
            padding: 14px;
            border-radius: 12px;
            border: 1px solid #232b36;
        }
        .qr-placeholder {
            width: 160px;
            height: 160px;
            background: #fff;
            padding: 6px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .qr-placeholder img {
            width: 100%;
            height: 100%;
        }
        .upi-info {
            font-size: 12px;
            color: #c9d1d9;
            text-align: center;
        }
        .upi-id-badge {
            background: #1c2430;
            padding: 4px 10px;
            border-radius: 6px;
            color: #00c238;
            font-weight: bold;
            font-family: monospace;
            margin-top: 4px;
            display: inline-block;
        }
        .timer-badge {
            font-size: 11px;
            color: #ff9800;
            font-weight: bold;
        }
        .utr-input {
            width: 100%;
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 6px;
            color: #fff;
            padding: 8px 10px;
            font-size: 12px;
            outline: none;
        }
        .btn-submit-utr {
            width: 100%;
            background: #238636;
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 10px;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
        }

        /* 7. Footer */
        .app-footer {
            padding: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 10px;
            color: #4f5b68;
            border-top: 1px solid #15181c;
            background: #090a0d;
        }
        .fair-badge {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            100% { transform: scale(1.02); }
        }
    </style>
</head>
<body>

<div class="app-wrapper">

    <!-- 1. Top Casino Header -->
    <div class="casino-header">
        <div class="header-left">
            <span class="back-arrow" onclick="location.href='/lottery'">&#10094;</span>
            <div class="balance-pill" onclick="location.href='/deposit'">
                <div class="coin-icon">₹</div>
                <div class="balance-text" id="topBalance">₹0.00</div>
            </div>
            <button class="btn-add" onclick="location.href='/deposit'">+</button>
        </div>
        <div class="header-right">
            <div class="user-globe">🌍</div>
        </div>
    </div>

    <!-- 2. Aviator Nav Bar -->
    <div class="aviator-nav">
        <span class="aviator-logo">Aviator</span>
        <div class="nav-right">
            <div class="currency-balance"><span id="aviatorBalance">0.00</span> <span>INR</span></div>
            <span class="menu-btn">&#9776;</span>
        </div>
    </div>

    <!-- 3. Multiplier History Bar -->
    <div class="history-row">
        <div class="history-chips" id="historyBar"></div>
        <div class="history-more">&#8942;</div>
    </div>

    <!-- 4. Game Flight Canvas Stage -->
    <div class="stage-box" id="stageContainer">
        <div class="watermark-ufc">
            <div class="ufc-text">UFC</div>
            <div class="partner-text">Official Partners</div>
        </div>
        <div class="spribe-badge">
            <span>SPRIBE</span>
            <span>Official Game &#10004;</span>
        </div>

        <canvas id="gameCanvas"></canvas>

        <div class="multiplier-overlay" id="multiplierDisplay">
            <div id="multValue">1.00x</div>
            <div id="waitingBox" style="display: none;">
                <div class="waiting-text">WAITING FOR NEXT ROUND</div>
                <div class="waiting-progress-bar"><div class="waiting-fill" id="waitingFill"></div></div>
            </div>
        </div>

        <div class="live-count-pill">
            <span class="live-dot"></span>
            <span id="onlineCount">184</span>
        </div>
    </div>

    <!-- 5. Dual Betting Panels -->
    <div class="controls-wrapper">
        
        <!-- PANEL 1 -->
        <div class="bet-card" id="panel-1">
            <div class="bet-tab-header">
                <div class="tab-switch">
                    <button class="tab-btn active" onclick="switchBetMode(1, 'bet')">Bet</button>
                    <button class="tab-btn" onclick="switchBetMode(1, 'auto')">Auto</button>
                </div>
            </div>

            <div class="auto-settings-row" id="auto-row-1">
                <span>Auto Cashout</span>
                <input type="number" step="0.1" value="2.00" class="auto-cash-input" id="auto-cash-1">
            </div>

            <div class="bet-main-row">
                <div class="stepper-side">
                    <div class="stepper-box">
                        <button class="step-btn" onclick="adjustAmount(1, -10)">-</button>
                        <input type="number" class="step-input" id="bet-input-1" value="10.00" step="10">
                        <button class="step-btn" onclick="adjustAmount(1, 10)">+</button>
                    </div>
                    <div class="quick-chips-grid">
                        <button class="quick-chip-btn" onclick="setAmount(1, 10)">10</button>
                        <button class="quick-chip-btn" onclick="setAmount(1, 100)">100</button>
                        <button class="quick-chip-btn" onclick="setAmount(1, 500)">500</button>
                        <button class="quick-chip-btn" onclick="setAmount(1, 1000)">1,000</button>
                    </div>
                </div>

                <button class="btn-action state-bet" id="btn-action-1" onclick="handleBetAction(1)">
                    <span class="action-label">Bet</span>
                    <span class="action-sub" id="btn-sub-1">10.00 INR</span>
                </button>
            </div>
        </div>

        <!-- PANEL 2 -->
        <div class="bet-card" id="panel-2">
            <div class="bet-tab-header">
                <div class="tab-switch">
                    <button class="tab-btn active" onclick="switchBetMode(2, 'bet')">Bet</button>
                    <button class="tab-btn" onclick="switchBetMode(2, 'auto')">Auto</button>
                </div>
                <button class="panel-close-btn" onclick="togglePanel2()">&#9633;</button>
            </div>

            <div class="auto-settings-row" id="auto-row-2">
                <span>Auto Cashout</span>
                <input type="number" step="0.1" value="1.50" class="auto-cash-input" id="auto-cash-2">
            </div>

            <div class="bet-main-row">
                <div class="stepper-side">
                    <div class="stepper-box">
                        <button class="step-btn" onclick="adjustAmount(2, -10)">-</button>
                        <input type="number" class="step-input" id="bet-input-2" value="10.00" step="10">
                        <button class="step-btn" onclick="adjustAmount(2, 10)">+</button>
                    </div>
                    <div class="quick-chips-grid">
                        <button class="quick-chip-btn" onclick="setAmount(2, 10)">10</button>
                        <button class="quick-chip-btn" onclick="setAmount(2, 100)">100</button>
                        <button class="quick-chip-btn" onclick="setAmount(2, 500)">500</button>
                        <button class="quick-chip-btn" onclick="setAmount(2, 1000)">1,000</button>
                    </div>
                </div>

                <button class="btn-action state-bet" id="btn-action-2" onclick="handleBetAction(2)">
                    <span class="action-label">Bet</span>
                    <span class="action-sub" id="btn-sub-2">10.00 INR</span>
                </button>
            </div>
        </div>

    </div>

    <!-- 6. Scrollable Live Bets Section -->
    <div class="live-bets-section">
        <div class="tab-filter-bar">
            <button class="tab-filter-btn active" onclick="switchMainTab(this, 'all')">All Bets</button>
            <button class="tab-filter-btn" onclick="switchMainTab(this, 'prev')">Previous</button>
            <button class="tab-filter-btn" onclick="switchMainTab(this, 'top')">Top</button>
        </div>

        <div class="bets-stats-bar">
            <div class="stats-left">
                <div class="stats-avatars">
                    <span>🦅</span><span>🍓</span><span>🍍</span>
                </div>
                <span id="betsCountLabel">360/360 Bets</span>
            </div>
            <div class="stats-right">
                <strong id="totalWinLabel">0.00</strong> Total win INR
            </div>
        </div>

        <div class="table-header">
            <div>Player</div>
            <div>Bet INR</div>
            <div>X</div>
            <div style="text-align: right;">Win INR</div>
        </div>

        <div class="player-list" id="playerList"></div>
    </div>

    <!-- 7. Footer -->
    <div class="app-footer">
        <div class="fair-badge">&#128737; Provably Fair Game</div>
        <div>Powered by <strong>SPRIBE</strong></div>
    </div>

</div>

<!-- Realistic UPI Payment Gateway Modal -->
<div class="modal-overlay" id="depositModal">
    <div class="deposit-modal">
        <div class="modal-head">
            <h3 id="modalTitle">Deposit Funds (INR)</h3>
            <button class="close-modal" onclick="closeDepositModal()">&times;</button>
        </div>

        <!-- STEP 1: Select Amount -->
        <div id="step-select-amount" style="display: flex; flex-direction: column; gap: 12px;">
            <p style="font-size: 11px; color: #8c9ba8;">Select deposit amount to recharge wallet:</p>
            <div class="deposit-amounts">
                <div class="dep-chip selected" onclick="selectDeposit(this, 200)">₹200</div>
                <div class="dep-chip" onclick="selectDeposit(this, 500)">₹500</div>
                <div class="dep-chip" onclick="selectDeposit(this, 1000)">₹1,000</div>
                <div class="dep-chip" onclick="selectDeposit(this, 2000)">₹2,000</div>
                <div class="dep-chip" onclick="selectDeposit(this, 5000)">₹5,000</div>
                <div class="dep-chip" onclick="selectDeposit(this, 10000)">₹10,000</div>
            </div>
            <input type="number" id="depositInput" class="custom-dep-input" value="200" placeholder="Enter custom amount (₹)">
            <button class="btn-proceed-pay" onclick="proceedToPayment()">Proceed to Pay with UPI</button>
        </div>

        <!-- STEP 2: Realistic UPI QR Gateway Screen -->
        <div class="gateway-box" id="step-gateway">
            <div class="timer-badge">Session Expires: <span id="gatewayTimer">04:59</span></div>
            
            <div class="qr-placeholder">
                <!-- SVG UPI QR Simulation -->
                <svg width="150" height="150" viewBox="0 0 100 100">
                    <rect width="100" height="100" fill="#ffffff" />
                    <!-- QR Corner 1 -->
                    <rect x="5" y="5" width="30" height="30" fill="#000" />
                    <rect x="10" y="10" width="20" height="20" fill="#fff" />
                    <rect x="15" y="15" width="10" height="10" fill="#000" />
                    <!-- QR Corner 2 -->
                    <rect x="65" y="5" width="30" height="30" fill="#000" />
                    <rect x="70" y="10" width="20" height="20" fill="#fff" />
                    <rect x="75" y="15" width="10" height="10" fill="#000" />
                    <!-- QR Corner 3 -->
                    <rect x="5" y="65" width="30" height="30" fill="#000" />
                    <rect x="10" y="70" width="20" height="20" fill="#fff" />
                    <rect x="15" y="75" width="10" height="10" fill="#000" />
                    <!-- Center Pattern -->
                    <rect x="42" y="42" width="16" height="16" fill="#e51b24" />
                    <circle cx="50" cy="50" r="4" fill="#fff" />
                    <rect x="45" y="10" width="10" height="25" fill="#000" />
                    <rect x="10" y="45" width="25" height="10" fill="#000" />
                    <rect x="65" y="65" width="25" height="25" fill="#000" />
                </svg>
            </div>

            <div class="upi-info">
                <div>Scan & Pay <strong>₹<span id="gatewayAmount">200</span></strong></div>
                <div class="upi-id-badge">paytm.merchant@upi</div>
            </div>

            <input type="text" id="utrInput" maxlength="12" class="utr-input" placeholder="Enter 12-Digit UPI Ref / UTR No.">
            
            <button class="btn-submit-utr" id="btnSubmitUTR" onclick="verifyUTR()">Submit & Verify Payment</button>
            <p id="gatewayMsg" style="font-size: 10px; color: #8c9ba8; text-align: center;">Money will be added to balance only after authentic UTR confirmation.</p>
        </div>

    </div>
</div>

<script>
    // ==========================================
    // AUDIO SYNTHESIS ENGINE
    // ==========================================
    let audioCtx = null;
    function initAudio() {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    
    function playCashoutSound() {
        try {
            initAudio();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.15);
            gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
            gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.2);
        } catch(e){}
    }

    function playCrashSound() {
        try {
            initAudio();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = 'sawtooth';
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.frequency.setValueAtTime(150, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(30, audioCtx.currentTime + 0.3);
            gain.gain.setValueAtTime(0.4, audioCtx.currentTime);
            gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.3);
        } catch(e){}
    }

    // ==========================================
    // REALISTIC WALLET STATE (LocalStorage)
    // ==========================================
    let userBalance = 0.00;
    let savedHistory = JSON.parse(localStorage.getItem("aviator_history")) || [3.48, 2.90, 2.37, 2.56, 1.05, 1.19, 1.19, 6.17];
    let pendingDepositAmount = 0;
    let timerInterval = null;

    function saveBalance() {
        // real balance is on server
    }
    function saveHistory() {
        localStorage.setItem("aviator_history", JSON.stringify(savedHistory));
    }

    function loadBalanceFromServer() {
        return fetch('/account_balance').then(r => r.json()).then(data => {
            if (data.ok) {
                userBalance = data.balance;
                updateBalanceDisplay();
            }
        }).catch(() => {});
    }

    function updateServerBalance(action, amount) {
        return fetch('/update_balance', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: action, amount: amount})
        }).then(r => r.json());
    }

    // Elements
    const canvas = document.getElementById("gameCanvas");
    const ctx = canvas.getContext("2d");
    const multValue = document.getElementById("multValue");
    const waitingBox = document.getElementById("waitingBox");
    const waitingFill = document.getElementById("waitingFill");
    const historyBar = document.getElementById("historyBar");
    const playerList = document.getElementById("playerList");
    const topBalance = document.getElementById("topBalance");
    const aviatorBalance = document.getElementById("aviatorBalance");
    const betsCountLabel = document.getElementById("betsCountLabel");
    const totalWinLabel = document.getElementById("totalWinLabel");
    const onlineCount = document.getElementById("onlineCount");

    let gameState = "WAITING";
    let currentMultiplier = 1.00;
    let crashMultiplier = 1.00;
    let flightProgress = 0;
    let totalRoundWins = 0;

    const panels = {
        1: { state: "IDLE", betAmount: 10.00, autoCashout: false, autoMultiplier: 2.00, cashedMultiplier: 0 },
        2: { state: "IDLE", betAmount: 10.00, autoCashout: false, autoMultiplier: 1.50, cashedMultiplier: 0 }
    };

    const avatars = ["🦅", "🍓", "🍍", "🐯", "🐱", "🐶", "🦊", "🦁", "🐵", "🐧", "🌴", "🚀", "🎩"];
    let livePlayers = [];

    function resizeCanvas() {
        const stage = document.getElementById("stageContainer");
        canvas.width = stage.clientWidth;
        canvas.height = stage.clientHeight;
    }
    window.addEventListener("resize", resizeCanvas);
    resizeCanvas();

    function updateBalanceDisplay() {
        topBalance.innerText = `₹${userBalance.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
        aviatorBalance.innerText = userBalance.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2});
        saveBalance();
    }

    // ==========================================
    // PAYMENT GATEWAY MODAL LOGIC
    // ==========================================
    function openDepositModal() {
        document.getElementById("depositModal").style.display = "flex";
        document.getElementById("step-select-amount").style.display = "flex";
        document.getElementById("step-gateway").style.display = "none";
        document.getElementById("modalTitle").innerText = "Deposit Funds (INR)";
    }

    function closeDepositModal() {
        document.getElementById("depositModal").style.display = "none";
        if (timerInterval) clearInterval(timerInterval);
    }

    function selectDeposit(element, amt) {
        document.querySelectorAll(".dep-chip").forEach(c => c.classList.remove("selected"));
        element.classList.add("selected");
        document.getElementById("depositInput").value = amt;
    }

    function proceedToPayment() {
        const amt = parseFloat(document.getElementById("depositInput").value);
        if (!amt || amt < 100) {
            alert("Minimum deposit amount is ₹100");
            return;
        }
        pendingDepositAmount = amt;
        document.getElementById("gatewayAmount").innerText = amt.toLocaleString('en-IN');
        
        // Hide Step 1, Show Step 2 (UPI Gateway)
        document.getElementById("step-select-amount").style.display = "none";
        document.getElementById("step-gateway").style.display = "flex";
        document.getElementById("modalTitle").innerText = "UPI Payment Gateway";
        document.getElementById("utrInput").value = "";
        document.getElementById("gatewayMsg").style.color = "#8c9ba8";
        document.getElementById("gatewayMsg").innerText = "Money will be added to balance only after authentic UTR confirmation.";

        // Start 5-Minute Timer
        startGatewayTimer();
    }

    function startGatewayTimer() {
        if (timerInterval) clearInterval(timerInterval);
        let seconds = 300;
        const timerLabel = document.getElementById("gatewayTimer");
        timerInterval = setInterval(() => {
            seconds--;
            let mins = Math.floor(seconds / 60);
            let remSecs = seconds % 60;
            timerLabel.innerText = `${mins < 10 ? '0' : ''}${mins}:${remSecs < 10 ? '0' : ''}${remSecs}`;
            if (seconds <= 0) {
                clearInterval(timerInterval);
                alert("Payment session expired. Please try again.");
                closeDepositModal();
            }
        }, 1000);
    }

    function verifyUTR() {
        const utr = document.getElementById("utrInput").value.trim();
        const msg = document.getElementById("gatewayMsg");
        const btn = document.getElementById("btnSubmitUTR");

        if (utr.length !== 12 || isNaN(utr)) {
            msg.innerText = "❌ Please enter a valid 12-digit UTR/Ref number from your UPI app!";
            msg.style.color = "#e51b24";
            return;
        }

        btn.innerText = "Verifying with Bank...";
        btn.style.background = "#555";
        btn.disabled = true;

        // Real deposit goes through site deposit page
        alert("Please use the official Deposit page for payments.");
        location.href = '/deposit';
    }

    // ==========================================
    // BETTING PANEL CONTROLS
    // ==========================================
    function adjustAmount(panelId, delta) {
        let current = parseFloat(document.getElementById(`bet-input-${panelId}`).value) || 10;
        let next = Math.max(10, current + delta);
        document.getElementById(`bet-input-${panelId}`).value = next.toFixed(2);
        panels[panelId].betAmount = next;
        updatePanelBtnUI(panelId);
    }

    function setAmount(panelId, amount) {
        document.getElementById(`bet-input-${panelId}`).value = amount.toFixed(2);
        panels[panelId].betAmount = amount;
        updatePanelBtnUI(panelId);
    }

    function switchBetMode(panelId, mode) {
        const card = document.getElementById(`panel-${panelId}`);
        const tabs = card.querySelectorAll(".tab-btn");
        tabs.forEach(t => t.classList.remove("active"));
        if (mode === 'bet') {
            tabs[0].classList.add("active");
            document.getElementById(`auto-row-${panelId}`).classList.remove("show");
            panels[panelId].autoCashout = false;
        } else {
            tabs[1].classList.add("active");
            document.getElementById(`auto-row-${panelId}`).classList.add("show");
            panels[panelId].autoCashout = true;
        }
    }

    function togglePanel2() {
        const p2 = document.getElementById("panel-2");
        p2.style.display = (p2.style.display === "none") ? "flex" : "none";
    }

    function updatePanelBtnUI(panelId) {
        const btn = document.getElementById(`btn-action-${panelId}`);
        const sub = document.getElementById(`btn-sub-${panelId}`);
        const p = panels[panelId];

        if (p.state === "IDLE") {
            btn.className = "btn-action state-bet";
            btn.querySelector(".action-label").innerText = "Bet";
            sub.innerText = `${p.betAmount.toFixed(2)} INR`;
        } else if (p.state === "PLACED") {
            btn.className = "btn-action state-cancel";
            btn.querySelector(".action-label").innerText = "Cancel";
            sub.innerText = "WAITING";
        } else if (p.state === "IN_ROUND") {
            btn.className = "btn-action state-cashout";
            btn.querySelector(".action-label").innerText = "Cash Out";
            let liveCash = (p.betAmount * currentMultiplier).toFixed(2);
            sub.innerText = `${liveCash} INR`;
        } else if (p.state === "CASHED") {
            btn.className = "btn-action state-bet";
            btn.style.filter = "grayscale(0.7)";
            btn.querySelector(".action-label").innerText = "Cashed Out";
            sub.innerText = `${(p.betAmount * p.cashedMultiplier).toFixed(2)} INR`;
        }
    }

    function handleBetAction(panelId) {
        initAudio();
        const p = panels[panelId];
        p.betAmount = parseFloat(document.getElementById(`bet-input-${panelId}`).value) || 10;
        
        if (p.autoCashout) {
            p.autoMultiplier = parseFloat(document.getElementById(`auto-cash-${panelId}`).value) || 2.00;
        }

        if (p.state === "IDLE") {
            if (userBalance < p.betAmount) {
                location.href = '/deposit';
                return;
            }
            updateServerBalance("subtract", p.betAmount).then(res => {
                if (!res.ok) {
                    alert(res.msg || "Insufficient balance");
                    loadBalanceFromServer();
                    return;
                }
                userBalance = res.balance;
                updateBalanceDisplay();
                p.state = "PLACED";
                updatePanelBtnUI(panelId);
            });
        } 
        else if (p.state === "PLACED") {
            updateServerBalance("add", p.betAmount).then(res => {
                if (res.ok) {
                    userBalance = res.balance;
                    updateBalanceDisplay();
                }
                p.state = "IDLE";
                updatePanelBtnUI(panelId);
            });
        } 
        else if (p.state === "IN_ROUND") {
            cashOutPanel(panelId);
        }
    }

    function cashOutPanel(panelId) {
        const p = panels[panelId];
        if (p.state !== "IN_ROUND") return;
        
        playCashoutSound();
        p.state = "CASHED";
        p.cashedMultiplier = currentMultiplier;
        const winAmount = p.betAmount * currentMultiplier;
        totalRoundWins += winAmount;
        updateServerBalance("add", winAmount).then(res => {
            if (res.ok) {
                userBalance = res.balance;
                updateBalanceDisplay();
            }
        });
        updatePanelBtnUI(panelId);
    }

    // Live Multiplayer Table
    function generateLivePlayers() {
        livePlayers = [];
        const count = Math.floor(Math.random() * 20) + 25;
        for (let i = 0; i < count; i++) {
            const firstDigit = Math.floor(Math.random() * 9) + 1;
            const randChar = String.fromCharCode(97 + Math.floor(Math.random() * 26));
            livePlayers.push({
                name: `${firstDigit}***${randChar}`,
                avatar: avatars[Math.floor(Math.random() * avatars.length)],
                bet: [100, 200, 500, 1000, 2000, 5000, 8000][Math.floor(Math.random() * 7)],
                targetMult: +(1.1 + Math.random() * 6).toFixed(2),
                cashed: false,
                cashMult: 0
            });
        }
        livePlayers.sort((a, b) => b.bet - a.bet);
        renderPlayerList();
    }

    function renderPlayerList() {
        betsCountLabel.innerText = `${livePlayers.length}/${livePlayers.length} Bets`;
        totalWinLabel.innerText = totalRoundWins.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2});
        
        playerList.innerHTML = livePlayers.map(p => `
            <div class="player-row ${p.cashed ? 'cashed-out' : ''}">
                <div class="player-user">
                    <span class="p-avatar">${p.avatar}</span>
                    <span>${p.name}</span>
                </div>
                <div class="p-bet">${p.bet.toLocaleString('en-IN')}.00</div>
                <div class="p-mult">${p.cashed ? p.cashMult.toFixed(2) + 'x' : ''}</div>
                <div class="p-win">${p.cashed ? (p.bet * p.cashMult).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2}) : ''}</div>
            </div>
        `).join('');
    }

    function updateLiveBetsCashouts() {
        let changed = false;
        livePlayers.forEach(p => {
            if (!p.cashed && currentMultiplier >= p.targetMult && p.targetMult <= crashMultiplier) {
                p.cashed = true;
                p.cashMult = p.targetMult;
                totalRoundWins += (p.bet * p.cashMult);
                changed = true;
            }
        });
        if (changed) renderPlayerList();
    }

    // Provably Fair Crash Curve
    function calculateCrashPoint() {
        const rand = Math.random();
        if (rand < 0.05) return 1.00;
        return Math.max(1.01, +(0.95 / (1 - rand)).toFixed(2));
    }

    function startWaitingState() {
        gameState = "WAITING";
        currentMultiplier = 1.00;
        flightProgress = 0;
        totalRoundWins = 0;

        [1, 2].forEach(id => {
            if (panels[id].state === "PLACED") {
                panels[id].state = "IN_ROUND";
            } else if (panels[id].state === "CASHED") {
                panels[id].state = "IDLE";
                document.getElementById(`btn-action-${id}`).style.filter = "none";
            }
            updatePanelBtnUI(id);
        });

        generateLivePlayers();

        multValue.style.display = "none";
        multValue.className = "";
        waitingBox.style.display = "block";
        waitingFill.style.width = "0%";

        let progress = 0;
        const interval = setInterval(() => {
            progress += 2.5;
            waitingFill.style.width = `${progress}%`;
            if (progress >= 100) {
                clearInterval(interval);
                startFlyingState();
            }
        }, 60);
    }

    function startFlyingState() {
        gameState = "FLYING";
        crashMultiplier = calculateCrashPoint();
        currentMultiplier = 1.00;
        flightProgress = 0;

        waitingBox.style.display = "none";
        multValue.style.display = "block";
        multValue.innerText = "1.00x";
        multValue.style.color = "#ffffff";

        [1, 2].forEach(id => {
            if (panels[id].state === "PLACED") panels[id].state = "IN_ROUND";
            updatePanelBtnUI(id);
        });

        loopFlight();
    }

    function drawFlightCanvas(planeX, planeY) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        const startX = 20;
        const startY = canvas.height - 25;

        // Area Glow
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.quadraticCurveTo(startX + (planeX - startX) * 0.45, startY, planeX, planeY);
        ctx.lineTo(planeX, startY);
        ctx.closePath();
        const fillGrad = ctx.createLinearGradient(0, planeY, 0, startY);
        fillGrad.addColorStop(0, "rgba(229, 27, 36, 0.35)");
        fillGrad.addColorStop(1, "rgba(229, 27, 36, 0.0)");
        ctx.fillStyle = fillGrad;
        ctx.fill();

        // Trajectory Line
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.quadraticCurveTo(startX + (planeX - startX) * 0.45, startY, planeX, planeY);
        ctx.strokeStyle = "#e51b24";
        ctx.lineWidth = 3.5;
        ctx.stroke();

        // Plane Body
        ctx.save();
        ctx.translate(planeX, planeY);
        ctx.rotate(-Math.PI / 14);

        ctx.fillStyle = "#e51b24";
        ctx.beginPath();
        ctx.ellipse(0, 0, 18, 7, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.ellipse(6, -2, 4, 2.5, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#b5121b";
        ctx.beginPath();
        ctx.moveTo(-4, 0); ctx.lineTo(2, -12); ctx.lineTo(7, -12); ctx.lineTo(3, 0); ctx.closePath();
        ctx.fill();

        ctx.fillStyle = "#b5121b";
        ctx.beginPath();
        ctx.moveTo(-14, 0); ctx.lineTo(-20, -9); ctx.lineTo(-16, -9); ctx.lineTo(-10, 0); ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = "rgba(255,255,255,0.7)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(18, -8); ctx.lineTo(18, 8);
        ctx.stroke();

        ctx.restore();
    }

    function loopFlight() {
        if (gameState !== "FLYING") return;

        currentMultiplier += 0.0055 * (1 + currentMultiplier * 0.048);
        flightProgress += 0.0032;

        multValue.innerText = `${currentMultiplier.toFixed(2)}x`;
        updateLiveBetsCashouts();

        [1, 2].forEach(id => {
            const p = panels[id];
            if (p.state === "IN_ROUND") {
                updatePanelBtnUI(id);
                if (p.autoCashout && currentMultiplier >= p.autoMultiplier) {
                    cashOutPanel(id);
                }
            }
        });

        const curX = Math.min(canvas.width - 45, 20 + (canvas.width - 70) * Math.min(1, flightProgress));
        const curY = Math.max(35, (canvas.height - 25) - (canvas.height - 70) * Math.min(1, flightProgress));

        drawFlightCanvas(curX, curY);

        if (currentMultiplier >= crashMultiplier) {
            handleCrash();
            return;
        }

        requestAnimationFrame(loopFlight);
    }

    function handleCrash() {
        gameState = "CRASHED";
        playCrashSound();
        multValue.className = "crash-state";
        multValue.innerText = `FLEW AWAY! (${crashMultiplier.toFixed(2)}x)`;

        addHistoryChip(crashMultiplier);

        [1, 2].forEach(id => {
            if (panels[id].state === "IN_ROUND") {
                panels[id].state = "IDLE";
                updatePanelBtnUI(id);
            }
        });

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        setTimeout(startWaitingState, 2800);
    }

    function addHistoryChip(multiplier) {
        savedHistory.unshift(multiplier);
        if (savedHistory.length > 25) savedHistory.pop();
        saveHistory();
        renderHistory();
    }

    function renderHistory() {
        historyBar.innerHTML = savedHistory.map(m => {
            let chipClass = "chip-blue";
            if (m >= 10.0) chipClass = "chip-pink";
            else if (m >= 2.0) chipClass = "chip-purple";
            return `<span class="chip ${chipClass}">${parseFloat(m).toFixed(2)}x</span>`;
        }).join('');
    }

    function switchMainTab(btn, tab) {
        document.querySelectorAll(".tab-filter-btn").forEach(t => t.classList.remove("active"));
        btn.classList.add("active");
    }

    setInterval(() => {
        onlineCount.innerText = 180 + Math.floor(Math.random() * 40);
    }, 4000);

    // Initial Start
    renderHistory();
    loadBalanceFromServer();
    startWaitingState();
</script>

</body>
</html>'''
