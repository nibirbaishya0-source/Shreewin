html_k3 = r'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Shree.Win - K3 (30s, 1m, 3m, 5m)</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    :root {
      --bg-main: #191340;
      --bg-darker: #100b2b;
      --card-bg: #221a53;
      --card-inner: #2c2266;
      --text-muted: #958dc2;
      --green-slot: #00b871;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
      user-select: none;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #0d0822;
      display: flex;
      justify-content: center;
      min-height: 100vh;
      color: #fff;
    }

    .app-container {
      width: 100%;
      max-width: 440px;
      background: linear-gradient(180deg, #1b1446 0%, #100b2c 100%);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      padding-bottom: 40px;
      position: relative;
      box-shadow: 0 0 30px rgba(0,0,0,0.9);
    }

    /* Top Nav */
    .top-nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 14px 16px;
      background: #17113f;
    }
    .top-nav .logo {
      font-size: 22px;
      font-weight: 900;
      background: linear-gradient(180deg, #ffe066 0%, #ff8c1a 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      letter-spacing: 0.5px;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .top-icons i {
      font-size: 18px;
      margin-left: 14px;
      color: #b7b0e2;
      cursor: pointer;
    }

    /* Wallet Card */
    .wallet-card {
      margin: 12px 16px;
      background: linear-gradient(135deg, #2d236e 0%, #1f1754 100%);
      border-radius: 18px;
      padding: 16px;
      box-shadow: 0 6px 18px rgba(0,0,0,0.4);
      border: 1px solid rgba(255,255,255,0.05);
    }
    .wallet-header {
      font-size: 13px;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }
    .wallet-balance {
      font-size: 30px;
      font-weight: 800;
      text-align: center;
      margin: 4px 0 14px 0;
      color: #ffffff;
      letter-spacing: 0.5px;
    }
    .wallet-btns {
      display: flex;
      gap: 12px;
    }
    .btn-withdraw {
      flex: 1;
      background: linear-gradient(180deg, #ffc837 0%, #ff8008 100%);
      color: #3b1e00;
      font-weight: 700;
      padding: 11px;
      border-radius: 25px;
      border: none;
      cursor: pointer;
      font-size: 14px;
      box-shadow: 0 4px 10px rgba(255, 153, 0, 0.3);
    }
    .btn-deposit {
      flex: 1;
      background: linear-gradient(180deg, #8a65f8 0%, #5931eb 100%);
      color: #fff;
      font-weight: 700;
      padding: 11px;
      border-radius: 25px;
      border: none;
      cursor: pointer;
      font-size: 14px;
      box-shadow: 0 4px 10px rgba(106, 68, 245, 0.3);
    }

    /* Notice */
    .notice-bar {
      margin: 0 16px 12px 16px;
      background: #1c1549;
      border-radius: 20px;
      padding: 6px 12px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 11px;
      color: var(--text-muted);
    }
    .notice-bar i { color: #ffb703; font-size: 13px; }
    .notice-text { flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

    /* Game Mode Tabs (30s, 1m, 3m, 5m) */
    .game-mode-tabs {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 8px;
      padding: 0 16px;
      margin-bottom: 12px;
    }
    .mode-tab {
      background: #1d164d;
      border-radius: 14px;
      padding: 10px 4px;
      text-align: center;
      cursor: pointer;
      color: var(--text-muted);
      border: 1px solid rgba(255,255,255,0.03);
      transition: all 0.2s;
    }
    .mode-tab.active {
      background: linear-gradient(180deg, #7c5af8 0%, #532deb 100%);
      color: #fff;
      box-shadow: 0 4px 12px rgba(99, 62, 243, 0.4);
    }
    .mode-tab i { font-size: 18px; margin-bottom: 4px; display: block; }
    .mode-tab span { font-size: 11px; font-weight: 700; display: block; }

    /* Arena Container */
    .game-arena {
      background: var(--card-bg);
      margin: 0 16px;
      border-radius: 18px;
      padding: 14px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.3);
      border: 1px solid rgba(255,255,255,0.05);
    }
    .arena-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
    }
    .period-title { font-size: 12px; color: var(--text-muted); }
    .period-id { font-size: 14px; font-weight: 800; color: #ffffff; letter-spacing: 0.5px; }

    .timer-wrap { text-align: right; }
    .timer-title { font-size: 10px; color: var(--text-muted); margin-bottom: 2px; }
    .timer-boxes { display: flex; align-items: center; gap: 3px; justify-content: flex-end; }
    .t-box {
      background: #2b216c;
      color: #9f8dfc;
      font-weight: 800;
      font-size: 14px;
      padding: 3px 6px;
      border-radius: 6px;
      min-width: 22px;
      text-align: center;
    }
    .t-box.alert { background: #8e1030; color: #ffb8c9; animation: pulseAlert 0.5s infinite alternate; }
    @keyframes pulseAlert { from { transform: scale(1); } to { transform: scale(1.08); } }

    /* Green Slot Machine */
    .dice-slot-machine {
      background: linear-gradient(180deg, #0ec87d 0%, #00995c 100%);
      border-radius: 16px;
      padding: 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: inset 0 2px 6px rgba(255,255,255,0.4), 0 6px 14px rgba(0,0,0,0.4);
    }
    .slot-arrow { color: rgba(255,255,255,0.8); font-size: 14px; font-weight: 900; }
    .dice-slots-container { display: flex; gap: 8px; flex: 1; justify-content: center; }
    .dice-pocket {
      width: 68px;
      height: 68px;
      background: linear-gradient(180deg, #07472d 0%, #0c6240 100%);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: inset 0 4px 8px rgba(0,0,0,0.6);
      border: 1px solid rgba(0,0,0,0.3);
    }

    /* 3D Dice */
    .dice-cube {
      width: 50px;
      height: 50px;
      background: radial-gradient(circle at 35% 30%, #ff4b58 0%, #d81628 60%, #870613 100%);
      border-radius: 12px;
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      grid-template-rows: repeat(3, 1fr);
      padding: 5px;
      box-shadow: 0 6px 10px rgba(0,0,0,0.5), inset 0 2px 3px rgba(255,255,255,0.5);
      transition: transform 0.2s;
    }
    .dice-cube.rolling { animation: diceRollAnim 0.4s infinite linear; }
    @keyframes diceRollAnim {
      0% { transform: rotate(0deg) scale(0.9); }
      50% { transform: rotate(180deg) scale(1.08); }
      100% { transform: rotate(360deg) scale(0.9); }
    }
    .pip-dot {
      width: 9px;
      height: 9px;
      background: radial-gradient(circle at 35% 30%, #fffb91 0%, #ffcc00 70%, #d49b00 100%);
      border-radius: 50%;
      margin: auto;
      box-shadow: inset 0 1px 2px rgba(0,0,0,0.4), 0 1px 2px rgba(0,0,0,0.3);
    }

    /* Sub Tabs */
    .bet-type-tabs {
      display: flex;
      background: #17113e;
      border-radius: 12px;
      margin: 14px 0 12px 0;
      padding: 4px;
    }
    .b-tab {
      flex: 1;
      text-align: center;
      padding: 8px 0;
      font-size: 11px;
      color: var(--text-muted);
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
    }
    .b-tab.active {
      background: linear-gradient(180deg, #7c5df8 0%, #5835eb 100%);
      color: #fff;
    }

    /* Tab Panes */
    .tab-content { display: none; }
    .tab-content.active { display: block; }

    /* 3D Glossy Balls */
    .numbers-matrix {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 12px 8px;
      margin-bottom: 14px;
    }
    .num-ball-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      cursor: pointer;
    }
    .ball-sphere {
      width: 46px;
      height: 46px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 800;
      font-size: 18px;
      color: #ffffff;
      position: relative;
      box-shadow: 0 6px 12px rgba(0,0,0,0.4), inset 0 -4px 6px rgba(0,0,0,0.35);
      border: 1.5px solid rgba(255,255,255,0.4);
    }
    .ball-sphere::after {
      content: "";
      position: absolute;
      top: 3px;
      left: 8px;
      width: 14px;
      height: 8px;
      background: radial-gradient(ellipse at center, rgba(255,255,255,0.85) 0%, rgba(255,255,255,0) 80%);
      border-radius: 50%;
      transform: rotate(-25deg);
    }
    .ball-sphere.red-ball { background: radial-gradient(circle at 35% 28%, #ff6b7b 0%, #e51d2f 55%, #8e0714 100%); }
    .ball-sphere.green-ball { background: radial-gradient(circle at 35% 28%, #36ec95 0%, #0fae62 55%, #055f32 100%); }
    .ball-mult { font-size: 10px; font-weight: 600; color: var(--text-muted); margin-top: 4px; }

    /* Quick Action Buttons */
    .quick-action-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 8px;
    }
    .q-action-btn {
      padding: 10px 0;
      border-radius: 12px;
      text-align: center;
      cursor: pointer;
      display: flex;
      flex-direction: column;
      align-items: center;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
      border: 1px solid rgba(255,255,255,0.15);
    }
    .q-action-btn .btn-label { font-size: 13px; font-weight: 700; }
    .q-action-btn .btn-mult { font-size: 10px; opacity: 0.9; font-weight: 600; margin-top: 2px; }

    .btn-style-small { background: linear-gradient(180deg, #44a6ff 0%, #1e7ada 100%); }
    .btn-style-big   { background: linear-gradient(180deg, #ffaf38 0%, #e68500 100%); }
    .btn-style-even  { background: linear-gradient(180deg, #20dc86 0%, #0ca75f 100%); }
    .btn-style-odd   { background: linear-gradient(180deg, #ff5252 0%, #d82424 100%); }

    /* Pairs & Triplets Grids */
    .custom-bet-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 10px;
      margin: 10px 0;
    }
    .bet-box-card {
      background: #17113e;
      border: 1px solid #3c2f7c;
      border-radius: 12px;
      padding: 12px 6px;
      text-align: center;
      cursor: pointer;
    }
    .bet-box-card .dice-duo {
      display: flex;
      justify-content: center;
      gap: 4px;
      margin-bottom: 6px;
    }
    .bet-box-card .tag-name { font-size: 13px; font-weight: 700; color: #fff; }
    .bet-box-card .tag-multiplier { font-size: 10px; color: #ffcc00; font-weight: 600; }

    /* Active Bet Bar */
    .active-bet-indicator {
      margin-top: 10px;
      background: #1b1244;
      border: 1px solid #ffcc00;
      padding: 8px;
      border-radius: 10px;
      text-align: center;
      font-size: 12px;
      color: #ffde59;
      display: none;
      font-weight: 600;
    }

    /* History & Stats Section */
    .history-card {
      margin: 16px;
      background: var(--card-bg);
      border-radius: 18px;
      padding: 16px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.3);
      border: 1px solid rgba(255,255,255,0.05);
    }
    .history-tabs-row {
      display: flex;
      background: #17113e;
      border-radius: 10px;
      padding: 4px;
      margin-bottom: 14px;
    }
    .h-tab-item {
      flex: 1;
      text-align: center;
      padding: 8px 0;
      font-size: 12px;
      color: var(--text-muted);
      cursor: pointer;
      font-weight: 600;
      border-radius: 8px;
    }
    .h-tab-item.active {
      background: linear-gradient(180deg, #7c5df8 0%, #5835eb 100%);
      color: #fff;
    }

    .history-table-custom { width: 100%; border-collapse: collapse; }
    .history-table-custom th {
      font-size: 11px;
      color: var(--text-muted);
      font-weight: 600;
      padding: 8px 4px;
      text-align: center;
      border-bottom: 1px solid #2e2469;
    }
    .history-table-custom td {
      font-size: 11px;
      padding: 8px 4px;
      text-align: center;
      border-bottom: 1px solid rgba(255,255,255,0.04);
      vertical-align: middle;
    }
    .tag-bubble { font-size: 10px; padding: 2px 6px; border-radius: 4px; font-weight: 700; }
    .tag-big   { background: rgba(255, 175, 56, 0.15); color: #ffaf38; }
    .tag-small { background: rgba(68, 166, 255, 0.15); color: #44a6ff; }
    .tag-even  { background: rgba(32, 220, 134, 0.15); color: #20dc86; }
    .tag-odd   { background: rgba(255, 82, 82, 0.15); color: #ff5252; }

    .mini-dice-wrap { display: inline-flex; gap: 3px; }
    .mini-cube {
      width: 15px;
      height: 15px;
      background: radial-gradient(circle at 35% 30%, #ff4b58 0%, #d81628 100%);
      border-radius: 3px;
      color: #fffb91;
      font-size: 9px;
      font-weight: 800;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    /* Chart Section */
    .chart-box { padding: 10px 0; font-size: 12px; }
    .stat-bar-wrap { margin-bottom: 14px; }
    .stat-label-row { display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 11px; color: var(--text-muted); }
    .progress-track { height: 12px; background: #140e36; border-radius: 6px; overflow: hidden; display: flex; }
    .progress-fill-big { background: #ffaf38; }
    .progress-fill-small { background: #44a6ff; }
    .progress-fill-even { background: #20dc86; }
    .progress-fill-odd { background: #ff5252; }

    /* Betting Drawer Modal */
    .bet-drawer-modal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.75);
      backdrop-filter: blur(4px);
      z-index: 200;
      justify-content: center;
      align-items: flex-end;
    }
    .drawer-body {
      width: 100%;
      max-width: 440px;
      background: #201754;
      border-radius: 24px 24px 0 0;
      padding: 20px;
      box-shadow: 0 -8px 24px rgba(0,0,0,0.6);
      animation: slideUp 0.25s ease-out;
    }
    @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
    .drawer-title {
      font-size: 16px;
      font-weight: 700;
      color: #ffde59;
      margin-bottom: 12px;
      display: flex;
      justify-content: space-between;
    }
    .quick-chips { display: flex; gap: 8px; margin-bottom: 14px; }
    .chip {
      flex: 1;
      padding: 8px 0;
      background: #150f38;
      border: 1px solid #43348f;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 700;
      text-align: center;
      cursor: pointer;
      color: #c9c3ee;
    }
    .chip.selected { background: #7355f6; border-color: #9277ff; color: #fff; }
    .custom-input {
      width: 100%;
      padding: 12px;
      background: #140e36;
      border: 1px solid #5844b5;
      border-radius: 10px;
      color: #fff;
      font-size: 16px;
      font-weight: 700;
      margin-bottom: 16px;
      outline: none;
    }
    .drawer-actions { display: flex; gap: 12px; }
    .drawer-actions button {
      flex: 1;
      padding: 12px;
      border-radius: 12px;
      border: none;
      font-weight: 700;
      font-size: 14px;
      cursor: pointer;
    }
    .btn-cancel-modal { background: #3d346b; color: #fff; }
    .btn-confirm-modal { background: linear-gradient(180deg, #1fdd86 0%, #0ba45e 100%); color: #fff; }
  </style>
</head>
<body>

<div class="app-container">

  <!-- Top Nav -->
  <div class="top-nav">
    <i class="fa-solid fa-chevron-left"></i>
    <div class="logo"><span>🎲</span> Shree.Win</div>
    <div class="top-icons">
      <i class="fa-solid fa-volume-high" id="soundToggleBtn" onclick="toggleSound()" title="Mute/Unmute"></i>
      <i class="fa-solid fa-rotate-right" onclick="loadBalanceFromServer()" title="Refresh Balance"></i>
    </div>
  </div>

  <!-- Wallet Header -->
  <div class="wallet-card">
    <div class="wallet-header"><i class="fa-solid fa-wallet"></i> Wallet balance</div>
    <div class="wallet-balance" id="balanceDisplay">₹0.00</div>
    <div class="wallet-btns">
      <button class="btn-withdraw" onclick="location.href='/withdraw'">Withdraw</button>
      <button class="btn-deposit" onclick="location.href='/deposit'">+ Deposit</button>
    </div>
  </div>

  <!-- Notice -->
  <div class="notice-bar">
    <i class="fa-solid fa-bullhorn"></i>
    <div class="notice-text">Our Shree.Win Customer Service will never send links directly to members.</div>
  </div>

  <!-- Game Mode Tabs (30s, 1m, 3m, 5m) -->
  <div class="game-mode-tabs">
    <div class="mode-tab active" onclick="switchGameMode('30sec', this)">
      <i class="fa-regular fa-clock"></i>
      <span>K3 30 Sec</span>
    </div>
    <div class="mode-tab" onclick="switchGameMode('1min', this)">
      <i class="fa-regular fa-clock"></i>
      <span>K3 1 Min</span>
    </div>
    <div class="mode-tab" onclick="switchGameMode('3min', this)">
      <i class="fa-regular fa-clock"></i>
      <span>K3 3 Min</span>
    </div>
    <div class="mode-tab" onclick="switchGameMode('5min', this)">
      <i class="fa-regular fa-clock"></i>
      <span>K3 5 Min</span>
    </div>
  </div>

  <!-- Arena Container -->
  <div class="game-arena">
    <div class="arena-top">
      <div>
        <div class="period-title">Period</div>
        <div class="period-id" id="currentPeriodDisplay">20260912101011189</div>
      </div>
      <div class="timer-wrap">
        <div class="timer-title">Time remaining</div>
        <div class="timer-boxes">
          <div class="t-box" id="minTens">0</div>
          <div class="t-box" id="minUnits">0</div>
          <span style="font-weight:900; color:#8575df;">:</span>
          <div class="t-box" id="secTens">3</div>
          <div class="t-box" id="secUnits">0</div>
        </div>
      </div>
    </div>

    <!-- Green Slot Machine Frame -->
    <div class="dice-slot-machine">
      <span class="slot-arrow">&#9664;</span>
      <div class="dice-slots-container">
        <div class="dice-pocket"><div class="dice-cube" id="dice1"></div></div>
        <div class="dice-pocket"><div class="dice-cube" id="dice2"></div></div>
        <div class="dice-pocket"><div class="dice-cube" id="dice3"></div></div>
      </div>
      <span class="slot-arrow">&#9654;</span>
    </div>

    <div class="active-bet-indicator" id="activeBetIndicator"></div>

    <!-- Sub Betting Navigation -->
    <div class="bet-type-tabs">
      <div class="b-tab active" onclick="switchBetTab('total', this)">Total</div>
      <div class="b-tab" onclick="switchBetTab('twoSame', this)">2 same</div>
      <div class="b-tab" onclick="switchBetTab('threeSame', this)">3 same</div>
      <div class="b-tab" onclick="switchBetTab('different', this)">Different</div>
    </div>

    <!-- Tab 1: Total -->
    <div class="tab-content active" id="tab-total">
      <div class="numbers-matrix" id="numbersGrid"></div>
      <div class="quick-action-grid">
        <div class="q-action-btn btn-style-small" onclick="openBetDrawer('Small', 2.0, 'total')">
          <span class="btn-label">Small</span><span class="btn-mult">2X</span>
        </div>
        <div class="q-action-btn btn-style-big" onclick="openBetDrawer('Big', 2.0, 'total')">
          <span class="btn-label">Big</span><span class="btn-mult">2X</span>
        </div>
        <div class="q-action-btn btn-style-even" onclick="openBetDrawer('Even', 2.0, 'total')">
          <span class="btn-label">Even</span><span class="btn-mult">2X</span>
        </div>
        <div class="q-action-btn btn-style-odd" onclick="openBetDrawer('Odd', 2.0, 'total')">
          <span class="btn-label">Odd</span><span class="btn-mult">2X</span>
        </div>
      </div>
    </div>

    <!-- Tab 2: 2 Same (Pairs) -->
    <div class="tab-content" id="tab-twoSame">
      <p style="font-size:11px; color:var(--text-muted); margin-bottom:8px;">Match at least 2 identical dice:</p>
      <div class="custom-bet-grid" id="twoSameGrid"></div>
    </div>

    <!-- Tab 3: 3 Same (Triplets) -->
    <div class="tab-content" id="tab-threeSame">
      <div class="bet-box-card" style="margin-bottom:10px; background:#291e63;" onclick="openBetDrawer('Any 3 Same', 34.56, 'threeSame')">
        <div class="tag-name">Any 3 Same (Any Triplet)</div>
        <div class="tag-multiplier">34.56X</div>
      </div>
      <p style="font-size:11px; color:var(--text-muted); margin-bottom:8px;">Specific Triplets:</p>
      <div class="custom-bet-grid" id="threeSameGrid"></div>
    </div>

    <!-- Tab 4: Different -->
    <div class="tab-content" id="tab-different">
      <p style="font-size:11px; color:var(--text-muted); margin-bottom:8px;">Continuous & Distinct Numbers:</p>
      <div class="custom-bet-grid">
        <div class="bet-box-card" onclick="openBetDrawer('3 Continuous', 8.64, 'different')">
          <div class="tag-name">3 Continuous (e.g. 1-2-3)</div>
          <div class="tag-multiplier">8.64X</div>
        </div>
        <div class="bet-box-card" onclick="openBetDrawer('3 All Different', 2.16, 'different')">
          <div class="tag-name">3 All Different</div>
          <div class="tag-multiplier">2.16X</div>
        </div>
      </div>
    </div>

  </div>

  <!-- History & Analysis -->
  <div class="history-card">
    <div class="history-tabs-row">
      <div class="h-tab-item active" onclick="switchHistoryTab('game', this)">Game history</div>
      <div class="h-tab-item" onclick="switchHistoryTab('chart', this)">Chart</div>
      <div class="h-tab-item" onclick="switchHistoryTab('my', this)">My history</div>
    </div>

    <!-- View 1: Game History -->
    <div id="hview-game">
      <table class="history-table-custom">
        <thead>
          <tr><th>Period</th><th>Sum</th><th>Results</th></tr>
        </thead>
        <tbody id="historyTableBody"></tbody>
      </table>
    </div>

    <!-- View 2: Chart Stats -->
    <div id="hview-chart" style="display:none;" class="chart-box">
      <div class="stat-bar-wrap">
        <div class="stat-label-row">
          <span>Big: <b id="statBigPct">50%</b></span>
          <span>Small: <b id="statSmallPct">50%</b></span>
        </div>
        <div class="progress-track">
          <div class="progress-fill-big" id="barBig" style="width:50%;"></div>
          <div class="progress-fill-small" id="barSmall" style="width:50%;"></div>
        </div>
      </div>
      <div class="stat-bar-wrap">
        <div class="stat-label-row">
          <span>Even: <b id="statEvenPct">50%</b></span>
          <span>Odd: <b id="statOddPct">50%</b></span>
        </div>
        <div class="progress-track">
          <div class="progress-fill-even" id="barEven" style="width:50%;"></div>
          <div class="progress-fill-odd" id="barOdd" style="width:50%;"></div>
        </div>
      </div>
    </div>

    <!-- View 3: My History -->
    <div id="hview-my" style="display:none;">
      <table class="history-table-custom">
        <thead>
          <tr><th>Period</th><th>Bet</th><th>Amount</th><th>Status</th></tr>
        </thead>
        <tbody id="myHistoryTableBody">
          <tr><td colspan="4" style="color:var(--text-muted); padding:16px;">No bets placed yet</td></tr>
        </tbody>
      </table>
    </div>

  </div>

</div>

<!-- Betting Drawer Modal -->
<div class="bet-drawer-modal" id="betDrawerModal">
  <div class="drawer-body">
    <div class="drawer-title">
      <span id="drawerBetLabel">Select Bet</span>
      <span id="drawerBetMult" style="color:#20dc86;">2X</span>
    </div>

    <div class="quick-chips">
      <div class="chip selected" onclick="selectChip(10, this)">₹10</div>
      <div class="chip" onclick="selectChip(50, this)">₹50</div>
      <div class="chip" onclick="selectChip(100, this)">₹100</div>
      <div class="chip" onclick="selectChip(500, this)">₹500</div>
    </div>

    <input type="number" id="drawerAmountInput" class="custom-input" value="10" min="10" step="10" />

    <div class="drawer-actions">
      <button class="btn-cancel-modal" onclick="closeBetDrawer()">Cancel</button>
      <button class="btn-confirm-modal" onclick="confirmPlacedBet()">Confirm</button>
    </div>
  </div>
</div>

<script>
  // Web Audio Synthesizer
  const AudioEngine = {
    ctx: null,
    muted: false,
    init() {
      if (!this.ctx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        this.ctx = new AudioContext();
      }
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
    },
    playTick() {
      if (this.muted) return;
      this.init();
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(900, this.ctx.currentTime);
      gain.gain.setValueAtTime(0.1, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.08);
    },
    playRoll() {
      if (this.muted) return;
      this.init();
      for (let i = 0; i < 5; i++) {
        setTimeout(() => {
          if (this.muted) return;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(200 + Math.random() * 300, this.ctx.currentTime);
          gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.06);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start();
          osc.stop(this.ctx.currentTime + 0.06);
        }, i * 70);
      }
    },
    playWin() {
      if (this.muted) return;
      this.init();
      const notes = [523.25, 659.25, 783.99, 1046.50];
      notes.forEach((freq, idx) => {
        setTimeout(() => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
          gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.25);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start();
          osc.stop(this.ctx.currentTime + 0.25);
        }, idx * 100);
      });
    },
    playLoss() {
      if (this.muted) return;
      this.init();
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(250, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(100, this.ctx.currentTime + 0.35);
      gain.gain.setValueAtTime(0.1, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.35);
    }
  };

  function toggleSound() {
    AudioEngine.muted = !AudioEngine.muted;
    const btn = document.getElementById("soundToggleBtn");
    btn.className = AudioEngine.muted ? "fa-solid fa-volume-xmark" : "fa-solid fa-volume-high";
  }

  // Multipliers
  const multipliers = {
    3: "207.36X", 4: "69.12X", 5: "34.56X", 6: "20.74X",
    7: "13.83X",  8: "9.88X",  9: "8.3X",   10: "7.68X",
    11: "7.68X", 12: "8.3X",   13: "9.88X", 14: "13.83X",
    15: "20.74X", 16: "34.56X", 17: "69.12X", 18: "207.36X"
  };

  // State Management for: 30sec, 1min, 3min, 5min
  let balance = 0.00;
  let currentMode = '30sec';

  const modeState = {
    '30sec': { duration: 30,  timeLeft: 30,  period: 20260912101011189, activeBet: null, dice: [2, 6, 5] },
    '1min':  { duration: 60,  timeLeft: 60,  period: 20260912102011054, activeBet: null, dice: [4, 4, 1] },
    '3min':  { duration: 180, timeLeft: 180, period: 20260912103011028, activeBet: null, dice: [6, 3, 2] },
    '5min':  { duration: 300, timeLeft: 300, period: 20260912105011012, activeBet: null, dice: [5, 5, 5] }
  };

  let selectedChoice = { label: "", mult: 1, type: "total" };
  let gameHistoryRecords = JSON.parse(localStorage.getItem("k3_game_history")) || [];
  let myHistoryRecords = JSON.parse(localStorage.getItem("k3_my_history")) || [];

  function init() {
    loadBalanceFromServer();
    renderBallsGrid();
    renderPairsGrid();
    renderTripletsGrid();
    renderDice();
    updateWalletDisplay();
    startMasterClock();

    if (gameHistoryRecords.length === 0) {
      preloadInitialData();
    } else {
      renderGameHistoryUI();
      updateChartStats();
    }
    renderMyHistoryUI();
    updateModeUI();
  }

  function renderBallsGrid() {
    const container = document.getElementById("numbersGrid");
    container.innerHTML = "";
    for (let i = 3; i <= 18; i++) {
      const isRed = (i % 2 !== 0);
      const multStr = multipliers[i];
      container.innerHTML += `
        <div class="num-ball-card" onclick="openBetDrawer('${i}', ${parseFloat(multStr)}, 'total')">
          <div class="ball-sphere ${isRed ? 'red-ball' : 'green-ball'}">${i}</div>
          <div class="ball-mult">${multStr}</div>
        </div>
      `;
    }
  }

  function renderPairsGrid() {
    const grid = document.getElementById("twoSameGrid");
    grid.innerHTML = "";
    for (let i = 1; i <= 6; i++) {
      grid.innerHTML += `
        <div class="bet-box-card" onclick="openBetDrawer('Pair ${i}${i}', 13.83, 'twoSame')">
          <div class="dice-duo">
            <span class="mini-cube">${i}</span>
            <span class="mini-cube">${i}</span>
          </div>
          <div class="tag-name">Pair ${i}${i}</div>
          <div class="tag-multiplier">13.83X</div>
        </div>
      `;
    }
  }

  function renderTripletsGrid() {
    const grid = document.getElementById("threeSameGrid");
    grid.innerHTML = "";
    for (let i = 1; i <= 6; i++) {
      grid.innerHTML += `
        <div class="bet-box-card" onclick="openBetDrawer('Triple ${i}${i}${i}', 207.36, 'threeSame')">
          <div class="dice-duo">
            <span class="mini-cube">${i}</span>
            <span class="mini-cube">${i}</span>
            <span class="mini-cube">${i}</span>
          </div>
          <div class="tag-name">${i}${i}${i}</div>
          <div class="tag-multiplier">207.36X</div>
        </div>
      `;
    }
  }

  function getDiceHTML(val) {
    const pipMap = {
      1: [4],
      2: [0, 8],
      3: [0, 4, 8],
      4: [0, 2, 6, 8],
      5: [0, 2, 4, 6, 8],
      6: [0, 2, 3, 5, 6, 8]
    };
    let out = "";
    for (let i = 0; i < 9; i++) {
      if (pipMap[val] && pipMap[val].includes(i)) {
        out += `<div class="pip-dot"></div>`;
      } else {
        out += `<div></div>`;
      }
    }
    return out;
  }

  function renderDice() {
    const curDice = modeState[currentMode].dice;
    document.getElementById("dice1").innerHTML = getDiceHTML(curDice[0]);
    document.getElementById("dice2").innerHTML = getDiceHTML(curDice[1]);
    document.getElementById("dice3").innerHTML = getDiceHTML(curDice[2]);
  }

  // Fair CSPRNG
  function getRandomFairRoll() {
    const arr = new Uint32Array(1);
    window.crypto.getRandomValues(arr);
    return (arr[0] % 6) + 1;
  }

  // Master Clock (Runs 30s, 1m, 3m, 5m concurrently)
  function startMasterClock() {
    setInterval(() => {
      Object.keys(modeState).forEach(mode => {
        const state = modeState[mode];
        if (state.timeLeft > 0) {
          state.timeLeft--;
        } else {
          executeRoundSettlement(mode);
          state.timeLeft = state.duration;
        }
      });

      const activeState = modeState[currentMode];
      if (activeState.timeLeft <= 5 && activeState.timeLeft > 0) {
        AudioEngine.playTick();
      }

      updateTimerDisplay();
    }, 1000);
  }

  function updateTimerDisplay() {
    const t = modeState[currentMode].timeLeft;
    const mins = Math.floor(t / 60);
    const secs = t % 60;

    const minTens = Math.floor(mins / 10);
    const minUnits = mins % 10;
    const secTens = Math.floor(secs / 10);
    const secUnits = secs % 10;

    const boxes = [
      document.getElementById("minTens"),
      document.getElementById("minUnits"),
      document.getElementById("secTens"),
      document.getElementById("secUnits")
    ];

    boxes[0].innerText = minTens;
    boxes[1].innerText = minUnits;
    boxes[2].innerText = secTens;
    boxes[3].innerText = secUnits;

    if (t <= 5) {
      boxes.forEach(b => b.classList.add("alert"));
    } else {
      boxes.forEach(b => b.classList.remove("alert"));
    }
  }

  // Mode Switch Handler
  function switchGameMode(modeKey, elem) {
    document.querySelectorAll(".game-mode-tabs .mode-tab").forEach(tab => tab.classList.remove("active"));
    elem.classList.add("active");
    currentMode = modeKey;
    updateModeUI();
  }

  function updateModeUI() {
    const state = modeState[currentMode];
    document.getElementById("currentPeriodDisplay").innerText = state.period;
    renderDice();
    updateTimerDisplay();

    const indicator = document.getElementById("activeBetIndicator");
    if (state.activeBet) {
      indicator.style.display = "block";
      indicator.innerText = `[${currentMode.toUpperCase()}] Active: ₹${state.activeBet.amount} on ${state.activeBet.label} (${state.activeBet.mult}X)`;
    } else {
      indicator.style.display = "none";
    }
  }

  // Settlement Engine
  function executeRoundSettlement(modeKey) {
    const state = modeState[modeKey];
    const isCurrentActiveView = (modeKey === currentMode);

    if (isCurrentActiveView) {
      const diceElements = [
        document.getElementById("dice1"),
        document.getElementById("dice2"),
        document.getElementById("dice3")
      ];
      diceElements.forEach(el => el.classList.add("rolling"));
      AudioEngine.playRoll();
    }

    setTimeout(() => {
      state.dice = [getRandomFairRoll(), getRandomFairRoll(), getRandomFairRoll()];

      if (isCurrentActiveView) {
        renderDice();
        const diceElements = [
          document.getElementById("dice1"),
          document.getElementById("dice2"),
          document.getElementById("dice3")
        ];
        diceElements.forEach(el => el.classList.remove("rolling"));
      }

      const sum = state.dice[0] + state.dice[1] + state.dice[2];
      const isBig = sum >= 11;
      const isEven = (sum % 2 === 0);

      // Settle bets for this mode
      if (state.activeBet) {
        let isWinner = evaluateBetWin(state.activeBet, state.dice, sum, isBig, isEven);

        if (isWinner) {
          const payout = state.activeBet.amount * state.activeBet.mult;
          updateServerBalance("add", payout).then(res => {
            if (res.ok) { balance = res.balance; updateWalletDisplay(); }
          });
          if (isCurrentActiveView) AudioEngine.playWin();
          alert(`🎉 [${modeKey.toUpperCase()}] Congratulation! You won ₹${payout.toFixed(2)} (Sum: ${sum})`);
          recordMyBet(state.period, `${modeKey.toUpperCase()} - ${state.activeBet.label}`, state.activeBet.amount, "WIN", payout);
        } else {
          if (isCurrentActiveView) AudioEngine.playLoss();
          alert(`❌ [${modeKey.toUpperCase()}] Round Ended. Sum: ${sum} (${isBig ? 'Big':'Small'}, ${isEven ? 'Even':'Odd'})`);
          recordMyBet(state.period, `${modeKey.toUpperCase()} - ${state.activeBet.label}`, state.activeBet.amount, "LOSE", 0);
        }
        updateWalletDisplay();
        state.activeBet = null;
        if (isCurrentActiveView) {
          document.getElementById("activeBetIndicator").style.display = "none";
        }
      }

      // Add to History Records
      const record = {
        p: state.period,
        mode: modeKey,
        sum: sum,
        bs: isBig ? "Big" : "Small",
        oe: isEven ? "Even" : "Odd",
        d: [...state.dice]
      };
      gameHistoryRecords.unshift(record);
      if (gameHistoryRecords.length > 50) gameHistoryRecords.pop();

      localStorage.setItem("k3_game_history", JSON.stringify(gameHistoryRecords));
      renderGameHistoryUI();
      updateChartStats();

      state.period++;
      if (isCurrentActiveView) {
        document.getElementById("currentPeriodDisplay").innerText = state.period;
      }
    }, 800);
  }

  function evaluateBetWin(bet, d, sum, isBig, isEven) {
    const [d1, d2, d3] = d;
    const sorted = [...d].sort();

    if (bet.type === 'total') {
      if (bet.label === "Small" && !isBig) return true;
      if (bet.label === "Big" && isBig) return true;
      if (bet.label === "Even" && isEven) return true;
      if (bet.label === "Odd" && !isEven) return true;
      if (bet.label === String(sum)) return true;
    } else if (bet.type === 'twoSame') {
      const targetNum = parseInt(bet.label.replace('Pair ', '')[0]);
      const matches = d.filter(x => x === targetNum).length;
      if (matches >= 2) return true;
    } else if (bet.type === 'threeSame') {
      if (bet.label === 'Any 3 Same' && d1 === d2 && d2 === d3) return true;
      const targetNum = parseInt(bet.label.replace('Triple ', '')[0]);
      if (d1 === targetNum && d2 === targetNum && d3 === targetNum) return true;
    } else if (bet.type === 'different') {
      if (bet.label === '3 All Different' && d1 !== d2 && d2 !== d3 && d1 !== d3) return true;
      if (bet.label === '3 Continuous' && sorted[0] + 1 === sorted[1] && sorted[1] + 1 === sorted[2]) return true;
    }
    return false;
  }

  // Navigation
  function switchBetTab(tabId, elem) {
    document.querySelectorAll(".bet-type-tabs .b-tab").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(tc => tc.classList.remove("active"));
    elem.classList.add("active");
    document.getElementById(`tab-${tabId}`).classList.add("active");
  }

  function switchHistoryTab(viewId, elem) {
    document.querySelectorAll(".history-tabs-row .h-tab-item").forEach(b => b.classList.remove("active"));
    elem.classList.add("active");
    document.getElementById("hview-game").style.display = (viewId === 'game') ? 'block' : 'none';
    document.getElementById("hview-chart").style.display = (viewId === 'chart') ? 'block' : 'none';
    document.getElementById("hview-my").style.display = (viewId === 'my') ? 'block' : 'none';
  }

  // Modal / Drawer Handlers
  function openBetDrawer(label, mult, type) {
    AudioEngine.init();
    if (modeState[currentMode].timeLeft <= 5) {
      alert(`Betting locked for ${currentMode.toUpperCase()}! Please wait for next round.`);
      return;
    }
    selectedChoice = { label, mult, type };
    document.getElementById("drawerBetLabel").innerText = `[${currentMode.toUpperCase()}] Bet: ${label}`;
    document.getElementById("drawerBetMult").innerText = `${mult}X`;
    document.getElementById("betDrawerModal").style.display = "flex";
  }

  function closeBetDrawer() {
    document.getElementById("betDrawerModal").style.display = "none";
  }

  function selectChip(val, elem) {
    document.querySelectorAll(".quick-chips .chip").forEach(c => c.classList.remove("selected"));
    elem.classList.add("selected");
    document.getElementById("drawerAmountInput").value = val;
  }

  async function confirmPlacedBet() {
    const amt = parseFloat(document.getElementById("drawerAmountInput").value);
    if (isNaN(amt) || amt <= 0) {
      alert("Please enter a valid amount!");
      return;
    }
    if (balance <= 0 || amt > balance) {
      alert("⚠️ Insufficient Wallet Balance! Please deposit funds.");
      return;
    }

    const res = await updateServerBalance("subtract", amt);
    if (!res.ok) {
      alert(res.msg || "Insufficient balance");
      await loadBalanceFromServer();
      return;
    }
    balance = res.balance;
    updateWalletDisplay();

    modeState[currentMode].activeBet = {
      label: selectedChoice.label,
      mult: selectedChoice.mult,
      type: selectedChoice.type,
      amount: amt
    };

    const indicator = document.getElementById("activeBetIndicator");
    indicator.style.display = "block";
    indicator.innerText = `[${currentMode.toUpperCase()}] Active: ₹${amt} on ${selectedChoice.label} (${selectedChoice.mult}X)`;

    closeBetDrawer();
  }

  function updateWalletDisplay() {
    document.getElementById("balanceDisplay").innerText = `₹${balance.toFixed(2)}`;
  }

  function loadBalanceFromServer() {
    return fetch('/account_balance').then(r => r.json()).then(data => {
      if (data.ok) {
        balance = data.balance;
        updateWalletDisplay();
      }
    }).catch(() => {});
  }

  function updateServerBalance(action, amount) {
    return fetch('/update_balance', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({action: action, amount: amount})
    }).then(r => r.json());
  }

  // History & Statistics
  function renderGameHistoryUI() {
    const tbody = document.getElementById("historyTableBody");
    tbody.innerHTML = "";
    gameHistoryRecords.forEach(r => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td style="font-size:11px; font-weight:600;">${r.p}</td>
        <td>
          <span style="font-weight:700; margin-right:4px;">${r.sum}</span>
          <span class="tag-bubble ${r.bs === 'Big' ? 'tag-big' : 'tag-small'}">${r.bs}</span>
          <span class="tag-bubble ${r.oe === 'Even' ? 'tag-even' : 'tag-odd'}">${r.oe}</span>
        </td>
        <td>
          <div class="mini-dice-wrap">
            <div class="mini-cube">${r.d[0]}</div>
            <div class="mini-cube">${r.d[1]}</div>
            <div class="mini-cube">${r.d[2]}</div>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  function updateChartStats() {
    if (gameHistoryRecords.length === 0) return;
    const total = gameHistoryRecords.length;
    const bigCount = gameHistoryRecords.filter(x => x.bs === 'Big').length;
    const evenCount = gameHistoryRecords.filter(x => x.oe === 'Even').length;

    const bigPct = Math.round((bigCount / total) * 100);
    const smallPct = 100 - bigPct;
    const evenPct = Math.round((evenCount / total) * 100);
    const oddPct = 100 - evenPct;

    document.getElementById("statBigPct").innerText = `${bigPct}%`;
    document.getElementById("statSmallPct").innerText = `${smallPct}%`;
    document.getElementById("barBig").style.width = `${bigPct}%`;
    document.getElementById("barSmall").style.width = `${smallPct}%`;

    document.getElementById("statEvenPct").innerText = `${evenPct}%`;
    document.getElementById("statOddPct").innerText = `${oddPct}%`;
    document.getElementById("barEven").style.width = `${evenPct}%`;
    document.getElementById("barOdd").style.width = `${oddPct}%`;
  }

  function recordMyBet(period, choice, amount, status, payout) {
    myHistoryRecords.unshift({ period, choice, amount, status, payout });
    if (myHistoryRecords.length > 30) myHistoryRecords.pop();
    localStorage.setItem("k3_my_history", JSON.stringify(myHistoryRecords));
    renderMyHistoryUI();
  }

  function renderMyHistoryUI() {
    const tbody = document.getElementById("myHistoryTableBody");
    if (myHistoryRecords.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" style="color:var(--text-muted); padding:16px;">No bets placed yet</td></tr>`;
      return;
    }
    tbody.innerHTML = "";
    myHistoryRecords.forEach(item => {
      const isWin = item.status === "WIN";
      tbody.innerHTML += `
        <tr>
          <td>${item.period}</td>
          <td><b>${item.choice}</b></td>
          <td>₹${item.amount.toFixed(2)}</td>
          <td style="font-weight:700; color:${isWin ? '#20dc86' : '#ff5252'}">
            ${isWin ? '+₹' + item.payout.toFixed(2) : '-₹' + item.amount.toFixed(2)}
          </td>
        </tr>
      `;
    });
  }

  function preloadInitialData() {
    gameHistoryRecords = [
      { p: 20260912101011188, mode: '30sec', sum: 13, bs: "Big", oe: "Odd", d: [2, 6, 5] },
      { p: 20260912101011187, mode: '30sec', sum: 14, bs: "Big", oe: "Even", d: [5, 5, 4] },
      { p: 20260912101011186, mode: '30sec', sum: 7,  bs: "Small", oe: "Odd", d: [1, 4, 2] },
      { p: 20260912101011185, mode: '30sec', sum: 17, bs: "Big", oe: "Odd", d: [6, 6, 5] }
    ];
    renderGameHistoryUI();
    updateChartStats();
  }

  window.onload = init;
</script>

</body>
</html>'''
