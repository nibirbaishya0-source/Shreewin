# Lazy-friendly package. Import from submodules directly:
# from pages.register import register_html
