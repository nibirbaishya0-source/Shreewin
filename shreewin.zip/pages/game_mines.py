html_mines = r'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Mines Game</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    :root {
      --bg-gradient: linear-gradient(180deg, #0056d6 0%, #003087 100%);
      --tile-bg: #093c88;
      --tile-border: #1355b8;
      --tile-active: #0d4ba8;
      --accent-yellow: #ffb703;
      --accent-green: #00c853;
      --btn-green: linear-gradient(180deg, #10db65 0%, #009938 100%);
      --btn-cashout: linear-gradient(180deg, #ffc400 0%, #e67e00 100%);
      --text-white: #ffffff;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
      user-select: none;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #00173d;
      display: flex;
      justify-content: center;
      min-height: 100vh;
      color: #fff;
    }

    .app-container {
      width: 100%;
      max-width: 440px;
      background: var(--bg-gradient);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      position: relative;
      box-shadow: 0 0 30px rgba(0,0,0,0.8);
      overflow-x: hidden;
    }

    /* Top Bar */
    .top-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
    }
    .back-btn {
      font-size: 20px;
      color: #fff;
      cursor: pointer;
    }
    .wallet-pill {
      display: flex;
      align-items: center;
      background: #02235c;
      border: 1px solid #14499e;
      border-radius: 20px;
      padding: 4px 10px 4px 4px;
      gap: 6px;
    }
    .coin-badge {
      width: 26px;
      height: 26px;
      background: radial-gradient(circle at 35% 35%, #fffb91 0%, #ffaa00 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
      color: #733c00;
      font-weight: 900;
      box-shadow: 0 2px 5px rgba(0,0,0,0.3);
    }
    .balance-txt {
      font-size: 15px;
      font-weight: 800;
      color: #fff;
      min-width: 50px;
    }
    .top-right-tools {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .btn-add-funds {
      width: 28px;
      height: 28px;
      background: #08439b;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #4da3ff;
      font-size: 15px;
      font-weight: 900;
      cursor: pointer;
      border: 1px solid #1a5ac0;
    }
    .support-icon {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: radial-gradient(circle, #00d2ff, #0077ff);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
    }

    /* Game Header Title & Status */
    .game-title {
      text-align: center;
      font-size: 20px;
      font-weight: 900;
      letter-spacing: 1.5px;
      margin-bottom: 8px;
      text-shadow: 0 2px 8px rgba(0,0,0,0.4);
    }
    .info-header-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 18px 10px 18px;
    }
    .game-id-badge {
      background: #008744;
      color: #fff;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 700;
      box-shadow: 0 3px 6px rgba(0,0,0,0.2);
    }
    .next-win-badge {
      background: linear-gradient(180deg, #ffc700 0%, #ff9900 100%);
      color: #2e1800;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 800;
      box-shadow: 0 3px 6px rgba(0,0,0,0.3);
    }

    /* 5x5 Mines Grid */
    .grid-wrap {
      display: flex;
      justify-content: center;
      padding: 8px 16px;
    }
    .mines-grid {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 9px;
      width: 100%;
      max-width: 380px;
      background: rgba(0, 31, 84, 0.5);
      padding: 12px;
      border-radius: 18px;
      box-shadow: inset 0 3px 10px rgba(0,0,0,0.5);
      border: 1px solid rgba(255,255,255,0.06);
    }
    .tile {
      aspect-ratio: 1 / 1;
      background: linear-gradient(180deg, #0d469b 0%, #073172 100%);
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      position: relative;
      box-shadow: 0 5px 0 #041f4d, 0 6px 10px rgba(0,0,0,0.4);
      border: 1px solid #1459be;
      transition: transform 0.1s, background 0.2s;
    }
    .tile:active {
      transform: translateY(3px);
      box-shadow: 0 2px 0 #041f4d;
    }
    .tile-dot {
      width: 16px;
      height: 16px;
      background: radial-gradient(circle, #105cc7 30%, #083c88 100%);
      border-radius: 50%;
      box-shadow: inset 0 1px 3px rgba(0,0,0,0.5);
    }
    .tile.revealed {
      box-shadow: inset 0 2px 6px rgba(0,0,0,0.6);
      cursor: default;
      transform: none !important;
    }
    .tile.revealed.gem {
      background: radial-gradient(circle at 35% 30%, #165abf 0%, #072659 100%);
      border-color: #00e5ff;
    }
    .tile.revealed.mine {
      background: radial-gradient(circle at 35% 30%, #ff4b58 0%, #870613 100%);
      border-color: #ff1744;
      animation: shakeBoom 0.4s ease-in-out;
    }
    @keyframes shakeBoom {
      0%, 100% { transform: scale(1); }
      25% { transform: scale(1.15) rotate(-6deg); }
      75% { transform: scale(1.15) rotate(6deg); }
    }
    .gem-icon {
      font-size: 26px;
      filter: drop-shadow(0 0 8px #00e5ff);
      animation: popGem 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    .mine-icon {
      font-size: 26px;
      filter: drop-shadow(0 0 10px #ff3d00);
      animation: popMine 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    @keyframes popGem {
      0% { transform: scale(0); opacity: 0; }
      100% { transform: scale(1); opacity: 1; }
    }
    @keyframes popMine {
      0% { transform: scale(0); }
      70% { transform: scale(1.25); }
      100% { transform: scale(1); }
    }

    /* Sub Controls Row (Random, Auto, Mines count) */
    .controls-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 18px;
      gap: 8px;
    }
    .btn-random {
      flex: 1;
      padding: 9px 0;
      background: #093c88;
      border: 1px solid #1455b8;
      border-radius: 20px;
      color: #fff;
      font-size: 12px;
      font-weight: 700;
      text-align: center;
      cursor: pointer;
      box-shadow: 0 3px 6px rgba(0,0,0,0.2);
    }
    .btn-random:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .auto-toggle-wrap {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      font-weight: 600;
      color: #b3cfff;
    }
    .toggle-switch {
      width: 38px;
      height: 20px;
      background: #072a63;
      border-radius: 10px;
      position: relative;
      cursor: pointer;
      border: 1px solid #14499e;
    }
    .toggle-dot {
      width: 16px;
      height: 16px;
      background: #fff;
      border-radius: 50%;
      position: absolute;
      top: 1px;
      left: 2px;
      transition: left 0.2s;
    }
    .mines-select-btn {
      flex: 1;
      padding: 9px 10px;
      background: #093c88;
      border: 1px solid #1455b8;
      border-radius: 20px;
      color: #fff;
      font-size: 12px;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: pointer;
    }

    /* Bottom Control Dashboard */
    .dashboard-panel {
      margin: 0 16px 12px 16px;
      background: #032560;
      border-radius: 22px;
      padding: 14px 16px;
      border: 1px solid #0d469b;
      box-shadow: 0 6px 16px rgba(0,0,0,0.3);
    }
    .bet-input-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      margin-bottom: 12px;
    }
    .bet-amount-box {
      flex: 1;
      background: #021a47;
      border: 1px solid #0d469b;
      border-radius: 25px;
      display: flex;
      align-items: center;
      padding: 6px 14px;
      justify-content: space-between;
    }
    .bet-lbl { font-size: 11px; color: #7aa7eb; font-weight: 700; }
    .bet-inp {
      background: transparent;
      border: none;
      color: #fff;
      font-size: 15px;
      font-weight: 800;
      text-align: right;
      width: 90px;
      outline: none;
    }
    .step-btn {
      width: 36px;
      height: 36px;
      background: #073579;
      border: 1px solid #1455b8;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-size: 15px;
      cursor: pointer;
      font-weight: 800;
    }
    .step-btn:active { transform: scale(0.92); }

    /* Action Bet / Cashout Button */
    .action-row {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .btn-circle-refresh {
      width: 48px;
      height: 48px;
      background: #073579;
      border: 1px solid #1455b8;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #4da3ff;
      font-size: 18px;
      cursor: pointer;
    }
    .btn-main-action {
      flex: 1;
      height: 48px;
      background: var(--btn-green);
      border: none;
      border-radius: 25px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      font-size: 16px;
      font-weight: 900;
      color: #fff;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(0, 200, 83, 0.4);
      letter-spacing: 0.5px;
      transition: background 0.2s, transform 0.1s;
    }
    .btn-main-action.cashout {
      background: var(--btn-cashout);
      color: #2e1800;
      box-shadow: 0 4px 12px rgba(255, 170, 0, 0.5);
    }
    .btn-main-action:active { transform: scale(0.98); }

    /* Footer Tools */
    .footer-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 20px 14px 20px;
      font-size: 13px;
      color: #85adff;
    }
    .footer-bar i { cursor: pointer; font-size: 18px; }

    /* Modal for Mines Selection */
    .mines-modal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.7);
      backdrop-filter: blur(4px);
      z-index: 100;
      justify-content: center;
      align-items: flex-end;
    }
    .modal-sheet {
      width: 100%;
      max-width: 440px;
      background: #032258;
      border-radius: 24px 24px 0 0;
      padding: 20px;
      border-top: 1px solid #1455b8;
    }
    .sheet-title {
      font-size: 16px;
      font-weight: 800;
      color: #ffc400;
      margin-bottom: 14px;
      text-align: center;
    }
    .mines-chip-grid {
      display: grid;
      grid-template-columns: repeat(6, 1fr);
      gap: 8px;
      margin-bottom: 16px;
    }
    .mine-chip {
      padding: 10px 0;
      background: #083478;
      border: 1px solid #1455b8;
      border-radius: 10px;
      text-align: center;
      font-size: 13px;
      font-weight: 800;
      cursor: pointer;
    }
    .mine-chip.active {
      background: #ffaa00;
      color: #291500;
      border-color: #ffcc00;
    }
  </style>
</head>
<body>

<div class="app-container">

  <!-- Top Header -->
  <div>
    <div class="top-bar">
      <i class="fa-solid fa-chevron-left back-btn"></i>
      <div class="wallet-pill">
        <div class="coin-badge">₹</div>
        <div class="balance-txt" id="walletBalance">₹0.00</div>
        <div class="btn-add-funds" onclick="location.href='/deposit'" title="Deposit">+</div>
      </div>
      <div class="top-right-tools">
        <div class="support-icon"><i class="fa-solid fa-headset"></i></div>
      </div>
    </div>

    <div class="game-title">MINES</div>

    <!-- Header Meta (Game ID & Next Multiplier Payout) -->
    <div class="info-header-row">
      <div class="game-id-badge" id="gameIdDisplay">Game ID: #849201</div>
      <div class="next-win-badge" id="nextWinDisplay">Next: 1.18x</div>
    </div>
  </div>

  <!-- 5x5 Mines Board (25 Tiles) -->
  <div class="grid-wrap">
    <div class="mines-grid" id="minesGrid">
      <!-- 25 tiles injected via JS -->
    </div>
  </div>

  <!-- Sub Controls -->
  <div>
    <div class="controls-row">
      <button class="btn-random" id="btnRandom" onclick="pickRandomTile()" disabled>RANDOM</button>
      <div class="auto-toggle-wrap">
        <div class="toggle-switch" onclick="toggleAuto()"><div class="toggle-dot" id="autoToggleDot"></div></div>
        <span>Auto Game</span>
      </div>
      <div class="mines-select-btn" id="btnOpenMines" onclick="openMinesModal()">
        <span>Mines: <b id="minesCountLabel" style="color:#ffc400;">3</b></span>
        <i class="fa-solid fa-chevron-down" style="font-size:10px;"></i>
      </div>
    </div>

    <!-- Dashboard Bet Controls -->
    <div class="dashboard-panel">
      <div class="bet-input-row">
        <div class="bet-amount-box">
          <span class="bet-lbl">Bet</span>
          <input type="number" id="betInput" class="bet-inp" value="10.00" min="10" step="10" />
        </div>
        <div class="step-btn" onclick="adjustBet(-10)">-</div>
        <div class="step-btn" onclick="multiplyBet(2)"><i class="fa-solid fa-coins"></i></div>
        <div class="step-btn" onclick="adjustBet(10)">+</div>
      </div>

      <div class="action-row">
        <div class="btn-circle-refresh" onclick="resetBoard()"><i class="fa-solid fa-rotate-right"></i></div>
        <button class="btn-main-action" id="btnMainAction" onclick="handleMainAction()">
          <i class="fa-solid fa-play" id="actionIcon"></i>
          <span id="actionLabel">BET</span>
        </button>
      </div>
    </div>

    <!-- Footer Status -->
    <div class="footer-bar">
      <i class="fa-regular fa-circle-question" onclick="alert('Mines Rules:\n1. Choose bet and number of mines.\n2. Click BET to start.\n3. Tap tiles to reveal Gems 💎 and increase multiplier.\n4. Hit Cashout anytime to take profits before hitting a Bomb 💣!')"></i>
      <span id="totalWinFooter">0.00 INR</span>
      <i class="fa-solid fa-bars"></i>
    </div>
  </div>

</div>

<!-- Mines Count Modal -->
<div class="mines-modal" id="minesModal">
  <div class="modal-sheet">
    <div class="sheet-title">Select Number of Mines (1 - 24)</div>
    <div class="mines-chip-grid" id="minesGridOptions"></div>
    <button class="btn-main-action" style="width:100%;" onclick="closeMinesModal()">Confirm</button>
  </div>
</div>

<script>
  // Web Audio Synthesizer for Mines SFX
  const SoundFx = {
    ctx: null,
    init() {
      if (!this.ctx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        this.ctx = new AudioContext();
      }
      if (this.ctx.state === 'suspended') this.ctx.resume();
    },
    tileClick() {
      this.init();
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, this.ctx.currentTime);
      gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.05);
    },
    gemChime(gemsCount) {
      this.init();
      const baseFreq = 450 + (gemsCount * 60);
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(baseFreq, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.5, this.ctx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.2);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.2);
    },
    explosion() {
      this.init();
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(30, this.ctx.currentTime + 0.4);
      gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.4);
    },
    cashout() {
      this.init();
      const notes = [523.25, 659.25, 783.99, 1046.50];
      notes.forEach((freq, idx) => {
        setTimeout(() => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
          gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.25);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start();
          osc.stop(this.ctx.currentTime + 0.25);
        }, idx * 80);
      });
    }
  };

  // State
  let balance = 0.00;
  let isPlaying = false;
  let minesCount = 3;
  let currentBet = 10.00;
  let tilesState = []; // 25 elements: 'gem' or 'mine'
  let revealedCount = 0;
  let currentMultiplier = 1.0;
  let gameId = 849201;

  function init() {
    loadBalanceFromServer();
    renderGrid();
    renderMinesSelectorChips();
    updateBalanceDisplay();
    updateNextPayoutPreview();
  }

  function renderGrid() {
    const grid = document.getElementById("minesGrid");
    grid.innerHTML = "";
    for (let i = 0; i < 25; i++) {
      grid.innerHTML += `
        <div class="tile" id="tile-${i}" onclick="onTileClick(${i})">
          <div class="tile-dot" id="dot-${i}"></div>
        </div>
      `;
    }
  }

  // Calculate Fair Multiplier for Mines
  function getMultiplierForGems(gemsFound, mines) {
    if (gemsFound === 0) return 1.0;
    let mult = 0.98;
    for (let i = 0; i < gemsFound; i++) {
      mult *= (25 - i) / (25 - mines - i);
    }
    return parseFloat(mult.toFixed(2));
  }

  function updateNextPayoutPreview() {
    const nextMult = getMultiplierForGems(revealedCount + 1, minesCount);
    const bet = parseFloat(document.getElementById("betInput").value) || 10;
    const nextVal = (bet * nextMult).toFixed(2);
    document.getElementById("nextWinDisplay").innerText = `Next: ${nextVal} INR (${nextMult}x)`;
  }

  // Cryptographically Secure Mines Layout Generation
  function generateFairMinesLayout(totalMines) {
    const arr = new Array(25).fill('gem');
    let placed = 0;
    while (placed < totalMines) {
      const randArr = new Uint32Array(1);
      window.crypto.getRandomValues(randArr);
      const idx = randArr[0] % 25;
      if (arr[idx] === 'gem') {
        arr[idx] = 'mine';
        placed++;
      }
    }
    return arr;
  }

  // Main Action: BET / CASHOUT
  async function handleMainAction() {
    SoundFx.init();
    if (!isPlaying) {
      // START BET
      const betAmt = parseFloat(document.getElementById("betInput").value);
      if (isNaN(betAmt) || betAmt <= 0) {
        alert("Enter a valid bet amount!");
        return;
      }
      if (balance < betAmt) {
        alert("⚠️ Insufficient Wallet Balance! Please deposit funds.");
        return;
      }

      const res = await updateServerBalance("subtract", betAmt);
      if (!res.ok) {
        alert(res.msg || "Insufficient balance");
        await loadBalanceFromServer();
        return;
      }
      balance = res.balance;
      currentBet = betAmt;
      updateBalanceDisplay();

      // Start new game
      isPlaying = true;
      revealedCount = 0;
      currentMultiplier = 1.0;
      tilesState = generateFairMinesLayout(minesCount);
      resetTileStyles();

      // UI Controls State
      document.getElementById("betInput").disabled = true;
      document.getElementById("btnRandom").disabled = false;
      document.getElementById("btnOpenMines").style.pointerEvents = "none";
      document.getElementById("gameIdDisplay").innerText = `Game ID: #${++gameId}`;

      updateActionButtonState();
      updateNextPayoutPreview();
    } else {
      // CASHOUT
      if (revealedCount === 0) return;
      const winAmt = currentBet * currentMultiplier;
      updateServerBalance("add", winAmt).then(res => {
        if (res.ok) { balance = res.balance; updateBalanceDisplay(); }
      });
      SoundFx.cashout();

      alert(`🎉 Won ₹${winAmt.toFixed(2)} (${currentMultiplier}x)!`);
      revealAllTiles(true);
      endGame();
    }
  }

  function onTileClick(index) {
    if (!isPlaying) return;
    const tileEl = document.getElementById(`tile-${index}`);
    if (tileEl.classList.contains("revealed")) return;

    SoundFx.tileClick();

    if (tilesState[index] === 'mine') {
      // BOOM! MINE HIT!
      tileEl.classList.add("revealed", "mine");
      tileEl.innerHTML = `<span class="mine-icon">💣</span>`;
      SoundFx.explosion();
      revealAllTiles(false);
      endGame();
      setTimeout(() => alert("💥 BOOM! You hit a mine. Better luck next time!"), 150);
    } else {
      // GEM REVEALED!
      revealedCount++;
      currentMultiplier = getMultiplierForGems(revealedCount, minesCount);
      tileEl.classList.add("revealed", "gem");
      tileEl.innerHTML = `<span class="gem-icon">💎</span>`;
      SoundFx.gemChime(revealedCount);

      const curWin = (currentBet * currentMultiplier).toFixed(2);
      document.getElementById("totalWinFooter").innerText = `${curWin} INR`;
      updateNextPayoutPreview();
      updateActionButtonState();

      // Check if all gems uncovered
      if (revealedCount === (25 - minesCount)) {
        handleMainAction(); // Auto cashout max win
      }
    }
  }

  function pickRandomTile() {
    if (!isPlaying) return;
    const available = [];
    for (let i = 0; i < 25; i++) {
      const t = document.getElementById(`tile-${i}`);
      if (!t.classList.contains("revealed")) available.push(i);
    }
    if (available.length === 0) return;
    const randArr = new Uint32Array(1);
    window.crypto.getRandomValues(randArr);
    const chosen = available[randArr[0] % available.length];
    onTileClick(chosen);
  }

  function revealAllTiles(userWon) {
    for (let i = 0; i < 25; i++) {
      const t = document.getElementById(`tile-${i}`);
      if (!t.classList.contains("revealed")) {
        t.classList.add("revealed");
        if (tilesState[i] === 'mine') {
          t.classList.add("mine");
          t.innerHTML = `<span class="mine-icon" style="opacity:0.75;">💣</span>`;
        } else {
          t.classList.add("gem");
          t.innerHTML = `<span class="gem-icon" style="opacity:0.6;">💎</span>`;
        }
      }
    }
  }

  function updateActionButtonState() {
    const btn = document.getElementById("btnMainAction");
    const lbl = document.getElementById("actionLabel");
    const icon = document.getElementById("actionIcon");

    if (isPlaying) {
      if (revealedCount > 0) {
        const cashoutVal = (currentBet * currentMultiplier).toFixed(2);
        btn.className = "btn-main-action cashout";
        icon.className = "fa-solid fa-coins";
        lbl.innerText = `CASHOUT ₹${cashoutVal}`;
      } else {
        btn.className = "btn-main-action";
        icon.className = "fa-solid fa-spinner fa-spin";
        lbl.innerText = "PICK A TILE";
      }
    } else {
      btn.className = "btn-main-action";
      icon.className = "fa-solid fa-play";
      lbl.innerText = "BET";
    }
  }

  function endGame() {
    isPlaying = false;
    document.getElementById("betInput").disabled = false;
    document.getElementById("btnRandom").disabled = true;
    document.getElementById("btnOpenMines").style.pointerEvents = "auto";
    updateActionButtonState();
  }

  function resetTileStyles() {
    for (let i = 0; i < 25; i++) {
      const t = document.getElementById(`tile-${i}`);
      t.className = "tile";
      t.innerHTML = `<div class="tile-dot" id="dot-${i}"></div>`;
    }
  }

  function resetBoard() {
    if (isPlaying) {
      if (!confirm("Quit current game? Current bet will be forfeited.")) return;
      endGame();
    }
    resetTileStyles();
    document.getElementById("totalWinFooter").innerText = "0.00 INR";
    updateNextPayoutPreview();
  }

  // Bet adjustments
  function adjustBet(delta) {
    if (isPlaying) return;
    const inp = document.getElementById("betInput");
    let val = parseFloat(inp.value) || 10;
    val = Math.max(10, val + delta);
    inp.value = val.toFixed(2);
    updateNextPayoutPreview();
  }

  function multiplyBet(factor) {
    if (isPlaying) return;
    const inp = document.getElementById("betInput");
    let val = parseFloat(inp.value) || 10;
    val = Math.max(10, val * factor);
    inp.value = val.toFixed(2);
    updateNextPayoutPreview();
  }

  function updateBalanceDisplay() {
    document.getElementById("walletBalance").innerText = `₹${balance.toFixed(2)}`;
  }

  function loadBalanceFromServer() {
    return fetch('/account_balance').then(r => r.json()).then(data => {
      if (data.ok) {
        balance = data.balance;
        updateBalanceDisplay();
      }
    }).catch(() => {});
  }

  function updateServerBalance(action, amount) {
    return fetch('/update_balance', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({action: action, amount: amount})
    }).then(r => r.json());
  }

  // Mines Count Selector Modal
  function renderMinesSelectorChips() {
    const grid = document.getElementById("minesGridOptions");
    grid.innerHTML = "";
    for (let i = 1; i <= 24; i++) {
      grid.innerHTML += `
        <div class="mine-chip ${i === minesCount ? 'active' : ''}" onclick="selectMinesCount(${i}, this)">${i}</div>
      `;
    }
  }

  function openMinesModal() {
    if (isPlaying) return;
    document.getElementById("minesModal").style.display = "flex";
  }

  function closeMinesModal() {
    document.getElementById("minesModal").style.display = "none";
  }

  function selectMinesCount(count, elem) {
    minesCount = count;
    document.querySelectorAll(".mine-chip").forEach(c => c.classList.remove("active"));
    elem.classList.add("active");
    document.getElementById("minesCountLabel").innerText = count;
    updateNextPayoutPreview();
    closeMinesModal();
  }

  function toggleAuto() {
    const dot = document.getElementById("autoToggleDot");
    dot.style.left = dot.style.left === "20px" ? "2px" : "20px";
  }

  window.onload = init;
</script>

</body>
</html>'''
