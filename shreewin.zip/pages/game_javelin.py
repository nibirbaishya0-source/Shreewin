html_javelin = r'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Shree.Win - JAVELIN Pro</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    :root {
      --bg-dark: #0d1117;
      --card-bg: #161c26;
      --card-inner: #212936;
      --accent-green: #00e676;
      --btn-green: linear-gradient(180deg, #00e676 0%, #00a844 100%);
      --btn-orange: linear-gradient(180deg, #ffb300 0%, #e66a00 100%);
      --accent-red: #ff334b;
      --accent-yellow: #ffb703;
      --text-muted: #8b9bb4;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
      user-select: none;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #05070a;
      display: flex;
      justify-content: center;
      min-height: 100vh;
      color: #fff;
    }

    .app-container {
      width: 100%;
      max-width: 440px;
      background: var(--bg-dark);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      position: relative;
      box-shadow: 0 0 30px rgba(0,0,0,0.9);
      padding-bottom: 24px;
    }

    /* Top Bar */
    .top-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
      background: #0d1117;
    }
    .back-btn { font-size: 20px; color: #fff; cursor: pointer; }
    .wallet-pill {
      display: flex;
      align-items: center;
      background: #161c26;
      border: 1px solid #283344;
      border-radius: 20px;
      padding: 4px 12px 4px 4px;
      gap: 6px;
      cursor: pointer;
    }
    .coin-badge {
      width: 26px;
      height: 26px;
      background: radial-gradient(circle at 35% 35%, #fffb91 0%, #ffaa00 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
      color: #733c00;
      font-weight: 900;
    }
    .balance-txt { font-size: 15px; font-weight: 800; color: #fff; }
    .support-icon {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: radial-gradient(circle, #00d2ff, #0077ff);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
    }

    /* Sub Header */
    .game-sub-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 16px 8px 16px;
    }
    .game-title {
      font-size: 19px;
      font-weight: 900;
      font-style: italic;
      letter-spacing: 1px;
      color: #fff;
    }
    .tools-right {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .help-btn {
      width: 22px;
      height: 22px;
      background: #ffaa00;
      color: #2b1800;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: 900;
      cursor: pointer;
    }
    .win-inr-tag {
      font-size: 13px;
      font-weight: 800;
      color: #00e676;
    }

    /* History Multiplier Strip */
    .history-row {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 0 16px 8px 16px;
      overflow-x: auto;
      scrollbar-width: none;
    }
    .history-row::-webkit-scrollbar { display: none; }
    .h-chip {
      font-size: 11px;
      font-weight: 800;
      padding: 3px 9px;
      border-radius: 12px;
      white-space: nowrap;
      background: #18202c;
    }
    .h-chip.high { color: #d654ff; background: rgba(214, 84, 255, 0.15); border: 1px solid rgba(214, 84, 255, 0.3); }
    .h-chip.mid  { color: #00d2ff; background: rgba(0, 210, 255, 0.15); border: 1px solid rgba(0, 210, 255, 0.3); }
    .h-chip.low  { color: #8b9bb4; border: 1px solid rgba(139, 155, 180, 0.2); }

    .round-meta-strip {
      display: flex;
      justify-content: space-between;
      padding: 0 16px 6px 16px;
      font-size: 10px;
      color: var(--text-muted);
    }

    /* Canvas Arena */
    .arena-box {
      margin: 0 12px 12px 12px;
      height: 230px;
      background: radial-gradient(circle at 50% 30%, #152238 0%, #080d14 100%);
      border-radius: 16px;
      position: relative;
      overflow: hidden;
      border: 1px solid #232d3d;
      box-shadow: inset 0 0 20px rgba(0,0,0,0.8);
    }
    #javelinCanvas {
      width: 100%;
      height: 100%;
      display: block;
    }
    .overlay-center {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      z-index: 5;
    }
    .main-mult-text {
      font-size: 54px;
      font-weight: 900;
      color: #fff;
      text-shadow: 0 4px 20px rgba(0,0,0,0.8), 0 0 30px rgba(0, 230, 118, 0.4);
      letter-spacing: 0.5px;
    }
    .main-mult-text.crashed {
      color: var(--accent-red);
      text-shadow: 0 0 30px rgba(255, 51, 75, 0.8);
    }
    .wait-countdown {
      font-size: 16px;
      font-weight: 800;
      color: #ffb703;
      background: rgba(0,0,0,0.6);
      padding: 6px 16px;
      border-radius: 20px;
      border: 1px solid #ffb703;
    }

    /* Dual Panels */
    .dual-panels-wrap {
      display: flex;
      flex-direction: column;
      gap: 10px;
      padding: 0 12px;
      margin-bottom: 14px;
    }
    .bet-card-panel {
      background: var(--card-bg);
      border-radius: 16px;
      padding: 10px 14px;
      border: 1px solid #232d3d;
    }
    .panel-sub-tabs {
      display: flex;
      background: #0d1117;
      border-radius: 14px;
      padding: 2px;
      width: 140px;
      margin: 0 auto 8px auto;
    }
    .p-tab {
      flex: 1;
      text-align: center;
      font-size: 11px;
      padding: 4px 0;
      border-radius: 12px;
      color: var(--text-muted);
      cursor: pointer;
      font-weight: 700;
    }
    .p-tab.active {
      background: #253144;
      color: #fff;
    }

    .panel-controls-grid {
      display: grid;
      grid-template-columns: 1fr 1.2fr;
      gap: 12px;
      align-items: center;
    }
    .amount-inputs-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .input-spinner-row {
      display: flex;
      align-items: center;
      background: #0d1117;
      border: 1px solid #253144;
      border-radius: 20px;
      padding: 4px 8px;
      justify-content: space-between;
    }
    .btn-spinner {
      width: 26px;
      height: 26px;
      background: #1c2534;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
      font-weight: 800;
      color: #8b9bb4;
      cursor: pointer;
    }
    .btn-spinner:active { transform: scale(0.9); }
    .bet-val-input {
      background: transparent;
      border: none;
      color: #fff;
      font-size: 15px;
      font-weight: 800;
      text-align: center;
      width: 55px;
      outline: none;
    }
    .quick-chips-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 4px;
    }
    .chip-btn {
      background: #0d1117;
      border: 1px solid #232d3d;
      border-radius: 8px;
      padding: 4px 0;
      font-size: 10px;
      font-weight: 700;
      color: var(--text-muted);
      text-align: center;
      cursor: pointer;
    }
    .chip-btn:active { background: #253144; color: #fff; }

    /* Auto Settings Controls inside Panel */
    .auto-config-box {
      display: none;
      flex-direction: column;
      gap: 6px;
      margin-top: 4px;
      padding-top: 6px;
      border-top: 1px solid #232d3d;
    }
    .auto-toggle-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 11px;
      color: var(--text-muted);
      font-weight: 600;
    }
    .switch-ui {
      width: 34px;
      height: 18px;
      background: #253144;
      border-radius: 10px;
      position: relative;
      cursor: pointer;
      transition: background 0.2s;
    }
    .switch-ui.on { background: #00e676; }
    .switch-dot {
      width: 14px;
      height: 14px;
      background: #fff;
      border-radius: 50%;
      position: absolute;
      top: 2px;
      left: 2px;
      transition: left 0.2s;
    }
    .switch-ui.on .switch-dot { left: 18px; }

    /* Action Buttons */
    .btn-action-bet {
      height: 64px;
      background: var(--btn-green);
      border: none;
      border-radius: 14px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-weight: 900;
      font-size: 15px;
      cursor: pointer;
      box-shadow: 0 4px 14px rgba(0, 230, 118, 0.35);
      line-height: 1.2;
      transition: transform 0.1s;
    }
    .btn-action-bet:active { transform: scale(0.97); }
    .btn-action-bet.cashout {
      background: var(--btn-orange);
      box-shadow: 0 4px 14px rgba(255, 179, 0, 0.4);
      color: #231200;
    }
    .btn-action-bet.waiting {
      background: #232d3d;
      color: #8b9bb4;
      box-shadow: none;
    }

    /* Live Feed & Tabs */
    .live-feed-card {
      margin: 0 12px;
      background: var(--card-bg);
      border-radius: 16px;
      padding: 12px 14px;
      border: 1px solid #232d3d;
    }
    .feed-tabs-row {
      display: flex;
      background: #0d1117;
      border-radius: 10px;
      padding: 3px;
      margin-bottom: 10px;
    }
    .f-tab {
      flex: 1;
      text-align: center;
      font-size: 12px;
      padding: 6px 0;
      color: var(--text-muted);
      font-weight: 700;
      cursor: pointer;
      border-radius: 8px;
    }
    .f-tab.active {
      background: #253144;
      color: #fff;
    }
    .feed-header-info {
      font-size: 12px;
      font-weight: 800;
      color: #fff;
      margin-bottom: 8px;
    }
    .live-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 11px;
    }
    .live-table th {
      color: var(--text-muted);
      font-weight: 600;
      padding: 6px 4px;
      text-align: left;
      border-bottom: 1px solid #232d3d;
    }
    .live-table td {
      padding: 7px 4px;
      border-bottom: 1px solid rgba(255,255,255,0.03);
      vertical-align: middle;
    }
    .user-cell {
      display: flex;
      align-items: center;
      gap: 6px;
      font-weight: 700;
      color: #fff;
    }
    .avatar-circ {
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: #2a384e;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
    }
    .cashout-tag {
      background: rgba(0, 230, 118, 0.15);
      color: #00e676;
      padding: 2px 6px;
      border-radius: 6px;
      font-weight: 800;
    }

    .provably-fair-tag {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      font-size: 11px;
      color: var(--text-muted);
      margin-top: 14px;
    }
    .provably-fair-tag i { color: #00e676; }
  </style>
</head>
<body>

<div class="app-container">

  <!-- Top Bar -->
  <div class="top-bar">
    <i class="fa-solid fa-chevron-left back-btn"></i>
    <div class="wallet-pill" onclick="location.href='/deposit'" title="Deposit">
      <div class="coin-badge">₹</div>
      <div class="balance-txt" id="walletBalance">₹0.00</div>
    </div>
    <div class="support-icon"><i class="fa-solid fa-headset"></i></div>
  </div>

  <!-- Sub Header -->
  <div class="game-sub-header">
    <div class="game-title">JAVELIN</div>
    <div class="tools-right">
      <div class="help-btn" onclick="alert('Javelin Rules:\n1. Place Bet on Panel 1 or 2.\n2. Auto Cashout automatically cashes out at target multiplier.\n3. Cashout before javelin crashes to win!')">?</div>
      <div class="win-inr-tag" id="topWinTag">0 INR</div>
      <i class="fa-solid fa-bars" style="color:#8b9bb4; cursor:pointer;"></i>
    </div>
  </div>

  <!-- History Multipliers -->
  <div class="history-row" id="historyRow"></div>

  <div class="round-meta-strip">
    <span>Round ID: <b id="roundIdTxt">19496995</b></span>
    <span>Ping: <b style="color:#00e676;">176ms</b></span>
  </div>

  <!-- Stadium Canvas Arena -->
  <div class="arena-box">
    <canvas id="javelinCanvas"></canvas>
    <div class="overlay-center">
      <div class="wait-countdown" id="waitCountdownBox" style="display:none;">Next Throw in 5s</div>
      <div class="main-mult-text" id="mainMultDisplay">1.00x</div>
    </div>
  </div>

  <!-- Dual Bet Panels -->
  <div class="dual-panels-wrap">

    <!-- Panel 1 -->
    <div class="bet-card-panel">
      <div class="panel-sub-tabs">
        <div class="p-tab active" id="tabMode1_manual" onclick="switchPanelTab(1, 'manual')">Bet</div>
        <div class="p-tab" id="tabMode1_auto" onclick="switchPanelTab(1, 'auto')">Auto</div>
      </div>
      <div class="panel-controls-grid">
        <div class="amount-inputs-group">
          <div class="input-spinner-row">
            <div class="btn-spinner" onclick="adjustPanelBet(1, -10)">-</div>
            <input type="number" id="panel1BetInp" class="bet-val-input" value="10" min="10" step="10" oninput="updatePanelUI(1)" />
            <div class="btn-spinner" onclick="adjustPanelBet(1, 10)">+</div>
          </div>
          <div class="quick-chips-grid">
            <div class="chip-btn" onclick="setPanelChip(1, 10)">10</div>
            <div class="chip-btn" onclick="setPanelChip(1, 100)">100</div>
            <div class="chip-btn" onclick="setPanelChip(1, 500)">500</div>
            <div class="chip-btn" onclick="setPanelChip(1, 1000)">1000</div>
          </div>
        </div>
        <button class="btn-action-bet" id="btnPanel1" onclick="handlePanelAction(1)">
          <span>BET</span>
          <span id="btnPanel1Amt">10 INR</span>
        </button>
      </div>

      <!-- Auto Config for Panel 1 -->
      <div class="auto-config-box" id="autoConfig1">
        <div class="auto-toggle-row">
          <span>Auto Bet:</span>
          <div class="switch-ui" id="autoBetSwitch1" onclick="toggleAutoBet(1)"><div class="switch-dot"></div></div>
        </div>
        <div class="auto-toggle-row">
          <span>Auto Cash Out (X):</span>
          <div style="display:flex; align-items:center; gap:6px;">
            <input type="number" id="autoCashoutInp1" value="2.00" step="0.1" min="1.05" style="width:60px; background:#0d1117; border:1px solid #253144; color:#fff; border-radius:8px; padding:2px 6px; font-weight:700; text-align:center; font-size:11px;" />
            <div class="switch-ui" id="autoCashoutSwitch1" onclick="toggleAutoCashout(1)"><div class="switch-dot"></div></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Panel 2 -->
    <div class="bet-card-panel">
      <div class="panel-sub-tabs">
        <div class="p-tab active" id="tabMode2_manual" onclick="switchPanelTab(2, 'manual')">Bet</div>
        <div class="p-tab" id="tabMode2_auto" onclick="switchPanelTab(2, 'auto')">Auto</div>
      </div>
      <div class="panel-controls-grid">
        <div class="amount-inputs-group">
          <div class="input-spinner-row">
            <div class="btn-spinner" onclick="adjustPanelBet(2, -10)">-</div>
            <input type="number" id="panel2BetInp" class="bet-val-input" value="10" min="10" step="10" oninput="updatePanelUI(2)" />
            <div class="btn-spinner" onclick="adjustPanelBet(2, 10)">+</div>
          </div>
          <div class="quick-chips-grid">
            <div class="chip-btn" onclick="setPanelChip(2, 10)">10</div>
            <div class="chip-btn" onclick="setPanelChip(2, 100)">100</div>
            <div class="chip-btn" onclick="setPanelChip(2, 500)">500</div>
            <div class="chip-btn" onclick="setPanelChip(2, 1000)">1000</div>
          </div>
        </div>
        <button class="btn-action-bet" id="btnPanel2" onclick="handlePanelAction(2)">
          <span>BET</span>
          <span id="btnPanel2Amt">10 INR</span>
        </button>
      </div>

      <!-- Auto Config for Panel 2 -->
      <div class="auto-config-box" id="autoConfig2">
        <div class="auto-toggle-row">
          <span>Auto Bet:</span>
          <div class="switch-ui" id="autoBetSwitch2" onclick="toggleAutoBet(2)"><div class="switch-dot"></div></div>
        </div>
        <div class="auto-toggle-row">
          <span>Auto Cash Out (X):</span>
          <div style="display:flex; align-items:center; gap:6px;">
            <input type="number" id="autoCashoutInp2" value="2.00" step="0.1" min="1.05" style="width:60px; background:#0d1117; border:1px solid #253144; color:#fff; border-radius:8px; padding:2px 6px; font-weight:700; text-align:center; font-size:11px;" />
            <div class="switch-ui" id="autoCashoutSwitch2" onclick="toggleAutoCashout(2)"><div class="switch-dot"></div></div>
          </div>
        </div>
      </div>
    </div>

  </div>

  <!-- Live Feed: All Bets, My Bets, Top -->
  <div class="live-feed-card">
    <div class="feed-tabs-row">
      <div class="f-tab active" id="fTab_all" onclick="switchFeedTab('all')">All Bets</div>
      <div class="f-tab" id="fTab_my" onclick="switchFeedTab('my')">My Bets</div>
      <div class="f-tab" id="fTab_top" onclick="switchFeedTab('top')">Top</div>
    </div>

    <!-- View: All Bets -->
    <div id="feedView_all">
      <div class="feed-header-info">ALL BETS <span style="color:#00e676;" id="livePlayerCount">804</span></div>
      <table class="live-table">
        <thead>
          <tr>
            <th>User</th>
            <th>Bet, INR</th>
            <th>X</th>
            <th style="text-align:right;">Cash out, INR</th>
          </tr>
        </thead>
        <tbody id="liveBetsBody"></tbody>
      </table>
    </div>

    <!-- View: My Bets -->
    <div id="feedView_my" style="display:none;">
      <div class="feed-header-info">MY BET HISTORY</div>
      <table class="live-table">
        <thead>
          <tr>
            <th>Round</th>
            <th>Bet, INR</th>
            <th>X</th>
            <th style="text-align:right;">Cash out, INR</th>
          </tr>
        </thead>
        <tbody id="myBetsBody">
          <tr><td colspan="4" style="text-align:center; color:var(--text-muted); padding:14px;">No bets placed yet</td></tr>
        </tbody>
      </table>
    </div>

    <!-- View: Top Bets -->
    <div id="feedView_top" style="display:none;">
      <div class="feed-header-info">TOP WINNERS LEADERBOARD</div>
      <table class="live-table">
        <thead>
          <tr>
            <th>User</th>
            <th>Bet, INR</th>
            <th>X</th>
            <th style="text-align:right;">Cash out, INR</th>
          </tr>
        </thead>
        <tbody id="topBetsBody"></tbody>
      </table>
    </div>
  </div>

  <!-- Provably Fair Banner -->
  <div class="provably-fair-tag">
    <i class="fa-solid fa-shield-halved"></i>
    <span>This game is <b>Provably Fair</b></span>
  </div>

</div>

<script>
  // Web Audio Synthesizer
  const SoundFx = {
    ctx: null,
    init() {
      if (!this.ctx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        this.ctx = new AudioContext();
      }
      if (this.ctx.state === 'suspended') this.ctx.resume();
    },
    throwWhoosh() {
      this.init();
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(180, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(700, this.ctx.currentTime + 0.4);
      gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.4);
    },
    cashoutChime() {
      this.init();
      const notes = [523.25, 659.25, 783.99, 1046.50];
      notes.forEach((f, i) => {
        setTimeout(() => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(f, this.ctx.currentTime);
          gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.2);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start();
          osc.stop(this.ctx.currentTime + 0.2);
        }, i * 60);
      });
    },
    crashImpact() {
      this.init();
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(30, this.ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.18, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.3);
    }
  };

  // State
  let balance = 0.00;
  let roundId = 19496995;
  let gameState = 'WAITING'; // WAITING, FLYING, CRASHED
  let currentMultiplier = 1.00;
  let crashMultiplier = 2.50;
  let waitCountdown = 5;

  const panelConfig = {
    1: { autoBet: false, autoCashout: false, autoCashoutVal: 2.00 },
    2: { autoBet: false, autoCashout: false, autoCashoutVal: 2.00 }
  };

  const bets = {
    1: { active: false, cashed: false, amount: 10, payout: 0 },
    2: { active: false, cashed: false, amount: 10, payout: 0 }
  };

  const myBetsHistory = JSON.parse(localStorage.getItem("javelin_my_history")) || [];
  const historyMultipliers = [30.33, 3.94, 2.20, 3.53, 1.27, 2.70, 1.15, 8.42];

  // Canvas
  const canvas = document.getElementById("javelinCanvas");
  const ctx = canvas.getContext("2d");
  let javelinX = 0, javelinY = 0;
  let trailParticles = [];

  function init() {
    loadBalanceFromServer();
    initCanvas();
    updateWalletDisplay();
    renderHistoryRow();
    generateSimulatedPlayers();
    renderTopWinners();
    renderMyBetsUI();
    startMasterGameLoop();
  }

  function initCanvas() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
  }

  function generateFairCrashPoint() {
    const arr = new Uint32Array(1);
    window.crypto.getRandomValues(arr);
    const u = (arr[0] + 1) / (0xFFFFFFFF + 1);
    const raw = 0.99 / (1 - u);
    return Math.max(1.00, parseFloat(raw.toFixed(2)));
  }

  function startMasterGameLoop() {
    runWaitingPhase();
  }

  function runWaitingPhase() {
    gameState = 'WAITING';
    waitCountdown = 5;
    currentMultiplier = 1.00;
    trailParticles = [];

    // Reset bets & handle auto-bets
    for (let p of [1, 2]) {
      bets[p].cashed = false;
      if (panelConfig[p].autoBet && !bets[p].active) {
        placeBet(p);
      } else {
        updatePanelUI(p);
      }
    }

    generateSimulatedPlayers();
    document.getElementById("waitCountdownBox").style.display = "block";
    document.getElementById("mainMultDisplay").className = "main-mult-text";
    document.getElementById("mainMultDisplay").innerText = "1.00x";

    const waitTimer = setInterval(() => {
      waitCountdown--;
      document.getElementById("waitCountdownBox").innerText = `Next Throw in ${waitCountdown}s`;
      if (waitCountdown <= 0) {
        clearInterval(waitTimer);
        document.getElementById("waitCountdownBox").style.display = "none";
        launchJavelinFlight();
      }
    }, 1000);
  }

  function launchJavelinFlight() {
    gameState = 'FLYING';
    crashMultiplier = generateFairCrashPoint();
    SoundFx.throwWhoosh();

    const startTime = performance.now();
    javelinX = 40;
    javelinY = canvas.height - 40;

    for (let p of [1, 2]) {
      updatePanelUI(p);
    }

    function flightStep(now) {
      if (gameState !== 'FLYING') return;

      const elapsed = (now - startTime) / 1000;
      currentMultiplier = parseFloat((1.00 + Math.pow(elapsed * 0.7, 1.8)).toFixed(2));

      document.getElementById("mainMultDisplay").innerText = `${currentMultiplier.toFixed(2)}x`;

      // Check Auto-Cashout & Update Live Buttons
      for (let p of [1, 2]) {
        if (bets[p].active && !bets[p].cashed) {
          // Auto Cashout Check
          if (panelConfig[p].autoCashout && currentMultiplier >= panelConfig[p].autoCashoutVal) {
            executeCashout(p);
          } else {
            const winVal = (bets[p].amount * currentMultiplier).toFixed(2);
            document.getElementById(`btnPanel${p}`).innerHTML = `
              <span>CASHOUT</span>
              <span>₹${winVal}</span>
            `;
          }
        }
      }

      // Check Crash
      if (currentMultiplier >= crashMultiplier) {
        handleCrashEvent();
        return;
      }

      updateSimulatedPlayers(currentMultiplier);
      requestAnimationFrame(flightStep);
    }

    requestAnimationFrame(flightStep);
  }

  function handleCrashEvent() {
    gameState = 'CRASHED';
    SoundFx.crashImpact();

    document.getElementById("mainMultDisplay").className = "main-mult-text crashed";
    document.getElementById("mainMultDisplay").innerText = `CRASHED @ ${crashMultiplier.toFixed(2)}x`;

    // Settle active bets
    for (let p of [1, 2]) {
      if (bets[p].active && !bets[p].cashed) {
        recordMyBet(roundId, bets[p].amount, 0, false);
        bets[p].active = false;
      }
      updatePanelUI(p);
    }

    historyMultipliers.unshift(crashMultiplier);
    if (historyMultipliers.length > 10) historyMultipliers.pop();
    renderHistoryRow();

    roundId++;
    document.getElementById("roundIdTxt").innerText = roundId;

    setTimeout(() => {
      runWaitingPhase();
    }, 3000);
  }

  async function placeBet(panelNum) {
    const inp = document.getElementById(`panel${panelNum}BetInp`);
    const amt = parseFloat(inp.value);

    if (isNaN(amt) || amt <= 0) return;
    if (balance < amt) {
      if (!panelConfig[panelNum].autoBet) {
        alert("⚠️ Insufficient Wallet Balance! Please deposit funds.");
      }
      return;
    }

    const res = await updateServerBalance("subtract", amt);
    if (!res.ok) {
      if (!panelConfig[panelNum].autoBet) alert(res.msg || "Insufficient balance");
      await loadBalanceFromServer();
      return;
    }
    balance = res.balance;
    updateWalletDisplay();
    bets[panelNum].active = true;
    bets[panelNum].amount = amt;
    bets[panelNum].cashed = false;
    updatePanelUI(panelNum);
  }

  function handlePanelAction(panelNum) {
    SoundFx.init();
    const b = bets[panelNum];

    if (gameState === 'WAITING') {
      if (b.active) {
        // Cancel Bet - refund
        updateServerBalance("add", b.amount).then(res => {
          if (res.ok) { balance = res.balance; updateWalletDisplay(); }
        });
        b.active = false;
        updatePanelUI(panelNum);
      } else {
        placeBet(panelNum);
      }
    } else if (gameState === 'FLYING') {
      if (b.active && !b.cashed) {
        executeCashout(panelNum);
      }
    }
  }

  function executeCashout(panelNum) {
    const b = bets[panelNum];
    b.cashed = true;
    b.payout = b.amount * currentMultiplier;
    updateServerBalance("add", b.payout).then(res => {
      if (res.ok) { balance = res.balance; updateWalletDisplay(); }
    });
    SoundFx.cashoutChime();

    document.getElementById("topWinTag").innerText = `+${b.payout.toFixed(2)} INR`;
    recordMyBet(roundId, b.amount, currentMultiplier, true, b.payout);
    updatePanelUI(panelNum);
  }

  function updatePanelUI(panelNum) {
    const btn = document.getElementById(`btnPanel${panelNum}`);
    const b = bets[panelNum];

    if (gameState === 'WAITING') {
      if (b.active) {
        btn.className = "btn-action-bet waiting";
        btn.innerHTML = `<span>CANCEL</span><span>₹${b.amount}</span>`;
      } else {
        const amt = document.getElementById(`panel${panelNum}BetInp`).value;
        btn.className = "btn-action-bet";
        btn.innerHTML = `<span>BET</span><span>${amt} INR</span>`;
      }
    } else if (gameState === 'FLYING') {
      if (b.active && !b.cashed) {
        btn.className = "btn-action-bet cashout";
      } else if (b.cashed) {
        btn.className = "btn-action-bet waiting";
        btn.innerHTML = `<span>CASHED</span><span>₹${b.payout.toFixed(2)}</span>`;
      } else {
        btn.className = "btn-action-bet waiting";
        btn.innerHTML = `<span>BET</span><span>(Next Round)</span>`;
      }
    } else if (gameState === 'CRASHED') {
      btn.className = "btn-action-bet waiting";
      btn.innerHTML = `<span>BET</span><span>(Ended)</span>`;
    }
  }

  // Panel Auto Controls
  function switchPanelTab(panelNum, mode) {
    document.getElementById(`tabMode${panelNum}_manual`).className = (mode === 'manual') ? 'p-tab active' : 'p-tab';
    document.getElementById(`tabMode${panelNum}_auto`).className = (mode === 'auto') ? 'p-tab active' : 'p-tab';
    document.getElementById(`autoConfig${panelNum}`).style.display = (mode === 'auto') ? 'flex' : 'none';
  }

  function toggleAutoBet(panelNum) {
    panelConfig[panelNum].autoBet = !panelConfig[panelNum].autoBet;
    document.getElementById(`autoBetSwitch${panelNum}`).className = panelConfig[panelNum].autoBet ? 'switch-ui on' : 'switch-ui';
  }

  function toggleAutoCashout(panelNum) {
    panelConfig[panelNum].autoCashout = !panelConfig[panelNum].autoCashout;
    const val = parseFloat(document.getElementById(`autoCashoutInp${panelNum}`).value) || 2.00;
    panelConfig[panelNum].autoCashoutVal = Math.max(1.05, val);
    document.getElementById(`autoCashoutSwitch${panelNum}`).className = panelConfig[panelNum].autoCashout ? 'switch-ui on' : 'switch-ui';
  }

  function adjustPanelBet(panelNum, delta) {
    if (bets[panelNum].active && gameState === 'WAITING') return;
    const inp = document.getElementById(`panel${panelNum}BetInp`);
    let val = parseFloat(inp.value) || 10;
    val = Math.max(10, val + delta);
    inp.value = val;
    updatePanelUI(panelNum);
  }

  function setPanelChip(panelNum, val) {
    if (bets[panelNum].active && gameState === 'WAITING') return;
    document.getElementById(`panel${panelNum}BetInp`).value = val;
    updatePanelUI(panelNum);
  }

  function loadBalanceFromServer() {
    return fetch('/account_balance').then(r => r.json()).then(data => {
      if (data.ok) {
        balance = data.balance;
        updateWalletDisplay();
      }
    }).catch(() => {});
  }

  function updateServerBalance(action, amount) {
    return fetch('/update_balance', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({action: action, amount: amount})
    }).then(r => r.json());
  }

  function updateWalletDisplay() {
    document.getElementById("walletBalance").innerText = `₹${balance.toFixed(2)}`;
  }

  function renderHistoryRow() {
    const row = document.getElementById("historyRow");
    row.innerHTML = "";
    historyMultipliers.forEach(m => {
      let cls = 'low';
      if (m >= 10) cls = 'high';
      else if (m >= 2.0) cls = 'mid';
      row.innerHTML += `<div class="h-chip ${cls}">${m.toFixed(2)}x</div>`;
    });
  }

  // Feed Tabs (All Bets, My Bets, Top)
  function switchFeedTab(tabKey) {
    document.querySelectorAll(".feed-tabs-row .f-tab").forEach(t => t.classList.remove("active"));
    document.getElementById(`fTab_${tabKey}`).classList.add("active");
    document.getElementById("feedView_all").style.display = (tabKey === 'all') ? 'block' : 'none';
    document.getElementById("feedView_my").style.display = (tabKey === 'my') ? 'block' : 'none';
    document.getElementById("feedView_top").style.display = (tabKey === 'top') ? 'block' : 'none';
  }

  function recordMyBet(round, betAmt, mult, won, payout = 0) {
    myBetsHistory.unshift({ round, betAmt, mult, won, payout });
    if (myBetsHistory.length > 25) myBetsHistory.pop();
    localStorage.setItem("javelin_my_history", JSON.stringify(myBetsHistory));
    renderMyBetsUI();
  }

  function renderMyBetsUI() {
    const tbody = document.getElementById("myBetsBody");
    if (myBetsHistory.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:var(--text-muted); padding:14px;">No bets placed yet</td></tr>`;
      return;
    }
    tbody.innerHTML = "";
    myBetsHistory.forEach(item => {
      tbody.innerHTML += `
        <tr>
          <td style="font-weight:700;">#${item.round}</td>
          <td>₹${item.betAmt.toFixed(2)}</td>
          <td>${item.won ? `<span class="cashout-tag">${item.mult.toFixed(2)}x</span>` : '<span style="color:#ff5252;">-</span>'}</td>
          <td style="text-align:right; font-weight:700; color:${item.won ? '#00e676' : '#ff5252'};">
            ${item.won ? '+₹' + item.payout.toFixed(2) : '-₹' + item.betAmt.toFixed(2)}
          </td>
        </tr>
      `;
    });
  }

  // Real-feeling Live Simulated Players
  let simulatedPlayers = [];
  function generateSimulatedPlayers() {
    const count = Math.floor(Math.random() * 50) + 800;
    document.getElementById("livePlayerCount").innerText = count;

    const names = ['l***2', 'a***0', 'a***8', 'c***5', 't***2', 'w***1', 'd***6', 'x***3', 'z***2', 'f***3', 's***5', 'r***9'];
    const avatars = ['🦹', '🤠', '🥷', '🤖', '👾', '🚀', '⚡', '🦅', '🎯', '🔥', '🐯', '👑'];
    simulatedPlayers = names.map((name, i) => ({
      user: name,
      avatar: avatars[i],
      bet: (Math.floor(Math.random() * 60) + 10) * 100,
      cashoutAt: parseFloat((Math.random() * 4.5 + 1.15).toFixed(2)),
      cashed: false
    }));
    renderSimulatedPlayers();
  }

  function updateSimulatedPlayers(curMult) {
    simulatedPlayers.forEach(p => {
      if (!p.cashed && curMult >= p.cashoutAt) {
        p.cashed = true;
      }
    });
    renderSimulatedPlayers();
  }

  function renderSimulatedPlayers() {
    const tbody = document.getElementById("liveBetsBody");
    tbody.innerHTML = "";
    simulatedPlayers.forEach(p => {
      tbody.innerHTML += `
        <tr>
          <td>
            <div class="user-cell">
              <div class="avatar-circ">${p.avatar}</div>
              <span>${p.user}</span>
            </div>
          </td>
          <td>₹${p.bet.toFixed(2)}</td>
          <td>${p.cashed ? `<span class="cashout-tag">${p.cashoutAt.toFixed(2)}x</span>` : '-'}</td>
          <td style="text-align:right; font-weight:700; color:${p.cashed ? '#00e676' : '#8b9bb4'};">
            ${p.cashed ? '₹' + (p.bet * p.cashoutAt).toFixed(2) : '-'}
          </td>
        </tr>
      `;
    });
  }

  function renderTopWinners() {
    const topData = [
      { user: 'k***9', avatar: '👑', bet: 5000, mult: 84.50, payout: 422500 },
      { user: 'm***1', avatar: '🔥', bet: 2000, mult: 42.10, payout: 84200 },
      { user: 'p***7', avatar: '⚡', bet: 8000, mult: 30.33, payout: 242640 },
      { user: 'v***0', avatar: '🎯', bet: 1500, mult: 24.80, payout: 37200 }
    ];
    const tbody = document.getElementById("topBetsBody");
    tbody.innerHTML = "";
    topData.forEach(item => {
      tbody.innerHTML += `
        <tr>
          <td>
            <div class="user-cell">
              <div class="avatar-circ">${item.avatar}</div>
              <span>${item.user}</span>
            </div>
          </td>
          <td>₹${item.bet.toFixed(2)}</td>
          <td><span class="cashout-tag" style="background:rgba(214,84,255,0.2); color:#d654ff;">${item.mult.toFixed(2)}x</span></td>
          <td style="text-align:right; font-weight:800; color:#00e676;">₹${item.payout.toFixed(2)}</td>
        </tr>
      `;
    });
  }

  // Canvas Flight Physics
  function renderCanvasLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, '#0c172a');
    gradient.addColorStop(1, '#050a12');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (gameState === 'FLYING') {
      javelinX += (canvas.width - 80) / (crashMultiplier * 25);
      javelinY = (canvas.height - 40) - Math.sin((javelinX / canvas.width) * Math.PI) * 110;

      trailParticles.push({
        x: javelinX,
        y: javelinY,
        alpha: 1.0,
        size: Math.random() * 4 + 2
      });

      ctx.lineWidth = 3;
      ctx.strokeStyle = '#00e676';
      ctx.shadowColor = '#00e676';
      ctx.shadowBlur = 12;

      ctx.beginPath();
      ctx.moveTo(40, canvas.height - 40);
      ctx.lineTo(javelinX, javelinY);
      ctx.stroke();
      ctx.shadowBlur = 0;

      ctx.save();
      ctx.translate(javelinX, javelinY);
      ctx.rotate(-0.35);

      ctx.fillStyle = '#00e676';
      ctx.fillRect(-24, -2, 48, 4);
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(24, -4);
      ctx.lineTo(34, 0);
      ctx.lineTo(24, 4);
      ctx.fill();
      ctx.restore();
    }

    for (let i = trailParticles.length - 1; i >= 0; i--) {
      const p = trailParticles[i];
      p.alpha -= 0.03;
      ctx.fillStyle = `rgba(0, 230, 118, ${p.alpha})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      if (p.alpha <= 0) trailParticles.splice(i, 1);
    }

    requestAnimationFrame(renderCanvasLoop);
  }

  window.onload = () => {
    init();
    renderCanvasLoop();
  };
</script>

</body>
</html>'''
