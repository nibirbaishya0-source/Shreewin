# Wallet / account pages — single HTML document each
account_html = """
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta charset="UTF-8">
<title>ShreeWin - Account</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>

/* === OFFICIAL COLOUR MATCH === */
:root{
  --sw-bg:#0d0a1f;
  --sw-bg-deep:#0a0816;
  --sw-surface:#141332;
  --sw-card:#1a1435;
  --sw-card-2:#1e1b4b;
  --sw-border:#26244f;
  --sw-accent:#6965e8;
  --sw-purple:#7c3aed;
  --sw-purple-2:#8b5cf6;
  --sw-text:#ffffff;
  --sw-muted:#9e8fc7;
  --sw-muted-2:#5d5c88;
  --sw-gold:#ffd700;
  --sw-orange:#ff8f00;
}
html,body{background:#0d0a1f!important;color:#fff!important}
/* === END OFFICIAL COLOUR MATCH === */





        :root {
            --bg-dark: #161239;
            --bg-card: #241d4c;
            --bg-card-alt: #1c1740;
            --bg-card-inner: #1f1b40;
            --primary-purple: #8d7ff7;
            --primary-gradient: linear-gradient(135deg, #a78bfa 0%, #7c66f6 100%);
            --btn-purple: #9b8df8;
            --btn-amount-bg: #2d275e;
            --btn-amount-active: #8d80f8;
            --text-white: #ffffff;
            --text-light: #b0a9d8;
            --color-green: #00e676;
            --color-orange: #ff9800;
            --color-red: #ff4d4f;
            --color-gold: #ffb800;
            --pay-card-bg: #2b245e;
            --input-dark: #272153;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Delius', 'Nunito', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #0d0a1f;
            display: flex;
            justify-content: center;
            min-height: 100vh;
            overflow-x: hidden;
            overflow-y: auto;
        }

        /* Mobile Container Frame */
        .app-container {
            width: 100%;
            max-width: 400px;
            height: 100vh;
            background-color: var(--bg-dark);
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(255,255,255,0.1);
        }

        /* Smooth Screen Transition Styles */
        .app-screen {
            display: none;
            flex-direction: column;
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            background-color: var(--bg-dark);
            opacity: 0;
            transition: opacity 0.25s ease-in-out;
            z-index: 1;
        }

        .app-screen.active {
            display: flex;
            opacity: 1;
            z-index: 5;
        }

        /* Shared Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 16px;
            color: var(--text-white);
            background-color: var(--bg-dark);
            z-index: 10;
        }
        .header .back-btn {
            font-size: 1.1rem;
            cursor: pointer;
            padding: 5px;
        }
        .header .title {
            font-size: 1.25rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .header .history-link {
            font-size: 0.9rem;
            color: #d8d4fd;
            text-decoration: none;
            cursor: pointer;
        }

        /* Scrollable Area */
        .scrollable-content {
            flex: 1;
            overflow-y: auto;
            scrollbar-width: none;
        }
        .scrollable-content::-webkit-scrollbar {
            display: none;
        }

        /* Floating Support */
        .sub-fab-right {
            position: fixed !important;
            bottom: 90px !important;
            right: 16px !important;
            width: 56px !important;
            height: 56px !important;
            border-radius: 50% !important;
            background: #00e676 !important;
            box-shadow: 0 0 20px rgba(0, 230, 118, 0.65), 0 4px 12px rgba(0,0,0,0.3) !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            cursor: pointer !important;
            border: 3.5px solid #ffffff !important;
            z-index: 999 !important;
        }
        .sub-fab-right i { color: #0b1f13 !important; font-size: 1.55rem !important; }

        /* ================= 1. ACCOUNT VIEW STYLES ================= */
        .profile-header {
            background: linear-gradient(180deg, #9b89ff 0%, #6e55f8 50%, var(--bg-dark) 100%);
            padding: 24px 16px 15px 16px;
            position: relative;
        }
        .profile-row {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .avatar-wrap {
            position: relative;
            width: 72px;
            height: 72px;
            border-radius: 50%;
            border: 2px solid rgba(255, 255, 255, 0.6);
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            flex-shrink: 0;
            background: #25204d;
        }
        .avatar-wrap img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .user-details {
            display: flex;
            flex-direction: column;
            gap: 4px;
            flex: 1;
        }
        .username-row {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .username {
            color: #ffffff;
            font-size: 1.15rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .vip-badge {
            background: linear-gradient(135deg, #e2e8f0 0%, #94a3b8 100%);
            color: #1e1b4b;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 800;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        .uid-pill {
            background: rgba(255, 152, 0, 0.9);
            color: #ffffff;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            width: fit-content;
            cursor: pointer;
            margin-top: 2px;
        }
        .last-login {
            color: #d1ccff;
            font-size: 0.72rem;
            margin-top: 2px;
        }

        /* Account page: normal scrolling + logout stays reachable above bottom nav */
        .account-logout-fixed { display: none; }
        .account-legacy-logout { display: none; }
        .main-padding { padding: 0 14px 110px 14px; }
        body { min-height: 100vh; overflow-y: auto; -webkit-overflow-scrolling: touch; padding-bottom: 88px; }
        .scrollable-content { overflow-y: auto; height: 100%; min-height: 0; padding-bottom: 100px; -webkit-overflow-scrolling: touch; }
        .btn-logout { margin-top: 8px; margin-bottom: 20px; }

        .wallet-card {
            background-color: var(--bg-card);
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 14px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.25);
        }
        .wallet-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .wallet-left {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .wallet-title {
            color: #a7a0d8;
            font-size: 0.9rem;
        }
        .balance-value-row {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #ffffff;
            font-size: 1.8rem;
            font-weight: bold;
        }
        .balance-value-row i {
            font-size: 1.1rem;
            color: #a7a0d8;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .btn-enter-wallet {
            background-color: #beb4ff;
            color: #2b2361;
            border: none;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
            cursor: pointer;
        }

        .wallet-actions-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            text-align: center;
        }
        .w-action-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            cursor: pointer;
            text-decoration: none;
        }
        .w-action-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
        }
        .w-action-icon.arwallet { background: rgba(255, 77, 79, 0.15); color: #ff4d4f; }
        .w-action-icon.deposit { background: rgba(255, 152, 0, 0.15); color: #ff9800; }
        .w-action-icon.withdraw { background: rgba(0, 186, 242, 0.15); color: #00baf2; }
        .w-action-icon.vip { background: rgba(0, 230, 118, 0.15); color: #00e676; }
        .w-action-label {
            color: #ffffff;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .history-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 14px;
        }
        .history-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            text-decoration: none;
        }
        .hist-icon-wrap {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }
        .hist-icon-wrap.game { background: #1a73e8; color: white; }
        .hist-icon-wrap.trans { background: #00c853; color: white; }
        .hist-icon-wrap.dep { background: #e53935; color: white; }
        .hist-icon-wrap.with { background: #fb8c00; color: white; }
        .hist-text { display: flex; flex-direction: column; overflow: hidden; }
        .hist-title { color: #ffffff; font-size: 0.95rem; font-weight: bold; line-height: 1.1; }
        .hist-sub { color: #8f88c2; font-size: 0.72rem; margin-top: 2px; white-space: nowrap; }

        .menu-card {
            background-color: var(--bg-card);
            border-radius: 14px;
            overflow: hidden;
            margin-bottom: 14px;
        }
        .menu-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            cursor: pointer;
            text-decoration: none;
            color: #ffffff;
        }
        .menu-row:last-child { border-bottom: none; }
        .menu-row-left { display: flex; align-items: center; gap: 14px; font-size: 0.95rem; font-weight: 600; }
        .menu-row-left i { font-size: 1.2rem; color: #9b8df8; width: 22px; text-align: center; }
        .menu-row-right { display: flex; align-items: center; gap: 8px; color: #7b74ba; font-size: 0.85rem; }

        .service-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 18px;
        }
        .service-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 16px; }
        .service-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            row-gap: 20px;
            column-gap: 8px;
            text-align: center;
        }
        .service-item { display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; text-decoration: none; }
        .service-icon { font-size: 1.6rem; color: #8d7ff7; }
        .service-label { color: #ffffff; font-size: 0.82rem; font-weight: 600; line-height: 1.2; }

        .btn-logout {
            width: 100%;
            background-color: transparent;
            border: 1px solid #4a3e8e;
            color: #ffffff;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 30px;
        }

        /* ================= 2. DEPOSIT VIEW STYLES ================= */
        .deposit-pad { padding: 10px 14px 125px 14px; }
        .balance-card {
            background: var(--primary-gradient);
            border-radius: 16px;
            padding: 20px 18px;
            color: white;
            position: relative;
            overflow: hidden;
            margin-bottom: 15px;
            box-shadow: 0 4px 15px rgba(124, 102, 246, 0.25);
        }
        .balance-label {
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 8px;
            opacity: 0.95;
        }
        .balance-amount {
            font-size: 2rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .balance-amount i { font-size: 1.2rem; cursor: pointer; transition: transform 0.4s ease; }
        .balance-card .dots-bg {
            position: absolute;
            bottom: 8px;
            right: 15px;
            color: rgba(255, 255, 255, 0.3);
            font-size: 1.1rem;
            letter-spacing: 2px;
            font-weight: bold;
        }

        .channels-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 15px;
        }
        .channel-card {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 4px 10px 4px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            position: relative;
            border: 1px solid transparent;
            min-height: 86px;
        }
        .channel-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .channel-icon-wrap {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 6px;
        }
        .channel-name { color: white; font-size: 0.72rem; font-weight: 600; line-height: 1.1; }
        .channel-badge {
            position: absolute;
            top: -4px;
            right: -2px;
            background-color: var(--color-red);
            color: white;
            font-size: 0.65rem;
            font-weight: bold;
            padding: 2px 5px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 2px;
        }

        .amount-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .section-title {
            color: white;
            font-size: 1.05rem;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 14px;
            font-weight: bold;
        }
        .section-title i { color: #b0a5fa; }

        .amount-grid-deposit {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 15px;
        }
        .amount-btn {
            background-color: var(--btn-amount-bg);
            border: 1px solid rgba(255, 255, 255, 0.05);
            color: #bcb6ea;
            padding: 12px 5px;
            border-radius: 8px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
            transition: all 0.2s ease;
        }
        .amount-btn:hover, .amount-btn:active, .amount-btn.active {
            background-color: var(--btn-amount-active);
            color: white;
            box-shadow: 0 2px 8px rgba(141, 128, 248, 0.4);
        }

        .amount-input-box {
            background-color: var(--bg-card-inner);
            border-radius: 25px;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .amount-input-box .currency-sym {
            color: #958df1;
            font-size: 1.1rem;
            font-weight: bold;
            padding-right: 10px;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
            margin-right: 10px;
        }
        .amount-input-box input {
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: #ffffff;
            font-size: 0.95rem;
        }
        .amount-input-box input::placeholder { color: #7b74ba; }
        .amount-input-box .clear-btn { color: #7b74ba; font-size: 1rem; cursor: pointer; padding: 2px 5px; }

        .instruction-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .instruction-inner {
            background-color: var(--bg-card-inner);
            border-radius: 10px;
            padding: 14px;
        }
        .instruction-list { list-style: none; }
        .instruction-list li {
            position: relative;
            padding-left: 18px;
            color: #9e97d8;
            font-size: 0.82rem;
            line-height: 1.45;
            margin-bottom: 14px;
        }
        .instruction-list li:last-child { margin-bottom: 0; }
        .instruction-list li::before {
            content: '×';
            position: absolute;
            left: 0;
            top: 0;
            color: #8d80f8;
            font-size: 0.75rem;
        }

        .sub-no-data-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px 0 10px 0;
        }
        .sub-no-data-icon { width: 170px; height: 120px; opacity: 0.85; margin-bottom: 10px; }
        .sub-no-data-text { color: #ffffff; font-size: 1.15rem; font-weight: 500; }

        .history-card-item {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-left: 4px solid var(--color-green);
        }
        .history-card-item.pending { border-left-color: var(--color-orange); }
        .history-card-item.rejected { border-left-color: var(--color-red); }
        .history-card-left .hist-amount { font-size: 1.1rem; font-weight: bold; color: white; margin-bottom: 2px;}
        .history-card-left .hist-utr { font-size: 0.75rem; color: var(--text-light); }
        .history-card-right { text-align: right; }
        .history-card-right .hist-status { font-size: 0.8rem; font-weight: bold; text-transform: capitalize; }
        .history-card-right .hist-time { font-size: 0.7rem; color: var(--text-light); margin-top: 2px; }

        .status-approved { color: var(--color-green); }
        .status-pending { color: var(--color-orange); }
        .status-rejected { color: var(--color-red); }

        .deposit-bottom-bar {
            position: fixed !important;
            bottom: 0 !important;
            left: 0;
            right: 0;
            background-color: #1a1540;
            padding: 12px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 99999 !important;
            position: fixed !important;
        }
        .recharge-method-info { display: flex; flex-direction: column; }
        .recharge-method-info .label { font-size: 0.78rem; color: #ffffff; margin-bottom: 2px; }
        .recharge-method-info .method-name { font-size: 0.95rem; color: #ffffff; font-weight: bold; }
        .deposit-btn {
            background-color: var(--primary-purple);
            color: white;
            border: none;
            padding: 10px 28px;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }

        /* Gateway Screen (ArUpiPay) */
        .cs-pill-btn {
            background: linear-gradient(90deg, #7c67ff 0%, #6852ee 100%);
            color: white;
            font-size: 0.8rem;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            cursor: pointer;
            font-weight: 600;
        }
        .pay-amount-bar {
            background-color: var(--pay-card-bg);
            border-radius: 12px;
            padding: 16px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .pay-amount-left { display: flex; align-items: center; gap: 12px; color: #ffffff; font-size: 1.7rem; font-weight: bold; }
        .pay-amount-left i { font-size: 1.25rem; color: #d1ccff; cursor: pointer; }
        .pay-timer { color: var(--color-red); font-size: 1.15rem; font-weight: bold; letter-spacing: 0.5px; }

        .pay-bullet-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
        .pay-bullet-title::before { content: '•'; color: #ffffff; font-size: 1.3rem; line-height: 0; }

        .pay-methods-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
        .pay-method-card { border-radius: 12px; padding: 12px 10px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; cursor: pointer; transition: transform 0.15s ease; }
        .pay-method-card:active { transform: scale(0.97); }
        .pay-method-card.paytm { background: linear-gradient(135deg, #d4f8ff 0%, #a4e6f9 100%); color: #042e6f; }
        .pay-method-card.phonepe { background: linear-gradient(135deg, #fce8ff 0%, #ebd0fc 100%); color: #5f259f; }
        .pay-logo-wrap { display: flex; align-items: center; gap: 6px; font-size: 1.05rem; font-weight: bold; margin-bottom: 4px; }
        .pay-logo-img { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.85rem; font-weight: bold; }
        .paytm .pay-logo-img { background-color: #002e6e; font-size: 0.6rem; }
        .phonepe .pay-logo-img { background-color: #5f259f; font-size: 1rem; }
        .wake-text { font-size: 0.75rem; color: #8b80cf; font-weight: 600; }

        .qr-card {
            background-color: #372f78;
            border-radius: 14px;
            padding: 22px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            margin-bottom: 22px;
        }
        .qr-image-wrapper {
            background-color: #ffffff;
            padding: 12px;
            border-radius: 14px;
            display: inline-block;
            margin-bottom: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        .qr-image-wrapper img { width: 180px; height: 180px; display: block; margin: 0 auto; }
        .qr-upi-info { color: #332d5e; font-size: 0.82rem; font-weight: bold; margin-top: 8px; font-family: 'Nunito', sans-serif; }
        .qr-desc { color: #ffffff; font-size: 0.88rem; line-height: 1.45; text-align: left; width: 100%; margin-top: 6px; }
        .qr-desc p { margin-bottom: 8px; }

        .utr-warning-text { color: var(--color-red); font-size: 0.95rem; line-height: 1.35; font-weight: bold; margin-bottom: 12px; }
        .utr-input-box {
            background-color: #272153;
            border-radius: 30px;
            padding: 6px 6px 6px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 22px;
            box-shadow: 0 0 10px rgba(186, 104, 200, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .utr-input-box input { background: transparent; border: none; outline: none; color: #b7b0ee; font-size: 0.95rem; width: 70%; }
        .utr-paste-btn { background-color: #8d80f8; color: #ffffff; border: none; padding: 8px 18px; border-radius: 20px; font-size: 0.9rem; font-weight: bold; cursor: pointer; }
        .reminder-list { color: #ffffff; font-size: 0.9rem; line-height: 1.6; margin-bottom: 25px; }

        .pay-bottom-bar {
            position: fixed !important;
            bottom: 0 !important;
            left: 0;
            right: 0;
            background-color: #1a1540;
            padding: 12px 16px;
            display: flex;
            gap: 12px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 20;
        }
        .btn-cancel { flex: 0.35; background-color: #38306e; color: #ffffff; border: none; padding: 12px 0; border-radius: 8px; font-size: 0.95rem; font-weight: bold; cursor: pointer; }
        .btn-submit-utr { flex: 0.65; background: linear-gradient(90deg,#8b5cf6,#7c3aed); color: #fff; border: none; padding: 14px 0; border-radius: 12px; font-size: 1rem; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(124,58,237,0.4); }
        .btn-submit-utr.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 12px rgba(141, 128, 248, 0.4); }

        /* ================= 3. WITHDRAW VIEW STYLES ================= */
        .withdraw-pad { padding: 10px 14px 40px 14px; }
        .arpay-banner {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 14px;
        }
        .arpay-logo { font-size: 2rem; color: #ffb800; font-weight: 900; line-height: 1; }
        .arpay-text h4 { color: white; font-size: 1.05rem; font-weight: bold; margin-bottom: 2px; }
        .arpay-text p { color: #9e97d8; font-size: 0.8rem; }

        .methods-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 14px;
        }
        .method-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            min-height: 90px;
            transition: all 0.2s;
        }
        .method-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .method-icon { font-size: 1.8rem; margin-bottom: 6px; height: 36px; display: flex; align-items: center; justify-content: center; }
        .method-name { color: white; font-size: 0.8rem; font-weight: 700; letter-spacing: 0.5px; }

        .account-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
            cursor: pointer;
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: 0.2s;
        }
        .account-card:active { transform: scale(0.98); }
        .account-left { display: flex; flex-direction: column; gap: 4px; }
        .account-name-row { display: flex; align-items: center; gap: 8px; color: white; font-size: 1rem; font-weight: bold; }
        .account-vpa { color: #9e97d8; font-size: 0.9rem; font-weight: 600; }
        .account-card i.fa-chevron-right { color: #7b74ba; font-size: 0.95rem; }

        .add-bank-box {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 24px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            margin-bottom: 6px;
        }
        .dashed-plus-icon {
            width: 46px;
            height: 46px;
            border: 2px dashed #7a70bb;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7a70bb;
            font-size: 1.5rem;
            margin-bottom: 12px;
        }
        .add-bank-text { color: #8c82cb; font-size: 1rem; font-weight: bold; }
        .add-bank-warning { color: var(--color-red); font-size: 0.8rem; text-align: center; margin-bottom: 14px; line-height: 1.3; }

        .amount-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 14px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.88rem;
            margin-bottom: 8px;
            color: #bcb6ea;
        }
        .btn-all-pill {
            background-color: #38306e;
            color: white;
            border: none;
            padding: 3px 18px;
            border-radius: 14px;
            font-size: 0.8rem;
            font-weight: bold;
            cursor: pointer;
        }
        .received-val { color: #ff9800; font-weight: bold; font-size: 1.1rem; }

        .withdraw-action-btn {
            width: 100%;
            background-color: #d1cbff;
            color: #7a6fc7;
            border: none;
            padding: 14px;
            border-radius: 25px;
            font-size: 1.05rem;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 20px;
            transition: 0.2s;
        }
        .withdraw-action-btn.ready {
            background: var(--primary-purple);
            color: white;
            box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4);
        }
        .val-red { color: var(--color-red); font-weight: bold; }

        .btn-all-history {
            width: 100%;
            background-color: transparent;
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #bcb6ea;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
        }

        /* Payment Method Screen (UPI Sub-Screen) */
        .pm-account-card {
            background-color: #262153;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            margin-bottom: 15px;
        }
        .pm-card-header-stripe { height: 38px; background: linear-gradient(90deg, #0066ff 0%, #0088ff 100%); width: 100%; }
        .pm-card-body { padding: 18px 16px; color: #ffffff; }
        .pm-info-row { font-size: 1rem; color: #d1ccff; margin-bottom: 12px; letter-spacing: 0.3px; }
        .pm-info-row .bold-text { color: #ffffff; font-weight: bold; }
        .pm-current-tag { display: flex; align-items: center; gap: 8px; color: #a49fc7; font-size: 0.92rem; margin-top: 14px; }
        .pm-check-circle { width: 20px; height: 20px; background-color: var(--color-red); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.75rem; }
        .pm-bottom-bar { position: fixed !important; bottom: 0 !important; left: 0; right: 0; padding: 16px; background-color: #1a1540; z-index: 99999 !important; max-width: 400px; margin: 0 auto; box-shadow: 0 -4px 20px rgba(0,0,0,0.5); }
        .btn-add-method { width: 100%; background: linear-gradient(90deg,#8b5cf6,#7c3aed) !important; color: #fff !important; border: none; padding: 16px; border-radius: 30px; font-size: 1.1rem; font-weight: 800; cursor: pointer; box-shadow: 0 4px 15px rgba(139,92,246,0.5); }

        /* Add Bank Sub-Screen */
        .ab-notice-pill { background-color: #272153; border-radius: 20px; padding: 10px 14px; display: flex; align-items: center; gap: 10px; margin-bottom: 18px; color: var(--color-red); font-size: 0.8rem; line-height: 1.35; }
        .ab-form-group { margin-bottom: 16px; }
        .ab-label { color: #ffffff; font-size: 0.95rem; font-weight: bold; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .ab-label i { color: #8d7ff7; font-size: 1rem; }
        .ab-select-box { background: linear-gradient(90deg, #6b55fb 0%, #503ef0 100%); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; color: #ffffff; cursor: pointer; font-size: 0.95rem; font-weight: bold; }
        .ab-input-box { background-color: var(--input-dark); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; }
        .ab-input { width: 100%; background: transparent; border: none; outline: none; color: #ffffff; font-size: 0.95rem; font-family: 'Delius', sans-serif; }
        .ab-input::placeholder { color: #766eb5; }
        .ab-bottom-bar { padding: 14px 16px; background-color: var(--bg-dark); }
        .btn-save-bank { width: 100%; background-color: #d1cbff; color: #7a6fc7; border: none; padding: 15px; border-radius: 25px; font-size: 1.1rem; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .btn-save-bank.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4); }

        /* Bank Selector Modal */
        .bank-modal {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 50;
            display: none;
            flex-direction: column;
            justify-content: flex-end;
        }
        .bank-modal-content {
            background: var(--bg-card);
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            padding: 20px;
            max-height: 70vh;
            display: flex;
            flex-direction: column;
        }
        .bank-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 14px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .bank-list { overflow-y: auto; flex: 1; }
        .bank-item {
            padding: 14px 12px;
            color: #d1ccff;
            font-size: 0.95rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .bank-item:hover, .bank-item:active { background: rgba(255,255,255,0.08); color: white; }

        /* Gift Claim Popup Modal */
        .gift-modal-backdrop {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 100;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .gift-popup-card {
            background: var(--bg-card);
            border-radius: 18px;
            width: 100%;
            max-width: 320px;
            padding: 24px 20px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.6);
            border: 1px solid rgba(255,255,255,0.1);
        }
        .gift-popup-card i.fa-gift { font-size: 3rem; color: #ffb800; margin-bottom: 12px; }
        .gift-input {
            width: 100%;
            background: var(--bg-card-alt);
            border: 1px solid rgba(255,255,255,0.1);
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-size: 1rem;
            text-transform: uppercase;
            text-align: center;
            margin: 14px 0;
            outline: none;
            font-family: 'Nunito', sans-serif;
            font-weight: bold;
        }
        .btn-claim-gift {
            width: 100%;
            background: var(--primary-purple);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }
    
/* Standalone account page */
body{min-height:100vh;overflow-y:auto;-webkit-overflow-scrolling:touch;padding-bottom:88px;}
.bottom-navbar{position:fixed;bottom:0;left:0;width:100%;height:65px;background:#141332;border-top:1px solid #26244f;display:flex;justify-content:space-around;align-items:center;z-index:1000;padding-bottom:5px;font-family:Poppins,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}
.nav-item{display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:#5d5c88;font-size:11px;font-weight:600;transition:all .2s ease;cursor:pointer;flex:1}
.nav-item svg{width:26px;height:26px;fill:#5d5c88;margin-bottom:2px;transition:all .2s ease}
.nav-item.active{color:#6965e8}
.nav-item.active svg{fill:#6965e8;filter:drop-shadow(0 0 8px rgba(105,101,232,.4))}
.wheel-item{position:relative;top:-16px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;flex:1.2;text-decoration:none}
.wheel-wrapper{width:72px;height:72px;position:relative;display:flex;justify-content:center;align-items:center;filter:drop-shadow(0 4px 10px rgba(0,0,0,.6))}
.wheel-wrapper svg{width:100%;height:100%}
.wheel-label{position:absolute;bottom:-6px;white-space:nowrap;font-size:13px;font-weight:900;color:#ffe600;text-shadow:-1.5px -1.5px 0 #b30000,1.5px -1.5px 0 #b30000,-1.5px 1.5px 0 #b30000,1.5px 1.5px 0 #b30000,0 2px 4px rgba(0,0,0,.8);letter-spacing:-.2px}

</style>
</head>
<body>
<div class="scrollable-content">
            <!-- 1. Profile Top Section -->
            <div class="profile-header">
                <div class="profile-row">
                    <div class="avatar-wrap">
                        <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80" alt="Avatar">
                    </div>

                    <div class="user-details">
                        <div class="username-row">
                            <span class="username">{{ member_name }}</span>
                            <div class="vip-badge"><i class="fa-solid fa-star"></i> VIP0</div>
                        </div>

                        <div class="uid-pill" onclick="copyUID()">
                            <span>UID | {{ uid }}</span>
                            <i class="fa-regular fa-copy"></i>
                        </div>

                        <div class="last-login" id="current-last-login">
                            Last login: {{ last_login }}
                        </div>
                    </div>
                </div>
            </div>

            <div class="main-padding">
                <!-- 2. Wallet Card -->
                <div class="wallet-card">
                    <div class="wallet-top">
                        <div class="wallet-left">
                            <span class="wallet-title">Total balance</span>
                            <div class="balance-value-row">
                                <span id="account-balance-display">₹{{ balance }}</span>
                                <i class="fa-solid fa-arrows-rotate" id="refresh-icon" onclick="refreshMasterBalance()"></i>
                            </div>
                        </div>
                        <button class="btn-enter-wallet" onclick="location.href='/deposit'">Enter wallet</button>
                    </div>

                    <!-- 4 Shortcuts -->
                    <div class="wallet-actions-grid">
                        <div class="w-action-item">
                            <div class="w-action-icon arwallet"><i class="fa-solid fa-wallet"></i></div>
                            <span class="w-action-label">ARWallet</span>
                        </div>
                        <div class="w-action-item" onclick="location.href='/deposit'">
                            <div class="w-action-icon deposit"><i class="fa-solid fa-sack-dollar"></i></div>
                            <span class="w-action-label">Deposit</span>
                        </div>
                        <div class="w-action-item" onclick="location.href='/withdraw'">
                            <div class="w-action-icon withdraw"><i class="fa-solid fa-credit-card"></i></div>
                            <span class="w-action-label">Withdraw</span>
                        </div>
                        <div class="w-action-item">
                            <div class="w-action-icon vip"><i class="fa-solid fa-gem"></i></div>
                            <span class="w-action-label">VIP</span>
                        </div>
                    </div>
                </div>

                <!-- 3. 2x2 History Cards Grid -->
                <div class="history-grid">
                    <div class="history-card">
                        <div class="hist-icon-wrap game"><i class="fa-solid fa-gamepad"></i></div>
                        <div class="hist-text">
                            <span class="hist-title">Game History</span>
                            <span class="hist-sub">My game history</span>
                        </div>
                    </div>

                    <div class="history-card">
                        <div class="hist-icon-wrap trans"><i class="fa-solid fa-receipt"></i></div>
                        <div class="hist-text">
                            <span class="hist-title">Transaction</span>
                            <span class="hist-sub">My transaction history</span>
                        </div>
                    </div>

                    <div class="history-card" onclick="location.href='/deposit-history'">
                        <div class="hist-icon-wrap dep"><i class="fa-solid fa-bookmark"></i></div>
                        <div class="hist-text">
                            <span class="hist-title">Deposit</span>
                            <span class="hist-sub">My deposit history</span>
                        </div>
                    </div>

                    <div class="history-card" onclick="location.href='/withdraw-history'">
                        <div class="hist-icon-wrap with"><i class="fa-solid fa-circle-dollar-to-slot"></i></div>
                        <div class="hist-text">
                            <span class="hist-title">Withdraw</span>
                            <span class="hist-sub">My withdraw history</span>
                        </div>
                    </div>
                </div>

                <!-- 4. Menu List -->
                <div class="menu-card">
                    <div class="menu-row">
                        <div class="menu-row-left">
                            <i class="fa-solid fa-envelope"></i>
                            <span>Notification</span>
                        </div>
                        <div class="menu-row-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </div>

                    <!-- Gift Code Modal -->
                    <div class="menu-row" onclick="openGiftRedeemModal()">
                        <div class="menu-row-left">
                            <i class="fa-solid fa-gift"></i>
                            <span>Gifts</span>
                        </div>
                        <div class="menu-row-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </div>

                    <div class="menu-row">
                        <div class="menu-row-left">
                            <i class="fa-solid fa-ticket"></i>
                            <span>My Top-Up Coupons</span>
                        </div>
                        <div class="menu-row-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </div>

                    <div class="menu-row">
                        <div class="menu-row-left">
                            <i class="fa-solid fa-chart-simple"></i>
                            <span>Game statistics</span>
                        </div>
                        <div class="menu-row-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </div>

                    <div class="menu-row">
                        <div class="menu-row-left">
                            <i class="fa-solid fa-globe"></i>
                            <span>Language</span>
                        </div>
                        <div class="menu-row-right">
                            <span>English</span>
                            <i class="fa-solid fa-chevron-right"></i>
                        </div>
                    </div>
                </div>

                <!-- 5. Service Center -->
                <div class="service-section">
                    <div class="service-title">Service center</div>
                    <div class="service-grid">
                        <div class="service-item">
                            <i class="fa-solid fa-gear service-icon"></i>
                            <span class="service-label">Settings</span>
                        </div>
                        <div class="service-item">
                            <i class="fa-solid fa-clipboard-list service-icon"></i>
                            <span class="service-label">Feedback</span>
                        </div>
                        <div class="service-item">
                            <i class="fa-solid fa-bullhorn service-icon"></i>
                            <span class="service-label">Announcement</span>
                        </div>
                        <a href="https://t.me/Shreewinofficial01_bot" target="_blank" rel="noopener" class="service-item">
                            <i class="fa-solid fa-headset service-icon"></i>
                            <span class="service-label">Customer Service</span>
                        </a>
                        <div class="service-item">
                            <i class="fa-solid fa-book-open service-icon"></i>
                            <span class="service-label">Beginner's Guide</span>
                        </div>
                        <div class="service-item">
                            <i class="fa-solid fa-cube service-icon"></i>
                            <span class="service-label">About us</span>
                        </div>
                    </div>
                </div>

                <!-- 6. Logout Button -->
                <button class="btn-logout" onclick="location.href='/logout'">
                    <i class="fa-solid fa-power-off"></i> Log out
                </button>
            </div>
        </div>
        <div class="sub-fab-right" onclick="window.open('https://t.me/Shreewinofficial01_bot','_blank')" style="cursor:pointer" title="Customer Service"><i class="fa-solid fa-headset"></i></div>
<div class="gift-modal-backdrop" id="gift-modal" onclick="closeGiftRedeemModal(event)"><div class="gift-popup-card" onclick="event.stopPropagation()"><i class="fa-solid fa-gift"></i><h3 style="color:white;margin-bottom:6px;">Gift Code</h3><p style="color:#a7a0d8;font-size:.8rem;">Enter a code to test the gift UI.</p><input type="text" id="gift-code-input" class="gift-input" placeholder="ENTER CODE HERE"><div style="display:flex;gap:10px;"><button class="btn-claim-gift" style="background:#38306e;" onclick="closeGiftRedeemModal()">Cancel</button><button class="btn-claim-gift" onclick="claimGiftCode()">Test Code</button></div></div></div>

<script>
function openGiftRedeemModal(){location.href="/gift";}
function closeGiftRedeemModal(e){if(!e||e.target===e.currentTarget){const m=document.getElementById("gift-modal");if(m)m.style.display="none";}}
function claimGiftCode(){location.href="/gift";}
function copyUID(){
 const text={{ uid|tojson }};
 if(navigator.clipboard){navigator.clipboard.writeText(String(text)).catch(()=>{});}
}
function refreshMasterBalance(){document.querySelectorAll('[data-balance]').forEach(e=>e.innerText='₹{{ balance }
 location.reload();
}
</script>
<div class="account-logout-fixed"><button class="btn-logout" onclick="location.href='/logout'"><i class="fa-solid fa-power-off"></i> Log out</button></div>
<!-- Bottom Navigation - New Design -->
<nav class="bottom-navbar">
    <a href="/home" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      <span>Home</span>
    </a>
    <a href="/activity" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2zm-7 10.25l-2.61 1.56.69-2.97-2.3-2 3.03-.26L12 7l1.19 2.58 3.03.26-2.3 2 .69 2.97L12 13.25z"/></svg>
      <span>Activity</span>
    </a>
    <a href="/spinwheel" class="wheel-item">
      <div class="wheel-wrapper">
        <svg viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="46" fill="#7522c7" stroke="#9d3efa" stroke-width="2"/>
          <circle cx="50" cy="8" r="2" fill="#ffd700"/>
          <circle cx="80" cy="20" r="2" fill="#ffd700"/>
          <circle cx="92" cy="50" r="2" fill="#ffd700"/>
          <circle cx="80" cy="80" r="2" fill="#ffd700"/>
          <circle cx="20" cy="80" r="2" fill="#ffd700"/>
          <circle cx="8" cy="50" r="2" fill="#ffd700"/>
          <circle cx="20" cy="20" r="2" fill="#ffd700"/>
          <circle cx="50" cy="50" r="40" fill="#b066fe" stroke="#d5a5ff" stroke-width="2"/>
          <path d="M50 50 L50 14 A36 36 0 0 1 81 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L81 32 A36 36 0 0 1 81 68 Z" fill="#c026d3"/>
          <path d="M50 50 L81 68 A36 36 0 0 1 50 86 Z" fill="#00e5ff"/>
          <path d="M50 50 L50 86 A36 36 0 0 1 19 68 Z" fill="#c026d3"/>
          <path d="M50 50 L19 68 A36 36 0 0 1 19 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L19 32 A36 36 0 0 1 50 14 Z" fill="#c026d3"/>
          <circle cx="50" cy="50" r="13" fill="#00b4d8" stroke="#ffffff" stroke-width="1.5"/>
          <text x="50" y="53" fill="#ffffff" font-size="7" font-weight="900" text-anchor="middle" font-family="'Poppins', sans-serif">SPIN</text>
          <polygon points="50,6 45,13 55,13" fill="#60a5fa" stroke="#ffffff" stroke-width="0.8"/>
        </svg>
      </div>
      <span class="wheel-label">Get ₹500</span>
    </a>
    <a href="/promotion" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
      <span>Promotion</span>
    </a>
    <a href="/account" class="nav-item active">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
      <span>Account</span>
    </a>
</nav>
</body>
</html>
"""

support_html = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Self Service Center</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; -webkit-tap-highlight-color: transparent; }
    body { background-color: #f0f2f5; display: flex; justify-content: center; min-height: 100vh; }
    .mobile-container { width: 100%; max-width: 480px; background-color: #ffffff; min-height: 100vh; display: flex; flex-direction: column; box-shadow: 0 0 15px rgba(0,0,0,0.05); position: relative; }
    .header { display: flex; align-items: center; justify-content: space-between; padding: 14px 18px; background-color: #ffffff; border-bottom: 1px solid #f0f0f0; }
    .header-left a { font-size: 22px; color: #333333; text-decoration: none; }
    .header-title { font-size: 17px; font-weight: 600; color: #222222; }
    .header-right { display: flex; align-items: center; gap: 6px; font-size: 14px; font-weight: 600; color: #333; }
    .flag-icon { width: 22px; height: 15px; border-radius: 2px; object-fit: cover; }
    .banner-container { background: linear-gradient(135deg, #120038, #3b007a, #001057); padding: 20px 16px; color: #ffffff; position: relative; overflow: hidden; }
    .banner-title { font-size: 18px; font-weight: 700; color: #ffeb3b; line-height: 1.3; margin-bottom: 6px; }
    .banner-badge { display: inline-block; background: rgba(255, 255, 255, 0.15); border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 20px; padding: 3px 10px; font-size: 11px; margin-bottom: 10px; }
    .banner-features { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; }
    .feature-chip { background: #0044ff; border-radius: 12px; padding: 3px 8px; font-size: 9px; display: flex; align-items: center; gap: 4px; font-weight: 500; }
    .content { padding: 16px 18px; flex: 1; }
    .section-heading { font-size: 16px; font-weight: 700; color: #222222; margin-bottom: 12px; }
    .service-list { display: flex; flex-direction: column; }
    .service-item { display: flex; align-items: center; justify-content: space-between; padding: 14px 4px; border-bottom: 1px solid #f2f2f2; text-decoration: none; cursor: pointer; }
    .service-item:active { background-color: #f8f8f8; }
    .item-left { display: flex; align-items: center; gap: 14px; }
    .icon-circle { width: 42px; height: 42px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 18px; color: #ffffff; flex-shrink: 0; }
    .icon-orange { background: linear-gradient(135deg, #ffb300, #f57c00); }
    .icon-purple { background: linear-gradient(135deg, #a01077, #72095b); }
    .item-label { font-size: 14px; font-weight: 600; color: #333333; }
    .chevron { color: #b0b0b0; font-size: 14px; }
    .tips-box { margin-top: 24px; padding-top: 10px; }
    .tips-title { font-size: 14px; font-weight: 700; color: #333333; margin-bottom: 8px; }
    .tips-text { font-size: 12px; color: #777777; line-height: 1.5; margin-bottom: 8px; }
    .action-container { padding: 16px 18px 25px; }
    .btn-progress { width: 100%; background: linear-gradient(180deg, #ffbb00, #f59e0b); color: #ffffff; border: none; padding: 14px 0; font-size: 16px; font-weight: 600; border-radius: 30px; cursor: pointer; box-shadow: 0 4px 10px rgba(245, 158, 11, 0.3); }
    .floating-chat-btn { position: fixed; bottom: 85px; right: max(20px, calc(50% - 220px)); width: 55px; height: 55px; border-radius: 50%; background: linear-gradient(135deg, #ff9800, #f57c00); color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 24px; box-shadow: 0 6px 18px rgba(245, 124, 0, 0.45); cursor: pointer; z-index: 999; }
    .chat-modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.6); display: none; justify-content: center; align-items: flex-end; z-index: 10000; }
    .chat-container { width: 100%; max-width: 480px; height: 85vh; background: #ffffff; border-radius: 20px 20px 0 0; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 -5px 25px rgba(0, 0, 0, 0.2); animation: slideUp 0.3s ease-out; }
    @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
    .chat-header { background: linear-gradient(135deg, #3b007a, #120038); color: #ffffff; padding: 15px 18px; display: flex; justify-content: space-between; align-items: center; }
    .chat-header-info h3 { font-size: 15px; font-weight: 600; }
    .chat-header-info small { font-size: 11px; color: #ffd54f; }
    .close-chat-btn { font-size: 20px; cursor: pointer; color: #ffffff; opacity: 0.85; }
    .uid-section { background: #f8fafc; padding: 10px 15px; border-bottom: 1px solid #e2e8f0; }
    .uid-badge { padding: 8px 12px; background: #ede9fe; border-radius: 8px; font-size: 13px; font-weight: 600; color: #5b21b6; }
    .chat-body { flex: 1; padding: 15px; overflow-y: auto; background: #f4f6f9; display: flex; flex-direction: column; gap: 12px; }
    .chat-bubble { max-width: 80%; padding: 10px 14px; border-radius: 14px; font-size: 13px; line-height: 1.4; word-break: break-word; }
    .bubble-user { align-self: flex-end; background: linear-gradient(135deg, #a01077, #72095b); color: #ffffff; border-bottom-right-radius: 2px; }
    .bubble-agent { align-self: flex-start; background: #ffffff; color: #1f2937; border: 1px solid #e5e7eb; border-bottom-left-radius: 2px; }
    .bubble-time { font-size: 10px; opacity: 0.65; margin-top: 4px; text-align: right; }
    .chat-footer { padding: 12px 15px; background: #ffffff; border-top: 1px solid #eee; display: flex; gap: 10px; align-items: center; }
    .chat-footer input { flex: 1; padding: 11px 16px; border: 1px solid #ddd; border-radius: 25px; outline: none; font-size: 14px; }
    .chat-footer button { width: 44px; height: 44px; border-radius: 50%; background: linear-gradient(180deg, #ffbb00, #f59e0b); border: none; color: #ffffff; font-size: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center; }
  </style>
</head>
<body>
  <div class="mobile-container">
    <header class="header">
      <div class="header-left"><a href="/account"><i class="fa-solid fa-arrow-left"></i></a></div>
      <div class="header-title">Self Service Center</div>
      <div class="header-right">
        <img src="https://flagcdn.com/w40/us.png" alt="US" class="flag-icon" />
        <span>EN</span>
      </div>
    </header>

    <div class="banner-container">
      <h1 class="banner-title">Welcome to Our<br />Self Service Center!</h1>
      <div class="banner-badge"><i class="fa-solid fa-headset"></i> 24/7 Support • Fast, Secure &amp; Easy Service</div>
      <div class="banner-features">
        <div class="feature-chip"><i class="fa-regular fa-comment-dots"></i> Quick Response</div>
        <div class="feature-chip"><i class="fa-solid fa-shield-halved"></i> Secure Service</div>
        <div class="feature-chip"><i class="fa-solid fa-headphones"></i> Easy Support</div>
      </div>
    </div>

    <main class="content">
      <h2 class="section-heading">Self Service</h2>
      <div class="service-list">
        <div class="service-item" onclick="openChatWithTopic('FAQ')">
          <div class="item-left"><div class="icon-circle icon-orange"><i class="fa-solid fa-comments"></i></div><span class="item-label">FAQ</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Deposit Not Receive')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-solid fa-wallet"></i></div><span class="item-label">Deposit Not Receive</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Withdrawal Problem')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-regular fa-credit-card"></i></div><span class="item-label">Withdrawal Problem</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('IFSC Modification')">
          <div class="item-left"><div class="icon-circle icon-purple" style="font-size:11px;font-weight:800;">IFSC</div><span class="item-label">IFSC Modification</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Delete Withdraw Bank Account')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-solid fa-money-check"></i></div><span class="item-label">Delete Withdraw Bank Account and Rebind</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Delete UPI and Rebind')">
          <div class="item-left"><div class="icon-circle icon-purple" style="font-size:11px;font-weight:800;">UPI</div><span class="item-label">Delete UPI and Rebind</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Change ID Login Password')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-solid fa-lock-open"></i></div><span class="item-label">Change ID Login Password</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Change Bank Name')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-solid fa-building-columns"></i></div><span class="item-label">Change Bank Name</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Delete Old USDT Address')">
          <div class="item-left"><div class="icon-circle icon-purple" style="font-size:14px;font-weight:800;">®</div><span class="item-label">Delete Old USDT Address and Rebind</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Game Problems')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-solid fa-headset"></i></div><span class="item-label">Game Problems</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
      </div>
      <div class="tips-box">
        <h4 class="tips-title">Kind tips</h4>
        <p class="tips-text">1. Please select the relevant query and submit it for review. After successful submission, the customer service specialist will handle it for you immediately.</p>
        <p class="tips-text">2. After submitting for review, you can use [Question in progress] to view the review results of the work order you submitted.</p>
      </div>
    </main>

    <div class="action-container">
      <button class="btn-progress" onclick="openTicketChat()">Progress Query</button>
    </div>
    <div class="floating-chat-btn" onclick="openChat()" title="Open Live Support">
      <i class="fa-solid fa-headset"></i>
    </div>
  </div>

  <div class="chat-modal-overlay" id="chatModal">
    <div class="chat-container">
      <div class="chat-header">
        <div class="chat-header-info">
          <h3>24/7 Live Customer Service</h3>
          <small>UID: {{ uid }}</small>
        </div>
        <i class="fa-solid fa-xmark close-chat-btn" onclick="closeChat()"></i>
      </div>
      <div class="uid-section">
        <div class="uid-badge"><i class="fa-solid fa-user"></i> Your UID: <b>{{ uid }}</b></div>
      </div>
      <div class="chat-body" id="chatBody">
        <div class="chat-bubble bubble-agent">
          Welcome to ShreeWin Support! For fastest help chat on Telegram @Shreewinofficial01_bot
          <div class="bubble-time">System</div>
        </div>
        {% for m in my_msgs %}
        <div class="chat-bubble bubble-user">
          {{ m.message }}
          <div class="bubble-time">{{ m.time }}</div>
        </div>
        {% if m.reply %}
        <div class="chat-bubble bubble-agent">
          <small style="color:#e11d48;font-weight:700;">Support Agent</small><br>
          {{ m.reply }}
          <div class="bubble-time">Replied</div>
        </div>
        {% endif %}
        {% endfor %}
      </div>
      <div class="chat-footer">
        <input type="text" id="chatInput" placeholder="Type your message here..." onkeypress="if(event.key==='Enter') sendMessage()" />
        <button type="button" onclick="sendMessage()"><i class="fa-solid fa-paper-plane"></i></button>
      </div>
    </div>
  </div>

  <script>
    function openChat() {
      // Live support via official Telegram bot
      window.open('{{ support_url }}', '_blank');
    }
    function openTicketChat() {
      document.getElementById('chatModal').style.display = 'flex';
      var body = document.getElementById('chatBody');
      body.scrollTop = body.scrollHeight;
    }
    function closeChat() {
      document.getElementById('chatModal').style.display = 'none';
    }
    function openChatWithTopic(topic) {
      openChat();
      var input = document.getElementById('chatInput');
      input.value = 'I have a query regarding: [' + topic + '] - ';
      input.focus();
    }
    async function sendMessage() {
      var input = document.getElementById('chatInput');
      var text = input.value.trim();
      if (!text) return;
      var form = new FormData();
      form.append('message', text);
      try {
        await fetch('/support', { method: 'POST', body: form, redirect: 'follow' });
        window.location.href = '/support?sent=1&open=1';
      } catch (e) {
        alert('Network error. Please try again.');
      }
    }
    if (location.search.indexOf('open=1') !== -1 || location.search.indexOf('sent=1') !== -1) {
      openChat();
    }
  </script>
</body>
</html>
"""

deposit_html = """


<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>Shree.Win - Deposit</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"><link href="https://fonts.googleapis.com/css2?family=Delius&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet"><style>
        :root {
            --bg-dark: #161239;
            --bg-card: #241d4c;
            --bg-card-alt: #1c1740;
            --bg-card-inner: #1f1b40;
            --primary-purple: #8d7ff7;
            --primary-gradient: linear-gradient(135deg, #a78bfa 0%, #7c66f6 100%);
            --btn-purple: #9b8df8;
            --btn-amount-bg: #2d275e;
            --btn-amount-active: #8d80f8;
            --text-white: #ffffff;
            --text-light: #b0a9d8;
            --color-green: #00e676;
            --color-orange: #ff9800;
            --color-red: #ff4d4f;
            --color-gold: #ffb800;
            --pay-card-bg: #2b245e;
            --input-dark: #272153;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Delius', 'Nunito', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #000;
            display: flex;
            justify-content: center;
            min-height: 100vh;
            overflow-x: hidden; overflow-y: auto;
        }

        /* Mobile Container Frame */
        .app-container {
            width: 100%;
            max-width: 400px;
            min-height: 100vh; height: auto;
            background-color: var(--bg-dark);
            display: flex;
            flex-direction: column;
            position: relative;
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 0 20px rgba(255,255,255,0.1);
        }

        /* Smooth Screen Transition Styles */
        .app-screen {
            display: none;
            flex-direction: column;
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            background-color: var(--bg-dark);
            opacity: 0;
            transition: opacity 0.25s ease-in-out;
            z-index: 1;
        }

        .app-screen.active {
            display: flex;
            opacity: 1;
            z-index: 5;
        }

        /* Shared Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 16px;
            color: var(--text-white);
            background-color: var(--bg-dark);
            z-index: 10;
        }
        .header .back-btn {
            font-size: 1.1rem;
            cursor: pointer;
            padding: 5px;
        }
        .header .title {
            font-size: 1.25rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .header .history-link {
            font-size: 0.9rem;
            color: #d8d4fd;
            text-decoration: none;
            cursor: pointer;
        }

        /* Scrollable Area */
        .scrollable-content {
            flex: 1;
            overflow-y: auto; -webkit-overflow-scrolling: touch; flex: 1; min-height: 0;
            scrollbar-width: none;
        }
        .scrollable-content::-webkit-scrollbar {
            display: none;
        }

        /* Floating Support */
        .sub-fab-right {
            position: fixed !important;
            bottom: 90px !important;
            right: 16px !important;
            width: 56px !important;
            height: 56px !important;
            border-radius: 50% !important;
            background: #00e676 !important;
            box-shadow: 0 0 20px rgba(0, 230, 118, 0.65), 0 4px 12px rgba(0,0,0,0.3) !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            cursor: pointer !important;
            border: 3.5px solid #ffffff !important;
            z-index: 999 !important;
        }
        .sub-fab-right i { color: #0b1f13 !important; font-size: 1.55rem !important; }

        /* ================= 1. ACCOUNT VIEW STYLES ================= */
        .profile-header {
            background: linear-gradient(180deg, #9b89ff 0%, #6e55f8 50%, var(--bg-dark) 100%);
            padding: 24px 16px 15px 16px;
            position: relative;
        }
        .profile-row {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .avatar-wrap {
            position: relative;
            width: 72px;
            height: 72px;
            border-radius: 50%;
            border: 2px solid rgba(255, 255, 255, 0.6);
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            flex-shrink: 0;
            background: #25204d;
        }
        .avatar-wrap img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .user-details {
            display: flex;
            flex-direction: column;
            gap: 4px;
            flex: 1;
        }
        .username-row {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .username {
            color: #ffffff;
            font-size: 1.15rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .vip-badge {
            background: linear-gradient(135deg, #e2e8f0 0%, #94a3b8 100%);
            color: #1e1b4b;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 800;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        .uid-pill {
            background: rgba(255, 152, 0, 0.9);
            color: #ffffff;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            width: fit-content;
            cursor: pointer;
            margin-top: 2px;
        }
        .last-login {
            color: #d1ccff;
            font-size: 0.72rem;
            margin-top: 2px;
        }

        .main-padding { padding: 0 14px; }

        .wallet-card {
            background-color: var(--bg-card);
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 14px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.25);
        }
        .wallet-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .wallet-left {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .wallet-title {
            color: #a7a0d8;
            font-size: 0.9rem;
        }
        .balance-value-row {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #ffffff;
            font-size: 1.8rem;
            font-weight: bold;
        }
        .balance-value-row i {
            font-size: 1.1rem;
            color: #a7a0d8;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .btn-enter-wallet {
            background-color: #beb4ff;
            color: #2b2361;
            border: none;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
            cursor: pointer;
        }

        .wallet-actions-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            text-align: center;
        }
        .w-action-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            cursor: pointer;
            text-decoration: none;
        }
        .w-action-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
        }
        .w-action-icon.arwallet { background: rgba(255, 77, 79, 0.15); color: #ff4d4f; }
        .w-action-icon.deposit { background: rgba(255, 152, 0, 0.15); color: #ff9800; }
        .w-action-icon.withdraw { background: rgba(0, 186, 242, 0.15); color: #00baf2; }
        .w-action-icon.vip { background: rgba(0, 230, 118, 0.15); color: #00e676; }
        .w-action-label {
            color: #ffffff;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .history-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 14px;
        }
        .history-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            text-decoration: none;
        }
        .hist-icon-wrap {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }
        .hist-icon-wrap.game { background: #1a73e8; color: white; }
        .hist-icon-wrap.trans { background: #00c853; color: white; }
        .hist-icon-wrap.dep { background: #e53935; color: white; }
        .hist-icon-wrap.with { background: #fb8c00; color: white; }
        .hist-text { display: flex; flex-direction: column; overflow-x: hidden; overflow-y: auto; }
        .hist-title { color: #ffffff; font-size: 0.95rem; font-weight: bold; line-height: 1.1; }
        .hist-sub { color: #8f88c2; font-size: 0.72rem; margin-top: 2px; white-space: nowrap; }

        .menu-card {
            background-color: var(--bg-card);
            border-radius: 14px;
            overflow-x: hidden; overflow-y: auto;
            margin-bottom: 14px;
        }
        .menu-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            cursor: pointer;
            text-decoration: none;
            color: #ffffff;
        }
        .menu-row:last-child { border-bottom: none; }
        .menu-row-left { display: flex; align-items: center; gap: 14px; font-size: 0.95rem; font-weight: 600; }
        .menu-row-left i { font-size: 1.2rem; color: #9b8df8; width: 22px; text-align: center; }
        .menu-row-right { display: flex; align-items: center; gap: 8px; color: #7b74ba; font-size: 0.85rem; }

        .service-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 18px;
        }
        .service-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 16px; }
        .service-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            row-gap: 20px;
            column-gap: 8px;
            text-align: center;
        }
        .service-item { display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; text-decoration: none; }
        .service-icon { font-size: 1.6rem; color: #8d7ff7; }
        .service-label { color: #ffffff; font-size: 0.82rem; font-weight: 600; line-height: 1.2; }

        .btn-logout {
            width: 100%;
            background-color: transparent;
            border: 1px solid #4a3e8e;
            color: #ffffff;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 30px;
        }

        /* ================= 2. DEPOSIT VIEW STYLES ================= */
        .deposit-pad { padding: 10px 14px 155px 14px; }
        .balance-card {
            background: var(--primary-gradient);
            border-radius: 16px;
            padding: 20px 18px;
            color: white;
            position: relative;
            overflow-x: hidden; overflow-y: auto;
            margin-bottom: 15px;
            box-shadow: 0 4px 15px rgba(124, 102, 246, 0.25);
        }
        .balance-label {
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 8px;
            opacity: 0.95;
        }
        .balance-amount {
            font-size: 2rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .balance-amount i { font-size: 1.2rem; cursor: pointer; transition: transform 0.4s ease; }
        .balance-card .dots-bg {
            position: absolute;
            bottom: 8px;
            right: 15px;
            color: rgba(255, 255, 255, 0.3);
            font-size: 1.1rem;
            letter-spacing: 2px;
            font-weight: bold;
        }

        .channels-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 15px;
        }
        .channel-card {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 4px 10px 4px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            position: relative;
            border: 1px solid transparent;
            min-height: 86px;
        }
        .channel-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .channel-icon-wrap {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 6px;
        }
        .channel-name { color: white; font-size: 0.72rem; font-weight: 600; line-height: 1.1; }
        .channel-badge {
            position: absolute;
            top: -4px;
            right: -2px;
            background-color: var(--color-red);
            color: white;
            font-size: 0.65rem;
            font-weight: bold;
            padding: 2px 5px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 2px;
        }

        .amount-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .section-title {
            color: white;
            font-size: 1.05rem;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 14px;
            font-weight: bold;
        }
        .section-title i { color: #b0a5fa; }

        .amount-grid-deposit {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 15px;
        }
        .amount-btn {
            background-color: var(--btn-amount-bg);
            border: 1px solid rgba(255, 255, 255, 0.05);
            color: #bcb6ea;
            padding: 12px 5px;
            border-radius: 8px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
            transition: all 0.2s ease;
        }
        .amount-btn:hover, .amount-btn:active, .amount-btn.active {
            background-color: var(--btn-amount-active);
            color: white;
            box-shadow: 0 2px 8px rgba(141, 128, 248, 0.4);
        }

        .amount-input-box {
            background-color: var(--bg-card-inner);
            border-radius: 25px;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .amount-input-box .currency-sym {
            color: #958df1;
            font-size: 1.1rem;
            font-weight: bold;
            padding-right: 10px;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
            margin-right: 10px;
        }
        .amount-input-box input {
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: #ffffff;
            font-size: 0.95rem;
        }
        .amount-input-box input::placeholder { color: #7b74ba; }
        .amount-input-box .clear-btn { color: #7b74ba; font-size: 1rem; cursor: pointer; padding: 2px 5px; }

        .instruction-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .instruction-inner {
            background-color: var(--bg-card-inner);
            border-radius: 10px;
            padding: 14px;
        }
        .instruction-list { list-style: none; }
        .instruction-list li {
            position: relative;
            padding-left: 18px;
            color: #9e97d8;
            font-size: 0.82rem;
            line-height: 1.45;
            margin-bottom: 14px;
        }
        .instruction-list li:last-child { margin-bottom: 0; }
        .instruction-list li::before {
            content: '◆';
            position: absolute;
            left: 0;
            top: 0;
            color: #8d80f8;
            font-size: 0.75rem;
        }

        .sub-no-data-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px 0 10px 0;
        }
        .sub-no-data-icon { width: 170px; height: 120px; opacity: 0.85; margin-bottom: 10px; }
        .sub-no-data-text { color: #ffffff; font-size: 1.15rem; font-weight: 500; }

        .history-card-item {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-left: 4px solid var(--color-green);
        }
        .history-card-item.pending { border-left-color: var(--color-orange); }
        .history-card-item.rejected { border-left-color: var(--color-red); }
        .history-card-left .hist-amount { font-size: 1.1rem; font-weight: bold; color: white; margin-bottom: 2px;}
        .history-card-left .hist-utr { font-size: 0.75rem; color: var(--text-light); }
        .history-card-right { text-align: right; }
        .history-card-right .hist-status { font-size: 0.8rem; font-weight: bold; text-transform: capitalize; }
        .history-card-right .hist-time { font-size: 0.7rem; color: var(--text-light); margin-top: 2px; }

        .status-approved { color: var(--color-green); }
        .status-pending { color: var(--color-orange); }
        .status-rejected { color: var(--color-red); }

        .deposit-bottom-bar {
            position: fixed;
            bottom: 64px;
            left: 0;
            right: 0;
            background-color: #171337;
            padding: 12px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 150;
            max-width: 400px;
            margin: 0 auto;
            box-shadow: 0 -4px 16px rgba(0,0,0,.22);
        }
        .recharge-method-info { display: flex; flex-direction: column; }
        .recharge-method-info .label { font-size: 0.78rem; color: #ffffff; margin-bottom: 2px; }
        .recharge-method-info .method-name { font-size: 0.95rem; color: #ffffff; font-weight: bold; }
        .deposit-btn {
            background-color: var(--primary-purple);
            color: white;
            border: none;
            padding: 10px 28px;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }

        /* Gateway Screen (ArUpiPay) */
        .cs-pill-btn {
            background: linear-gradient(90deg, #7c67ff 0%, #6852ee 100%);
            color: white;
            font-size: 0.8rem;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            cursor: pointer;
            font-weight: 600;
        }
        .pay-amount-bar {
            background-color: var(--pay-card-bg);
            border-radius: 12px;
            padding: 16px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .pay-amount-left { display: flex; align-items: center; gap: 12px; color: #ffffff; font-size: 1.7rem; font-weight: bold; }
        .pay-amount-left i { font-size: 1.25rem; color: #d1ccff; cursor: pointer; }
        .pay-timer { color: var(--color-red); font-size: 1.15rem; font-weight: bold; letter-spacing: 0.5px; }

        .pay-bullet-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
        .pay-bullet-title::before { content: '•'; color: #ffffff; font-size: 1.3rem; line-height: 0; }

        .pay-methods-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
        .pay-method-card { border-radius: 12px; padding: 12px 10px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; cursor: pointer; transition: transform 0.15s ease; }
        .pay-method-card:active { transform: scale(0.97); }
        .pay-method-card.paytm { background: linear-gradient(135deg, #d4f8ff 0%, #a4e6f9 100%); color: #042e6f; }
        .pay-method-card.phonepe { background: linear-gradient(135deg, #fce8ff 0%, #ebd0fc 100%); color: #5f259f; }
        .pay-logo-wrap { display: flex; align-items: center; gap: 6px; font-size: 1.05rem; font-weight: bold; margin-bottom: 4px; }
        .pay-logo-img { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.85rem; font-weight: bold; }
        .paytm .pay-logo-img { background-color: #002e6e; font-size: 0.6rem; }
        .phonepe .pay-logo-img { background-color: #5f259f; font-size: 1rem; }
        .wake-text { font-size: 0.75rem; color: #8b80cf; font-weight: 600; }

        .qr-card {
            background-color: #372f78;
            border-radius: 14px;
            padding: 22px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            margin-bottom: 22px;
        }
        .qr-image-wrapper {
            background-color: #ffffff;
            padding: 12px;
            border-radius: 14px;
            display: inline-block;
            margin-bottom: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        .qr-image-wrapper img { width: 180px; height: 180px; display: block; margin: 0 auto; }
        .qr-upi-info { color: #332d5e; font-size: 0.82rem; font-weight: bold; margin-top: 8px; font-family: 'Nunito', sans-serif; }
        .qr-desc { color: #ffffff; font-size: 0.88rem; line-height: 1.45; text-align: left; width: 100%; margin-top: 6px; }
        .qr-desc p { margin-bottom: 8px; }

        .utr-warning-text { color: var(--color-red); font-size: 0.95rem; line-height: 1.35; font-weight: bold; margin-bottom: 12px; }
        .utr-input-box {
            background-color: #272153;
            border-radius: 30px;
            padding: 6px 6px 6px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 22px;
            box-shadow: 0 0 10px rgba(186, 104, 200, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .utr-input-box input { background: transparent; border: none; outline: none; color: #b7b0ee; font-size: 0.95rem; width: 70%; }
        .utr-paste-btn { background-color: #8d80f8; color: #ffffff; border: none; padding: 8px 18px; border-radius: 20px; font-size: 0.9rem; font-weight: bold; cursor: pointer; }
        .reminder-list { color: #ffffff; font-size: 0.9rem; line-height: 1.6; margin-bottom: 25px; }

        .pay-bottom-bar {
            position: fixed !important;
            bottom: 0 !important;
            left: 0;
            right: 0;
            max-width: 400px;
            margin: 0 auto;
            background-color: #1a1540;
            padding: 12px 16px calc(12px + env(safe-area-inset-bottom, 0px));
            display: flex !important;
            gap: 12px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 2000 !important;
            box-sizing: border-box;
        }
        .btn-cancel { flex: 0.35; background-color: #38306e; color: #ffffff; border: none; padding: 12px 0; border-radius: 8px; font-size: 0.95rem; font-weight: bold; cursor: pointer; }
        .btn-submit-utr { flex: 0.65; background: linear-gradient(90deg,#8b5cf6,#7c3aed); color: #fff; border: none; padding: 14px 0; border-radius: 12px; font-size: 1rem; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(124,58,237,0.4); }
        .btn-submit-utr.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 12px rgba(141, 128, 248, 0.4); }

        /* ================= 3. WITHDRAW VIEW STYLES ================= */
        .withdraw-pad { padding: 10px 14px 40px 14px; }
        .arpay-banner {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 14px;
        }
        .arpay-logo { font-size: 2rem; color: #ffb800; font-weight: 900; line-height: 1; }
        .arpay-text h4 { color: white; font-size: 1.05rem; font-weight: bold; margin-bottom: 2px; }
        .arpay-text p { color: #9e97d8; font-size: 0.8rem; }

        .methods-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 14px;
        }
        .method-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            min-height: 90px;
            transition: all 0.2s;
        }
        .method-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .method-icon { font-size: 1.8rem; margin-bottom: 6px; height: 36px; display: flex; align-items: center; justify-content: center; }
        .method-name { color: white; font-size: 0.8rem; font-weight: 700; letter-spacing: 0.5px; }

        .account-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
            cursor: pointer;
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: 0.2s;
        }
        .account-card:active { transform: scale(0.98); }
        .account-left { display: flex; flex-direction: column; gap: 4px; }
        .account-name-row { display: flex; align-items: center; gap: 8px; color: white; font-size: 1rem; font-weight: bold; }
        .account-vpa { color: #9e97d8; font-size: 0.9rem; font-weight: 600; }
        .account-card i.fa-chevron-right { color: #7b74ba; font-size: 0.95rem; }

        .add-bank-box {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 24px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            margin-bottom: 6px;
        }
        .dashed-plus-icon {
            width: 46px;
            height: 46px;
            border: 2px dashed #7a70bb;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7a70bb;
            font-size: 1.5rem;
            margin-bottom: 12px;
        }
        .add-bank-text { color: #8c82cb; font-size: 1rem; font-weight: bold; }
        .add-bank-warning { color: var(--color-red); font-size: 0.8rem; text-align: center; margin-bottom: 14px; line-height: 1.3; }

        .amount-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 14px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.88rem;
            margin-bottom: 8px;
            color: #bcb6ea;
        }
        .btn-all-pill {
            background-color: #38306e;
            color: white;
            border: none;
            padding: 3px 18px;
            border-radius: 14px;
            font-size: 0.8rem;
            font-weight: bold;
            cursor: pointer;
        }
        .received-val { color: #ff9800; font-weight: bold; font-size: 1.1rem; }

        .withdraw-action-btn {
            width: 100%;
            background-color: #d1cbff;
            color: #7a6fc7;
            border: none;
            padding: 14px;
            border-radius: 25px;
            font-size: 1.05rem;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 20px;
            transition: 0.2s;
        }
        .withdraw-action-btn.ready {
            background: var(--primary-purple);
            color: white;
            box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4);
        }
        .val-red { color: var(--color-red); font-weight: bold; }

        .btn-all-history {
            width: 100%;
            background-color: transparent;
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #bcb6ea;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
        }

        /* Payment Method Screen (UPI Sub-Screen) */
        .pm-account-card {
            background-color: #262153;
            border-radius: 14px;
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            margin-bottom: 15px;
        }
        .pm-card-header-stripe { height: 38px; background: linear-gradient(90deg, #0066ff 0%, #0088ff 100%); width: 100%; }
        .pm-card-body { padding: 18px 16px; color: #ffffff; }
        .pm-info-row { font-size: 1rem; color: #d1ccff; margin-bottom: 12px; letter-spacing: 0.3px; }
        .pm-info-row .bold-text { color: #ffffff; font-weight: bold; }
        .pm-current-tag { display: flex; align-items: center; gap: 8px; color: #a49fc7; font-size: 0.92rem; margin-top: 14px; }
        .pm-check-circle { width: 20px; height: 20px; background-color: var(--color-red); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.75rem; }
        .pm-bottom-bar { position: fixed !important; bottom: 0 !important; left: 0; right: 0; padding: 16px; background-color: #1a1540; z-index: 99999 !important; max-width: 400px; margin: 0 auto; box-shadow: 0 -4px 20px rgba(0,0,0,0.5); }
        .btn-add-method { width: 100%; background: linear-gradient(90deg,#8b5cf6,#7c3aed) !important; color: #fff !important; border: none; padding: 16px; border-radius: 30px; font-size: 1.1rem; font-weight: 800; cursor: pointer; box-shadow: 0 4px 15px rgba(139,92,246,0.5); }

        /* Add Bank Sub-Screen */
        .ab-notice-pill { background-color: #272153; border-radius: 20px; padding: 10px 14px; display: flex; align-items: center; gap: 10px; margin-bottom: 18px; color: var(--color-red); font-size: 0.8rem; line-height: 1.35; }
        .ab-form-group { margin-bottom: 16px; }
        .ab-label { color: #ffffff; font-size: 0.95rem; font-weight: bold; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .ab-label i { color: #8d7ff7; font-size: 1rem; }
        .ab-select-box { background: linear-gradient(90deg, #6b55fb 0%, #503ef0 100%); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; color: #ffffff; cursor: pointer; font-size: 0.95rem; font-weight: bold; }
        .ab-input-box { background-color: var(--input-dark); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; }
        .ab-input { width: 100%; background: transparent; border: none; outline: none; color: #ffffff; font-size: 0.95rem; font-family: 'Delius', sans-serif; }
        .ab-input::placeholder { color: #766eb5; }
        .ab-bottom-bar { padding: 14px 16px; background-color: var(--bg-dark); }
        .btn-save-bank { width: 100%; background-color: #d1cbff; color: #7a6fc7; border: none; padding: 15px; border-radius: 25px; font-size: 1.1rem; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .btn-save-bank.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4); }

        /* Bank Selector Modal */
        .bank-modal {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 50;
            display: none;
            flex-direction: column;
            justify-content: flex-end;
        }
        .bank-modal-content {
            background: var(--bg-card);
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            padding: 20px;
            max-height: 70vh;
            display: flex;
            flex-direction: column;
        }
        .bank-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 14px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .bank-list { overflow-y: auto; flex: 1; }
        .bank-item {
            padding: 14px 12px;
            color: #d1ccff;
            font-size: 0.95rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .bank-item:hover, .bank-item:active { background: rgba(255,255,255,0.08); color: white; }

        /* Gift Claim Popup Modal */
        .gift-modal-backdrop {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 100;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .gift-popup-card {
            background: var(--bg-card);
            border-radius: 18px;
            width: 100%;
            max-width: 320px;
            padding: 24px 20px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.6);
            border: 1px solid rgba(255,255,255,0.1);
        }
        .gift-popup-card i.fa-gift { font-size: 3rem; color: #ffb800; margin-bottom: 12px; }
        .gift-input {
            width: 100%;
            background: var(--bg-card-alt);
            border: 1px solid rgba(255,255,255,0.1);
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-size: 1rem;
            text-transform: uppercase;
            text-align: center;
            margin: 14px 0;
            outline: none;
            font-family: 'Nunito', sans-serif;
            font-weight: bold;
        }
        .btn-claim-gift {
            width: 100%;
            background: var(--primary-purple);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }
    .bnav{position:absolute;bottom:0;left:0;right:0;background:#16122e;z-index:100;border-top:1px solid #2a1f55}.bnav img{width:100%;display:block}.bnav-links{position:absolute;inset:0;display:flex}.bnav-links a{flex:1;height:100%;display:block}

/* Bottom Navigation Fix */.bottom-navbar{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:400px;height:65px;background:#141332;border-top:1px solid #26244f;display:flex;justify-content:space-around;align-items:center;z-index:1000;padding-bottom:5px;box-sizing:border-box}.bottom-navbar .nav-item{display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:#5d5c88;font-size:11px;font-weight:600;flex:1}.bottom-navbar .nav-item svg{width:26px;height:26px;fill:#5d5c88;margin-bottom:2px}.bottom-navbar .nav-item.active{color:#6965e8}.bottom-navbar .nav-item.active svg{fill:#6965e8}.bottom-navbar .wheel-item{position:relative;top:-16px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;flex:1.2;text-decoration:none}.bottom-navbar .wheel-wrapper{width:72px;height:72px;position:relative;display:flex;justify-content:center;align-items:center}.bottom-navbar .wheel-wrapper svg{width:100%;height:100%}.bottom-navbar .wheel-label{position:absolute;bottom:-6px;white-space:nowrap;font-size:13px;font-weight:900;color:#ffe600;text-shadow:-1.5px -1.5px 0 #b30000,1.5px -1.5px 0 #b30000,-1.5px 1.5px 0 #b30000,1.5px 1.5px 0 #b30000}.scrollable-content{padding-bottom:90px !important}.screen-payment-gateway .scrollable-content, #screen-payment-gateway {
            padding-bottom: 90px !important;
        }
        #screen-payment-gateway .pay-bottom-bar {
            z-index: 2000 !important;
        }
        .bottom-navbar.hidden-for-pay, .bnav.hidden-for-pay {
            display: none !important;
        }
</style>
<style>
/* smooth deposit polish */
.app-container, .app-screen, .scrollable-content {
  -webkit-overflow-scrolling: touch;
  scroll-behavior: smooth;
}
.amount-btn, .channel-card, .deposit-btn {
  transition: transform .15s ease, background .2s ease, box-shadow .2s ease;
}
.amount-btn:active, .channel-card:active, .deposit-btn:active {
  transform: scale(0.96);
}
.amount-btn.active {
  box-shadow: 0 4px 14px rgba(141,128,248,.45);
}
.channel-card.active {
  box-shadow: 0 4px 14px rgba(104,82,238,.4);
}
.deposit-bottom-bar {
  backdrop-filter: blur(8px);
  box-shadow: 0 -8px 24px rgba(0,0,0,.25);
}
#screen-payment-gateway {
  animation: fadeIn .25s ease;
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: none; }
}
</style>
</head><body><div class="app-container"><style>#screen-deposit.app-screen.active{display:flex!important;opacity:1!important;position:relative!important;z-index:1!important;height:auto!important;min-height:100vh!important}#screen-payment-gateway{display:none}#screen-payment-gateway.active{display:flex!important}</style><div class="app-screen active" id="screen-deposit" class="app-screen active">
<div class="header">
<div class="back-btn" onclick="window.location.href='/account'"><i class="fa-solid fa-chevron-left"></i></div>
<div class="title">Deposit</div>
<a class="history-link" href="/deposit-history">Deposit history</a>
</div>
<div class="scrollable-content deposit-pad" id="deposit-scroll-area">
<!-- Balance Card -->
<div class="balance-card">
<div class="balance-label">
<i class="fa-solid fa-wallet"></i> Balance
                </div>
<div class="balance-amount">
<span id="deposit-balance-val">₹{{ balance }}</span>
<i class="fa-solid fa-arrows-rotate" id="refresh-deposit-btn" onclick="refreshMasterBalance()"></i>
</div>
<div class="dots-bg">**** ****</div>
</div>
<!-- Channels Selector -->
<div class="channels-grid">
<div class="channel-card active" data-channel="UPI-QR" onclick="selectDepositChannel(this)">
<div class="channel-icon-wrap"><i class="fa-solid fa-qrcode" style="font-size: 1.8rem; color: #00e676;"></i></div>
<div class="channel-name">UPI-QR</div>
</div>
<div class="channel-card" data-channel="Innate UPI-QR" onclick="selectDepositChannel(this)">
<div class="channel-icon-wrap"><i class="fa-solid fa-qrcode" style="font-size: 1.8rem; color: #38ef7d;"></i></div>
<div class="channel-name">Innate UPI-QR</div>
</div>
<div class="channel-card" data-channel="PAYTM" onclick="selectDepositChannel(this)">
<div class="channel-icon-wrap"><i class="fa-solid fa-mobile-screen-button" style="font-size: 1.8rem; color: #00baf2;"></i></div>
<div class="channel-name">PAYTM</div>
</div>
<div class="channel-card" data-channel="ARPay" onclick="selectDepositChannel(this)">
<div class="channel-badge"><i class="fa-solid fa-gift"></i>+2%</div>
<div class="channel-icon-wrap"><i class="fa-solid fa-shapes" style="font-size: 1.8rem; color: #ffbc00;"></i></div>
<div class="channel-name">ARPay</div>
</div>
<div class="channel-card" data-channel="Expert UPI-QR" onclick="selectDepositChannel(this)">
<div class="channel-icon-wrap"><i class="fa-solid fa-qrcode" style="font-size: 1.8rem; color: #ff5722;"></i></div>
<div class="channel-name">Expert UPI-QR</div>
</div>
</div>
<!-- Amount Section -->
<div class="amount-section">
<div class="section-title"><i class="fa-solid fa-money-bill-wave"></i> Deposit amount</div>
<div class="amount-grid-deposit">
<div class="amount-btn active" onclick="onDepositAmountClick(100)">₹ 100</div>
<div class="amount-btn" onclick="onDepositAmountClick(300)">₹ 300</div>
<div class="amount-btn" onclick="onDepositAmountClick(500)">₹ 500</div>
<div class="amount-btn" onclick="onDepositAmountClick(1000)">₹ 1K</div>
<div class="amount-btn" onclick="onDepositAmountClick(2000)">₹ 2K</div>
<div class="amount-btn" onclick="onDepositAmountClick(3000)">₹ 3K</div>
<div class="amount-btn" onclick="onDepositAmountClick(5000)">₹ 5K</div>
<div class="amount-btn" onclick="onDepositAmountClick(10000)">₹ 10K</div>
<div class="amount-btn" onclick="onDepositAmountClick(20000)">₹ 20K</div>
<div class="amount-btn" onclick="onDepositAmountClick(30000)">₹ 30K</div>
<div class="amount-btn" onclick="onDepositAmountClick(40000)">₹ 40K</div>
<div class="amount-btn" onclick="onDepositAmountClick(50000)">₹ 50K</div>
</div>
<div class="amount-input-box">
<div class="currency-sym">₹</div>
<input id="deposit-input" placeholder="₹100.00 - ₹50,000.00" type="number" value="100" oninput="window.selectedDepositAmount=parseFloat(this.value)||0"/>
<div class="clear-btn" onclick="document.getElementById('deposit-input').value=''"><i class="fa-regular fa-circle-xmark"></i></div>
</div>
</div>
<!-- Recharge Instructions -->
<div class="instruction-section">
<div class="section-title"><i class="fa-solid fa-book-open"></i> Recharge instructions</div>
<div class="instruction-inner">
<ul class="instruction-list">
<li>If the transfer time is up, please fill out the deposit form again.</li>
<li>The transfer amount must match the order you created, otherwise the money cannot be credited successfully.</li>
<li>If you transfer the wrong amount, our company will not be responsible for the lost amount!</li>
<li>Note: do not cancel the deposit order after the money has been transferred.</li>
</ul>
</div>
</div>
<!-- Deposit History -->
<div class="history-section" id="deposit-history-anchor">
<div class="section-title"><i class="fa-solid fa-file-invoice"></i> Deposit history</div>
<div id="deposit-history-container">
<div class="sub-no-data-area" id="no-deposit-history-view" style="display:none;">
<svg class="sub-no-data-icon" fill="none" viewbox="0 0 200 150" xmlns="http://www.w3.org/2000/svg">
<path d="M20 100 Q 60 70 100 95 Q 150 75 180 105 L 180 140 L 20 140 Z" fill="#2a245c"></path>
<path d="M50 110 Q 90 85 130 110 Q 165 95 190 120 L 190 140 L 50 140 Z" fill="#363073"></path>
<path d="M35 125 C 28 115 28 100 35 90 C 42 100 42 115 35 125 Z" fill="#6d65b5"></path>
<rect fill="#4d478a" height="10" width="2" x="34" y="125"></rect>
<path d="M165 130 C 160 122 160 112 165 105 C 170 112 170 122 165 130 Z" fill="#6d65b5"></path>
<rect fill="#4d478a" height="8" width="1" x="164.5" y="130"></rect>
<rect fill="#756bbd" height="75" rx="4" width="50" x="90" y="45"></rect>
<rect fill="#8d84d6" height="12" rx="3" width="45" x="95" y="40"></rect>
<rect fill="#8d84d6" height="12" rx="4" width="55" x="80" y="120"></rect>
<rect fill="#857ccf" height="65" opacity="0.9" width="55" x="90" y="55"></rect>
<rect fill="#645ca3" height="20" rx="3" width="20" x="140" y="105"></rect>
</svg>
<div class="sub-no-data-text">No data</div>
</div>
<div id="deposit-history-list-view">
<div class="history-card-item approved">
  <div class="history-card-left">
    <div class="hist-amount">₹500.00</div>
    <div class="hist-utr">UTR: 123456789012</div>
  </div>
  <div class="history-card-right">
    <div class="hist-status status-approved">Approved</div>
    <div class="hist-time">2025-09-18 14:32</div>
  </div>
</div>
<div class="history-card-item pending">
  <div class="history-card-left">
    <div class="hist-amount">₹1,000.00</div>
    <div class="hist-utr">UTR: 987654321098</div>
  </div>
  <div class="history-card-right">
    <div class="hist-status status-pending">Processing</div>
    <div class="hist-time">2025-09-19 09:15</div>
  </div>
</div>
</div>
</div>
</div>
</div>
<!-- Fixed Bottom Deposit Bar -->
<div class="deposit-bottom-bar">
<div class="recharge-method-info">
<span class="label">Recharge Method:</span>
<span class="method-name" id="selected-method-text">UPI-QR</span>
</div>
<button class="deposit-btn" onclick="event.preventDefault();openPaymentGateway();return false;">Deposit</button>
</div>
<div class="sub-fab-right" style="bottom: 75px;cursor:pointer" onclick="window.open('https://t.me/Shreewinofficial01_bot','_blank')" title="Customer Service"><i class="fa-solid fa-headset"></i></div>
</div><div class="app-screen" id="screen-payment-gateway">
<div class="header">
<div class="back-btn" onclick="closePaymentGateway()"><i class="fa-solid fa-chevron-left"></i></div>
<div class="title">ArUpiPay</div>
<button class="cs-pill-btn" type="button" onclick="window.open('https://t.me/Shreewinofficial01_bot','_blank')">Customer Service</button>
</div>
<div class="scrollable-content" style="padding: 14px 14px 130px 14px;">
<div class="pay-amount-bar">
<div class="pay-amount-left">
<span id="gateway-amount-display">₹0.00</span>
<i class="fa-regular fa-copy" onclick="copyAmount()" title="Copy Amount"></i>
</div>
<div class="pay-timer" id="pay-countdown">15:00</div>
</div>
<div class="pay-bullet-title">Choose a payment method to pay</div>
<div class="pay-methods-row">
<div class="pay-method-card paytm" onclick="openAppPay('paytm')">
<div class="pay-logo-wrap">
<div class="pay-logo-img">paytm</div>
<span>Paytm</span>
</div>
<span class="wake-text">Wake up support</span>
</div>
<div class="pay-method-card phonepe" onclick="openAppPay('phonepe')">
<div class="pay-logo-wrap">
<div class="pay-logo-img">पे</div>
<span>PhonePe</span>
</div>
<span class="wake-text">Open app</span>
</div>
<div class="pay-method-card" onclick="openAppPay('gpay')" style="background:linear-gradient(135deg,#1a73e8,#0d47a1);">
<div class="pay-logo-wrap">
<div class="pay-logo-img" style="background:#fff;color:#1a73e8;font-weight:800;font-size:0.75rem;">G</div>
<span>GPay</span>
</div>
<span class="wake-text">Open app</span>
</div>
<div class="pay-method-card" onclick="openAppPay('upi')" style="background:linear-gradient(135deg,#6a1b9a,#4a148c);">
<div class="pay-logo-wrap">
<div class="pay-logo-img" style="background:#fff;color:#6a1b9a;font-size:0.7rem;">UPI</div>
<span>Any UPI</span>
</div>
<span class="wake-text">Open app</span>
</div>
</div>
<div class="pay-bullet-title">Use Mobile Scan code to pay</div>
<div class="qr-card">
<div class="qr-image-wrapper">
<img alt="UPI QR" id="dynamic-qr-img" src=""/>
<div class="qr-upi-info" id="qr-upi-text">UPI ID: {{ upi_vpa }}</div>
</div>
<div class="qr-desc">
<p>1. Please use another device to scan the QR code with your payment app</p>
<p>2. If you scan the QR code from this device's gallery, the payment amount may be limited (≤2000).</p>
</div>
</div>
<div class="pay-bullet-title">Input UTR/ Paste UTR</div>
<div class="utr-warning-text">
                If you do not back fill UTR/ paste UTR, 100% will fail.
            </div>
<div class="utr-input-box">
<input id="utr-input" maxlength="12" oninput="validateUTR(this.value)" placeholder="Input 12 digits here" type="text"/>
<button class="utr-paste-btn" onclick="pasteUTR()">Paste</button>
</div>
<div class="pay-bullet-title">Important reminder:</div>
<div class="reminder-list">
<p>1. Do not pay for the same link repeatedly!</p>
<p>2. Paytm is wake up support!</p>
</div>
</div>
<div class="pay-bottom-bar" id="utr-action-bar" style="display:flex!important;z-index:2000!important;position:fixed!important;bottom:0!important;left:0;right:0;">
<button class="btn-cancel" onclick="closePaymentGateway()" style="flex:0.35;background:#38306e;color:#fff;border:none;padding:14px 0;border-radius:12px;font-size:15px;font-weight:600;">Cancel</button>
<button class="btn-submit-utr" id="submit-utr-btn" onclick="submitUTR()" style="flex:0.65;background:linear-gradient(90deg,#8b5cf6,#7c3aed);color:#fff!important;border:none;border-radius:12px;font-weight:700;font-size:16px;padding:14px 0;">SUBMIT UTR</button>
</div>
</div></div><script>
function showAppScreen(screenId,anchorId=null){const t=document.getElementById(screenId);if(!t){if(screenId==="screen-account"){window.location.href="/account";}else if(screenId==="screen-deposit"){window.location.href="/deposit";}else if(screenId==="screen-withdraw"){window.location.href="/withdraw";}return;}document.querySelectorAll(".app-screen").forEach(s=>s.classList.remove("active"));t.classList.add("active");const hideNav=["screen-payment-gateway","screen-payment-method","screen-add-bank","screen-payment"].includes(screenId);document.querySelectorAll(".bnav,.bottom-navbar,.bottom-nav").forEach(function(nav){nav.style.display=hideNav?"none":"";});if(anchorId)setTimeout(()=>{const e=document.getElementById(anchorId);if(e)e.scrollIntoView({behavior:"smooth"});},100);}function scrollToAnchor(areaId,anchorId){const e=document.getElementById(anchorId);if(e)e.scrollIntoView({behavior:'smooth'});}
function refreshMasterBalance(){document.querySelectorAll('[data-balance]').forEach(e=>e.innerText='₹{{ balance }}');document.querySelectorAll('#deposit-balance-val,#withdraw-balance-val,#withdrawable-val').forEach(e=>e.innerText='₹{{ balance }}');}
function selectDepositChannel(el){document.querySelectorAll('.channel-card').forEach(c=>c.classList.remove('active'));el.classList.add('active');const o=document.getElementById('selected-method-text');if(o)o.innerText=el.getAttribute('data-channel')||'UPI-QR';}
function onDepositAmountClick(amt){window.selectedDepositAmount=Number(amt)||0;const i=document.getElementById('deposit-input');if(i)i.value=amt;document.querySelectorAll('.amount-grid-deposit .amount-btn').forEach(b=>b.classList.remove('active'));if(typeof event!=='undefined'&&event&&event.currentTarget)event.currentTarget.classList.add('active');}
function getUpiConfig(){var vpa='{{ upi_vpa }}';if(!vpa||vpa.indexOf('{{')===0)vpa='merchant@upi';var name='{{ upi_name }}';if(!name||name.indexOf('{{')===0)name='ShreeWin';var min=parseFloat('{{ min_deposit }}');if(!(min>0))min=100;var max=parseFloat('{{ max_deposit }}');if(!(max>0))max=50000;return{vpa:vpa,name:name,min:min,max:max};}
function buildUpiLink(amt,orderId){var cfg=getUpiConfig();var tn='DEP'+String(orderId||Date.now()).slice(-10);return 'upi://pay?pa='+encodeURIComponent(cfg.vpa)+'&pn='+encodeURIComponent(cfg.name)+'&am='+Number(amt).toFixed(2)+'&cu=INR&tn='+encodeURIComponent(tn);}
function makeOrderId(){return 'SW'+Date.now().toString().slice(-10)+(Math.floor(Math.random()*90)+10);}
function openPaymentGateway(){
  try{
    var cfg=getUpiConfig();
    var inp=document.getElementById('deposit-input');
    var amt=(window.selectedDepositAmount!=null&&window.selectedDepositAmount>0)?Number(window.selectedDepositAmount):((inp&&parseFloat(inp.value))||cfg.min);
    if(!amt||isNaN(amt)||amt<cfg.min){alert('Minimum deposit is Rs.'+cfg.min);return;}
    if(amt>cfg.max){alert('Maximum deposit is Rs.'+cfg.max);return;}
    window.selectedDepositAmount=amt;
    window.depositOrderId=makeOrderId();
    var el=document.getElementById('gateway-amount-display');
    if(el)el.innerText='Rs.'+Number(amt).toFixed(2);
    var upiLink=buildUpiLink(amt,window.depositOrderId);
    window.currentUpiLink=upiLink;
    var qr=document.getElementById('dynamic-qr-img');
    if(qr)qr.src='https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data='+encodeURIComponent(upiLink);
    var ut=document.getElementById('qr-upi-text');
    if(ut)ut.innerHTML='UPI ID: '+cfg.vpa;
    document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav').forEach(function(n){n.style.display='none';});
    if(typeof startPayCountdown==='function')startPayCountdown(15*60);
    var gw=document.getElementById('screen-payment-gateway');
    if(gw){
      document.querySelectorAll('.app-screen').forEach(function(s){s.classList.remove('active');s.style.display='none';});
      gw.classList.add('active');
      gw.style.display='flex';
      gw.style.opacity='1';
      gw.style.zIndex='50';
    } else if(typeof showAppScreen==='function'){
      showAppScreen('screen-payment-gateway');
    } else {
      alert('Payment screen missing. Please refresh.');
    }
  }catch(err){
    console.error(err);
    alert('Deposit error: '+(err&&err.message?err.message:err));
  }
}
function copyUpiId(){var cfg=getUpiConfig();try{navigator.clipboard.writeText(cfg.vpa);}catch(e){}alert('UPI ID copied: '+cfg.vpa);}
function openAppPay(app){var amt=window.selectedDepositAmount||100;var link=window.currentUpiLink||buildUpiLink(amt,window.depositOrderId||makeOrderId());var q=link.split('?')[1]||'';var url=link;if(app==='phonepe')url='phonepe://pay?'+q;else if(app==='gpay')url='tez://upi/pay?'+q;else if(app==='paytm')url='paytmmp://cash_wallet?'+q;try{window.location.href=url;}catch(e){}setTimeout(function(){window.location.href=link;},700);}
function startPayCountdown(sec){var el=document.getElementById('pay-countdown');if(!el)return;if(window._payTimer)clearInterval(window._payTimer);var left=sec|0;function tick(){var m=('0'+Math.floor(left/60)).slice(-2);var s=('0'+(left%60)).slice(-2);el.innerText=m+':'+s;if(left<=0){clearInterval(window._payTimer);return;}left--;}tick();window._payTimer=setInterval(tick,1000);}
function closePaymentGateway(){
  var gw=document.getElementById('screen-payment-gateway');
  var dep=document.getElementById('screen-deposit');
  if(gw){gw.classList.remove('active');gw.style.display='none';}
  if(dep){dep.classList.add('active');dep.style.display='flex';dep.style.opacity='1';}
  document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav').forEach(function(n){n.style.display='';});
}
window.openPaymentGateway=openPaymentGateway;
window.closePaymentGateway=closePaymentGateway;
window.openAppPay=openAppPay;
document.addEventListener('DOMContentLoaded',function(){
  if(typeof refreshMasterBalance==='function')refreshMasterBalance();
  var depBtn=document.querySelector('.deposit-btn');
  if(depBtn){
    depBtn.onclick=function(e){e.preventDefault();openPaymentGateway();return false;};
  }
});

</script>
<!-- Bottom Navigation - New Design -->
<nav class="bottom-navbar">
    <a href="/home" class="nav-item active">
      <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      <span>Home</span>
    </a>
    <a href="/activity" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2zm-7 10.25l-2.61 1.56.69-2.97-2.3-2 3.03-.26L12 7l1.19 2.58 3.03.26-2.3 2 .69 2.97L12 13.25z"/></svg>
      <span>Activity</span>
    </a>
    <a href="/spinwheel" class="wheel-item">
      <div class="wheel-wrapper">
        <svg viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="46" fill="#7522c7" stroke="#9d3efa" stroke-width="2"/>
          <circle cx="50" cy="8" r="2" fill="#ffd700"/>
          <circle cx="80" cy="20" r="2" fill="#ffd700"/>
          <circle cx="92" cy="50" r="2" fill="#ffd700"/>
          <circle cx="80" cy="80" r="2" fill="#ffd700"/>
          <circle cx="20" cy="80" r="2" fill="#ffd700"/>
          <circle cx="8" cy="50" r="2" fill="#ffd700"/>
          <circle cx="20" cy="20" r="2" fill="#ffd700"/>
          <circle cx="50" cy="50" r="40" fill="#b066fe" stroke="#d5a5ff" stroke-width="2"/>
          <path d="M50 50 L50 14 A36 36 0 0 1 81 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L81 32 A36 36 0 0 1 81 68 Z" fill="#c026d3"/>
          <path d="M50 50 L81 68 A36 36 0 0 1 50 86 Z" fill="#00e5ff"/>
          <path d="M50 50 L50 86 A36 36 0 0 1 19 68 Z" fill="#c026d3"/>
          <path d="M50 50 L19 68 A36 36 0 0 1 19 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L19 32 A36 36 0 0 1 50 14 Z" fill="#c026d3"/>
          <circle cx="50" cy="50" r="13" fill="#00b4d8" stroke="#ffffff" stroke-width="1.5"/>
          <text x="50" y="53" fill="#ffffff" font-size="7" font-weight="900" text-anchor="middle" font-family="'Poppins', sans-serif">SPIN</text>
          <polygon points="50,6 45,13 55,13" fill="#60a5fa" stroke="#ffffff" stroke-width="0.8"/>
        </svg>
      </div>
      <span class="wheel-label">Get ₹500</span>
    </a>
    <a href="/promotion" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
      <span>Promotion</span>
    </a>
    <a href="/account" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
      <span>Account</span>
    </a>
</nav>

<script>
function refreshMasterBalance(){
  var bal='₹'+'{{ balance }}';
  document.querySelectorAll('[data-balance]').forEach(function(e){e.innerText=bal;});
  document.querySelectorAll('#deposit-balance-val,#withdraw-balance-val,#withdrawable-val').forEach(function(e){e.innerText=bal;});
}
</script>


<script>
(function(){
  window.selectedDepositAmount = window.selectedDepositAmount || 100;

  window.onDepositAmountClick = function(amt){
    window.selectedDepositAmount = Number(amt) || 0;
    var i = document.getElementById('deposit-input');
    if(i) i.value = amt;
    document.querySelectorAll('.amount-grid-deposit .amount-btn, .amount-btn').forEach(function(b){
      b.classList.remove('active');
    });
    if(typeof event !== 'undefined' && event && event.currentTarget){
      event.currentTarget.classList.add('active');
    }
  };

  window.openPaymentGateway = function(){ if(typeof openPaymentGateway==='function') openPaymentGateway(); };

  window.closePaymentGateway = function(){
    document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav').forEach(function(n){ n.style.display=''; });
    if(typeof showAppScreen === 'function') showAppScreen('screen-deposit');
    else {
      var gw = document.getElementById('screen-payment-gateway');
      var dep = document.getElementById('screen-deposit');
      if(gw){ gw.classList.remove('active'); gw.style.display='none'; }
      if(dep){ dep.classList.add('active'); dep.style.display='flex'; }
    }
  };

  window.submitUTR = function(){
    var el = document.getElementById('utr-input');
    var utr = el ? el.value.replace(/[^0-9]/g,'').trim() : '';
    if(el) el.value = utr;
    if(utr.length !== 12){ alert('Please enter a valid 12-digit UTR number'); return; }
    var inp = document.getElementById('deposit-input');
    var amt = (window.selectedDepositAmount != null && window.selectedDepositAmount > 0)
      ? window.selectedDepositAmount
      : ((inp && parseFloat(inp.value)) || 0);
    if(!amt || amt < 1){ alert('Invalid amount'); return; }
    window.location = '/submit_utr?amount=' + encodeURIComponent(amt) + '&utr=' + encodeURIComponent(utr);
  };

  // Wire amount buttons with direct listeners (more reliable than only onclick)
  document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.amount-grid-deposit .amount-btn, .amount-section .amount-btn').forEach(function(btn){
      btn.style.cursor = 'pointer';
      btn.style.pointerEvents = 'auto';
      btn.addEventListener('click', function(e){
        e.preventDefault();
        e.stopPropagation();
        var t = (btn.textContent || '').replace(/[^0-9]/g,'');
        // handle 1K 2K etc
        var label = (btn.textContent || '').toUpperCase();
        var amt = 0;
        if(label.indexOf('K') >= 0){
          amt = parseFloat(label.replace(/[^0-9.]/g,'')) * 1000;
        } else {
          amt = parseFloat(t) || 0;
        }
        if(amt > 0) window.onDepositAmountClick(amt);
        document.querySelectorAll('.amount-grid-deposit .amount-btn, .amount-section .amount-btn').forEach(function(b){ b.classList.remove('active'); });
        btn.classList.add('active');
      });
    });
    var depBtn = document.querySelector('.deposit-btn, button.deposit-btn, .deposit-bottom-bar button');
    if(depBtn){
      depBtn.style.pointerEvents = 'auto';
      depBtn.addEventListener('click', function(e){
        e.preventDefault();
        window.openPaymentGateway();
      });
    }
  });
})();
</script>


<script>
/* === DEPOSIT BOOTSTRAP (runs last, fixes dead button) === */
(function(){
  function cfg(){
    var vpa = '{{ upi_vpa }}';
    if(!vpa || vpa.indexOf('{{') === 0) vpa = 'merchant@upi';
    var name = '{{ upi_name }}';
    if(!name || name.indexOf('{{') === 0) name = 'ShreeWin';
    var min = parseFloat('{{ min_deposit }}'); if(!(min>0)) min = 100;
    var max = parseFloat('{{ max_deposit }}'); if(!(max>0)) max = 50000;
    return {vpa:vpa, name:name, min:min, max:max};
  }
  function orderId(){ return 'SW' + Date.now().toString().slice(-10) + Math.floor(Math.random()*90+10); }
  function upiLink(amt, oid){
    var c = cfg();
    return 'upi://pay?pa=' + encodeURIComponent(c.vpa)
      + '&pn=' + encodeURIComponent(c.name)
      + '&am=' + Number(amt).toFixed(2)
      + '&cu=INR&tn=' + encodeURIComponent('DEP' + String(oid).slice(-10));
  }
  function showPayScreen(){
    var gw = document.getElementById('screen-payment-gateway');
    var dep = document.getElementById('screen-deposit');
    if(!gw){ alert('Payment screen not found. Hard refresh page.'); return false; }
    document.querySelectorAll('.app-screen').forEach(function(s){
      s.classList.remove('active');
      s.style.display = 'none';
    });
    gw.classList.add('active');
    gw.style.cssText = 'display:flex!important;opacity:1!important;z-index:9999!important;position:absolute;top:0;left:0;width:100%;height:100%;flex-direction:column;';
    document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav,.deposit-bottom-bar').forEach(function(n){
      n.style.display = 'none';
    });
    return true;
  }
  window.openPaymentGateway = function(){
    try{
      var c = cfg();
      var inp = document.getElementById('deposit-input');
      var amt = (window.selectedDepositAmount > 0) ? Number(window.selectedDepositAmount)
              : (inp && parseFloat(inp.value)) || c.min;
      if(!amt || isNaN(amt) || amt < c.min){ alert('Minimum deposit is Rs.' + c.min); return; }
      if(amt > c.max){ alert('Maximum deposit is Rs.' + c.max); return; }
      window.selectedDepositAmount = amt;
      window.depositOrderId = orderId();
      var link = upiLink(amt, window.depositOrderId);
      window.currentUpiLink = link;
      var el = document.getElementById('gateway-amount-display');
      if(el) el.innerText = 'Rs.' + Number(amt).toFixed(2);
      var qr = document.getElementById('dynamic-qr-img');
      if(qr) qr.src = 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data=' + encodeURIComponent(link);
      var ut = document.getElementById('qr-upi-text');
      if(ut) ut.textContent = 'UPI ID: ' + c.vpa;
      if(!showPayScreen()) return;
      // countdown
      var cd = document.getElementById('pay-countdown');
      if(cd){
        var left = 15*60;
        if(window._payTimer) clearInterval(window._payTimer);
        window._payTimer = setInterval(function(){
          var m = ('0'+Math.floor(left/60)).slice(-2);
          var s = ('0'+(left%60)).slice(-2);
          cd.innerText = m+':'+s;
          if(left-- <= 0) clearInterval(window._payTimer);
        }, 1000);
      }
    }catch(err){
      alert('Deposit error: ' + (err && err.message ? err.message : err));
      console.error(err);
    }
  };
  window.closePaymentGateway = function(){
    var gw = document.getElementById('screen-payment-gateway');
    var dep = document.getElementById('screen-deposit');
    if(gw){ gw.classList.remove('active'); gw.style.display = 'none'; }
    if(dep){ dep.classList.add('active'); dep.style.cssText = 'display:flex!important;opacity:1;'; }
    document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav,.deposit-bottom-bar').forEach(function(n){
      n.style.display = '';
    });
  };
  function bindDepositButtons(){
    document.querySelectorAll('.deposit-btn, .deposit-bottom-bar button, button.deposit-btn').forEach(function(btn){
      btn.style.pointerEvents = 'auto';
      btn.style.cursor = 'pointer';
      btn.onclick = function(e){
        if(e){ e.preventDefault(); e.stopPropagation(); }
        window.openPaymentGateway();
        return false;
      };
    });
    // amount chips
    document.querySelectorAll('.amount-grid-deposit .amount-btn').forEach(function(btn){
      btn.addEventListener('click', function(){
        var label = (btn.textContent || '').toUpperCase();
        var amt = 0;
        if(label.indexOf('K') >= 0) amt = parseFloat(label.replace(/[^0-9.]/g,'')) * 1000;
        else amt = parseFloat(label.replace(/[^0-9.]/g,'')) || 0;
        if(amt > 0){
          window.selectedDepositAmount = amt;
          var inp = document.getElementById('deposit-input');
          if(inp) inp.value = amt;
          document.querySelectorAll('.amount-grid-deposit .amount-btn').forEach(function(b){ b.classList.remove('active'); });
          btn.classList.add('active');
        }
      }, true);
    });
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', bindDepositButtons);
  } else {
    bindDepositButtons();
  }
  // also bind after short delay (in case late DOM)
  setTimeout(bindDepositButtons, 500);
})();
</script>
</body></html>


"""

withdraw_html = """


<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>Shree.Win - Withdraw</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"><link href="https://fonts.googleapis.com/css2?family=Delius&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet"><style>
        :root {
            --bg-dark: #161239;
            --bg-card: #241d4c;
            --bg-card-alt: #1c1740;
            --bg-card-inner: #1f1b40;
            --primary-purple: #8d7ff7;
            --primary-gradient: linear-gradient(135deg, #a78bfa 0%, #7c66f6 100%);
            --btn-purple: #9b8df8;
            --btn-amount-bg: #2d275e;
            --btn-amount-active: #8d80f8;
            --text-white: #ffffff;
            --text-light: #b0a9d8;
            --color-green: #00e676;
            --color-orange: #ff9800;
            --color-red: #ff4d4f;
            --color-gold: #ffb800;
            --pay-card-bg: #2b245e;
            --input-dark: #272153;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Delius', 'Nunito', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #000;
            display: flex;
            justify-content: center;
            min-height: 100vh;
            overflow-x: hidden; overflow-y: auto;
        }

        /* Mobile Container Frame */
        .app-container {
            width: 100%;
            max-width: 400px;
            min-height: 100vh; height: auto;
            background-color: var(--bg-dark);
            display: flex;
            flex-direction: column;
            position: relative;
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 0 20px rgba(255,255,255,0.1);
        }

        /* Smooth Screen Transition Styles */
        .app-screen {
            display: none;
            flex-direction: column;
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            background-color: var(--bg-dark);
            opacity: 0;
            transition: opacity 0.25s ease-in-out;
            z-index: 1;
        }

        .app-screen.active {
            display: flex;
            opacity: 1;
            z-index: 5;
        }

        /* Shared Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 16px;
            color: var(--text-white);
            background-color: var(--bg-dark);
            z-index: 10;
        }
        .header .back-btn {
            font-size: 1.1rem;
            cursor: pointer;
            padding: 5px;
        }
        .header .title {
            font-size: 1.25rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .header .history-link {
            font-size: 0.9rem;
            color: #d8d4fd;
            text-decoration: none;
            cursor: pointer;
        }

        /* Scrollable Area */
        .scrollable-content {
            flex: 1;
            overflow-y: auto; -webkit-overflow-scrolling: touch; flex: 1; min-height: 0;
            scrollbar-width: none;
        }
        .scrollable-content::-webkit-scrollbar {
            display: none;
        }

        /* Floating Support */
        .sub-fab-right {
            position: fixed !important;
            bottom: 90px !important;
            right: 16px !important;
            width: 56px !important;
            height: 56px !important;
            border-radius: 50% !important;
            background: #00e676 !important;
            box-shadow: 0 0 20px rgba(0, 230, 118, 0.65), 0 4px 12px rgba(0,0,0,0.3) !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            cursor: pointer !important;
            border: 3.5px solid #ffffff !important;
            z-index: 999 !important;
        }
        .sub-fab-right i { color: #0b1f13 !important; font-size: 1.55rem !important; }

        /* ================= 1. ACCOUNT VIEW STYLES ================= */
        .profile-header {
            background: linear-gradient(180deg, #9b89ff 0%, #6e55f8 50%, var(--bg-dark) 100%);
            padding: 24px 16px 15px 16px;
            position: relative;
        }
        .profile-row {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .avatar-wrap {
            position: relative;
            width: 72px;
            height: 72px;
            border-radius: 50%;
            border: 2px solid rgba(255, 255, 255, 0.6);
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            flex-shrink: 0;
            background: #25204d;
        }
        .avatar-wrap img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .user-details {
            display: flex;
            flex-direction: column;
            gap: 4px;
            flex: 1;
        }
        .username-row {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .username {
            color: #ffffff;
            font-size: 1.15rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .vip-badge {
            background: linear-gradient(135deg, #e2e8f0 0%, #94a3b8 100%);
            color: #1e1b4b;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 800;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        .uid-pill {
            background: rgba(255, 152, 0, 0.9);
            color: #ffffff;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            width: fit-content;
            cursor: pointer;
            margin-top: 2px;
        }
        .last-login {
            color: #d1ccff;
            font-size: 0.72rem;
            margin-top: 2px;
        }

        .main-padding { padding: 0 14px; }

        .wallet-card {
            background-color: var(--bg-card);
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 14px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.25);
        }
        .wallet-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .wallet-left {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .wallet-title {
            color: #a7a0d8;
            font-size: 0.9rem;
        }
        .balance-value-row {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #ffffff;
            font-size: 1.8rem;
            font-weight: bold;
        }
        .balance-value-row i {
            font-size: 1.1rem;
            color: #a7a0d8;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .btn-enter-wallet {
            background-color: #beb4ff;
            color: #2b2361;
            border: none;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
            cursor: pointer;
        }

        .wallet-actions-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            text-align: center;
        }
        .w-action-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            cursor: pointer;
            text-decoration: none;
        }
        .w-action-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
        }
        .w-action-icon.arwallet { background: rgba(255, 77, 79, 0.15); color: #ff4d4f; }
        .w-action-icon.deposit { background: rgba(255, 152, 0, 0.15); color: #ff9800; }
        .w-action-icon.withdraw { background: rgba(0, 186, 242, 0.15); color: #00baf2; }
        .w-action-icon.vip { background: rgba(0, 230, 118, 0.15); color: #00e676; }
        .w-action-label {
            color: #ffffff;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .history-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 14px;
        }
        .history-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            text-decoration: none;
        }
        .hist-icon-wrap {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }
        .hist-icon-wrap.game { background: #1a73e8; color: white; }
        .hist-icon-wrap.trans { background: #00c853; color: white; }
        .hist-icon-wrap.dep { background: #e53935; color: white; }
        .hist-icon-wrap.with { background: #fb8c00; color: white; }
        .hist-text { display: flex; flex-direction: column; overflow-x: hidden; overflow-y: auto; }
        .hist-title { color: #ffffff; font-size: 0.95rem; font-weight: bold; line-height: 1.1; }
        .hist-sub { color: #8f88c2; font-size: 0.72rem; margin-top: 2px; white-space: nowrap; }

        .menu-card {
            background-color: var(--bg-card);
            border-radius: 14px;
            overflow-x: hidden; overflow-y: auto;
            margin-bottom: 14px;
        }
        .menu-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            cursor: pointer;
            text-decoration: none;
            color: #ffffff;
        }
        .menu-row:last-child { border-bottom: none; }
        .menu-row-left { display: flex; align-items: center; gap: 14px; font-size: 0.95rem; font-weight: 600; }
        .menu-row-left i { font-size: 1.2rem; color: #9b8df8; width: 22px; text-align: center; }
        .menu-row-right { display: flex; align-items: center; gap: 8px; color: #7b74ba; font-size: 0.85rem; }

        .service-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 18px;
        }
        .service-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 16px; }
        .service-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            row-gap: 20px;
            column-gap: 8px;
            text-align: center;
        }
        .service-item { display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; text-decoration: none; }
        .service-icon { font-size: 1.6rem; color: #8d7ff7; }
        .service-label { color: #ffffff; font-size: 0.82rem; font-weight: 600; line-height: 1.2; }

        .btn-logout {
            width: 100%;
            background-color: transparent;
            border: 1px solid #4a3e8e;
            color: #ffffff;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 30px;
        }

        /* ================= 2. DEPOSIT VIEW STYLES ================= */
        .deposit-pad { padding: 10px 14px 90px 14px; }
        .balance-card {
            background: var(--primary-gradient);
            border-radius: 16px;
            padding: 20px 18px;
            color: white;
            position: relative;
            overflow-x: hidden; overflow-y: auto;
            margin-bottom: 15px;
            box-shadow: 0 4px 15px rgba(124, 102, 246, 0.25);
        }
        .balance-label {
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 8px;
            opacity: 0.95;
        }
        .balance-amount {
            font-size: 2rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .balance-amount i { font-size: 1.2rem; cursor: pointer; transition: transform 0.4s ease; }
        .balance-card .dots-bg {
            position: absolute;
            bottom: 8px;
            right: 15px;
            color: rgba(255, 255, 255, 0.3);
            font-size: 1.1rem;
            letter-spacing: 2px;
            font-weight: bold;
        }

        .channels-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 15px;
        }
        .channel-card {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 4px 10px 4px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            position: relative;
            border: 1px solid transparent;
            min-height: 86px;
        }
        .channel-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .channel-icon-wrap {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 6px;
        }
        .channel-name { color: white; font-size: 0.72rem; font-weight: 600; line-height: 1.1; }
        .channel-badge {
            position: absolute;
            top: -4px;
            right: -2px;
            background-color: var(--color-red);
            color: white;
            font-size: 0.65rem;
            font-weight: bold;
            padding: 2px 5px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 2px;
        }

        .amount-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .section-title {
            color: white;
            font-size: 1.05rem;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 14px;
            font-weight: bold;
        }
        .section-title i { color: #b0a5fa; }

        .amount-grid-deposit {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 15px;
        }
        .amount-btn {
            background-color: var(--btn-amount-bg);
            border: 1px solid rgba(255, 255, 255, 0.05);
            color: #bcb6ea;
            padding: 12px 5px;
            border-radius: 8px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
            transition: all 0.2s ease;
        }
        .amount-btn:hover, .amount-btn:active, .amount-btn.active {
            background-color: var(--btn-amount-active);
            color: white;
            box-shadow: 0 2px 8px rgba(141, 128, 248, 0.4);
        }

        .amount-input-box {
            background-color: var(--bg-card-inner);
            border-radius: 25px;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .amount-input-box .currency-sym {
            color: #958df1;
            font-size: 1.1rem;
            font-weight: bold;
            padding-right: 10px;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
            margin-right: 10px;
        }
        .amount-input-box input {
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: #ffffff;
            font-size: 0.95rem;
        }
        .amount-input-box input::placeholder { color: #7b74ba; }
        .amount-input-box .clear-btn { color: #7b74ba; font-size: 1rem; cursor: pointer; padding: 2px 5px; }

        .instruction-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .instruction-inner {
            background-color: var(--bg-card-inner);
            border-radius: 10px;
            padding: 14px;
        }
        .instruction-list { list-style: none; }
        .instruction-list li {
            position: relative;
            padding-left: 18px;
            color: #9e97d8;
            font-size: 0.82rem;
            line-height: 1.45;
            margin-bottom: 14px;
        }
        .instruction-list li:last-child { margin-bottom: 0; }
        .instruction-list li::before {
            content: '◆';
            position: absolute;
            left: 0;
            top: 0;
            color: #8d80f8;
            font-size: 0.75rem;
        }

        .sub-no-data-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px 0 10px 0;
        }
        .sub-no-data-icon { width: 170px; height: 120px; opacity: 0.85; margin-bottom: 10px; }
        .sub-no-data-text { color: #ffffff; font-size: 1.15rem; font-weight: 500; }

        .history-card-item {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-left: 4px solid var(--color-green);
        }
        .history-card-item.pending { border-left-color: var(--color-orange); }
        .history-card-item.rejected { border-left-color: var(--color-red); }
        .history-card-left .hist-amount { font-size: 1.1rem; font-weight: bold; color: white; margin-bottom: 2px;}
        .history-card-left .hist-utr { font-size: 0.75rem; color: var(--text-light); }
        .history-card-right { text-align: right; }
        .history-card-right .hist-status { font-size: 0.8rem; font-weight: bold; text-transform: capitalize; }
        .history-card-right .hist-time { font-size: 0.7rem; color: var(--text-light); margin-top: 2px; }

        .status-approved { color: var(--color-green); }
        .status-pending { color: var(--color-orange); }
        .status-rejected { color: var(--color-red); }

        .deposit-bottom-bar {
            position: fixed !important;
            bottom: 0 !important;
            left: 0;
            right: 0;
            background-color: #1a1540;
            padding: 12px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 20;
        }
        .recharge-method-info { display: flex; flex-direction: column; }
        .recharge-method-info .label { font-size: 0.78rem; color: #ffffff; margin-bottom: 2px; }
        .recharge-method-info .method-name { font-size: 0.95rem; color: #ffffff; font-weight: bold; }
        .deposit-btn {
            background-color: var(--primary-purple);
            color: white;
            border: none;
            padding: 10px 28px;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }

        /* Gateway Screen (ArUpiPay) */
        .cs-pill-btn {
            background: linear-gradient(90deg, #7c67ff 0%, #6852ee 100%);
            color: white;
            font-size: 0.8rem;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            cursor: pointer;
            font-weight: 600;
        }
        .pay-amount-bar {
            background-color: var(--pay-card-bg);
            border-radius: 12px;
            padding: 16px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .pay-amount-left { display: flex; align-items: center; gap: 12px; color: #ffffff; font-size: 1.7rem; font-weight: bold; }
        .pay-amount-left i { font-size: 1.25rem; color: #d1ccff; cursor: pointer; }
        .pay-timer { color: var(--color-red); font-size: 1.15rem; font-weight: bold; letter-spacing: 0.5px; }

        .pay-bullet-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
        .pay-bullet-title::before { content: 'â¢'; color: #ffffff; font-size: 1.3rem; line-height: 0; }

        .pay-methods-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
        .pay-method-card { border-radius: 12px; padding: 12px 10px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; cursor: pointer; transition: transform 0.15s ease; }
        .pay-method-card:active { transform: scale(0.97); }
        .pay-method-card.paytm { background: linear-gradient(135deg, #d4f8ff 0%, #a4e6f9 100%); color: #042e6f; }
        .pay-method-card.phonepe { background: linear-gradient(135deg, #fce8ff 0%, #ebd0fc 100%); color: #5f259f; }
        .pay-logo-wrap { display: flex; align-items: center; gap: 6px; font-size: 1.05rem; font-weight: bold; margin-bottom: 4px; }
        .pay-logo-img { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.85rem; font-weight: bold; }
        .paytm .pay-logo-img { background-color: #002e6e; font-size: 0.6rem; }
        .phonepe .pay-logo-img { background-color: #5f259f; font-size: 1rem; }
        .wake-text { font-size: 0.75rem; color: #8b80cf; font-weight: 600; }

        .qr-card {
            background-color: #372f78;
            border-radius: 14px;
            padding: 22px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            margin-bottom: 22px;
        }
        .qr-image-wrapper {
            background-color: #ffffff;
            padding: 12px;
            border-radius: 14px;
            display: inline-block;
            margin-bottom: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        .qr-image-wrapper img { width: 180px; height: 180px; display: block; margin: 0 auto; }
        .qr-upi-info { color: #332d5e; font-size: 0.82rem; font-weight: bold; margin-top: 8px; font-family: 'Nunito', sans-serif; }
        .qr-desc { color: #ffffff; font-size: 0.88rem; line-height: 1.45; text-align: left; width: 100%; margin-top: 6px; }
        .qr-desc p { margin-bottom: 8px; }

        .utr-warning-text { color: var(--color-red); font-size: 0.95rem; line-height: 1.35; font-weight: bold; margin-bottom: 12px; }
        .utr-input-box {
            background-color: #272153;
            border-radius: 30px;
            padding: 6px 6px 6px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 22px;
            box-shadow: 0 0 10px rgba(186, 104, 200, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .utr-input-box input { background: transparent; border: none; outline: none; color: #b7b0ee; font-size: 0.95rem; width: 70%; }
        .utr-paste-btn { background-color: #8d80f8; color: #ffffff; border: none; padding: 8px 18px; border-radius: 20px; font-size: 0.9rem; font-weight: bold; cursor: pointer; }
        .reminder-list { color: #ffffff; font-size: 0.9rem; line-height: 1.6; margin-bottom: 25px; }

        .pay-bottom-bar {
            position: fixed !important;
            bottom: 0 !important;
            left: 0;
            right: 0;
            background-color: #1a1540;
            padding: 12px 16px;
            display: flex;
            gap: 12px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 20;
        }
        .btn-cancel { flex: 0.35; background-color: #38306e; color: #ffffff; border: none; padding: 12px 0; border-radius: 8px; font-size: 0.95rem; font-weight: bold; cursor: pointer; }
        .btn-submit-utr { flex: 0.65; background: linear-gradient(90deg,#8b5cf6,#7c3aed); color: #fff; border: none; padding: 14px 0; border-radius: 12px; font-size: 1rem; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(124,58,237,0.4); }
        .btn-submit-utr.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 12px rgba(141, 128, 248, 0.4); }

        /* ================= 3. WITHDRAW VIEW STYLES ================= */
        .withdraw-pad { padding: 10px 14px 90px 14px; }
        .arpay-banner {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 14px;
        }
        .arpay-logo { font-size: 2rem; color: #ffb800; font-weight: 900; line-height: 1; }
        .arpay-text h4 { color: white; font-size: 1.05rem; font-weight: bold; margin-bottom: 2px; }
        .arpay-text p { color: #9e97d8; font-size: 0.8rem; }

        .methods-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 14px;
        }
        .method-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            min-height: 90px;
            transition: all 0.2s;
        }
        .method-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .method-icon { font-size: 1.8rem; margin-bottom: 6px; height: 36px; display: flex; align-items: center; justify-content: center; }
        .method-name { color: white; font-size: 0.8rem; font-weight: 700; letter-spacing: 0.5px; }

        .account-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
            cursor: pointer;
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: 0.2s;
        }
        .account-card:active { transform: scale(0.98); }
        .account-left { display: flex; flex-direction: column; gap: 4px; }
        .account-name-row { display: flex; align-items: center; gap: 8px; color: white; font-size: 1rem; font-weight: bold; }
        .account-vpa { color: #9e97d8; font-size: 0.9rem; font-weight: 600; }
        .account-card i.fa-chevron-right { color: #7b74ba; font-size: 0.95rem; }

        .add-upi-box {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 24px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            margin-bottom: 14px;
            border: 1px solid rgba(255,255,255,0.05);
        }
        .add-upi-box:active { transform: scale(0.98); }
        .add-upi-icon { width: 46px; height: 46px; border: 2px dashed #7a70bb; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #7a70bb; font-size: 1.45rem; margin-bottom: 12px; }
        .add-upi-text { color: #8c82cb; font-size: 1rem; font-weight: bold; }

        .add-bank-box {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 24px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            margin-bottom: 6px;
        }
        .dashed-plus-icon {
            width: 46px;
            height: 46px;
            border: 2px dashed #7a70bb;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7a70bb;
            font-size: 1.5rem;
            margin-bottom: 12px;
        }
        .add-bank-text { color: #8c82cb; font-size: 1rem; font-weight: bold; }
        .add-bank-warning { color: var(--color-red); font-size: 0.8rem; text-align: center; margin-bottom: 14px; line-height: 1.3; }

        .amount-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 14px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.88rem;
            margin-bottom: 8px;
            color: #bcb6ea;
        }
        .btn-all-pill {
            background-color: #38306e;
            color: white;
            border: none;
            padding: 3px 18px;
            border-radius: 14px;
            font-size: 0.8rem;
            font-weight: bold;
            cursor: pointer;
        }
        .received-val { color: #ff9800; font-weight: bold; font-size: 1.1rem; }

        .withdraw-action-btn {
            width: 100%;
            background-color: #d1cbff;
            color: #7a6fc7;
            border: none;
            padding: 14px;
            border-radius: 25px;
            font-size: 1.05rem;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 20px;
            transition: 0.2s;
        }
        .withdraw-action-btn.ready {
            background: var(--primary-purple);
            color: white;
            box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4);
        }
        .val-red { color: var(--color-red); font-weight: bold; }

        .btn-all-history {
            width: 100%;
            background-color: transparent;
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #bcb6ea;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
        }

        /* Payment Method Screen (UPI Sub-Screen) */
        .pm-account-card {
            background-color: #262153;
            border-radius: 14px;
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            margin-bottom: 15px;
        }
        .pm-card-header-stripe { height: 38px; background: linear-gradient(90deg, #0066ff 0%, #0088ff 100%); width: 100%; }
        .pm-card-body { padding: 18px 16px; color: #ffffff; }
        .pm-info-row { font-size: 1rem; color: #d1ccff; margin-bottom: 12px; letter-spacing: 0.3px; }
        .pm-info-row .bold-text { color: #ffffff; font-weight: bold; }
        .pm-current-tag { display: flex; align-items: center; gap: 8px; color: #a49fc7; font-size: 0.92rem; margin-top: 14px; }
        .pm-check-circle { width: 20px; height: 20px; background-color: var(--color-red); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.75rem; }
        .pm-bottom-bar { position: fixed !important; bottom: 0 !important; left: 0; right: 0; padding: 16px; background-color: #1a1540; z-index: 99999 !important; max-width: 400px; margin: 0 auto; box-shadow: 0 -4px 20px rgba(0,0,0,0.5); }
        .btn-add-method { width: 100%; background: linear-gradient(90deg,#8b5cf6,#7c3aed) !important; color: #fff !important; border: none; padding: 16px; border-radius: 30px; font-size: 1.1rem; font-weight: 800; cursor: pointer; box-shadow: 0 4px 15px rgba(139,92,246,0.5); }

        /* Add Bank Sub-Screen */
        .ab-notice-pill { background-color: #272153; border-radius: 20px; padding: 10px 14px; display: flex; align-items: center; gap: 10px; margin-bottom: 18px; color: var(--color-red); font-size: 0.8rem; line-height: 1.35; }
        .ab-form-group { margin-bottom: 16px; }
        .ab-label { color: #ffffff; font-size: 0.95rem; font-weight: bold; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .ab-label i { color: #8d7ff7; font-size: 1rem; }
        .ab-select-box { background: linear-gradient(90deg, #6b55fb 0%, #503ef0 100%); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; color: #ffffff; cursor: pointer; font-size: 0.95rem; font-weight: bold; }
        .ab-input-box { background-color: var(--input-dark); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; }
        .ab-input { width: 100%; background: transparent; border: none; outline: none; color: #ffffff; font-size: 0.95rem; font-family: 'Delius', sans-serif; }
        .ab-input::placeholder { color: #766eb5; }
        .ab-bottom-bar { padding: 14px 16px; background-color: var(--bg-dark); }
        .btn-save-bank { width: 100%; background-color: #d1cbff; color: #7a6fc7; border: none; padding: 15px; border-radius: 25px; font-size: 1.1rem; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .btn-save-bank.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4); }

        /* Bank Selector Modal */
        .bank-modal {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 50;
            display: none;
            flex-direction: column;
            justify-content: flex-end;
        }
        .bank-modal-content {
            background: var(--bg-card);
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            padding: 20px;
            max-height: 70vh;
            display: flex;
            flex-direction: column;
        }
        .bank-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 14px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .bank-list { overflow-y: auto; flex: 1; }
        .bank-item {
            padding: 14px 12px;
            color: #d1ccff;
            font-size: 0.95rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .bank-item:hover, .bank-item:active { background: rgba(255,255,255,0.08); color: white; }

        /* Gift Claim Popup Modal */
        .gift-modal-backdrop {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 100;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .gift-popup-card {
            background: var(--bg-card);
            border-radius: 18px;
            width: 100%;
            max-width: 320px;
            padding: 24px 20px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.6);
            border: 1px solid rgba(255,255,255,0.1);
        }
        .gift-popup-card i.fa-gift { font-size: 3rem; color: #ffb800; margin-bottom: 12px; }
        .gift-input {
            width: 100%;
            background: var(--bg-card-alt);
            border: 1px solid rgba(255,255,255,0.1);
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-size: 1rem;
            text-transform: uppercase;
            text-align: center;
            margin: 14px 0;
            outline: none;
            font-family: 'Nunito', sans-serif;
            font-weight: bold;
        }
        .btn-claim-gift {
            width: 100%;
            background: var(--primary-purple);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }
    .bnav{position:absolute;bottom:0;left:0;right:0;background:#16122e;z-index:100;border-top:1px solid #2a1f55}.bnav img{width:100%;display:block}.bnav-links{position:absolute;inset:0;display:flex}.bnav-links a{flex:1;height:100%;display:block}

/* Bottom Navigation Fix */.bottom-navbar{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:400px;height:65px;background:#141332;border-top:1px solid #26244f;display:flex;justify-content:space-around;align-items:center;z-index:1000;padding-bottom:5px;box-sizing:border-box}.bottom-navbar .nav-item{display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:#5d5c88;font-size:11px;font-weight:600;flex:1}.bottom-navbar .nav-item svg{width:26px;height:26px;fill:#5d5c88;margin-bottom:2px}.bottom-navbar .nav-item.active{color:#6965e8}.bottom-navbar .nav-item.active svg{fill:#6965e8}.bottom-navbar .wheel-item{position:relative;top:-16px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;flex:1.2;text-decoration:none}.bottom-navbar .wheel-wrapper{width:72px;height:72px;position:relative;display:flex;justify-content:center;align-items:center}.bottom-navbar .wheel-wrapper svg{width:100%;height:100%}.bottom-navbar .wheel-label{position:absolute;bottom:-6px;white-space:nowrap;font-size:13px;font-weight:900;color:#ffe600;text-shadow:-1.5px -1.5px 0 #b30000,1.5px -1.5px 0 #b30000,-1.5px 1.5px 0 #b30000,1.5px 1.5px 0 #b30000}.scrollable-content{padding-bottom:90px !important}
        .arpay-banner {
            display: flex; align-items: center; gap: 12px;
            background: var(--bg-card); border-radius: 14px;
            padding: 14px 16px; margin-bottom: 14px;
        }
        .arpay-logo { flex-shrink: 0; display:flex; align-items:center; }
        .arpay-text h4 { color:#fff; font-size:1.05rem; margin:0 0 2px; font-weight:700; }
        .arpay-text p { color:#9b93c9; font-size:.78rem; margin:0; }
        .methods-grid-withdraw {
            display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px;
        }
        .methods-grid-withdraw .method-card {
            background: var(--bg-card); border-radius: 12px; padding: 14px 8px;
            display:flex; flex-direction:column; align-items:center; gap:8px;
            border: 1.5px solid transparent; cursor:pointer;
        }
        .methods-grid-withdraw .method-card.active {
            background: linear-gradient(160deg, #6d5ce7 0%, #4b3bb8 100%);
            border-color: rgba(255,255,255,.15);
            box-shadow: 0 4px 14px rgba(109,92,231,.35);
        }
        .methods-grid-withdraw .method-name { color:#cfc8f5; font-size:.78rem; font-weight:700; }
        .methods-grid-withdraw .method-card.active .method-name { color:#fff; }
        .add-upi-box {
            background: var(--bg-card); border-radius: 14px; padding: 28px 16px;
            display:flex; flex-direction:column; align-items:center; justify-content:center;
            margin-bottom: 14px; cursor:pointer;
        }
        .add-upi-icon {
            width: 48px; height: 48px; border: 2px dashed #7a70bb; border-radius: 10px;
            display:flex; align-items:center; justify-content:center;
            color:#7a70bb; font-size:1.4rem; margin-bottom: 10px;
        }
        .add-upi-text { color:#8c82cb; font-size:1rem; font-weight:700; }
        .amount-input-box {
            display:flex; align-items:center; background: var(--input-dark);
            border-radius: 24px; padding: 4px 16px; margin-bottom: 12px;
            border: 1px solid rgba(255,255,255,.06);
        }
        .amount-input-box .currency-sym { color:#a78bfa; font-size:1.2rem; font-weight:700; margin-right:8px; }
        .amount-input-box input {
            flex:1; background:transparent; border:none; outline:none;
            color:#fff; font-size:1rem; padding:12px 0; font-family:inherit;
        }
        .amount-input-box input::placeholder { color:#6b6399; }
        .withdraw-action-btn {
            width:100%; margin-top:14px; border:none; border-radius:24px;
            padding:14px; font-size:1.05rem; font-weight:700; cursor:pointer;
            background:#c5bfff; color:#6b63a8; font-family:inherit;
        }
        .withdraw-action-btn.ready {
            background: linear-gradient(135deg,#a78bfa,#7c66f6); color:#fff;
        }
        .instruction-section { margin-bottom: 16px; }
        .instruction-inner {
            background: var(--bg-card); border-radius: 14px; padding: 14px 16px;
        }
        .instruction-list { list-style: none; padding:0; margin:0; }
        .instruction-list li {
            position:relative; padding-left: 16px; margin-bottom: 10px;
            color:#9b93c9; font-size:.82rem; line-height:1.45;
        }
        .instruction-list li::before {
            content:"◆"; position:absolute; left:0; top:1px;
            color:#7a70bb; font-size:.55rem;
        }
        .instruction-list .val-red { color:#ff6b6b; font-weight:600; }
        .wd-hist-bar {
            display:flex; align-items:center; gap:10px;
            background: var(--bg-card); border-radius: 12px;
            padding: 14px 16px; margin-bottom: 24px;
            color:#cfc8f5; text-decoration:none; font-weight:700; font-size:.95rem;
        }
        .wd-hist-bar i { color:#8d7ff7; }
        .cs-float {
            position:fixed; right:16px; bottom:90px; width:48px; height:48px;
            border-radius:50%; background:linear-gradient(135deg,#22c55e,#16a34a);
            color:#fff; display:flex; align-items:center; justify-content:center;
            font-size:1.2rem; box-shadow:0 4px 14px rgba(34,197,94,.4); z-index:50;
            cursor:pointer;
        }
</style></head><body><div class="app-container"><div class="app-screen active" id="screen-withdraw">
<div class="header">
<div class="back-btn" onclick="window.location.href='/account'"><i class="fa-solid fa-chevron-left"></i></div>
<div class="title">Withdraw</div>
<a class="history-link" href="/withdraw-history">Withdrawal history</a>
</div>
<div class="scrollable-content withdraw-pad" id="withdraw-scroll-area">

<!-- Available balance -->
<div class="balance-card">
  <div class="balance-label"><i class="fa-solid fa-wallet"></i> Available balance</div>
  <div class="balance-amount">
    <span id="withdraw-balance-val">₹{{ balance }}</span>
    <i class="fa-solid fa-arrows-rotate" id="refresh-withdraw-btn" onclick="refreshMasterBalance()" style="margin-left:8px;cursor:pointer;opacity:.85;"></i>
  </div>
  <div class="dots-bg">**** ****</div>
</div>

<!-- ARPay -->
<div class="arpay-banner">
  <div class="arpay-logo" aria-hidden="true">
    <svg width="28" height="28" viewBox="0 0 40 40" fill="none"><path d="M20 4L36 34H4L20 4Z" fill="#F5C518"/><path d="M20 12L28 28H12L20 12Z" fill="#1a1438"/></svg>
  </div>
  <div class="arpay-text">
    <h4>ARPay</h4>
    <p>Supports UPI for fast payment</p>
  </div>
</div>

<!-- Methods: UPI / BANK CARD / USDT -->
<div class="methods-grid-withdraw">
  <div class="method-card active" id="btn-upi-method" onclick="switchWithdrawChannel('UPI')">
    <div class="method-icon upi-ico">
      <svg width="32" height="32" viewBox="0 0 48 48" fill="none"><rect x="6" y="6" width="36" height="36" rx="8" fill="url(#ug)" stroke="#c4b5fd" stroke-width="1.5"/><text x="24" y="29" text-anchor="middle" fill="#fff" font-size="11" font-weight="700" font-family="Arial">UPI</text><defs><linearGradient id="ug" x1="6" y1="6" x2="42" y2="42"><stop stop-color="#7c3aed"/><stop offset="1" stop-color="#4c1d95"/></linearGradient></defs></svg>
    </div>
    <div class="method-name">UPI</div>
  </div>
  <div class="method-card" id="btn-bank-method" onclick="switchWithdrawChannel('BANK CARD')">
    <div class="method-icon"><i class="fa-solid fa-credit-card" style="color:#7dd3fc;font-size:1.4rem;"></i></div>
    <div class="method-name">BANK CARD</div>
  </div>
  <div class="method-card" id="btn-usdt-method" onclick="switchWithdrawChannel('USDT')">
    <div class="method-icon"><i class="fa-solid fa-t" style="color:#26a17b;font-size:1.35rem;background:#26a17b22;border-radius:50%;width:34px;height:34px;display:flex;align-items:center;justify-content:center;"></i></div>
    <div class="method-name">USDT</div>
  </div>
</div>

<!-- UPI beneficiary / Add UPI -->
<div id="upi-beneficiary-view">
  <div class="add-upi-box" onclick="location.href='/add-bank'">
    <div class="add-upi-icon"><i class="fa-solid fa-plus"></i></div>
    <div class="add-upi-text">Add UPI</div>
  </div>
</div>

<!-- Bank card view -->
<div id="bank-beneficiary-view" style="display:none;">
  <div class="add-upi-box" onclick="location.href='/add-bank'">
    <div class="add-upi-icon"><i class="fa-solid fa-plus"></i></div>
    <div class="add-upi-text">Add Bank Card</div>
  </div>
</div>

<!-- Amount -->
<div class="amount-section" style="background:var(--bg-card);border-radius:14px;padding:14px;margin-bottom:14px;">
  <div class="amount-input-box">
    <div class="currency-sym">₹</div>
    <input id="withdraw-input" type="number" inputmode="decimal" placeholder="Please enter the amount" oninput="onCustomWithdrawAmount(this.value)" value=""/>
  </div>
  <div class="info-row">
    <span>Withdrawable balance <span id="withdrawable-val" style="color:#ff9800;">₹{{ balance }}</span></span>
    <button type="button" class="btn-all-pill" onclick="withdrawAll()">All</button>
  </div>
  <div class="info-row" style="margin-top:10px;">
    <span>Withdrawal amount received</span>
    <span class="received-val" id="received-amount-display">₹0.00</span>
  </div>
  <button type="button" class="withdraw-action-btn" id="submit-withdraw-btn" onclick="handleWithdrawSubmit()">Withdraw</button>
</div>

<!-- Rules -->
<div class="instruction-section">
  <div class="instruction-inner">
    <ul class="instruction-list">
      <li>Need to bet <span class="val-red">₹0.00</span> to be able to withdraw</li>
      <li>Withdraw time <span class="val-red">00:00-23:59</span></li>
      <li>Inday Remaining Withdrawal Times <span class="val-red">3</span></li>
      <li>Withdrawal amount range <span class="val-red">₹100.00-₹50,000.00</span></li>
      <li>Please check your registered bank information again before making a withdrawal. If your registered bank information is incorrect, our company will not be responsible for any losses you may incur.</li>
      <li>If your registered bank information is incorrect, please contact customer service.</li>
    </ul>
  </div>
</div>

<!-- Bottom history link -->
<a href="/withdraw-history" class="wd-hist-bar">
  <i class="fa-solid fa-file-lines"></i> Withdrawal history
</a>

</div>
<div class="cs-float" onclick="window.open('https://t.me/Shreewinofficial01_bot','_blank')" title="Customer Service"><i class="fa-solid fa-headset"></i></div>
</div>
<div class="app-screen" id="screen-payment-method">
<div class="header">
<div class="back-btn" onclick="showAppScreen('screen-withdraw')"><i class="fa-solid fa-chevron-left"></i></div>
<div class="title">Payment method</div>
<div style="width: 32px;"></div>
</div>
<div class="scrollable-content" style="padding: 16px 14px;">
<div class="pm-account-card">
<div class="pm-card-header-stripe"></div>
<div class="pm-card-body">
<div class="pm-info-row">
                        Account name: <span class="bold-text" id="pm-display-name">Please Add Account</span>
</div>
<div class="pm-info-row">
                        UPI ID: <span class="bold-text" id="pm-display-vpa">Not bound</span>
</div>
<div class="pm-current-tag">
<div class="pm-check-circle"><i class="fa-solid fa-check"></i></div>
<span>Current Payment</span>
</div>
<button onclick="promptEditUpi()" style="display:block;width:100%;margin-top:18px;background:linear-gradient(90deg,#8b5cf6,#7c3aed);color:#fff;border:none;padding:16px;border-radius:30px;font-size:16px;font-weight:800;cursor:pointer;">+ Add / Bind UPI ID</button>
</div>
</div>
</div>
<div class="pm-bottom-bar">
<button class="btn-add-method" onclick="promptEditUpi()">+ Add / Bind UPI ID</button>
</div>
</div><div class="app-screen" id="screen-add-bank">
<div class="header">
<div class="back-btn" onclick="showAppScreen('screen-withdraw')"><i class="fa-solid fa-chevron-left"></i></div>
<div class="title">Add a bank account number</div>
<div style="width: 32px;"></div>
</div>
<div class="scrollable-content" style="padding: 14px 14px 30px 14px;">
<div class="ab-notice-pill">
<i class="fa-solid fa-circle-exclamation"></i>
<span>To ensure the safety of your funds, please bind your bank account</span>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-building-columns"></i> Choose a bank</div>
<div class="ab-select-box" onclick="openBankModal()">
<span id="selected-bank-name">Please select a bank</span>
<i class="fa-solid fa-chevron-right"></i>
</div>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-user"></i> Full recipient's name</div>
<div class="ab-input-box">
<input class="ab-input" id="bank-recipient-name" oninput="validateBankForm()" placeholder="Please enter recipient name" type="text"/>
</div>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-credit-card"></i> Bank account number</div>
<div class="ab-input-box">
<input class="ab-input" id="bank-acc-num" oninput="validateBankForm()" placeholder="Please enter your bank account number" type="number"/>
</div>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-mobile-screen"></i> Phone number</div>
<div class="ab-input-box">
<input class="ab-input" id="bank-phone" maxlength="10" oninput="validateBankForm()" placeholder="Please enter your phone number" type="tel"/>
</div>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-envelope"></i> Mail</div>
<div class="ab-input-box">
<input class="ab-input" id="bank-email" oninput="validateBankForm()" placeholder="please input your email" type="email"/>
</div>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-magnifying-glass"></i> IFSC code</div>
<div class="ab-input-box">
<input class="ab-input" id="bank-ifsc" oninput="validateBankForm()" placeholder="Please enter IFSC code" style="text-transform: uppercase;" type="text"/>
</div>
</div>
</div>
<div class="ab-bottom-bar">
<button class="btn-save-bank" id="btn-save-bank" onclick="saveBankAccount()">Save</button>
</div>
</div><div class="bank-modal" id="bank-modal" onclick="closeBankModal(event)">
<div class="bank-modal-content" onclick="event.stopPropagation()">
<div class="bank-modal-header">
<span>Select Your Bank</span>
<i class="fa-solid fa-xmark" onclick="closeBankModal()" style="cursor: pointer;"></i>
</div>
<div class="bank-list">
<div class="bank-item" onclick="chooseBank('State Bank of India (SBI)')"><i class="fa-solid fa-building-columns"></i> State Bank of India (SBI)</div>
<div class="bank-item" onclick="chooseBank('HDFC Bank')"><i class="fa-solid fa-building-columns"></i> HDFC Bank</div>
<div class="bank-item" onclick="chooseBank('ICICI Bank')"><i class="fa-solid fa-building-columns"></i> ICICI Bank</div>
<div class="bank-item" onclick="chooseBank('Axis Bank')"><i class="fa-solid fa-building-columns"></i> Axis Bank</div>
<div class="bank-item" onclick="chooseBank('Punjab National Bank (PNB)')"><i class="fa-solid fa-building-columns"></i> Punjab National Bank (PNB)</div>
<div class="bank-item" onclick="chooseBank('Bank of Baroda')"><i class="fa-solid fa-building-columns"></i> Bank of Baroda</div>
<div class="bank-item" onclick="chooseBank('Kotak Mahindra Bank')"><i class="fa-solid fa-building-columns"></i> Kotak Mahindra Bank</div>
<div class="bank-item" onclick="chooseBank('Canara Bank')"><i class="fa-solid fa-building-columns"></i> Canara Bank</div>
<div class="bank-item" onclick="chooseBank('Union Bank of India')"><i class="fa-solid fa-building-columns"></i> Union Bank of India</div>
<div class="bank-item" onclick="chooseBank('Paytm Payments Bank')"><i class="fa-solid fa-building-columns"></i> Paytm Payments Bank</div>
<div class="bank-item" onclick="chooseBank('Airtel Payments Bank')"><i class="fa-solid fa-building-columns"></i> Airtel Payments Bank</div>
</div>
</div>
</div></div><script>
function showAppScreen(screenId,anchorId=null){const t=document.getElementById(screenId);if(!t){if(screenId==="screen-account"){window.location.href="/account";}else if(screenId==="screen-deposit"){window.location.href="/deposit";}else if(screenId==="screen-withdraw"){window.location.href="/withdraw";}return;}document.querySelectorAll(".app-screen").forEach(s=>s.classList.remove("active"));t.classList.add("active");const nav=document.querySelector(".bnav");if(nav)nav.style.display=["screen-payment-gateway","screen-payment-method","screen-add-bank","screen-payment"].includes(screenId)?"none":"block";if(anchorId)setTimeout(()=>{const e=document.getElementById(anchorId);if(e)e.scrollIntoView({behavior:"smooth"});},100);}function scrollToAnchor(areaId,anchorId){const e=document.getElementById(anchorId);if(e)e.scrollIntoView({behavior:'smooth'});}
function refreshMasterBalance(){document.querySelectorAll('[data-balance]').forEach(e=>e.innerText='₹{{ balance }}');document.querySelectorAll('#deposit-balance-val,#withdraw-balance-val,#withdrawable-val').forEach(e=>e.innerText='₹{{ balance }}');}
function selectDepositChannel(el){document.querySelectorAll('.channel-card').forEach(c=>c.classList.remove('active'));el.classList.add('active');const o=document.getElementById('selected-method-text');if(o)o.innerText=el.getAttribute('data-channel')||'UPI-QR';}
function onDepositAmountClick(amt){window.selectedDepositAmount=Number(amt)||0;const i=document.getElementById('deposit-input');if(i)i.value=amt;document.querySelectorAll('.amount-grid-deposit .amount-btn').forEach(b=>b.classList.remove('active'));if(typeof event!=='undefined'&&event&&event.currentTarget)event.currentTarget.classList.add('active');}
function getUpiConfig(){return{vpa:'{{ upi_vpa }}',name:'{{ upi_name }}',min:parseFloat('{{ min_deposit }}')||100,max:parseFloat('{{ max_deposit }}')||50000};}
function buildUpiLink(amt,orderId){var cfg=getUpiConfig();var pa=encodeURIComponent(cfg.vpa);var pn=encodeURIComponent(cfg.name||'ShreeWin');var am=encodeURIComponent(Number(amt).toFixed(2));var tn=encodeURIComponent('DEP'+String(orderId||'').slice(-10));return 'upi://pay?pa='+cfg.vpa+'&pn='+encodeURIComponent(cfg.name||'ShreeWin')+'&am='+Number(amt).toFixed(2)+'&cu=INR&tn='+tn;}
function makeOrderId(){return 'SW'+Date.now().toString().slice(-10)+(Math.floor(Math.random()*90)+10);}
function openPaymentGateway(){var cfg=getUpiConfig();var inp=document.getElementById('deposit-input');var amt=(window.selectedDepositAmount!=null&&window.selectedDepositAmount>0)?window.selectedDepositAmount:((inp&&parseFloat(inp.value))||cfg.min);if(!amt||amt<cfg.min){alert('Minimum deposit is Rs.'+cfg.min);return;}if(amt>cfg.max){alert('Maximum deposit is Rs.'+cfg.max);return;}window.selectedDepositAmount=amt;window.depositOrderId=makeOrderId();var el=document.getElementById('gateway-amount-display');if(el)el.innerText='Rs.'+Number(amt).toFixed(2);var upiLink=buildUpiLink(amt,window.depositOrderId);window.currentUpiLink=upiLink;var qr=document.getElementById('dynamic-qr-img');if(qr)qr.src='https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data='+encodeURIComponent(upiLink);var ut=document.getElementById('qr-upi-text');if(ut)ut.innerHTML='UPI ID: '+cfg.vpa+' <i class="fa-regular fa-copy" style="cursor:pointer;margin-left:6px" onclick="copyUpiId()"></i>';document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav').forEach(function(n){n.style.display='none';});if(typeof startPayCountdown==='function')startPayCountdown(15*60);if(typeof showAppScreen==='function')showAppScreen('screen-payment-gateway');else{var gw=document.getElementById('screen-payment-gateway');var dep=document.getElementById('screen-deposit');if(dep)dep.classList.remove('active');if(gw){gw.classList.add('active');gw.style.display='flex';}}}
function copyUpiId(){var cfg=getUpiConfig();var t=cfg.vpa;if(navigator.clipboard)navigator.clipboard.writeText(t);alert('UPI ID copied: '+t);}
function openAppPay(app){var amt=window.selectedDepositAmount||100;var link=window.currentUpiLink||buildUpiLink(amt,window.depositOrderId||makeOrderId());var encoded=encodeURIComponent(link);var url=link;if(app==='phonepe'){url='phonepe://pay?'+link.split('?')[1];setTimeout(function(){window.location.href=link;},800);}else if(app==='paytm'){url='paytmmp://cash_wallet?pa='+encodeURIComponent(getUpiConfig().vpa)+'&pn='+encodeURIComponent(getUpiConfig().name)+'&am='+Number(amt).toFixed(2)+'&cu=INR&tn=DEP';setTimeout(function(){window.location.href=link;},800);}else if(app==='gpay'){url='tez://upi/pay?'+link.split('?')[1];setTimeout(function(){window.location.href=link;},800);}try{window.location.href=url;}catch(e){window.location.href=link;}}
function startPayCountdown(sec){var el=document.getElementById('pay-countdown');if(!el)return;if(window._payTimer)clearInterval(window._payTimer);var left=sec|0;function tick(){var m=('0'+Math.floor(left/60)).slice(-2);var s=('0'+(left%60)).slice(-2);el.innerText=m+':'+s;if(left<=0){clearInterval(window._payTimer);el.innerText='00:00';return;}left--;}tick();window._payTimer=setInterval(tick,1000);}

function closePaymentGateway(){showAppScreen('screen-deposit');}
function copyAmount(){var el=document.getElementById('gateway-amount-display');var t=(el?el.innerText:'').replace(/[^0-9.]/g,'');if(navigator.clipboard)navigator.clipboard.writeText(t);alert('Amount Copied');} function validateUTR(v){var btn=document.getElementById('submit-utr-btn');if(!btn)return;v=(v||'').replace(/[^0-9]/g,'');if(v.length>=10){btn.innerText='Submit UTR';btn.style.background='#22c55e';btn.style.color='#fff';}else{btn.innerText='Submit (UTR not entered)';btn.style.background='';btn.style.color='';}} function pasteUTR(){if(navigator.clipboard&&navigator.clipboard.readText){navigator.clipboard.readText().then(function(t){var el=document.getElementById('utr-input');if(el){el.value=String(t).replace(/[^0-9]/g,'').slice(0,12);validateUTR(el.value);}});}} function submitUTR(){var el=document.getElementById('utr-input');var utr=el?el.value.trim():'';if(utr.length<10){alert('Enter valid 12-digit UTR');return;}var inp=document.getElementById('deposit-input');var amt=(window.selectedDepositAmount!=null&&window.selectedDepositAmount>0)?window.selectedDepositAmount:((inp&&parseFloat(inp.value))||100);window.location='/submit_utr?amount='+amt+'&utr='+encodeURIComponent(utr);}
let currentWithdrawAmount=100;
function switchWithdrawChannel(method){document.querySelectorAll('.methods-grid-withdraw .method-card').forEach(c=>c.classList.remove('active'));const m={'UPI':'btn-upi-method','BANK CARD':'btn-bank-method','USDT':'btn-usdt-method'};if(m[method])document.getElementById(m[method]).classList.add('active');const u=document.getElementById('upi-beneficiary-view'),b=document.getElementById('bank-beneficiary-view');if(u&&b){u.style.display=method==='BANK CARD'?'none':'block';b.style.display=method==='BANK CARD'?'block':'none';}}
function setWithdrawAmount(amt,el){currentWithdrawAmount=Number(amt)||0;const i=document.getElementById('withdraw-input');if(i)i.value=amt;document.querySelectorAll('.amount-grid-withdraw .amount-btn').forEach(b=>b.classList.remove('active'));if(el)el.classList.add('active');updateReceivedDisplay();}
function onCustomWithdrawAmount(v){currentWithdrawAmount=parseFloat(v)||0;updateReceivedDisplay();var btn=document.getElementById('submit-withdraw-btn');if(btn){if(currentWithdrawAmount>=100)btn.classList.add('ready');else btn.classList.remove('ready');}} function withdrawAll(){var b=parseFloat(String('{{ balance }}').replace(/,/g,''))||0;var el=document.getElementById('withdraw-input');if(el){el.value=b>0?b:'';}onCustomWithdrawAmount(b);}function updateReceivedDisplay(){const e=document.getElementById('received-amount-display');if(e)e.innerText='₹'+Number(typeof currentWithdrawAmount!=='undefined'?currentWithdrawAmount:0).toFixed(2);}function handleWithdrawSubmit(){var amountEl=document.getElementById('withdraw-input');var amount=amountEl?parseFloat(amountEl.value):(typeof currentWithdrawAmount!=='undefined'?currentWithdrawAmount:0);if(!amount||amount<100){alert('Minimum withdrawal is Rs.100');return false;}var form=document.createElement('form');form.method='POST';form.action='/request_withdraw';var inp=document.createElement('input');inp.type='hidden';inp.name='amount';inp.value=amount;form.appendChild(inp);document.body.appendChild(form);form.submit();return false;}
function openBankModal(){const m=document.getElementById('bank-modal');if(m)m.style.display='flex';} function closeBankModal(){const m=document.getElementById('bank-modal');if(m)m.style.display='none';} function chooseBank(n){const e=document.getElementById('selected-bank-name');if(e)e.innerText=n;closeBankModal();} function validateBankForm(){var bank=document.getElementById('selected-bank-name');var name=document.getElementById('bank-recipient-name');var acc=document.getElementById('bank-acc-num');var phone=document.getElementById('bank-phone');var ifsc=document.getElementById('bank-ifsc');var btn=document.getElementById('btn-save-bank');if(!btn)return;var ok=bank&&bank.innerText&&bank.innerText!=='Please select a bank'&&name&&name.value.trim()&&acc&&acc.value.trim()&&ifsc&&ifsc.value.trim().length>=4;btn.disabled=!ok;btn.style.opacity=ok?'1':'0.6';} function saveBankAccount(){var bankEl=document.getElementById('selected-bank-name');var nameEl=document.getElementById('bank-recipient-name');var accEl=document.getElementById('bank-acc-num');var phoneEl=document.getElementById('bank-phone');var ifscEl=document.getElementById('bank-ifsc');var bankName=bankEl?bankEl.innerText.trim():'';var name=nameEl?nameEl.value.trim():'';var account=accEl?accEl.value.trim():'';var phone=phoneEl?phoneEl.value.trim():'';var ifsc=ifscEl?ifscEl.value.trim().toUpperCase():'';if(!bankName||bankName==='Please select a bank'){alert('Please select a bank');return;}if(!name){alert('Please enter recipient name');return;}if(!account){alert('Please enter account number');return;}if(!ifsc||ifsc.length<4){alert('Please enter valid IFSC');return;}var form=document.createElement('form');form.method='POST';form.action='/save_bank';[['type','bank'],['bank',bankName],['name',name],['account',account],['phone',phone],['ifsc',ifsc]].forEach(function(p){var i=document.createElement('input');i.type='hidden';i.name=p[0];i.value=p[1];form.appendChild(i);});document.body.appendChild(form);form.submit();} function promptEditUpi(){var vpa=prompt('Enter UPI ID (example: name@paytm / name@okhdfcbank):');if(!vpa)return;vpa=vpa.trim();if(vpa.indexOf('@')<1){alert('Invalid UPI ID. Must contain @');return;}var namePart=vpa.split('@')[0];var form=document.createElement('form');form.method='POST';form.action='/save_bank';[['type','upi'],['name',namePart],['account',vpa],['upi',vpa]].forEach(function(p){var i=document.createElement('input');i.type='hidden';i.name=p[0];i.value=p[1];form.appendChild(i);});document.body.appendChild(form);form.submit();}
document.addEventListener('DOMContentLoaded',()=>{refreshMasterBalance();updateReceivedDisplay();});
</script>
<!-- Bottom Navigation - New Design -->
<nav class="bottom-navbar">
    <a href="/home" class="nav-item active">
      <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      <span>Home</span>
    </a>
    <a href="/activity" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2zm-7 10.25l-2.61 1.56.69-2.97-2.3-2 3.03-.26L12 7l1.19 2.58 3.03.26-2.3 2 .69 2.97L12 13.25z"/></svg>
      <span>Activity</span>
    </a>
    <a href="/spinwheel" class="wheel-item">
      <div class="wheel-wrapper">
        <svg viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="46" fill="#7522c7" stroke="#9d3efa" stroke-width="2"/>
          <circle cx="50" cy="8" r="2" fill="#ffd700"/>
          <circle cx="80" cy="20" r="2" fill="#ffd700"/>
          <circle cx="92" cy="50" r="2" fill="#ffd700"/>
          <circle cx="80" cy="80" r="2" fill="#ffd700"/>
          <circle cx="20" cy="80" r="2" fill="#ffd700"/>
          <circle cx="8" cy="50" r="2" fill="#ffd700"/>
          <circle cx="20" cy="20" r="2" fill="#ffd700"/>
          <circle cx="50" cy="50" r="40" fill="#b066fe" stroke="#d5a5ff" stroke-width="2"/>
          <path d="M50 50 L50 14 A36 36 0 0 1 81 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L81 32 A36 36 0 0 1 81 68 Z" fill="#c026d3"/>
          <path d="M50 50 L81 68 A36 36 0 0 1 50 86 Z" fill="#00e5ff"/>
          <path d="M50 50 L50 86 A36 36 0 0 1 19 68 Z" fill="#c026d3"/>
          <path d="M50 50 L19 68 A36 36 0 0 1 19 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L19 32 A36 36 0 0 1 50 14 Z" fill="#c026d3"/>
          <circle cx="50" cy="50" r="13" fill="#00b4d8" stroke="#ffffff" stroke-width="1.5"/>
          <text x="50" y="53" fill="#ffffff" font-size="7" font-weight="900" text-anchor="middle" font-family="'Poppins', sans-serif">SPIN</text>
          <polygon points="50,6 45,13 55,13" fill="#60a5fa" stroke="#ffffff" stroke-width="0.8"/>
        </svg>
      </div>
      <span class="wheel-label">Get ₹500</span>
    </a>
    <a href="/promotion" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
      <span>Promotion</span>
    </a>
    <a href="/account" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
      <span>Account</span>
    </a>
</nav>




<script>
(function(){
  window.currentWithdrawAmount = window.currentWithdrawAmount || 100;

  window.setWithdrawAmount = function(amt, el){
    window.currentWithdrawAmount = Number(amt) || 0;
    var i = document.getElementById('withdraw-input');
    if(i) i.value = amt;
    document.querySelectorAll('.amount-grid-withdraw .amount-btn, .amount-btn').forEach(function(b){ b.classList.remove('active'); });
    if(el) el.classList.add('active');
    window.updateReceivedDisplay();
  };

  window.updateReceivedDisplay = function(){
    var e = document.getElementById('received-amount-display');
    if(e) e.innerText = '₹' + Number(window.currentWithdrawAmount || 0).toFixed(2);
  };

  window.onCustomWithdrawAmount = function(v){
    window.currentWithdrawAmount = parseFloat(v) || 0;
    window.updateReceivedDisplay();
  };

  window.withdrawAll = function(){
    var b = parseFloat(String('{{ balance }}').replace(/,/g,'')) || 0;
    window.setWithdrawAmount(b, null);
  };

  window.handleWithdrawSubmit = function(){
    var amountEl = document.getElementById('withdraw-input');
    var amount = amountEl ? parseFloat(amountEl.value) : (window.currentWithdrawAmount || 0);
    if(!amount || amount < 100){ alert('Minimum withdrawal is ₹100'); return false; }
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = '/request_withdraw';
    var inp = document.createElement('input');
    inp.type = 'hidden';
    inp.name = 'amount';
    inp.value = amount;
    form.appendChild(inp);
    document.body.appendChild(form);
    form.submit();
    return false;
  };

  document.addEventListener('DOMContentLoaded', function(){
    // enable scroll on containers
    document.documentElement.style.overflowY = 'auto';
    document.body.style.overflowY = 'auto';
    document.body.style.height = 'auto';
    var app = document.querySelector('.app-container');
    if(app){ app.style.height = 'auto'; app.style.minHeight = '100vh'; app.style.overflowY = 'auto'; }
    var sc = document.querySelector('.scrollable-content');
    if(sc){ sc.style.overflowY = 'auto'; sc.style.webkitOverflowScrolling = 'touch'; sc.style.flex = '1'; }

    document.querySelectorAll('.amount-grid-withdraw .amount-btn, .methods-grid-withdraw ~ * .amount-btn').forEach(function(btn){
      btn.style.cursor = 'pointer';
      btn.style.pointerEvents = 'auto';
      btn.addEventListener('click', function(e){
        e.preventDefault();
        var label = (btn.textContent || '').trim().toUpperCase();
        var amt = 0;
        if(label.indexOf('K') >= 0) amt = parseFloat(label) * 1000;
        else amt = parseFloat(label.replace(/[^0-9.]/g,'')) || 0;
        if(amt > 0) window.setWithdrawAmount(amt, btn);
      });
    });
    // also catch any amount-btn inside withdraw screen
    document.querySelectorAll('#screen-withdraw .amount-btn').forEach(function(btn){
      btn.style.pointerEvents = 'auto';
      btn.addEventListener('click', function(e){
        e.preventDefault();
        var label = (btn.textContent || '').trim().toUpperCase();
        var amt = 0;
        if(label.indexOf('K') >= 0) amt = parseFloat(label) * 1000;
        else amt = parseFloat(label.replace(/[^0-9.]/g,'')) || 0;
        if(amt > 0) window.setWithdrawAmount(amt, btn);
      });
    });

    var wBtn = document.getElementById('submit-withdraw-btn') || document.querySelector('.withdraw-action-btn');
    if(wBtn){
      wBtn.style.pointerEvents = 'auto';
      wBtn.onclick = function(e){ e.preventDefault(); window.handleWithdrawSubmit(); };
    }

    var inp = document.getElementById('withdraw-input');
    if(inp){
      inp.addEventListener('input', function(){ window.onCustomWithdrawAmount(inp.value); });
    }

    window.updateReceivedDisplay();
  });
})();
</script>

</body></html>


"""

add_bank_html = """


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Add Bank Account</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif}
body{background:#0f0c29;min-height:100vh;color:#e0d4ff;padding-bottom:100px}
.topbar{display:flex;align-items:center;padding:14px 16px;background:#1a1440;border-bottom:1px solid #eee}
.topbar .back{font-size:20px;text-decoration:none;color:#d1c4e9;margin-right:12px}
.topbar .title{font-size:17px;font-weight:700}
.warning{margin:16px 14px;background:#fff3e0;border-radius:12px;padding:12px 14px;font-size:13px;color:#e65100}
.form{margin:0 14px}
.field{margin-bottom:18px}
.field label{display:block;font-size:14px;font-weight:600;color:#d1c4e9;margin-bottom:8px}
.field input,.field select{width:100%;padding:14px 16px;border:1px solid #e0e0e0;border-radius:12px;font-size:15px;background:#1a1440;outline:none}
.save-bar{position:fixed;bottom:0;left:0;right:0;background:#1a1440;padding:14px 16px;box-shadow:0 -4px 20px rgba(0,0,0,0.08)}
.save-btn{width:100%;padding:16px;background:#7c4dff;color:#fff;border:none;border-radius:30px;font-size:17px;font-weight:700}
</style>
</head>
<body>
<div class="topbar"><a href="/withdraw" class="back">←</a><div class="title">Add a bank account number</div></div>
<div class="warning">⚠️ To ensure the safety of your funds, please bind your bank account</div>
<form class="form" method="POST" action="/save_bank">
<div class="field"><label>Choose a bank</label>
<select name="bank" required>
<option value="">Please select a bank</option>
<option value="State Bank of India">State Bank of India</option>
<option value="HDFC Bank">HDFC Bank</option>
<option value="ICICI Bank">ICICI Bank</option>
<option value="Axis Bank">Axis Bank</option>
<option value="Punjab National Bank">Punjab National Bank</option>
<option value="Bank of Baroda">Bank of Baroda</option>
<option value="Other">Other</option>
</select></div>
<div class="field"><label>Full recipient's name</label>
<input type="text" name="name" placeholder="Enter full name" required value=""></div>
<div class="field"><label>Bank account number</label>
<input type="text" name="account" placeholder="Account number" required></div>
<div class="field"><label>Phone number</label>
<input type="tel" name="phone" placeholder="Phone number" required></div>
<div class="field"><label>IFSC code</label>
<input type="text" name="ifsc" placeholder="IFSC code" required style="text-transform:uppercase"></div>
<div class="save-bar"><button type="submit" class="save-btn">Save</button></div>
</form>
</body>
</html>


"""

deposit_history_html = """

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Deposit history</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #12183a;
      color: #ffffff;
      min-height: 100vh;
      display: flex;
      justify-content: center;
    }

    .app-container {
      width: 100%;
      max-width: 480px;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      position: relative;
      padding-bottom: 30px;
    }

    /* Top Navbar */
    .header {
      position: sticky;
      top: 0;
      background: #12183a;
      height: 52px;
      display: flex;
      align-items: center;
      padding: 0 16px;
      z-index: 50;
    }

    .back-btn {
      background: none;
      border: none;
      color: #ffffff;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 6px;
      margin-left: -6px;
    }

    .header-title {
      font-size: 19px;
      font-weight: 600;
      letter-spacing: 0.3px;
      margin-left: 12px;
    }

    /* Channel Tabs */
    .tabs-container {
      display: flex;
      gap: 10px;
      padding: 10px 16px;
      overflow-x: auto;
      scrollbar-width: none;
    }
    .tabs-container::-webkit-scrollbar { display: none; }

    .tab-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 10px 20px;
      background: #232c5f;
      color: #9aa8e5;
      border: none;
      border-radius: 10px;
      font-size: 14px;
      font-weight: 500;
      white-space: nowrap;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .tab-btn.active {
      background: linear-gradient(135deg, #7c5cfc, #5b36f5);
      color: #ffffff;
      box-shadow: 0 4px 12px rgba(124, 92, 252, 0.35);
    }

    /* Filter Bar */
    .filter-bar {
      display: flex;
      gap: 12px;
      padding: 8px 16px 14px;
    }

    .filter-box {
      flex: 1;
      position: relative;
    }

    .filter-select, .filter-date-btn {
      width: 100%;
      height: 44px;
      background: #21295b;
      border: none;
      border-radius: 10px;
      color: #b8c4f5;
      font-size: 14px;
      padding: 0 36px 0 14px;
      appearance: none;
      cursor: pointer;
      outline: none;
    }

    .filter-icon {
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
      pointer-events: none;
      color: #7d8bb8;
    }

    /* History List & Cards */
    .history-list {
      padding: 0 16px;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }

    .card {
      background: #1f2756;
      border-radius: 12px;
      padding: 16px 16px 18px;
    }

    .card-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }

    .type-badge {
      background: #00e676;
      color: #0b1f13;
      font-size: 12px;
      font-weight: 700;
      padding: 4px 14px;
      border-radius: 6px;
      text-transform: capitalize;
    }

    .status-text {
      font-size: 14px;
      font-weight: 500;
    }
    .status-text.complete { color: #00e676; }
    .status-text.pending { color: #ffb300; }
    .status-text.failed { color: #ff5252; }

    .data-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 11px;
      font-size: 13.5px;
    }

    .data-row:last-child {
      margin-bottom: 0;
    }

    .data-label {
      color: #8c9ac9;
    }

    .data-value {
      color: #d1dbff;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .amount-val {
      color: #ff9800;
      font-size: 15px;
      font-weight: 700;
    }

    .copy-icon-btn {
      background: none;
      border: none;
      color: #8c9ac9;
      cursor: pointer;
      display: flex;
      align-items: center;
      padding: 2px;
    }
    .copy-icon-btn:active { color: #ffffff; }

    /* No More footer */
    .no-more {
      text-align: center;
      color: #6371a3;
      font-size: 13px;
      margin: 28px 0 10px;
    }

    /* Toast Notification */
    .toast {
      position: fixed;
      bottom: 40px;
      left: 50%;
      transform: translateX(-50%) translateY(20px);
      background: rgba(0, 0, 0, 0.85);
      color: #fff;
      padding: 8px 18px;
      border-radius: 20px;
      font-size: 13px;
      opacity: 0;
      pointer-events: none;
      transition: all 0.25s ease;
      z-index: 100;
    }
    .toast.show {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
  </style>
</head>
<body>

  <div class="app-container">
    <!-- Navbar -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="header-title">Deposit history</span>
    </header>

    <!-- Category Tabs -->
    <div class="tabs-container">
      <button class="tab-btn active" onclick="filterChannel('ALL', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M4 4h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 10h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 16h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4z"/></svg>
        All
      </button>
      <button class="tab-btn" onclick="filterChannel('ArUpi Pay', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
        ArUpi Pay
      </button>
      <button class="tab-btn" onclick="filterChannel('Innate UPI-QR', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M3 3h8v8H3zm2 2v4h4V5zm8-2h8v8h-8zm2 2v4h4V5zM3 13h8v8H3zm2 2v4h4v-4zm13-2h3v2h-3zm-5 0h3v5h-3zm2 5h3v3h-3zm3-3h3v5h-3z"/></svg>
        Innate UPI-QR
      </button>
    </div>

    <!-- Filter Dropdowns -->
    <div class="filter-bar">
      <div class="filter-box">
        <select class="filter-select" id="statusFilter" onchange="renderData()">
          <option value="ALL">All</option>
          <option value="Complete">Complete</option>
          <option value="Pending">Pending</option>
          <option value="Failed">Failed</option>
        </select>
        <svg class="filter-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
      </div>

      <div class="filter-box">
        <input type="date" class="filter-select" id="dateFilter" onchange="renderData()" />
        <svg class="filter-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>

    <!-- Dynamic History Items -->
    <div class="history-list" id="depositList"></div>

    <div class="no-more">No more</div>
  </div>

  <div id="toast" class="toast">Copied to clipboard</div>

  <script>
    // Real dynamic data array (Aap ise API response se replace kar sakte hain)
    let depositRecords = [
      {
        id: "RC20260905213444211101336c",
        typeTag: "Deposit",
        channel: "Innate UPI-QR",
        paymentType: "Phonepe_QR",
        amount: 100.00,
        status: "Complete",
        time: "2026-09-05 21:34:44"
      }
    ];

    let selectedChannel = "ALL";

    function filterChannel(channel, element) {
      document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
      element.classList.add('active');
      selectedChannel = channel;
      renderData();
    }

    function renderData() {
      const container = document.getElementById("depositList");
      const statusFilter = document.getElementById("statusFilter").value;
      const dateFilter = document.getElementById("dateFilter").value;

      let filtered = depositRecords.filter(item => {
        let channelMatch = (selectedChannel === "ALL" || item.channel === selectedChannel);
        let statusMatch = (statusFilter === "ALL" || item.status.toLowerCase() === statusFilter.toLowerCase());
        let dateMatch = !dateFilter || item.time.startsWith(dateFilter);
        return channelMatch && statusMatch && dateMatch;
      });

      if(filtered.length === 0) {
        container.innerHTML = `<div style="text-align:center; padding:40px 0; color:#6371a3;">No records found</div>`;
        return;
      }

      container.innerHTML = filtered.map(item => `
        <div class="card">
          <div class="card-top">
            <span class="type-badge">${item.typeTag}</span>
            <span class="status-text ${item.status.toLowerCase()}">${item.status}</span>
          </div>
          
          <div class="data-row">
            <span class="data-label">Order amount</span>
            <span class="data-value amount-val">₹${item.amount.toFixed(2)}</span>
          </div>
          
          <div class="data-row">
            <span class="data-label">Type</span>
            <span class="data-value">${item.paymentType}</span>
          </div>

          <div class="data-row">
            <span class="data-label">UTR</span>
            <span class="data-value">${item.utr || '-'}</span>
          </div>

          <div class="data-row">
            <span class="data-label">Time</span>
            <span class="data-value">${item.time}</span>
          </div>

          <div class="data-row">
            <span class="data-label">Order number</span>
            <span class="data-value">
              <span>${item.id}</span>
              <button class="copy-icon-btn" onclick="copyText('${item.id}')" title="Copy">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
              </button>
            </span>
          </div>
        </div>
      `).join('');
    }

    function copyText(text) {
      navigator.clipboard.writeText(text).then(() => {
        const toast = document.getElementById("toast");
        toast.classList.add("show");
        setTimeout(() => toast.classList.remove("show"), 1800);
      });
    }

    // Initial render
    window.addEventListener("DOMContentLoaded", renderData);
  </script>
</body>
</html>

"""

withdraw_history_html = """

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Withdrawal history</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #12183a;
      color: #ffffff;
      min-height: 100vh;
      display: flex;
      justify-content: center;
    }

    .app-container {
      width: 100%;
      max-width: 480px;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      position: relative;
      padding-bottom: 50px;
    }

    /* Top Navbar */
    .header {
      position: sticky;
      top: 0;
      background: #12183a;
      height: 52px;
      display: flex;
      align-items: center;
      padding: 0 16px;
      z-index: 50;
    }

    .back-btn {
      background: none;
      border: none;
      color: #ffffff;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 6px;
      margin-left: -6px;
    }

    .header-title {
      font-size: 19px;
      font-weight: 600;
      letter-spacing: 0.3px;
      margin-left: 12px;
    }

    /* Channel Tabs */
    .tabs-container {
      display: flex;
      gap: 10px;
      padding: 10px 16px;
      overflow-x: auto;
      scrollbar-width: none;
    }
    .tabs-container::-webkit-scrollbar { display: none; }

    .tab-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 10px 18px;
      background: #232c5f;
      color: #9aa8e5;
      border: none;
      border-radius: 10px;
      font-size: 14px;
      font-weight: 500;
      white-space: nowrap;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .tab-btn.active {
      background: linear-gradient(135deg, #7c5cfc, #5b36f5);
      color: #ffffff;
      box-shadow: 0 4px 12px rgba(124, 92, 252, 0.35);
    }

    /* Filter Bar */
    .filter-bar {
      display: flex;
      gap: 12px;
      padding: 8px 16px 14px;
    }

    .filter-box {
      flex: 1;
      position: relative;
    }

    .filter-select, .filter-date-btn {
      width: 100%;
      height: 44px;
      background: #21295b;
      border: none;
      border-radius: 10px;
      color: #b8c4f5;
      font-size: 14px;
      padding: 0 36px 0 14px;
      appearance: none;
      cursor: pointer;
      outline: none;
    }

    .filter-icon {
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
      pointer-events: none;
      color: #7d8bb8;
    }

    /* History List & Cards */
    .history-list {
      padding: 0 16px;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }

    .card {
      background: #1f2756;
      border-radius: 12px;
      padding: 16px 16px 18px;
    }

    .card-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }

    /* Withdraw Badge (Red style) */
    .type-badge-withdraw {
      background: #ff3b30;
      color: #ffffff;
      font-size: 12px;
      font-weight: 600;
      padding: 4px 14px;
      border-radius: 6px;
    }

    .status-text {
      font-size: 14px;
      font-weight: 500;
    }
    .status-text.completed { color: #00e676; }
    .status-text.pending { color: #ffb300; }
    .status-text.rejected { color: #ff5252; }

    .data-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 11px;
      font-size: 13.5px;
    }

    .data-row:last-child {
      margin-bottom: 0;
    }

    .data-label {
      color: #8c9ac9;
    }

    .data-value {
      color: #d1dbff;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .amount-val {
      color: #ff9800;
      font-size: 15px;
      font-weight: 700;
    }

    .copy-icon-btn {
      background: none;
      border: none;
      color: #8c9ac9;
      cursor: pointer;
      display: flex;
      align-items: center;
      padding: 2px;
    }
    .copy-icon-btn:active { color: #ffffff; }

    /* No More footer */
    .no-more {
      text-align: center;
      color: #6371a3;
      font-size: 13px;
      margin: 28px 0 10px;
    }

    /* Floating Support Icon */
    .floating-cs {
      position: fixed;
      right: 20px;
      bottom: 40px;
      width: 54px;
      height: 54px;
      background: #0d122e;
      border: 3px solid #00e676;
      box-shadow: 0 0 15px rgba(0, 230, 118, 0.45);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      z-index: 80;
    }

    /* Toast */
    .toast {
      position: fixed;
      bottom: 40px;
      left: 50%;
      transform: translateX(-50%) translateY(20px);
      background: rgba(0, 0, 0, 0.85);
      color: #fff;
      padding: 8px 18px;
      border-radius: 20px;
      font-size: 13px;
      opacity: 0;
      pointer-events: none;
      transition: all 0.25s ease;
      z-index: 100;
    }
    .toast.show {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
  </style>
</head>
<body>

  <div class="app-container">
    <!-- Navbar -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="header-title">Withdrawal history</span>
    </header>

    <!-- Channel Tabs -->
    <div class="tabs-container">
      <button class="tab-btn active" onclick="filterChannel('ALL', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M4 4h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 10h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 16h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4z"/></svg>
        All
      </button>
      <button class="tab-btn" onclick="filterChannel('UPI', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 15h10M7 9h10"/></svg>
        UPI
      </button>
      <button class="tab-btn" onclick="filterChannel('ARPay', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="#ffb300"><path d="M12 2L2 22h20L12 2zm0 4l6.5 13h-13L12 6z"/></svg>
        ARPay
      </button>
      <button class="tab-btn" onclick="filterChannel('BANK CARD', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
        BANK CARD
      </button>
    </div>

    <!-- Filter Bar -->
    <div class="filter-bar">
      <div class="filter-box">
        <select class="filter-select" id="statusFilter" onchange="renderData()">
          <option value="ALL">All</option>
          <option value="Completed">Completed</option>
          <option value="Pending">Pending</option>
          <option value="Rejected">Rejected</option>
        </select>
        <svg class="filter-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
      </div>

      <div class="filter-box">
        <input type="date" class="filter-select" id="dateFilter" onchange="renderData()" />
        <svg class="filter-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>

    <!-- Dynamic History Items -->
    <div class="history-list" id="withdrawList"></div>

    <div class="no-more">No more</div>

    <!-- Floating Customer Support Widget -->
    <div class="floating-cs" onclick="window.open('https://t.me/Shreewinofficial01_bot','_blank')">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="#00e676"><path d="M12 1a9 9 0 0 0-9 9v7a3 3 0 0 0 3 3h1a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1H5v-3a7 7 0 1 1 14 0v3h-2a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h1a3 3 0 0 0 3-3v-7a9 9 0 0 0-9-9z"/></svg>
    </div>
  </div>

  <div id="toast" class="toast">Copied to clipboard</div>

  <script>
    // Real dynamic data array
    let withdrawRecords = [
      {
        id: "WD20260905214749141101296c",
        typeTag: "Withdraw",
        channel: "BANK CARD",
        paymentType: "BANK CARD",
        amount: 130.00,
        status: "Completed",
        time: "2026-09-05 21:47:49",
        remarks: ""
      }
    ];

    let selectedChannel = "ALL";

    function filterChannel(channel, element) {
      document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
      element.classList.add('active');
      selectedChannel = channel;
      renderData();
    }

    function renderData() {
      const container = document.getElementById("withdrawList");
      const statusFilter = document.getElementById("statusFilter").value;
      const dateFilter = document.getElementById("dateFilter").value;

      let filtered = withdrawRecords.filter(item => {
        let channelMatch = (selectedChannel === "ALL" || item.channel === selectedChannel);
        let statusMatch = (statusFilter === "ALL" || item.status.toLowerCase() === statusFilter.toLowerCase());
        let dateMatch = !dateFilter || item.time.startsWith(dateFilter);
        return channelMatch && statusMatch && dateMatch;
      });

      if(filtered.length === 0) {
        container.innerHTML = `<div style="text-align:center; padding:40px 0; color:#6371a3;">No records found</div>`;
        return;
      }

      container.innerHTML = filtered.map(item => `
        <div class="card">
          <div class="card-top">
            <span class="type-badge-withdraw">${item.typeTag}</span>
            <span class="status-text ${item.status.toLowerCase()}">${item.status}</span>
          </div>
          
          <div class="data-row">
            <span class="data-label">Balance</span>
            <span class="data-value amount-val">₹${item.amount.toFixed(2)}</span>
          </div>
          
          <div class="data-row">
            <span class="data-label">Type</span>
            <span class="data-value">${item.paymentType}</span>
          </div>

          <div class="data-row">
            <span class="data-label">Time</span>
            <span class="data-value">${item.time}</span>
          </div>

          <div class="data-row">
            <span class="data-label">Order number</span>
            <span class="data-value">
              <span>${item.id}</span>
              <button class="copy-icon-btn" onclick="copyText('${item.id}')" title="Copy">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
              </button>
            </span>
          </div>

          <div class="data-row">
            <span class="data-label">Remarks</span>
            <span class="data-value">${item.remarks || ""}</span>
          </div>
        </div>
      `).join('');
    }

    function copyText(text) {
      navigator.clipboard.writeText(text).then(() => {
        const toast = document.getElementById("toast");
        toast.classList.add("show");
        setTimeout(() => toast.classList.remove("show"), 1800);
      });
    }

    // Initial render
    window.addEventListener("DOMContentLoaded", renderData);
  </script>
</body>
</html>

"""

