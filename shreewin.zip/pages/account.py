# Wallet / account pages — single HTML document each
account_html = """
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta charset="UTF-8">
<title>ShreeWin - Account</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>

/* === OFFICIAL COLOUR MATCH === */
:root{
  --sw-bg:#0d0a1f;
  --sw-bg-deep:#0a0816;
  --sw-surface:#141332;
  --sw-card:#1a1435;
  --sw-card-2:#1e1b4b;
  --sw-border:#26244f;
  --sw-accent:#6965e8;
  --sw-purple:#7c3aed;
  --sw-purple-2:#8b5cf6;
  --sw-text:#ffffff;
  --sw-muted:#9e8fc7;
  --sw-muted-2:#5d5c88;
  --sw-gold:#ffd700;
  --sw-orange:#ff8f00;
}
html,body{background:#0d0a1f!important;color:#fff!important}
/* === END OFFICIAL COLOUR MATCH === */





        :root {
            --bg-dark: #161239;
            --bg-card: #241d4c;
            --bg-card-alt: #1c1740;
            --bg-card-inner: #1f1b40;
            --primary-purple: #8d7ff7;
            --primary-gradient: linear-gradient(135deg, #a78bfa 0%, #7c66f6 100%);
            --btn-purple: #9b8df8;
            --btn-amount-bg: #2d275e;
            --btn-amount-active: #8d80f8;
            --text-white: #ffffff;
            --text-light: #b0a9d8;
            --color-green: #00e676;
            --color-orange: #ff9800;
            --color-red: #ff4d4f;
            --color-gold: #ffb800;
            --pay-card-bg: #2b245e;
            --input-dark: #272153;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Delius', 'Nunito', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #0d0a1f;
            display: flex;
            justify-content: center;
            min-height: 100vh;
            overflow-x: hidden;
            overflow-y: auto;
        }

        /* Mobile Container Frame */
        .app-container {
            width: 100%;
            max-width: 400px;
            height: 100vh;
            background-color: var(--bg-dark);
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(255,255,255,0.1);
        }

        /* Smooth Screen Transition Styles */
        .app-screen {
            display: none;
            flex-direction: column;
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            background-color: var(--bg-dark);
            opacity: 0;
            transition: opacity 0.25s ease-in-out;
            z-index: 1;
        }

        .app-screen.active {
            display: flex;
            opacity: 1;
            z-index: 5;
        }

        /* Shared Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 16px;
            color: var(--text-white);
            background-color: var(--bg-dark);
            z-index: 10;
        }
        .header .back-btn {
            font-size: 1.1rem;
            cursor: pointer;
            padding: 5px;
        }
        .header .title {
            font-size: 1.25rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .header .history-link {
            font-size: 0.9rem;
            color: #d8d4fd;
            text-decoration: none;
            cursor: pointer;
        }

        /* Scrollable Area */
        .scrollable-content {
            flex: 1;
            overflow-y: auto;
            scrollbar-width: none;
        }
        .scrollable-content::-webkit-scrollbar {
            display: none;
        }

        /* Floating Support */
        .sub-fab-right {
            position: absolute;
            bottom: 25px;
            right: 15px;
            width: 52px;
            height: 52px;
            border-radius: 50%;
            background: radial-gradient(circle, #00f5a0 0%, #00d9e9 100%);
            box-shadow: 0 0 15px rgba(0, 245, 160, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: 3px solid rgba(255, 255, 255, 0.4);
            z-index: 15;
        }
        .sub-fab-right i { color: #1e1b4b; font-size: 1.5rem; }

        /* ================= 1. ACCOUNT VIEW STYLES ================= */
        .profile-header {
            background: linear-gradient(180deg, #9b89ff 0%, #6e55f8 50%, var(--bg-dark) 100%);
            padding: 24px 16px 15px 16px;
            position: relative;
        }
        .profile-row {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .avatar-wrap {
            position: relative;
            width: 72px;
            height: 72px;
            border-radius: 50%;
            border: 2px solid rgba(255, 255, 255, 0.6);
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            flex-shrink: 0;
            background: #25204d;
        }
        .avatar-wrap img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .user-details {
            display: flex;
            flex-direction: column;
            gap: 4px;
            flex: 1;
        }
        .username-row {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .username {
            color: #ffffff;
            font-size: 1.15rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .vip-badge {
            background: linear-gradient(135deg, #e2e8f0 0%, #94a3b8 100%);
            color: #1e1b4b;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 800;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        .uid-pill {
            background: rgba(255, 152, 0, 0.9);
            color: #ffffff;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            width: fit-content;
            cursor: pointer;
            margin-top: 2px;
        }
        .last-login {
            color: #d1ccff;
            font-size: 0.72rem;
            margin-top: 2px;
        }

        /* Account page: normal scrolling + logout stays reachable above bottom nav */
        .account-logout-fixed { display: none; }
        .account-legacy-logout { display: none; }
        .main-padding { padding: 0 14px 110px 14px; }
        body { min-height: 100vh; overflow-y: auto; -webkit-overflow-scrolling: touch; padding-bottom: 88px; }
        .scrollable-content { overflow-y: auto; height: 100%; min-height: 0; padding-bottom: 100px; -webkit-overflow-scrolling: touch; }
        .btn-logout { margin-top: 8px; margin-bottom: 20px; }

        .wallet-card {
            background-color: var(--bg-card);
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 14px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.25);
        }
        .wallet-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .wallet-left {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .wallet-title {
            color: #a7a0d8;
            font-size: 0.9rem;
        }
        .balance-value-row {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #ffffff;
            font-size: 1.8rem;
            font-weight: bold;
        }
        .balance-value-row i {
            font-size: 1.1rem;
            color: #a7a0d8;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .btn-enter-wallet {
            background-color: #beb4ff;
            color: #2b2361;
            border: none;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
            cursor: pointer;
        }

        .wallet-actions-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            text-align: center;
        }
        .w-action-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            cursor: pointer;
            text-decoration: none;
        }
        .w-action-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
        }
        .w-action-icon.arwallet { background: rgba(255, 77, 79, 0.15); color: #ff4d4f; }
        .w-action-icon.deposit { background: rgba(255, 152, 0, 0.15); color: #ff9800; }
        .w-action-icon.withdraw { background: rgba(0, 186, 242, 0.15); color: #00baf2; }
        .w-action-icon.vip { background: rgba(0, 230, 118, 0.15); color: #00e676; }
        .w-action-label {
            color: #ffffff;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .history-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 14px;
        }
        .history-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            text-decoration: none;
        }
        .hist-icon-wrap {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }
        .hist-icon-wrap.game { background: #1a73e8; color: white; }
        .hist-icon-wrap.trans { background: #00c853; color: white; }
        .hist-icon-wrap.dep { background: #e53935; color: white; }
        .hist-icon-wrap.with { background: #fb8c00; color: white; }
        .hist-text { display: flex; flex-direction: column; overflow: hidden; }
        .hist-title { color: #ffffff; font-size: 0.95rem; font-weight: bold; line-height: 1.1; }
        .hist-sub { color: #8f88c2; font-size: 0.72rem; margin-top: 2px; white-space: nowrap; }

        .menu-card {
            background-color: var(--bg-card);
            border-radius: 14px;
            overflow: hidden;
            margin-bottom: 14px;
        }
        .menu-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            cursor: pointer;
            text-decoration: none;
            color: #ffffff;
        }
        .menu-row:last-child { border-bottom: none; }
        .menu-row-left { display: flex; align-items: center; gap: 14px; font-size: 0.95rem; font-weight: 600; }
        .menu-row-left i { font-size: 1.2rem; color: #9b8df8; width: 22px; text-align: center; }
        .menu-row-right { display: flex; align-items: center; gap: 8px; color: #7b74ba; font-size: 0.85rem; }

        .service-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 18px;
        }
        .service-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 16px; }
        .service-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            row-gap: 20px;
            column-gap: 8px;
            text-align: center;
        }
        .service-item { display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; text-decoration: none; }
        .service-icon { font-size: 1.6rem; color: #8d7ff7; }
        .service-label { color: #ffffff; font-size: 0.82rem; font-weight: 600; line-height: 1.2; }

        .btn-logout {
            width: 100%;
            background-color: transparent;
            border: 1px solid #4a3e8e;
            color: #ffffff;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 30px;
        }

        /* ================= 2. DEPOSIT VIEW STYLES ================= */
        .deposit-pad { padding: 10px 14px 125px 14px; }
        .balance-card {
            background: var(--primary-gradient);
            border-radius: 16px;
            padding: 20px 18px;
            color: white;
            position: relative;
            overflow: hidden;
            margin-bottom: 15px;
            box-shadow: 0 4px 15px rgba(124, 102, 246, 0.25);
        }
        .balance-label {
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 8px;
            opacity: 0.95;
        }
        .balance-amount {
            font-size: 2rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .balance-amount i { font-size: 1.2rem; cursor: pointer; transition: transform 0.4s ease; }
        .balance-card .dots-bg {
            position: absolute;
            bottom: 8px;
            right: 15px;
            color: rgba(255, 255, 255, 0.3);
            font-size: 1.1rem;
            letter-spacing: 2px;
            font-weight: bold;
        }

        .channels-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 15px;
        }
        .channel-card {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 4px 10px 4px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            position: relative;
            border: 1px solid transparent;
            min-height: 86px;
        }
        .channel-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .channel-icon-wrap {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 6px;
        }
        .channel-name { color: white; font-size: 0.72rem; font-weight: 600; line-height: 1.1; }
        .channel-badge {
            position: absolute;
            top: -4px;
            right: -2px;
            background-color: var(--color-red);
            color: white;
            font-size: 0.65rem;
            font-weight: bold;
            padding: 2px 5px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 2px;
        }

        .amount-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .section-title {
            color: white;
            font-size: 1.05rem;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 14px;
            font-weight: bold;
        }
        .section-title i { color: #b0a5fa; }

        .amount-grid-deposit {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 15px;
        }
        .amount-btn {
            background-color: var(--btn-amount-bg);
            border: 1px solid rgba(255, 255, 255, 0.05);
            color: #bcb6ea;
            padding: 12px 5px;
            border-radius: 8px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
            transition: all 0.2s ease;
        }
        .amount-btn:hover, .amount-btn:active, .amount-btn.active {
            background-color: var(--btn-amount-active);
            color: white;
            box-shadow: 0 2px 8px rgba(141, 128, 248, 0.4);
        }

        .amount-input-box {
            background-color: var(--bg-card-inner);
            border-radius: 25px;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .amount-input-box .currency-sym {
            color: #958df1;
            font-size: 1.1rem;
            font-weight: bold;
            padding-right: 10px;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
            margin-right: 10px;
        }
        .amount-input-box input {
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: #ffffff;
            font-size: 0.95rem;
        }
        .amount-input-box input::placeholder { color: #7b74ba; }
        .amount-input-box .clear-btn { color: #7b74ba; font-size: 1rem; cursor: pointer; padding: 2px 5px; }

        .instruction-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .instruction-inner {
            background-color: var(--bg-card-inner);
            border-radius: 10px;
            padding: 14px;
        }
        .instruction-list { list-style: none; }
        .instruction-list li {
            position: relative;
            padding-left: 18px;
            color: #9e97d8;
            font-size: 0.82rem;
            line-height: 1.45;
            margin-bottom: 14px;
        }
        .instruction-list li:last-child { margin-bottom: 0; }
        .instruction-list li::before {
            content: '×';
            position: absolute;
            left: 0;
            top: 0;
            color: #8d80f8;
            font-size: 0.75rem;
        }

        .sub-no-data-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px 0 10px 0;
        }
        .sub-no-data-icon { width: 170px; height: 120px; opacity: 0.85; margin-bottom: 10px; }
        .sub-no-data-text { color: #ffffff; font-size: 1.15rem; font-weight: 500; }

        .history-card-item {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-left: 4px solid var(--color-green);
        }
        .history-card-item.pending { border-left-color: var(--color-orange); }
        .history-card-item.rejected { border-left-color: var(--color-red); }
        .history-card-left .hist-amount { font-size: 1.1rem; font-weight: bold; color: white; margin-bottom: 2px;}
        .history-card-left .hist-utr { font-size: 0.75rem; color: var(--text-light); }
        .history-card-right { text-align: right; }
        .history-card-right .hist-status { font-size: 0.8rem; font-weight: bold; text-transform: capitalize; }
        .history-card-right .hist-time { font-size: 0.7rem; color: var(--text-light); margin-top: 2px; }

        .status-approved { color: var(--color-green); }
        .status-pending { color: var(--color-orange); }
        .status-rejected { color: var(--color-red); }

        .deposit-bottom-bar {
            position: fixed !important;
            bottom: 0 !important;
            left: 0;
            right: 0;
            background-color: #1a1540;
            padding: 12px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 99999 !important;
            position: fixed !important;
        }
        .recharge-method-info { display: flex; flex-direction: column; }
        .recharge-method-info .label { font-size: 0.78rem; color: #ffffff; margin-bottom: 2px; }
        .recharge-method-info .method-name { font-size: 0.95rem; color: #ffffff; font-weight: bold; }
        .deposit-btn {
            background-color: var(--primary-purple);
            color: white;
            border: none;
            padding: 10px 28px;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }

        /* Gateway Screen (ArUpiPay) */
        .cs-pill-btn {
            background: linear-gradient(90deg, #7c67ff 0%, #6852ee 100%);
            color: white;
            font-size: 0.8rem;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            cursor: pointer;
            font-weight: 600;
        }
        .pay-amount-bar {
            background-color: var(--pay-card-bg);
            border-radius: 12px;
            padding: 16px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .pay-amount-left { display: flex; align-items: center; gap: 12px; color: #ffffff; font-size: 1.7rem; font-weight: bold; }
        .pay-amount-left i { font-size: 1.25rem; color: #d1ccff; cursor: pointer; }
        .pay-timer { color: var(--color-red); font-size: 1.15rem; font-weight: bold; letter-spacing: 0.5px; }

        .pay-bullet-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
        .pay-bullet-title::before { content: '•'; color: #ffffff; font-size: 1.3rem; line-height: 0; }

        .pay-methods-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
        .pay-method-card { border-radius: 12px; padding: 12px 10px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; cursor: pointer; transition: transform 0.15s ease; }
        .pay-method-card:active { transform: scale(0.97); }
        .pay-method-card.paytm { background: linear-gradient(135deg, #d4f8ff 0%, #a4e6f9 100%); color: #042e6f; }
        .pay-method-card.phonepe { background: linear-gradient(135deg, #fce8ff 0%, #ebd0fc 100%); color: #5f259f; }
        .pay-logo-wrap { display: flex; align-items: center; gap: 6px; font-size: 1.05rem; font-weight: bold; margin-bottom: 4px; }
        .pay-logo-img { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.85rem; font-weight: bold; }
        .paytm .pay-logo-img { background-color: #002e6e; font-size: 0.6rem; }
        .phonepe .pay-logo-img { background-color: #5f259f; font-size: 1rem; }
        .wake-text { font-size: 0.75rem; color: #8b80cf; font-weight: 600; }

        .qr-card {
            background-color: #372f78;
            border-radius: 14px;
            padding: 22px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            margin-bottom: 22px;
        }
        .qr-image-wrapper {
            background-color: #ffffff;
            padding: 12px;
            border-radius: 14px;
            display: inline-block;
            margin-bottom: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        .qr-image-wrapper img { width: 180px; height: 180px; display: block; margin: 0 auto; }
        .qr-upi-info { color: #332d5e; font-size: 0.82rem; font-weight: bold; margin-top: 8px; font-family: 'Nunito', sans-serif; }
        .qr-desc { color: #ffffff; font-size: 0.88rem; line-height: 1.45; text-align: left; width: 100%; margin-top: 6px; }
        .qr-desc p { margin-bottom: 8px; }

        .utr-warning-text { color: var(--color-red); font-size: 0.95rem; line-height: 1.35; font-weight: bold; margin-bottom: 12px; }
        .utr-input-box {
            background-color: #272153;
            border-radius: 30px;
            padding: 6px 6px 6px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 22px;
            box-shadow: 0 0 10px rgba(186, 104, 200, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .utr-input-box input { background: transparent; border: none; outline: none; color: #b7b0ee; font-size: 0.95rem; width: 70%; }
        .utr-paste-btn { background-color: #8d80f8; color: #ffffff; border: none; padding: 8px 18px; border-radius: 20px; font-size: 0.9rem; font-weight: bold; cursor: pointer; }
        .reminder-list { color: #ffffff; font-size: 0.9rem; line-height: 1.6; margin-bottom: 25px; }

        .pay-bottom-bar {
            position: fixed !important;
            bottom: 0 !important;
            left: 0;
            right: 0;
            background-color: #1a1540;
            padding: 12px 16px;
            display: flex;
            gap: 12px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 20;
        }
        .btn-cancel { flex: 0.35; background-color: #38306e; color: #ffffff; border: none; padding: 12px 0; border-radius: 8px; font-size: 0.95rem; font-weight: bold; cursor: pointer; }
        .btn-submit-utr { flex: 0.65; background: linear-gradient(90deg,#8b5cf6,#7c3aed); color: #fff; border: none; padding: 14px 0; border-radius: 12px; font-size: 1rem; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(124,58,237,0.4); }
        .btn-submit-utr.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 12px rgba(141, 128, 248, 0.4); }

        /* ================= 3. WITHDRAW VIEW STYLES ================= */
        .withdraw-pad { padding: 10px 14px 40px 14px; }
        .arpay-banner {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 14px;
        }
        .arpay-logo { font-size: 2rem; color: #ffb800; font-weight: 900; line-height: 1; }
        .arpay-text h4 { color: white; font-size: 1.05rem; font-weight: bold; margin-bottom: 2px; }
        .arpay-text p { color: #9e97d8; font-size: 0.8rem; }

        .methods-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 14px;
        }
        .method-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            min-height: 90px;
            transition: all 0.2s;
        }
        .method-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .method-icon { font-size: 1.8rem; margin-bottom: 6px; height: 36px; display: flex; align-items: center; justify-content: center; }
        .method-name { color: white; font-size: 0.8rem; font-weight: 700; letter-spacing: 0.5px; }

        .account-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
            cursor: pointer;
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: 0.2s;
        }
        .account-card:active { transform: scale(0.98); }
        .account-left { display: flex; flex-direction: column; gap: 4px; }
        .account-name-row { display: flex; align-items: center; gap: 8px; color: white; font-size: 1rem; font-weight: bold; }
        .account-vpa { color: #9e97d8; font-size: 0.9rem; font-weight: 600; }
        .account-card i.fa-chevron-right { color: #7b74ba; font-size: 0.95rem; }

        .add-bank-box {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 24px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            margin-bottom: 6px;
        }
        .dashed-plus-icon {
            width: 46px;
            height: 46px;
            border: 2px dashed #7a70bb;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7a70bb;
            font-size: 1.5rem;
            margin-bottom: 12px;
        }
        .add-bank-text { color: #8c82cb; font-size: 1rem; font-weight: bold; }
        .add-bank-warning { color: var(--color-red); font-size: 0.8rem; text-align: center; margin-bottom: 14px; line-height: 1.3; }

        .amount-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 14px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.88rem;
            margin-bottom: 8px;
            color: #bcb6ea;
        }
        .btn-all-pill {
            background-color: #38306e;
            color: white;
            border: none;
            padding: 3px 18px;
            border-radius: 14px;
            font-size: 0.8rem;
            font-weight: bold;
            cursor: pointer;
        }
        .received-val { color: #ff9800; font-weight: bold; font-size: 1.1rem; }

        .withdraw-action-btn {
            width: 100%;
            background-color: #d1cbff;
            color: #7a6fc7;
            border: none;
            padding: 14px;
            border-radius: 25px;
            font-size: 1.05rem;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 20px;
            transition: 0.2s;
        }
        .withdraw-action-btn.ready {
            background: var(--primary-purple);
            color: white;
            box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4);
        }
        .val-red { color: var(--color-red); font-weight: bold; }

        .btn-all-history {
            width: 100%;
            background-color: transparent;
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #bcb6ea;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
        }

        /* Payment Method Screen (UPI Sub-Screen) */
        .pm-account-card {
            background-color: #262153;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            margin-bottom: 15px;
        }
        .pm-card-header-stripe { height: 38px; background: linear-gradient(90deg, #0066ff 0%, #0088ff 100%); width: 100%; }
        .pm-card-body { padding: 18px 16px; color: #ffffff; }
        .pm-info-row { font-size: 1rem; color: #d1ccff; margin-bottom: 12px; letter-spacing: 0.3px; }
        .pm-info-row .bold-text { color: #ffffff; font-weight: bold; }
        .pm-current-tag { display: flex; align-items: center; gap: 8px; color: #a49fc7; font-size: 0.92rem; margin-top: 14px; }
        .pm-check-circle { width: 20px; height: 20px; background-color: var(--color-red); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.75rem; }
        .pm-bottom-bar { position: fixed !important; bottom: 0 !important; left: 0; right: 0; padding: 16px; background-color: #1a1540; z-index: 99999 !important; max-width: 400px; margin: 0 auto; box-shadow: 0 -4px 20px rgba(0,0,0,0.5); }
        .btn-add-method { width: 100%; background: linear-gradient(90deg,#8b5cf6,#7c3aed) !important; color: #fff !important; border: none; padding: 16px; border-radius: 30px; font-size: 1.1rem; font-weight: 800; cursor: pointer; box-shadow: 0 4px 15px rgba(139,92,246,0.5); }

        /* Add Bank Sub-Screen */
        .ab-notice-pill { background-color: #272153; border-radius: 20px; padding: 10px 14px; display: flex; align-items: center; gap: 10px; margin-bottom: 18px; color: var(--color-red); font-size: 0.8rem; line-height: 1.35; }
        .ab-form-group { margin-bottom: 16px; }
        .ab-label { color: #ffffff; font-size: 0.95rem; font-weight: bold; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .ab-label i { color: #8d7ff7; font-size: 1rem; }
        .ab-select-box { background: linear-gradient(90deg, #6b55fb 0%, #503ef0 100%); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; color: #ffffff; cursor: pointer; font-size: 0.95rem; font-weight: bold; }
        .ab-input-box { background-color: var(--input-dark); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; }
        .ab-input { width: 100%; background: transparent; border: none; outline: none; color: #ffffff; font-size: 0.95rem; font-family: 'Delius', sans-serif; }
        .ab-input::placeholder { color: #766eb5; }
        .ab-bottom-bar { padding: 14px 16px; background-color: var(--bg-dark); }
        .btn-save-bank { width: 100%; background-color: #d1cbff; color: #7a6fc7; border: none; padding: 15px; border-radius: 25px; font-size: 1.1rem; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .btn-save-bank.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4); }

        /* Bank Selector Modal */
        .bank-modal {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 50;
            display: none;
            flex-direction: column;
            justify-content: flex-end;
        }
        .bank-modal-content {
            background: var(--bg-card);
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            padding: 20px;
            max-height: 70vh;
            display: flex;
            flex-direction: column;
        }
        .bank-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 14px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .bank-list { overflow-y: auto; flex: 1; }
        .bank-item {
            padding: 14px 12px;
            color: #d1ccff;
            font-size: 0.95rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .bank-item:hover, .bank-item:active { background: rgba(255,255,255,0.08); color: white; }

        /* Gift Claim Popup Modal */
        .gift-modal-backdrop {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 100;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .gift-popup-card {
            background: var(--bg-card);
            border-radius: 18px;
            width: 100%;
            max-width: 320px;
            padding: 24px 20px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.6);
            border: 1px solid rgba(255,255,255,0.1);
        }
        .gift-popup-card i.fa-gift { font-size: 3rem; color: #ffb800; margin-bottom: 12px; }
        .gift-input {
            width: 100%;
            background: var(--bg-card-alt);
            border: 1px solid rgba(255,255,255,0.1);
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-size: 1rem;
            text-transform: uppercase;
            text-align: center;
            margin: 14px 0;
            outline: none;
            font-family: 'Nunito', sans-serif;
            font-weight: bold;
        }
        .btn-claim-gift {
            width: 100%;
            background: var(--primary-purple);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }
    
/* Standalone account page */
body{min-height:100vh;overflow-y:auto;-webkit-overflow-scrolling:touch;padding-bottom:88px;}
.bottom-navbar{position:fixed;bottom:0;left:0;width:100%;height:65px;background:#141332;border-top:1px solid #26244f;display:flex;justify-content:space-around;align-items:center;z-index:1000;padding-bottom:5px;font-family:Poppins,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}
.nav-item{display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:#5d5c88;font-size:11px;font-weight:600;transition:all .2s ease;cursor:pointer;flex:1}
.nav-item svg{width:26px;height:26px;fill:#5d5c88;margin-bottom:2px;transition:all .2s ease}
.nav-item.active{color:#6965e8}
.nav-item.active svg{fill:#6965e8;filter:drop-shadow(0 0 8px rgba(105,101,232,.4))}
.wheel-item{position:relative;top:-16px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;flex:1.2;text-decoration:none}
.wheel-wrapper{width:72px;height:72px;position:relative;display:flex;justify-content:center;align-items:center;filter:drop-shadow(0 4px 10px rgba(0,0,0,.6))}
.wheel-wrapper svg{width:100%;height:100%}
.wheel-label{position:absolute;bottom:-6px;white-space:nowrap;font-size:13px;font-weight:900;color:#ffe600;text-shadow:-1.5px -1.5px 0 #b30000,1.5px -1.5px 0 #b30000,-1.5px 1.5px 0 #b30000,1.5px 1.5px 0 #b30000,0 2px 4px rgba(0,0,0,.8);letter-spacing:-.2px}

</style>
</head>
<body>
<div class="scrollable-content">
            <!-- 1. Profile Top Section -->
            <div class="profile-header">
                <div class="profile-row">
                    <div class="avatar-wrap">
                        <img src="data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAXcBZcDASIAAhEBAxEB/8QAHAABAAIDAQEBAAAAAAAAAAAAAAECAwQFBgcI/8QAOhAAAgICAQMDBAAFAgUEAwADAAECAwQRIQUSMQZBUQcTImEUMkJxkSNSQ2JygaEVMzRTFiU1FyRU/8QAGwEBAAMBAQEBAAAAAAAAAAAAAAECAwQFBgf/xAAlEQEBAAMBAAICAgMBAQEAAAAAAQIDEQQSIRMxBRQiQVEyYRX/2gAMAwEAAhEDEQA/APz+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABKTfhAQDLHHtn/LBszw6Xlz8VSf8A2A0wdKPQs6Xiif8Agzw9NdQn/wACf+AOMD0MPSPUZ/8ABn/g26vQ/UJ+apf4A8mSot+Ee7x/p5mTa3CX+D0PTvplOTX3Iv8AwB8mjRZLxFmeHTsmfiuX+D75g/S/HWu+H/g9FifTbBgluv8A8Ej8zx6LmS8Uy/wZF0DOf/Bl/g/VNP0+wI/8Nf4NuHoPp6/4aIH5Pj6bz5eKJ/4Lf/jHUf8A6J/4P1tD0R0+K/8AaiZV6N6el/7UQPyKvS3UX/wJ/wCCf/xXqP8A/wA8/wDB+ul6P6ev+FEl+ken6/8AaiB+Q/8A8W6j/wDRP/BD9MdQX/An/g/Xf/4f09v/ANqJEvRnTn/wkB+QX6dz1/wZf4McuhZsfNMv8H67n6G6c/8Ahr/BrWegenS/4a/wB+SZdJyo+apf4MMsG+HmDP1fd9OenSX/ALa/wcfM+meFJPtr/wDBI/MUqpx8xZRpo+8dS+mFa24Qf+DyWd9OMiDfZB/4A+aA9lb6Dz4viuX+DTt9GdRh/wAGf+CB5kHbs9MdQh/wJ/4NeXQc+Pmif+AOYDdn0rLh5pl/gwTxbofzQaAwglxa8ogAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWUJS8RYFQbEMK+zxB/4Oliem8zKa1XLn9AcVJvwZI0WT8RbPovR/pxkZLi7Itb/AEe+6V9LaoxTnFP/ALE8HwKPT8ifiuX+DYq6JmWviqX+D9O4n03w4Jbqj/g61PoPBr1/ow/wB+XsX0hnXyW63/g9b0j6b23drti/8H6Cp9IYdetVR/wdGjoNFOtQX+APkfTfpfjx05R5/sepxPp5iVRX+mv8H0OvCrr1pIzqEYr2HR4ir0TiR/4S/wAG7X6RxI/8KP8Ag9Z2r4GkRxDzkPTGIv8AhL/Bmj6dxV/w1/g7o/7Dh1x49Cxo+K0Z4dLph4gjpIBDVjiQj4iXVaj4Rm4I4HBRLT8FhwBw4jbDbGxsnieI2ySNjuHDiQO4bHDgBsbQk4cRrfsVdUX5Rk4BKWtPCqn5ijWn0bHm+YL/AAdJEkDjP09iv/hr/Bis9M4sl/7a/wAHe2T3EcOvK2eksSX/AAo/4NSz0ViS3/pL/B7Xa+BpfBHDr51k/TzCtT/01/g831P6W4003GH/AIPtHYtmOyqElpxRYfmPq30ynT3OuL/weOzfRebRJpVv/B+v7+mUXb3Bf4Odd6Ww7nzVH/AH49u9PZtXmqX+DUn0zKh5ql/g/YNnofAn5ph/g5uV9OcG1PVMf8AfkqWNbHzB/wCDG4SXlM/S/UPpXjzTcIJf9jxfWPpdOmMnWvH6A+NA9T1H0dmYsnquXH6OHd0vJpb7q5f4IGkC8qZxfMWU1oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFowlJ6SYFRps6vT+g5edNKFcuf0e66N9MsvJ7ZW1PTHB8zjVOb0otm9i9Hy8mSUapc/o+9dM+ktEYxdlXJ6zp/07wsXT+yuCR8H6P8ATvMze1yg0n8o9z0z6TcRdkU/+x9nwvT1GNFKMEtHWqw4VrhAfLcP6Z4dKXdTFv8Asehw/Q2HQk1VFf8AY9t9uK9i6S1wOjh4vQaMdJRhFHUqxa61wkZnF+wSYDtUfYJpluPcpJfBAukR3aJiHoihvaK9r35LJkN8le8Fl4BGyrkT84nixJic9FXaUu6RMxZmyGzXd6+SjyF8md9EWmtsuRVyNV5K+TG8lfJT+zFvxt1zI7zReUvkr/E/spfZItNTf7yO80P4pfI/iSv96H4m/wB5HcaH8Uvkj+KQ/vQ/E6PcT3HO/il8lllL5H96J/E6HcO40P4tfI/il8kz2Souqt9SLJmgslfJkjkL5LT0xX8dbqLI1Fevkur18mmPoit11sDRhVpdTNpulVuC5OynciO4t84j4rOemO7fsE0OCZlA2vgdxGieEXEOeiU+4huPwWTQopKqMvKNTI6ZTempRRuSTb4YjGSMsujy+Z6Qw8jbdUf8Hn8v6eYN6eqIb/sfSm9cMhRj8E4X/qHw3qn0mrmpOqEV/wBjwPWvppl4alKEW0vhH6unTGcdaOXm9EpyotSgnsuPxfmdCy8WbUqpcfo506LIPUoNH65z/p9hZTbdS5PL9R+k2JOMnClbHB+a9NexB9e6x9K76VJ01+DwPVPSub0+bU6npfocHnwZJ02VvUotGMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZK6Z2ySjFs9J0f0fm9RlHVUtP30B5hJvwjbxenX5U1GEG9/o+t9K+k9lijKyL/we46N9NcfDnFyrTa/RPB8f6N9PsvN7XOqST/R7rpv0mhuLnBn2bp3QcfHgkoJa/R14Y9cFwkB896L6Bx8Ht/0lx+j2eH0mrHikopaOoopeEW0gKQpjFcJF1FL2JBAAAgCCSGIlOyNkAsJIYCBxK2SyrkYZ2NEUZXJIrKyKNOy9mtK+XyY536TI3pZEfkxyyV8mg7JGOVjPOz22VvMY3J5L+TBLKfyasptmNts5M99aY4NiWTJvyU/iJfJgexycuXpraa2b70n7kOyXyY9juRjfTWk1rOcvkj7jKtldmeW+1ea2TvYc2Y9kNlfy5J/HF/uMn7jMWyNsflp+OM33H8j7r+TBtkbY/LT8cZ/uv5H3n8mDbBM3WF1xsffl8llkSXuajbIcmaT1VT8TfWVL5Mkcp78nL72SrGjbH1VW6nZjlP5Mscr9nEVzMivfyb4+tW6Xdjk79zLG9M4Ecl/JljlP5Np7FLod+NiZdSONDM0vJsQzE/c6sPT1zZar10tg045KfuZY2p+514eiKXXWxpErgxqaZZPZ047JVLitsJshkJ6NPqq8ZNbRAUgVonYIJI6Gl8GOdcZPWjIQ/wCYno0sjp1d0WnFHlereicXPUu6tc/o9z7FWiej4b1f6S0TUpV1vZ89639OMnD7nXVLj9H6xlXCa5SOZm9Ex8qL3BcgfirN6NlYc2p1yWv0c9xcXyj9X9b+nOLm9zUFt/o+d9a+k86+6VUX/wBkOD4mD1fVvRmb09v/AEpaX6PM20WUycZxaZAxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANjHxLciajCLez1vRvQmbnuMnW9P9AeQpxrb5KMIN/9j1HRvROZ1GS/CST+UfV/Tf00hS4ytqTf7R9Q6V6Yx8OuOqorX6JHyD0/9LeycJWw3/2Pq/RfStGBTFKtcfo9PTh11pJRRsqCSHRp0Y0K0koI2ftR+DI+CN7I6IjFInRG9DZInwNkN7CQSe5IeiCBIIAEggjZTK8FgV7h3ETNKw4K9xDkX+QmSMM4bL9xVsplmNadOzDLHN4OOzDLLqY5kqtexrWRaOxKpMwTxtnJnrbY5OS0yVF/BvyxSv2NHBt1tsa0XEq0bVlfJglE4NmFdGNYWVMkkVOe4NoqQWZUrfpcI2SQyPkdQTsqQPkdWI2QyB8jq2yNlQyLenUtkMjZGygknRXZOy0tOCJI2VbLfOnE9xeMzC2SpFptp8WbvaZeN7Rg7uA3wdGO+yKXT1uwyn8m3Vl/s4rk0y8LmjbH1WM8tL0NeSvk2YXp+55yGS17m1Vl69zs1exz5aXoIzTLb2cmvM/Zt15Kl7npavV1z5arG4kWMULU0ZEztw2fJjlOJJIJNFElWn3EkrQBPgaTD/RCZIntI1pk9wfJFEOCbMN2LXZFpxTM3glvgr8h5PrPpajPrkvtx5/R8t6/9KnZKU6or/B99ik/JSzHhNcxTLSj8edZ9A5uA5NQbS+EeSyMK/Gm4zhJa/R+1uodAxsyElKqL3+j5r6m+mleUpSqqSf6RI/NQPoHWfpzm4blKNb0jxuZ0zIw5uNkGtfojg0QGtAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADPRi25ElGEWz1vQvRGXnzi5VvT/QHlMbBuyZKMINnq+j+hM7NcZOqWmfXvTX02x6a4StpTl/Y+j9M9M4+JFJVpJEj5b6X+msanGV1O3+0fVOmemsbEqSVUVr9Hcpxa6lqMdGfRA1asOurxFG0opIEgQNk6IIEMJEkEISCNjaJ6n7ToghyMcrUjPLZxaSsmuSG9Gu70jFLI/Zhlv4vMK2nYkR91Gg7yrv/ZjfUvNbfd6RR5COfK4p979mOfqWmp0v4hD+IRzfvEfeMv7dW/E6f8SiP4lHN+9+yHcT/cqPxup/EIfeTOX98sr/ANk/2uo/G6isRPejmLI/ZZZPPktN6Lg6KlsstM0Y3oyxvRpNsrOytiUEzDKrZdWJlu5MtccciZWNOdBgso0dJrZinDZz7NGLbHZXInUzC62dOyo1Z16PP2apHVjsajg0iutGeaMLRwbMPttjl1VvRXuJ0R2mNx40iNkBklKvyIILFWR1HENkbDIFyJDZAZGysyW4nROiuxsvKjidlWyWmVaHUI0SkNEor0Rp78k+CrlyRsfJbtWZUkaLSoqYtllNop4IbNcdlitxlbML2n5NunKa9zlpmWE9HRj6copdUru1Zmmjery00jzcLtG1Xk+OTv0e3KOXboj0ULVIyp7ONTlL5N2vIT9z1NXq+X7ceWrjdKtPZWE0zId+OyVhZYhIsAaS9IhkpkNBErJfkAkr8VOo0T7EkEJNIw2URs3tIy7JLSjj5nQ8bJg1KuL3+j5z6m+nFOWpyqpW38I+ulJVxlw0T1W2vyR136cdQxJylXS+1HiszpeThycba5LX6P2xn9Goyk04LTPA+pfp3h5lc5V0ruJ4mPyu1ryD3/qD6fZ2FbN10ycf0jxWV0+/Em42waa+UV4lqgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlRcnpLZ1OndDys6yKjXLT/AEBzYVTseops7/SfS2Zn2R1VLTfwfQvS303dsoTui/8Auj7D0X0dj4UYr7a4/RPB859J/TaEVGd1XJ9X6V6XxcOuKjWto72PhV0QSjFIzKPb4Aw04sakkkbS4CBW0Nk7KklYJIJILhskqTsX6SEMhy0Y5WIyyzkOLSeijs0Yp2mvO39nPnvkbY6+tid2vc1p3fswTtbMTns49nobTWyytbKObMblwV2cGz0NJgu5Fe4q2Ucjky9FXmDJsq2QpEN8lPz2rzBOxsjZGyPy1PwTsbK7GyPy1HwTsbI2Rsmb6fBbuJ72Y9jZeeio/Gyq1mSN7NYbNsfQi6o34Xv5M8b/ANnLjPRkVp0Y+ljlqdaNy0W70zlK5ozQv/ZtN3WVx43pJM17KtiN2/cv3pkXlTLY1LKePBq2V6OnJJo17K9o492v7dGGbmtaBmsr0YHwcmettjmq0PYsVZyZzjaXqsmY3LRdmKZz5ZcaRDmO8xSloxOeilzXxjZ7x3Gr9wsrCJm0+DY2TswKz9lu/g0maPgy95HcYlIsmW+SvwX2iO4gDqPia2NE7Q2R8kfEJ2V2RsmZI4lsqNjZeZI4Du0Q2QXmRxfvZkjY0YC/sWm34q3HrcryGvc3KcrT8nG7tF42tHZp9XGOenr01OWteTdryFJeTyteS17nQx8vjyepq9bk2aXoYz2ZEcqnKT9zeruTXk9LT6JXHnhxnZUKSYO/HKWMftYkqSSmJBAI4sAAjgnYIBHRSak3wRKmM46ki7lotraLSocPO6JRlqSnBPf6Pl/rD6dUXxnOmv8AL9H2ppe5htxKr4/kkyej8Z9a9H5mBbJqqXav0eZtospk1OLR+0Orek8XOrlF1x5/R8j9W/TCMFOyiP8AhE8HwcHb6r6dyun2yUqpaX6ONKEovTWioqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEqLk9JbAg2MfDtyZqMIN7Or0b05k9Stiowev7H2j0d9OK1GE7qk3+0TwfPfTHoLIzbYTsg9P5R9s9O+hsfFhDupjtfo9h0z07i4Vce2tLR2q64w4igNDD6PRjRXbFLR0owSXCLNbQS0R0NgkgrRA0SBBBIGy3EAI2Q2RbxaRLZVyKSmYZ2aObbu4vMerWWa9zVnb+yllu/c15PZ5uz0NJgyTt2zG57KEHDn6La6MZyJb2VAOfLba0iNgPwUMMsrV4szG0WBncerRCRD8liomKemhoAn4p6hkMsQytxOqkEkFeANkMhgTsNlSdlvksbHcxsgtNnGeU6yRlwWUzFsdxthuZXBsxsM0LTSUi6kdWG5H42+rNmTW0aNU9SNj7qZr2ZK3HiLYJo0LYNPwdFy2YbIJmOeMXxc7eiDLZVyYmtHDtxb40ZimjIQzhzxdGNadiZqz2dCcTWsic2U42xau2O8vJGGRVtGRWE/d/Zr7I2WlX+LaVxkVppxZfuLTJFwbf3V8kq1Gi5lo2Fuq/BufcJUzT7+S8bCOq3BtKROzArEX+4ieq/Bk2Rsr3bCLTJW4p2SgCfkr8UjZTZOytvTnFmULbGy+OVhzopaM9dzia7RKejow32M8tfXSpyde50qMtccnnFP9meq1p+T0dHr449mjr1tWQpLybUZJnnca/WuTqU5C+T2NHr64s9HHRJNeFyZmUz1MNsrnuPFgR3EdxtPtTqwIAPksQQSVsT1DjsnwiQVFXHY1pFgTKK+fJrZOHVfFxlBPZuaISLSjwXqH0Ri59U2qoptfB8O9WfTy/CnKdVba/SP1VZHa0c7O6Pj5tTjZWnv5RPR+IMrBuxbHGcGtfo1T9Meqvplj5CnZTTFPzwj4h6g9JZXS75/g+1P4HB5YFpQlB6aaKkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAa2dLpvSMjPujGFcntgamPi2ZM1GEW2z6H6U9AX58oTtrfb/AGPW+ivp3GUK7b6uf2j7P0f0/Rg1RUYJa/RKHmfTfoXGwa4v7S3/AGPd4uFViwSjFIzxrUNKKMmiCK+eESlolLQ2EjYTGkx4AnZA2NkcANjZDJkEkBBvRW5cIpJ6MUrNC2ejTst8nJt3NcYyzuNWy3ZjlY2yr5PM27eujHFEp7ZCZDiR4ODPK1rMVmQCDnvVviEbDKtlaniWyo2SQtxAALRPAqTsgjKyJ4AAr8gIZJDJ6IZUsypWrcQyCWQUtOI0C2irM7kniARskjpxDY2SypaVPEplkyhOzWZ0ZO/RaNv7ML8Eb0dOG3kZZY9b0LDJ3Jo0Yz0ZFaTdvVfizSSZqzXJd2/sxyezDPLq+LEyCZFTlzbY1VrZilDZnZV6OfLFtMmnOs1pw0dGaNayJlcW+OTRcSujPOJikuCrfFTYciCA14hsKTJ0GiyOLKXBPfox7IbCPiyq0urTW2SpBW4tyFnJmViOerNFlb+yeq3Fv/cRPeaUbTJGwdU+LZ2SYVMv3ItKpcFtkpmPuCZZExZkysnyVUg3spacSmXjLTKInZfDZYpcZW5Vfr3N6jL/AC8nFUjLC1x9z0NPosrHZqlj09WSnrk3q7k15PLU5LXudKjK8cnr6fZ152eh3oy2XS2c6rI37m5CzZ7Ojf1x56+MwITLI7ZeuewAJBIAElauaABHAIb0yWRxIkOGQ0RyiyeyRgtqhbFxktnk+v8Ao3E6nXLdS2/0ez7UQ0mO8H5g9YfTWzDc7aK3pHyvMwLsO1wsi1r9H7e6n0mrOqlGUU0z5L6v+mlV6nZTX+X6Rb9j84g9H130vldKukpVy0v0edlFxemtMqIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALQhKctRW2ZcfGsyJqMIt7PonpP0HdnWQnZDj+wHC9OekMnql0d1vtf6PuPpL6eVYcITnWt/2PT+mfSVOBRDda4Xwe0qojVFJJEjSwOn04lajGKWjoJaHYt7J0RUcRsnY0NaIiR7K8ltE6LCvgb2S1sdukQIAZGx0SCGyvcVyy5BMno17LtFrZ8GlZJtnHns6vIWXbNeUtlu3ZKrOLZ2tcbxh1yWSM6pRdUo5ctOVazORqtFXE3HSijq0V/rVpNkavaGjYdZRwM8tFi0zjA0VaM7gUlAwy1WLzKMWgW0yGjDLGxaVUglkaKrIAY9imfUgIGyslEkMAvyiGVLtFGVq0QyCG9FHJmOWS0i7kY3Io5mN2HPc/tpMGXuLKRrfcJVhM2xP42zsNmBWk/cNJuit11kbGzGpkqSLflilwrImGyu0Nk/lR8EpltsoidkzYrcEtss3wV2V2T8+o+KWQNgi/a8iGY2y7KtFLivFdbMc4GYPkzuLXG8aNkDWnE6FkVo1rI8GdxdOGbSaKmSaMfuU46McupKykSVkiYvFXIbI0WSLcSEEkEK1DBKWw1oKiloyRmYfcshxXjYUyVca7kyu2OI43FZsyKRoqxoyRtZPeIuLc2O4wRs2W7tlbWdwZ1IORhUidsSqXFlTLb4MSbLb4NflyK8ZYWaZuVZGvc58UjIuDXTvsrPPX13sfJ3rk6lF+9cnlabnFnToynwe95fVHBt0vSQltGVM5VOS2kb1Vvce7p9Eyjz89djZDZCe0GdkvXPbxMSxRMnYOrArsbHEpfgrHjyWD5ItEdyY0QolvYSiHsqt7L7GtiwQ/HBr2Y8botTWzZS0ToQeB9U+icfqlcmq1vR8F9XegL+m2SnVW3H+x+tpQUlycDrvQKeo0Si4J7XwXlH4muonRNxmmmjEfZPW305nRKd1EN8+yPk2bgXYVrhZFrRFg1AAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEtsAdDpvS7s++MIRb2zZ6N0LI6lfGMK2038H3T0T6AjRGuy6pb88okcP0h9O3Lsstr/fKPs/RfTtOBVFKCWv0dDC6bXixjGMUtHVSSQEQiopJFysfJYgAAAIJIAkEACSGCGwIZCIbCZAlmOT0WbMc+UUznYmMU5bMDjtmx2hQOa62nWGNRk+0Z4wLdpW6jrVUOTJGBl7CyiRNR1j+2VdRsaDReakfJqOoo6Td7dlXArfP1aZtJ0mOVRvuBSUDnz8rSZudKowygdGVezDOng4dnm42x2Oe0NGxOoxOGjiz08azNiaHsS0Qc2eNaTLqGQS2VbKfpZJJTZI+SUtlGWKsplepijRjkuDKyrW0ZZRaNSW9mKWzclWYZwObLFtMms2yO4vKOjEzOxpKupj7hibK7KrNhWllaaux3Fpki4tyNpfv/ZpKei33S8yR8G4pllI01Z+yysLzJS4NvuGzWVhlU+C0yU+DKCncTs0mR8RkBslC5J4qyNlpFCtorLkwTjwbLRjlHgpWmNaE4mvJaN+cDVsiZ10YVhIZLWgirolU0Rssyhfq6dkpbIijNCJCtY9dpVtmz9ru8BYrJkZ3Jq8/BO3o2/4Uq8YvMVPm1NvZb2Mzo0Y5RZNwJkxMlS5Eosr4K3FaZMqmZIzNdS0HMpcUttSMiZpKwyRtI4i49biZOzWVpeNm2Sp8GdMnuMfcNifStxZoWaZuVXa0c5Myxnr3O3Ts4w2YO9RkcLk6mPfvXJ5aq/XudLGyfHJ7Xm9Eedt1PTQt2vJlT2cqjI3rk36rEz3NPonHnbNTYSJKqWyyZ2Y5fJz84MAgsnqSSu+SxWxPQAESAACwlAgkAQ0n5JKyWyBy+odJpyq5d0U9nxv1z9Ov4jvux6+f0j7w47jo08vEhbW1KKZaD8R9W6JkdMvlCyDWn8HKP1D609CVdQostqqXd+kfn7r/AKbyulZMlKqSjv4Fg8+A009MEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWrrlZJRitsCIxcnpI9P6c9K5HVMiH+m3Fv4N/0p6Pu6lkQlOt9u/g/QnpP0dR0+mH+mtpfAHI9HehasGMJTqW/wCx9OxMOGPBKK1oy0Y0KopJJGdcDojSIbLMaI6IiWI0SAAI2SJfgqS2QSAAAEMkqyBVhEMju0QJZXyN7JiuSBDiSkWaCiOJ6lIErgEfE6IkAfE6AkE8h1CILMqXnEfI0VcS6BFxlTMmHs5IlWZtBmGzTKvM2lOkwTp/R0nExTr2ebt0NJscmdWjDKOmdOdLNOyppnn7dHHRqzarRVozuDKOOjhz12OmZMWgWfBVs5cpYt1BBIKRZUjRYjZfn0lVoxTWzNoq0ZXBMrUnAwSgb0omNwMcsW2OTQlHTKNGzbW9mJwaMMo2xYmQWa0V2ZNJBsrsNkbLSr/FZSLKRRDZb5IuLJ3syK012yu2WmSlwbqtMis2aKnoyRtSLTJX4NzuLRkaiuReFqZaZKXFsORBi70Spk9U4ylW9kd2yNPZXq0UlHZrWwNySNexEVrjWhNaKIzWQZiaaZVtKq0V9y5Ul0T9CMsZGEb0Srk3qZrZtwcWcmux7NqvIS8mmLnzjodqaKyrXwVqvjI2Y6kdGMc9vGo6d+xiljfo6nYiPtov8VfnxyJYr+DXnjtHdda+DDZQn7FbgtNjgSqaKdjOxPF37GtZiy9jK4Nsdjn+B3GzPHkjBKqSKXFrMhSZkjPTMPgOW1wV4t2Vtq0vGzZoptGSNmhYjjeUi3ca0bUZVLZT5WKZY9Z4y0bVV+jTUuCVLk7NO+xy7NTuY+VyuTq0ZO/c8tVa0zpY+Slrk9bT6XFs0PUU29yM6kcjDyoteTpVz7vB73m3dxeXu18rY2RsIHoY5dc9hssV1ySWqqQAV4mUJIJJWCSCSAIbJIZUQ3tFfPDLaJ0hKNa/GjbBx15PCerfRNHUsWb+0nPT1wfQ9PZWytWRaaL9H429U+jsnpORN/baj/Y8fKDhJprTP2T6o9K4/U8afdWnJp64Pzn6x9F39NyJzrrfbv4IHgAXsrlXJxktNFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAF6qpWzUYrYCuuVslGK2z3no70fdn5MJTrfb/Yy+i/RlufkwnZW+39o/RPpv0vj9PohqtJpEjH6X9LY+Djw/00ml8HsYVRqilFaJrrjXHSXBbuTZFBeCQCokEDZPBIIBIEAACACYAAAEMkggVkYn5MzRikiBCZkizDvRZSIozbJRjUiyZHRcjRILCUAAAAK9EMBjRHVbBEkEl5RA0SNFkmikkZCrRjlh1PWCUTBZVs3HErKHBy7NHWuGfHMnUYJwOnOs151nn7fM6cdjmTjoxa5N6yr9GtOGjzdujjbHNjI0W0QcmWvjWZKtEaLEMrxp1BUArYKsq0ZCNGeWK8rXnHbME4G64mKcTnzwa45NCcDDJG7OBryic9xdGOTBogySWihRrKgjYZBK8Nk7KkknBkbIZGwrYumXjPRi2Q2TKrcWwrC8bDUTZZTLdU+DejMupmjGwyK3knqPi25S2YZPZX7m/cju2SnHHjHNGvNG1I15ohriwNlNlpeShLefpYNEJkthNiv8o7uSGyNF8ayyxbdFumjq0XJrycFPtZtU5DWuTfHJzZ4O/FpobNCrK3xs24y2azJy542MnkjRKJLKfbE4GOVezZ4KtcleLTKtSdG/Y1rMX9HU0UlFMrcWuOxwbMbXsa1lTitpHetp2a0sXu40U+DTHY4n5FkdG3DUVwjTsqafgrli2maqloyK3XuYO1k8mVxW71uRtM0Z7ObGembFdn7Ik5VbHQgzZrlo50Lf2bELNnVhs4xyxdjFv7Xwzs4uS+OTzFNuvc6eNkJNcnteX08jyt+r7emrt7kZU9nNxr00uTfhNNeT29G7rgzw4zIkopclzuxy65rBEhEMsQbBUlBdJJAIQsCpKI4GiQCOAACRjnCNi0zyvqT01T1HGmnWm9HqZNxfBL1KGmTB+S/Wvouzp987K63rb9j53ZXKuTjJaaP2X6k9O1dUpnF1p8H529aei7enZFk4Qfan7Ing+dAvZXKubjJaaKEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAF6qpWzUYrewFVUrZqMVtn0X0R6Nnn3xnZXxv4L+h/RdnULYWWVvt37o/Qnp30vT0+mGoJaXwBf036ax+n48NVpPXwephWoLgrHVaUUjLvaI6IbWikY/lsKD2TJ9qLJWBCe0SRxAACQAAAgAigCCRAABIEe5I9yBDMc0ZvYw2EDXkyFLkTMWyKNhTMsZGrGRljIiDYTLpmKLLpl4LgIDgAArYABBMxOJBBJPDgNgghPEklSUTEGiGWDHJTvGGUdmOVZsaDiZZ65Ytjk0J0mrbUdScDXnXs8zfpb4ZuXKowyjo6dlZqWQPJ3arHVhk02iplkjGcOWNjolV0NFmQU4uqQSyrIsElJIug0Z5RaVrzgYJVm7KJjlAwyxa45OfZXwa7idK2HBqSgYZYujDJrNEGSa0YmU42lSQNkhZVkFmVCQAbJODKtktlWDidkqXJUEq2MqmXjM19l4ssfFmcjFNk9xSTJTIxSKMmT5K7LcawIZKDRC8UbJTDiRrRKLEsReiAiesssGzVY00dOm/aXJxk9GxRa9+TTHJzbMHdhPaMm+DTos2lybKe0bY1zZY8W2PJBJrGdiGQSQTxB27IlBRWyyYk+5aK2RaVq2LuXg1J46ZvygUaM+NccnKsx0jUsXade/Wmcq9csj4Nscms/JKnohlWV+C3yjPC3k2qrTnJ8maueivLFblHUjbo2qchpnKjZ+zPC3TNtWyyubZh16bEyfHJ2qLu5Lk8dj5OmuTt4eX45Pd8u5527B6KDM6ZoUXqWjcUj3NWcsefniyAhEnTGcVJQ1ySStQAghASvJUmPkkXBAIEggAGY2my0kyV4JFPtprlHlfUvpujqdE06020/Y9VvUiZwVkGmh0fkf1r6Os6dlWTrg+3fwfPrK5VycZLTR+zPUnpajqWNNOtNtfB+c/Wvo23puTZKEH27+APnoLTg4ScWtMqQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABaEHZJRS5AmuuVs1GK22fRPRnou3qFtc51vT+UV9FejbOo3wnOt9vnwfon016ao6djwSgk0Bb0x6Zp6ZjQSglpHq46hqKREUoRSRaKT5JFtJjRIKiCGtliACXAAJQgAEiGAAAAABglgQyESyEBIAAESWyQwNeyKNWxaNyaNW1cFalhTLxk/kxMdxkltwmzNGZoxmZo2CVLeUlonZrRnwZYy2XlRWVAqmTsvFalkBAlAQSAlBYqWISAAJNgEkFCCSrJkVQ1srKKLElM9cqZWrOCNWys6MomGdezz92iV0YZuRZWa04NM69lRq208M8vbo46sM3PZVmRwe2Ro87PHjqmUY9MjRkeirOfI71UnZD8kGVWkGVZLIY4vGOS4MM4o2HyY5RKZYtca0rIo15I3pwNadZhlHRjk12R7l5RKGLaUIZJDYWVZCLMr4JTEsqNglKGQASngNkbIJOLbZG2RsgHEPyRosQSuqCxBJ1G9EN7JZUk6BAJEo+UW3wTW9Pgr2tmWup7EjDZY3KJy45OhU3o0qK2b9cdI3xlcuVZohheCfJvjHPkqCzKsniqARsbKXq8NFJou5FG9lZKt1p3RbNC2lvZ13HZjlSmnwa4xFyeZsfbNohSOhkYb720jn3UzgX+PWeWyr9yKu1I1HKaZaMt+R+PrG7a267tm1XPZz4vXg2K56MstV79OjDbPj9uhC3t9zpYmXprk4Pe/kz02ST8mmq5Y1ls5k9pi5m9LZ2Kbt65PEYmS1NbZ6PEy09cnu+X0f9cGzW9BGW0ZFI0qrU0jZgz2MNsyjkyx4yNhDySbRn0GgCxw0AABJACUgAgACQI0gSQRRWcVKDTPGepvS1PU8ealBNtHs23siytTjpotB+Q/Wfoy7pmVZKut9v6R4KcHCTjJaaP2P6o9L4/VMef4Jy0z83+s/SVvSsubjW1HfwB4YEyi4yaa5IIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlt6AlJyekez9Iel7ep5UHKD7d/Bz/Tfp67qeVDUG1v4P0f6L9JQwceuTgk9L2A6fpL0zV0/Fr/AAW0vg9pCuMFpIiiqNUEkWk37DoNbJi9cEx8Ea/LYFxsjZGwJ2NkbI2TwW2QAEBAAAEIkAAABLIJYEMhEshASSQT7AQASgMcka10eDbkjBauCKNCSMb4NmcTWmuTKrIUtGSMzDssmQs24zM8JnPU9GaFhMRXQjIvs1IWGeMtl5VLGQkqiSeiQCSeiCQAkAASEkEgGVLFWSqgkgEgVaLAyzw6tKwzga1le0brWzHKJx7dPY2xy45U6PPBq2V6OzOtM1baf0eTt81b47XJkmipt2U6NaUdHnbdNjqwy6xsFtEaOPLHjoirIZbRDK9WV9w0SQyt+0sU0a84mzIwzRjlGmNak4mvJcm7KBryhyY3F0Y5MDKtmSUTG0RxrKjZAA4vEMAglcIZJVkiNjZAJDY2QAJ2RsAlIRsnRGgrajZDZOiyhsvIyuTEttmaEGzLXj79jbqxi0ilza8KdtcG7XjrS4MsKNGxGKSNMcWOefVK6tGdRSIXBbZtOMbRkJ6IbKyemaSxSxdso2R3FdkWpmKWyrYbI2U6v8UjQ2O4m8R8ah8FHImUjG2R8lLjUuEZeTFZhQmvBZT0y/3Xo1wyY5Y1yMjp0VvSOZbizi/xR6aT7vIjhws8nVjJWGWNeWrrsX8yJcpRPS39Nil+KOZkYLjvg0muVjc7Lxo12bfJuVSRoWQdci1Vz2Uy0tMdrrRs7eUdLCzJbXJw4T2jax59rXJTG3GmWcr2uJlbS5OtRZ3aPH4eVrXJ6PCyFLXJ6/l23/bj2cdheCSkJpx8l/J7eOXY55PsBILLcQSNEA4kAgITsbIGwLBBeAQJABFFZLjZSDk97LN8kpoSjFbUpR1ryeI9Yekauq402oLu18HvHyY7IqcGmi3R+NfVvpa/pGVP/Tajv4PINNPTP1r659IQ6pjTlGC3r4PzX6k9P3dJzJxlBqKfwB54AEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdroXRrepZdcYxbTa9jV6V02zqGVCuEW9s+++gPRKxoQtsr58+AOv6K9H14VVcpVLf9j6li40aK0kimHiwpqSUUtG2RUASBISrJ8GOU9GR+DBb/KBKt2X7jUjLRljMkZXJhSIWmSOi2yd7KEpkoWIJAEIkgnYAAAAAAAAAkglAAAAaMcobRkIZFGlbDRpWcM6dsdo590dMpVo19juKSfITKVaMmy0Z6MGye4jqW5C3RsQuObGRljYWlVsdOFu0ZFPZoVWGxCwnqONtE+DFGZfeyeoSnySVGywsRsgkkCQCKAAIlEaCRIL9VQ0NEgCNFXAuQ/BT49T1icDDOGzYZVx2Z56JYvjk511Ro21aZ2p17RqWUb9jy9/mdmvY5LhoxyejdupaZp2QaPF3aLHZjn1XyGivglnnZ42NZkrvkMgjZGKejRjlAybKsixeVicDBKvk2mHDgzuLTHJz5VGGVejpSga9lZT4tsc2i4lGjPODRj7StjbHJj0Q0ZGirKtfkxsqZGtlXHRKeq6I0SQyUqtkbLFdEiyZIWtDYWWUdl1TspGRljMmM8otHGT9zNDGWykbDLG1GkY5Ss9dKRnSSNZXIn76Lxjca2+5E7RovIQ/ikT8lfg3e5Ed6NJ5BX+IJ+Z8G/3lZTW/Jo/xJSWTz5HzTNbf7v2Q5o0P4kh5JFzWmtvOxFXajQeSVeQRM15rdD7pH3P2c7+IH8SWua/4nQ7/ANkd6Of/ABI/iTP5IulvJrZfaOesgssj9muGbLLQ3toyQs7Tm/xKJWSjrw2Mb53brtU1yYLoRs44NGvLSXkt/FrZ169kcG3z3rDldLU4to4l+PPHn/K+D1lGVCx9r0Zb+mwyK20kdePMo4s8bi8ZDKcY6aM9OXto2OodInS3Jb0jh2TlTL3KZaXNlsseqxb1tfkd/CzFHX5Hz7GznvydjFzZJr8jTVj8ar8+vpGNk96WmdCue0eS6VnL8ds9HTep6aPV1bU9dBcgxxltE7OqZo6uyik9l0Q1o0lOgAJAaAIDZKZUlAW2SVLIrRVoqoaZkBAhLgaJBIwZFMba3Frez5N9Q/RsM3HnZXWu7l+D6+/Bz87BjlVyUkmmi0o/EvWek29Ny51zi1pnLPvv1K9GfhZkVV8/pHwnKxp410oSTWmKMAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADZw8WeXfGuCbbZgrg7JqKW2z6j9PvSMsrJrusr4/aA9J9PfRKj9u+6vnzyj7r03BqxqYqMUtI0+i9Jqw8aEYxS0juRioolCeESRslMggEGEOJGjDZH8TOUktogc+e0Y1bpm1dXwzQsi0yOjcru2Z1PaOVCxpmzC0jo3e4lMwRltF1IvEMyZOzGpE9xItsbK7J2BYkqiQJAAAAACUQSgAAABgEUY5x2jRyIeTotcGtdDaZWrRxZrTETYur0zWlwZ1aJYMfcT3FFl0XUjDsnuHUNmE9GaFppKRdTLyq10YWmxCzZy4WGzC0tEOgpbJ0a0LOTMplohkSJKqRYsg2CAhZ0SACOJAAOHAABHAMAk4q0EixA+SUOKZhnA2DHJGeeHyWmfGlZRv2NG6j9HYcdo1ratnmb/O6dexw516ZjaOjdSak62eLu87rwz61ZFDNKJXtOHLD4ujFQqzI0UZnYuqR3Bk9pSxMqPJSUdmVIrIzsXlas6zXsr0b0kYpQ2Z5NscmjKJjaN2VRhlUUazJraIa4Mrhoq1wS0mTBojRk0VaJaRQaJZUNEMjZfWyGiRTbRPew0VZKLGRWNEq5mFgnqtxbH338h3v5MBVk9V+DM738kfeZhK7HT8ba+8yPvP5NfuGwn8bM7n8lXa/kxEBaa2X7r+SPuP5MY2OLfjXdj+Sv3G/cqyNk8TMF+9/JHeyuyGyVpFu9kfcZRsrsni3wZfuv5J+6zASTziLhGV3MK5/JgbK7Ly1S642XkNNcmVXNryaXkj7jia47OMc/PK6FWROue9ncweqR0oyZ5VW7MtV0oy4Z16/Rx5u/wAj2l06cqppJbZ5jqXSGttIz42dKOm3wdKORDKjrez0NW35PG3ebjwVtcseb2bOLmpNJnouodG+6m4xPN39Mux5t6Onjzs/8XosLqHbrTPVdO6knBbZ8xjdZVw2dvp3UZJLci2GXKpNnX1PGylOJuKSZ43pvUtpbZ6PGylNLk68M1pk6KlolS2zHFqSLpaZ1YVeVYAGy0AQSFglAFUBJAAsgQgBII2TsCJLaKKSX4su3pFHprZHRx+u9Ir6jiyhKKaaPzn9QPRc8O+dtNb7fPCP1H/PFo8x6k9P19SxLFKCbaLQfi+2qVU3GS00UPoHrr0lPpeVKcK2o7+DwEk4vTIEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLb0gdbofS7Oo5kIxi2tgdz0d6as6nmRcoPt8+D9K+kfTsOn4sF2JaXwcT0D6VrxMSucoLevg+nU0xqgkkBMa1CPBfXBICOI0PBJASAACQQSBjsjtGhfV54OizFZDafBWjiT/F8kwtWzNk1NbNB7iyo6tdq7fJmjNM5Nc/2bddnBPyON5Msmays2ZIzLdTxmT0WTMTnsKRPTjMW2YlInZKrJtEmPZbuI6LArsbCVhsgEoWBBIAkD2AhmKa2ZWVa2Vqzn3wObammdi+PDOZfHlmWS0amgmTJmNszSy7Q4MaZPeEsg2Y1MnuLdOM0ZaM8LF8mlsspEynxdKFq+TPGxHKhPnybELf2XlRcXUhMzJnPrtNmFiZbqljYBVNFkWlVkCSGyEyUrEbLexVLTBEgjZOwkIJI0FLQEgrMVuhVokFlKporKGzIGZ7MOrY5caNtW/Y0raf0deUTBOvfscGzzSunHdxxbKWl4Ndwa9jtWVceDTtp/R5Po8nK7dW7sc6RjkbNlT2YXDR5+ejjeZ9YWmW9izIZy542LxBVksqzHi0qNIOKBK8EXFaZViaRjlBMyyRVIpcF5nWrOt/BglWzpSjwYZQ2ytjbHNz3BlJRZ0HSYpVlW+ObQcWUcX8G5KP6MTWvYlrM2DwNl2ufBGh0+ajKPZmcSriJUzJi5HJkSIaLLyqckF9DRaRaKMros0Cf0nkUaIMjRXRHTsgislyXSLduyOo+TFyQZuz9EOBPUzJh5IMrWikvBPVuqNlWw2RsvEyKtkbZYaLReQXgdyD8GNlk8WbICRLRCLFW2/A7V7krgNNgNRQ5XgjsZeKHXPsxlPuTSOh07IcJLbNLXBelNNHXo3WPL9GmV7jDtpuglJ+xhz+l13QbgtnGw73Brk9HiZKmkme1ozub531aePE53RLVJ6hwcv7duNb2ta0fVJ40bo+EeZ6t0b8pTUTtmn668fLuNcfC6h9pruej0/T+r1vX5nhMqidNnhovi5TpkuWOfFM2Pr2LnRsitSN+u1SPnHTOtNNLuPXYPUFZFfkXx22NcdjvJosatdql7mdSOnDb10Y5dX0Rsju2DojWLgLwCFaAACQQEBIAIBra0V7eNFgRwRGOitsFOLTRkBMHz31t6Zh1LCsl2LuSeuD8v+oui3dNzbIyg0t/B+28iiN1bjJbTPj/1I9HV5OPO2utbW3wif2PzODb6hiTxMqdck1pmoQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFoRc5KK8sDLi488i6MIre2fbfpv6Qe422V+eeUeU9CelJ5uRCyde1v4P0h6c6RDCxYJR1pEjq9Mwli0qKWjolVwWItAAEAQGCQA2NkgTsjY2QDI1tBldkDXyKu5HIvpab4PQSXcjSvoTT4K0cPfazJC7XuVyK3GbNOU3FmfV5HWhdv3NiFhxKrzdhfx5JlW46cZbLpmlTdtmwrNlpUWM3cXUjCpE7L9UsZu4nuMHcXTBGVSLKRh2T3AZtlkzB3F1LglDKNmPuJ2ShfY2V2SBOydbKF0xYdYbY7Rzr6/J1praNO6HDMcotHEnHUmYmjZujqTNafBlWkRoNFe4nuIWQ3osmVfIQ6payJjZVMnZPU9SpcmSNhhGy0qW7C7RtV3/s5KnozQt17luqWO1C79mxC1NeTiRyP2ZYZD7vJaVEjtJpjWjVpuWuWXlkRXuX6zyvGfuCezXhdGT8maLRKszXaIJT2NEtZeiJII2Di2iASV6jiNDRILI4o1ySToCo4q0Vcdl2VZjlFoxTgmjWsqN1rgxyic+en5LzZ8XMsoNSyk7Eq9mvZT+ji2+V0YbnFnW0zH2HTso/Rqzq0zy93m47MNnWo4lXE2JQMUlo87ZqsdONlU0Q+A2VZz3GtJxWQS5JaIKWLcGU1yWbKsrxMQykol2hon4rTJrSr2YnSbjiR2k/FMzaEqeSPtG869lXWVuLWZNJ1FXUbzrI+2V4vMmg6irrN91FHUVt4tM2j9sfbNz7RP2ivzWmxoOshVm66iFUWmfS7Gp9sr9s3/tFXWPkj8jUVZkVfBmUC3aOkya/2ysoGy0YbGXjSZNWa0YJvgz2M15M0xjXGsRBZojRvcG0NkpkaJUSlT1D5I7TNGvZdVFfki5NdQLdmzYVJljQR8mdzaaq2ZoY+zajRr2Nmun9CdqmW3jQeNwU/hnvwduON3exmrwN+x0YarXLs3xwoYjfsZ44TXsegr6dz4NqHT0/Y7tXnrg27pXnIUSi/DOrgqSa8nTj0vb8G5R03t9j2vNp48j0XrLi/yrZbKx43VtaRlVLgiHtM9T4fTx9uDxXV+j8ykkeQy8WdU2tM+t5OPG6DWjyvVekeZKJhng5rOPG4s5VS22z03TOq9sknI81m1uiTWjVx8qULPLMLjwmXH1/p3UVZrlHchapx8ny3pfVHFrcj2WB1JTiuS+GXHRr2PRpcmVI1KL1NeTP3cnTjsdeOXWYgJ8A2lSEEkaJBEgASSRsbK0SNEbJEAADoM5fVcCGZjzhKKe0zqFZLaJg/L31G9GTw7rMiuHDe+EfJbIOubi1yj9nereiV9SwrIuCb0z8serug2dN6lb+DUe5+xNHlgAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB3/TPR7Oo58IqLa2jkYePLJyI1xW9s+8/Tb0i4QrunD/wB7n0b6eqwsOC7Enpex76iCqilowYeJDHpikvCNxLY6GixD4JIAAgmAwyASAAAAAgPJDXJIICJSyK0XDWyBysnH2m9HCyq+2TPW2QUlo5GbippvRlY1jz8W0zYhN/Jjvr7JcGBWNFVnTpt0/Jt13bOLC7T8m1Vfz5J6WO3CWzKmaFNy15NhWlpVLGx7ljCpNrZZTRaVHGQnZRTQ7kSL7JUjGmidk9RxlUi6ZrpllJko42EWRr97LKbJiKzMJmLvZKkWQzN7RhsW0yykHyZWLRy7qeWznXQ1s79sIuJyMutrejKxpHNfDCYkmpckrWjOrxKGyHwUcmQrYy9xKZiTLdxKZiy74Ktle8q2T1bi+yUzGtlyeosZFJmWE9cmBNe5edkIV7LY1nleM0837cfJycvrnZLXcaHUc9R2kzzl+TKyfkv1xbdj2WH19SlzI9LhdQjelpnymm1w5R2um9WsqnzLgt1zzZ9vpsbN+5lT2jzfTurQsa7pHdqyIWR/FlpXVrz62GVK/k3+i5PXRKlElXsLZUWBDkkN7LISyCQSK6J7SQVsFWiriZCNE8iljE4GOUEbGirRXLCVbG8aM6v0a0qOfB1HBGOVaOPboldWGzjkWUfo1LKf0dudS+DXnQmeXu8rpx3OJKvRjcdHXnjx+DXsx0vY4Nnl43w3NBxKNG5KnXsYZVnNfPW/5I1mQjM4FO0xy02LTNBVou0V5MbhYvL1VojRk0NEcq3FEuCGjLrgo1yPjUfPjHoaMqiiZRSIuFT+RgaKuJlaZXtM8sFpmxdpLiXaIMcsVvkxOKIUTK0tFGin6T3qO3gpJGTkhrZPVowhl2kYpPRaNcYpJmvZIyWSNSyTNcW2MY7GYWXk9lWtmuN41xVLKJaMGzPCktlsafJhjXsuq/0bMaTPGpfBjcus8tjWhVx4M8af0ZVBIyxgTjhawz3MCpXwZoUr4M8KW2bNeNJ+x1YaLXNlva0cffsbFWNz4N/HxX7o3qsNfB6Gnx2uTZ6WlTi79jfqxF8G7TipextxoSXg9PV43n7fS0Y4yXsZ4Y6+DbVS2ZFBI7cPNxy5b+sEaEvYyxrSL6B1YYcYZZ9YZwXwYpU7Xg2mkyGtI6Y58/toOrt8mpl40bYNaOrOOzDKtaKZYuXPF896z0V8tRPH5WK6Jvg+xZeNG1aaPL9Y6LXKDcY8nNng5rHiMbIdbXJ6Lp3Umml3Hns7DnjyeloxYmTKE0mznv00wr6v03PU4rk71VikkfM+mdRlFx1I9j0/qUZRSlLkiZ/brwzekT4LJmlVf3LybUXtHZhn9OiVkJITDfBtL1YAQZYAVJIqtSiyKokhMSACEhWb4LFNbfJMGK2pW1NNeT5H9RfR8MrGstrr/Pz4PsG/y0aPVMGGXjTi1vaLD8QdUwLMDLnVOOmmaJ9c+pXpSWPlWXwret+yPks4OE3FoUVABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASlt6IOp0Tps+oZsK4x3tgen9C+n5ZudXNw2tr2P1F6a6bDCwYR7daR4X0D6UWHj1zlDnXwfVaaFXWooUZP0i0SFHRLIBrYCYHAIAJAEEoAAAAAAAAAABwV1tmHIpUoszryTLlFbimZPMZuLpvSOPbBxfg9lk46mnwcLMw9b4MsovK4fc9mSFrTFtTg3wa7lpmVq7qVZOvc3KsnbXJwY26M9d7TJlTx6au5OPkspbONTleOTeryN+5pjVbG+iTDCxMv3luoZUS3yYPuF4y2T1HGTZKZTZOyeoZNjZj2TsmVHGXuJ7jDslSJ6jjMpE9xhUidkJZN9xrZFPdEzRemWm04lLFuvP30uMnwa/a0du6hSZpW4/b7GdieufLgro2J1clHDRTi8rGNEb0y3ekgfJXnZYwSyIxfktC+MvdBW5syeiXIhOL9yWopeQyu1jlY0c/Ny+2t8mfIujFPk85nZm5uKZMrm27mlm5Mp2M1YP5Jmu+WzFZLsRaV52za2Pupe4/iHF8M5csh9xmhbtcl5WMz+3dw+qWVyXJ63pfXP5VKZ85VqXuZ6uoSqfDLyurXs4+043UarYr8+Tb+4pcpnyvpnXZRcU2z2HT+txs0nNclnTjuenjL5L7NSu+ucU1JGxFrXBPHRM+rOKZKSRXZO9haVIIS0SSsAAFCCWQVpwIaJGieimg48FtE+xFnTrXlAxuo2mh2mWWuVaZVoSpMUsffsdFwK/bMM/PKvjnY5U8b9GvZj/o7UqtmGdOzky8rebXDlj/AKMTofwduWP+jG8X9HLn5W2O5xpUv4KOp/B2JY36Mbxv0cuXkrfHfHK+0/gh1v4Op/Dfoq8b9GP9OtfzxzlDgh1HQ/h/0Psfot/UrC7e1zvt6H22zfdAVKKZebi+OxofaKyr0b84JIwTSOXZq43xy60pR0YmbNhryRwZ/TeRj2S0NENnPb1rjEMq2GyrZVpIrJmGci8jBN8l41xnGOyRrT5M8lsp9vbNcV/kwdrZaNb2bMaTNCgvb9HzYIVGxGsyqpIuomcltUuxiUS6TMsa9meGPv2OnVptc+e1rwrb9jZrpb9jbqxd6OhThr4PU0+Vw7N7Toxm2uDp0YvHg2acNL2N6uhI9TV5HDs9DVrxkvY2oUJGeNaRdLR6WrRJHJlttVjWkW1ollWdeOEjmyytPcsU1yX0Wsis6gEkaKrWIIZI0WivFHEpKJm0UkiWeWPWrOvuNLKxYyj4OnopZBSRnlj1z5a3gesdJ74yaieKy8Kyi1/ifZcnEjOOno8l1npEXGTSOXPBlzjx+DkuDSZ6TCzX3R0zy2Vjzx7eEzaws1xa2c1nFsc/t9NwMxSjFNncqsUork+e9P6hrXJ6zBzlOK5LY7HZjk7ey8TBVNTXkzrhHXhk2ixBG9knRKsgEglWwJIBHCJJIBHEpIGwSK6/IS54LFZLjZI8b6z9P19S6fb+Kb7Wflf1V0eXTOo2Q7dLZ+076VdRKLXlHwn6nekXbOzIrh/4A+AAz5WPLHulCS1pmAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABeqt2WKK9z7B9OPTDnZXfOG+fg8B6U6RLqGfBdu1s/Ufo7oVeFg1/hp6QHpelYkcfGiktaR0tlIR7VpGTQFWwuSeAA3ogrJN+Cy8ACAyABKIJRAkEbGwJBGydkgBsAABokCACWfTW0aeTjqa8G6HFSMssWmNeTz8PS4Rw8ipwZ7rLxVZHwefzunNJvRz5Y1tjXnV5Milom2t1zaZXW0U/TSMkLtNcm7Vk+OTjzl2stC5r3L45Iyj09OTv3NuNqZ5mrK17nQpzP2X+cV+LtLkyxWkaFWSmjbhami0y6ixmGyinsnZeKVbY2V2SgLbJ2VGyErk7KKRbZbosmT3FCSLUL8NGvfBMy70YrJopUNJ18mKyvg2ZSRgnYvBSrNGUOWa2Q3CGzp9qbOd1DUa2Rxnllx53MzXCT5MNHVGnyzT6lZ+bObCUvZkOTZvkeur6uvkz/+qKUfJ47vmv6jNXkyXlkOTL0Sutm57e9M41lrnPbZa23vXk12wx2bmZTSRgukpFJN/Jje/ctHJln1hcNSEpaXBebMDenyWiJkt9xloyZRNMN6Lytsc25Vc4eGdHH6pOqafc+DiRs5NiEk0WmS+Oz7e66b6kbcU2exwOrwvjH8kfGq7ZVtNM73TOqzrktzZpLHfhtnH16FkZxWmZFweT6Z1qMoxTkegpy43RWmh10Y7JW6nskxxmZNkNpQENjZK/EkDYQ4JIZIIQgEghHEEgEiGiNFiAso0VcTLojRW4ynaxfb2Ptr4MuidGd1SnyrWlSvgxun9G60Y2il0xP5K1fsfoq6P0bmkQ0it1Yrfkrnyo0Udejdmka1jSMM8cI2xtrXlBGCx9plsuUTQuyUzh254R1a8bS2xGrOwpO7ZhlZs8ffsx/07deFTOZhbEpbK+TyNt7+nVjDZDJ0GYSVfvGNoq0ZNDRbi0ya8kYnDbNtw2V7NEyVb5NZVF1SbCii6ia441FyYI16MnbwZVAvGptm2OrLK8Z5bONdQbMkaWzcrx9vwblWJv2O3X48v+OfL0YtCrHb9jfqxvHBvVYevY3K8bXseno8ljj2eiNKrG/R0aaNexnroSXgzxgketq0ccGzd1SENexlSJ4IO7HCRy5ZWpRJCJLc/wCIiCBoF4jidAgEVaQ2ACOJoT7EE74LK8VbI1slolcCHGKUdGNmxJbMf23slnli1ZxbNHKxVZBpo7DikjWtSfBlnj1zZ4PA9X6Qm20jyV+NKiz38n1fOxPuQlweK6t0xpyaRy567xzWWVyMTJcWls9R07Oa1yeKTdNjT+TqYmeoa5OKy437dGvZP0+l4OZ3JcnXhZ3RPDdL6gpNLZ6rEylJJbOjVtjtwdOPgsjFGaZkTPQwvYv1KDI7id7LoQBoCfYkkhEoAANAQShoIgQ9eDh+oOlV52HZFxTbTO3KLb4InX3waYlH5D+oPp2XTc+Uow0m2zwDWno/U/1H9KLPxp2RhtpfB+Z+q4E8HMnXJa0yaNAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGXHpd1sYJb2zEeu9GdEl1DPhuLa2gPpH009LNfbunD/wfesKhUUxil7HB9LdHrwcKtdqXB6qMEkSLJEkIkgQQySGAAAEMglkACSCQAACAAACUQSgJQCAEAkD5I4gkAEisls1b8ZWR8G4Q/BTKLyvIdS6e47aR5y7urno+jZWPG2LTR5nqPSvMlEwywb45POpqUdsx75L5FU6Za0YEzP48LkzKzRmrye1+TV1sq00Uq+NdunMSXk36cxNeTy6slE2qchpeS+GSMo9VXkJ+5sRsTPOU5f7N+rLXydEzY2Owmi6NGvIT9zYjYvkfNPxZuSOSPuInuRPUcOSdsjZGx0ZE2Tt6KJiUlojopObSNSy1/JktsSNG21fJXozK3aZhnPkw/d+CvfshLP8Ad0ji9UyfwfJ0LZ6ief6nbtNEObdfp5zMu7rXyYYTQyY7m2jAtoh4voy+2zKaZRSZj2yyZVwzL7XcmSuSnciyZbFbPL6S0UcTIT2lmXWs4GKytm72BVdwWlc9QaDizoPH/RjdH6C8yaOtGSE9NGadD+DBKqS9iYtMm13qSWjLXOUHtM58JSi+TMshJcsvK1x2u5i9SnU1+R6PA6+4pJz/APJ8/wD4lb4Zs05bWtMt10Ybn2HA6zXbBblydirIVq3FnxnG6vdTJalwel6b6m7dKc//ACWldeG59GSky6T0cDC65Vcl+f8A5OvVkxsS0y3XVjujZSLGNTJ7g0myVYjTCZYLTJXkkdyJCQAAACGRUcAAREpBALISV0WIKZCrRjk0WnLRrWWaMclpFbbUjQvvS3yRfc+5mhdNvZ5e63rs1xS+/fuaU5tsvPbZRRPK39d2uMT2Q0ZnDRRxPL2Y2uzGxhaCRl7QoGP46t84okT2mRQHaXx02qXNicSO0z9myyqL/wBeo/I1+0hwbNxUv4MkcZv2NcPLVbu456rZmhU2b8cRv2NmrD/R2a/HWWXpkaFeM37G1Vh7fg6VeJpeDZrx0n4O7T4+Xrnz9PY0K8PT8G7Vja9jajUkZYw0epho44stjHCnXsZFWZEtE7OrDVxz5ZVCWkCSDeYsrUgAniYAAcWCACQBBIAAAAAAAAArJ6LENbCKxy20YJLk2nHgwTWmGOca9sO6DOD1LD74S49j0T8GrkUqcXwVs+nLnHybqmJKqyT17nNhc4S1s951vpqkm1E8Rn4rpk3o8/dg58Pqux03N7WuT1/Ts/ulHk+aYd7jNLZ6jpuX2yjycUxsr0dex9Kx7lNI3IvaPOdOzFOC5O5j2qSPT0bZJxt+2xolcIlcjR197F5EbJI1yWEnCgAJQkkqWIAAEAAGQOd1LFhlY04SW9o/MP1M9PvDzZ2xhpOT9j9VOO00z5p9R/TK6jhSnGG2k34LQflFrT0QdPrPTrMDMnXKLWmcwAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8gbOFjSyciMIre2foL6bellTXXdOHLXwfMfQXQXnZsJuO0mj9P+nOmxxMKC7daRI7OPjqqqMV7Gw3pFU2uC2itolElUywgghkkMkAABDIJZAAkgkAAAgAAAlEEoCUAgBBKAKcT0AGy8iLUMn2IZVyaJ51HyQ/Jivx42VvZnS3yS/BW4xaZPI9T6UmpSUTzFuNOuT4Ppl1Ksi015OB1DpcUm0jHOSLy9eLc3HyR9xMz52JKuT1FnP5jLk5cq6MY2HImE9GJc+5ZcFZVrGzG5o2a8lr3Od3Eqevc0mSnHepzP2b1WWn7nl4XNGzVlOL8ky/abj9PURyE/czwtT9zzdebz5N2nMXya/Jnx3FJMttM5sMpfJnWSvkfJHG+taMVskka/wDFr5MNuSmvJHTjHkW+TnzsbZa+7bZrd22OnGaMiykYFJIspcBGX0x5V3bA8x1DJ3JrZ28+xKHk8pmSbsYefvzYJz7uTE5FkuOTHKHJDxd2S8Xsu4mOtaMrZDj6r2FlwQpfoeWTC5Lpl0Y0XTLK9XLReiiZDYT1n3sntTMUZFu/QTMl/tpkPGTXgiNnJsQmgn5NCWFvwjWswZeyO7Ht/Qfb+ieqfN57+Bkn4J+1Kv2O92RfsjHZixkietcdjiqxrhmWuySaaNqfTlveyn8NKHCRMrox2t/C6tZjtcnrOmepN6Upng3jSl7NF6oTpe02T8m03vsWJ1Wq6K/M6MMmuXiR8iw+r20SXLO/ieopNrbNJk69e99EVkX4ZfuR5bG65GaX5I6NXUoz9yeunHdHXLbNOrJUvczqxNeR1tjsjLsbMamvknuQ60mcX2CvciUyOpmUSCNjaET2J2NkbQ2iyPks2Q2V2CtWilhp2Jm9JbMMobMso0xcq2lt7NadD+DtOnfsYZ0fo8/Zq7XRjlI4cqH8GN0tex2ZY/6Kfwv6OPZ57XRjt45H2W/Yh0P4Ox/C69iP4b9HNfHa1m9xvsP4JVD+Dr/wv6LLF/RE8SLvclY7+C6xX8HWWLz4Mqx18G2HjZ3e48cV/Blhi/o6qx18GSNC+DaeNS73Mji/oz14vHg6Kp/RkjVo6MPJGOW5pQxl8GxChL2M6hoslo7dfnjmy2VRVJFlAuDomqRn86jRZIgkt8YtaMgsQWUtQATolCCQCF4EAACAABJUsAAAAAAAAAACCKhsxTWzM0VaDPKNZxKSjwzPNGFsMMsXHz6FYnweK630/UW0j6HdWpHF6pg/cqfBhnh1yZzj5T9uVV3g6ONlOLXJn6phOqyT7TkQbjatnDtw4rhs5XuOldQaits9dgZnclyfMcPJ7JJJnr+lZa0uTkmy416mnLr3NdnckZk+DlYuQpJcnRhLaPT8+z5OmxlGiqfJc7VEABkIQXRQsgJAAAhvRJElsjgh+DTzsaGTRKElvaNxPfBWUfOy0H5j+qnp5YmTZdCGk2fIZLUmmfrT6j+n11Hp83GO3yz8u9a6dPAzZ1yjrTFHMABAAAAAAAAAAAAAAAAAAAAAAAAAGxhY8sjIhBLe2a57j0J0J9Q6hW3Ha2B9Z+mfp37NMLJQ86Z9porVdSikcL050uGFhVpRS0keiQoaRBIKgAQTAIZJBIEE7IAAAAAAAACAAACRokAAgBVrkEkBVIBDY7AA2VctFbskTMbVg2YnYkYp3pe5jlvkaTXWaclo1LkpJ7MdmUknyaFnUIp+Tj2+iOjVprXz8KM0+EeXzcJxk2j01ufCSOZlWQsT0jky9EdmOp5t7rfI+7sz5VW29GoouPknDbKrlhxZy2FLQ0Drwy6579LqzRP3dmNLZZrXJodZY2Ne5mhkNe5pbJ2x1XjrV5jXuZo5z15OKm/kspS+R8jjsrMbfks8pteTlRm/kyKb+SenG3O/Zj+6zDvZKHTjMpt+5lVmkzWT0ikp8FmOz6jW6jZuL5ODYtyZ1Mye0cyb5Dx/Tk15PT0UZM/5iuyXkbL2oLIgsiWFiyQ9yUR7hVZEkIkgAgEEJLFSyCOpRZN/JVEhHWVSfyWUn8mHZKkBsxmZFM01IupEplbcfykbMKoNcpHNjb2s268haHVpmzToj7JGKWLsushGWNsWT1abGp/B7ZH8JNS4bOhCyOzKpQb8FpWmO/jFh02xa/Jnexu+OtyZo0SgvY3Y2xSLfJvj6XWovaS5NpZml5OF/Ea9y332/cfJ0Y+l3oZvPkzLNXyecVz+TIr38j5NZ6nooZSb8mb+IXyedryGvczfxX7HyXx9TurIT9yHd+zjRy/2X/i/2T1p/ajq/f8A2WV6fucdZO/cvDI58k9J6Y7EbDIpHMhkfszxv/Y66MN8rbb2EYI2bMsZFXVjti/aQ4EqRbaJ/HKfkYnWvgq618GwNEXTF5ta32v0T9pfBsKJPaR+CLfkav218EqtfBsdo7SZpxRdlYftr4HYZtE6Rb8UV+dYe0skWaI0T+OI+dSiy0yhaJPwkR1YgnZGyf0ngBsE9OJAAUAADiAARatIAArUgALQAASBBJAAAACSCQAAABABCWQwSgrYwzRrTRuyiYZQ5CtxamuSl9alX4NqyvRXt2ieOXbg8L1rCUnJqJ4rOodUm9H1vPwlZF8Hhet9Na7mkcm/DscNx5Xk8e9qa2z03TctrXJ5WymVNnPydLBucWuTyNmuyu3Rs4+jdOy29cnpsWzuij5703K5XJ7Dp+TtLk6NGfxejjl13Yr8tl2Y6ppxMuz1MM/lCoJJIZohVll4KkgSSQSAD8BkAY4/zMmzwTrTJ1tEjRzcSOViyhJb2j84fVH01/C5Vl0IaX9j9OPWtHz/AOofQo5/S7ZKG5aA/Iko9smmQdTrfTp4GdOEotcnLIAAAAAAAAAAAAAAAAAAAAAAAAGfFod98IJb20foL6Yen3TXXbKH/g+S+iujS6h1Gv8AHa2mfqb0v0qOFh1rt1wiR6THh2VRX6MpCWkSUokAgmANggkCAAAIJAAAAAAAACAAAWGyNkAW2RsrsNkdEkbKOejHKzRnc0zHrM5FXNGpO/XuYJZX7MM9vGuOvrencomCeQvk0Lcr9mtPKfycO30cdOGl0LMpL3NG7M17mnZkP5NC/IfPJ52z1OrDQ3L838Xyci7Llt8mK29v3NaU+44Nvqrr16eLSy578kxyJPyzA4orvRz/ANm1pcJGec1Lya0oOUtonbZlTUYbZ2aN1tcm2SMHYyrgzFkZkK35NZdRg3ruPY053jzs8o23uJH3G3oxRvjZ7kt65Ozv0zmU6y9xKka/cWTI60bCki6kjXWzItjqWXuHeyjekU7+SenGypst9w14yL7LdGdWcGOdi0zE56TNW2/W+S0cu6/TFmWcHP7tsyZFvcYYrks8L037Un5KkzfJVEvNqyLJFUXRZWxZEe5KI9yKpxZEkIkhFAgEFaksipZBSpRJCJCqCSdDRJ1KLIonospEK3Ia5MibSKrkl+ArckqxmWNuvc1edludBX5tr7735Mkb38nPUtMzRlsdUux0IZbj7mxDP/ZxpSeyYTY6tNtdv+O/Zmhmp+5wXNlq7ZJ+R1rN1eljlL5MkchHnlktLyXjmPfkdW/PXolkJe5b+K/ZwFmPXkj+NfyTKj+zY77y9e5X+N/ZwXmP5Kfxb35LdR/ar01eXv3NmOUteTyteY9+TahmNryOtMfVXo4Zn7NqvL/Z5iGS9+TbqyX8k9d2r0vTV5O/c24XrR5urJfyb9WRwuSevR17+u5GxMyxns5Vd/Hk2K7v2XmTsxy66KZY1I27MisL/KNZkz7JTMKnsumOxrGQaIRI6txAZJGh04gaDIJ6rYnQBBKvU7BAI4tMgkgEcW+Sdk7IARxIIAW4AEE8SkbIA4JAQCAAACCSAAAAEkEgAAAAAQgsirJQFtcFGi5Vg4xWLgwt6NiS2Ypw4JZ5Y9atupLRwep4SsjLg9A4fkYMmlODM8p1xbcOPk3WcL7V3COXXP7cke469hKUm0jw2bB1Wf8Ac4tupyzPld7p2Vprk9d03L8cnznBvakuT1fTMl7XJw534vU82XX0PFv7ork34y2ec6df3Jcncrkd3kz7HXnG57FWQnwNnbFEoBEPyWEkkAkSQ9kgARvnROyNc7ICS4NLqGIsnGlCS3tG9sSXctAfmT6oemVj5E7oQ0vJ8dlHtk18H63+ovRFmdNumo7aiz8r9WxJYmbZCS1pk0c8AEAAAAAAAAAAAAAAAAAAABkpg7LYxXyYzu+m+myzuoVxUdrYH1r6W9G04WuHt8H33Eq+3VFa9jxPoboiwsKvcedHv4rUUKJA9iUVAgkgtBDI2SyAAAAaIJIAbGwAGxsAK5AbYBWymKNssioUtD9L8WfBVyKzma879FM8+ExrYc0YpW69zUnk/s155X7OHZ6ONcdbanfpmvZkte5pzyeTXsyNnFn6a016r1tWZLNaV7ZrStbKd+zl2eqvR16seNiU+4w2S0VdmjBZcteTg2+m1t8J/pW21o0bbGy1txrSntnBntta4YqTezH4LtmOUjL7ydMuOM+1m0Y5cGOVnb7mpkZ0YLyjr06O/twej0SfptPIjDyzSzOqRhFpSOHmdV03pnByeozss1tntefzR8/6fXl/10eodVm5cM58OqWd3uasm7OWYXHTPUw1SR5efryr0+F1VtrbO1XmwnBfkeDrtlDxs3aOoSi9Ns2+KdfpvXtoWxl7meLR5jG6jtrk69GUpLyV+L0MPR101LRZWGorU/cupbI46cdkrP37ZZRTMCLqeiGvyjJyvBKlvyV7tlXIr9otZJta4NC82dtpmnezbH9OHfk1ppNld6KylyU2WeJ6L9kuWRoe5Yl59EZEURdDqPtDYT2SyArV0SVRYlW1DCDAUtWRdIomWTClW0CQFTZPDKE7IRVtEMnZGthSrQfBZyKrgBU2NhRLKGwcU1tl4rRbs0Tozyqlw+1e3ZKTRkii6gRMmmOqsW2wtoy9o7C3yhlrrG22RpmVQLdhPWVxrFsjZecdFEtjqmUqGyVyO0lInrKyrRejJC3TML4KJ/kOqzOx0oXGaGS0c6M2T917HXRr32O5Tlv5N6Ga0vJ5uq/TNpZPBHa7dfqsekqz/wBm5XnR1/MeUhftb2Zo5DXuWlelr9d49WuoJe5lhn93ueWhft+Tdps37lpa69fotemqyk/c3q7FLR5zGm9+TsY8m9Gkr0dWdrpJ8FkzDDejLFcF5HXOjY2SQW4ShBIAgkAHEEbJIJ6j4pAJHUyAACwAAA0AA0NAAAAAAAAaAAaGgAGgAAAAAAANBIEgSQ0SgQKlJeDIzHJEoYGtMx2R7lozyRjaKubbHnerYiknwfPeuYark2kfV8unvgzwvqLD/m4M9kebnOV4XGscbGj0WBkdrXJ5ycHVc/7m/jXa0eXvxb6dlxfQOm52kuT0+Hk/cS2z5t0/Mamls9l03K2lyRpzuL1tWXyn29XCW0WZqY9vckba5R6OvPpkmL5JKx8ljpigACVglckEoIRosQSQlXt5JJBA5nWMRZeHZW1va0fmH6menHgZ8rIx0mz9XWJNNHyL6q9GWTiStUfCZeD8wtabRBmyq3VkTi/ZmEqAAAAAAAAAAAAAAAAAAAtCPdJI+u/TXoLtvrtlH4Z8s6ZjvIzIQS3yfpr6c9H+xhVScdcImD6N0vGVFEVr2Olv2KVxUYJBfzEUZCACoEAFoIZAZBNEggECQQSAAAAqyw1smIqiLkeA5aRGecicYiRilPRFlqSNG7JSXk4dnokbY4s1l37NK279mCeTv3Ned/7PO3etvhr6y2Xfs1p2v5MU7jBK9HlbfZ9u3XoZpTbfko3v3MH3kQ70jny9HY6ZokjLJ6KOxI155CNedzfucee+nx42brzUstb9zG5tlZGFzta44KTm2Y+4tIwSmkWxxtTbMWZy4NWy1Q3tlbMhRizjZ/UEk9M9Hzef5PM9ns+P6ZszqEYJ8nm8zqTk2kzVy82U5P8AI1Fub5PW1ebjwt/t6tO2Vj5bKKvctsyOOgmenq18ePu9HaPUUYW9syPbCgdMjl/IdvBiltPgzN8aMfbthabLGXHtlFrlnWx83tS5OOlon7jj7kcb4eivU056euTery4v3PFwypRfk3KuoNa5K2O7X6HtI2qS8l9b9zzVHU/G2dXH6hGSWyvHZhvdDlF1yayyYyLK1EfFr+aM8mkjRvZkttNK6zZpI4923rFLyEjG5bZZMl5O7Lqz4I2Gyoci6ZdMxIyIJGyUVZZeCYpkknZUBlVyGESFaJl0URZBSr7J2U2NhVcBMEKpRZFGyO/QRxZvktFlU0+Q7FEJmLMi20jUllRRhlmx+Q0mDqQak9GZVJnDr6hFS8nTxstWaMc60x09bapLqozV6ki/ac+Wzjv1eXrB9gl06RtRiW7NmX52+Xi+nPdegkbsqTE6tMvjv65M/Fxqzr2Y/t6N9VbInR+jWbY58vJWj2hRNmVLRX7bJ/Kwy8la8oGPs5Nz7ZV1kzY5c/NYwKPBSS0bKgUnWWmbC6coxRemX72goESg9FpkrzKMkL34NiNjaNCPEjahYki8b69t/Tajc0/J0Ma1yOTGackdjAr7muDSPX82Vtdvp6cpHoMeHg5OHV2pPR2aPY0xj6Hzz6bcY8F/CKJl0aR3cUfkkNAlAAAAAAggkgCSSCQAAJSAAAAAAAAAAAAAAAAAAAAAAAAAAASQSBKAQAhlWXZQhCjiY5LRs6MNiEZ549jTu8NHm+tY33IS49j0t0Tl5tffXL+xGUedtwfJOq0fatk9e5p0Walo9H6hxe1t6PKxThazh3YOW5/F3cS3U1yeu6VkcR5PBY9rUken6XkaS5ODL/GvV8m3sfQsK7aXJ2IS3FHk8DJ8cnoqLO6KOvTm7f23Ivkkxxey56WF7Di2wQCytiSUQSiFQkgkLAAKjFNfkec9WdOWb0y2Pbt9rPT+TXy6lbTKLXlF4Pxd6s6TPA6jZuOltnmj7t9WPT0a07oQPhdkeyxxfsxRUAEAAAAAAAAAAAAAADywZceH3Lox+WB7P0J0WWZ1GuTi2tn6l9NdPWJhVxS1pHyj6YdCj9uu2Ufg+5Y1SqqSS8IkZJb9iYr5C8kt6RAAhPZJAggkgkQyCzIAgEgCCQAAAAE+xAIopNtGvZb2mzKOzVuq2jm2y1bFz8jJ88nMuyG98nSvxm/Y0LcRr2PN268q3xrRle17mGV5szxZP2ME8SSXg8vfrydmprzu/ZrTufyXyISh7HPnOSZ5G3CyvV1YzjZdz35McrZfJii9l3HgytvG2R9xslMqolnwZVSYDkkVc0Y7JGLuZphrtWysxjJOXBoZFvbvktfkdifJws7qGt8np6PP14nr9cxZcvNSrkt8nnL8iU5PkX5jnLWzWb2e15tHxj5f1+u5VSUe57JjHRYto7scOPMy22qvkjXBfQZrGFvVEiW+OCSrJ6Rj52WbSiSVaIlWSvBWWiyXBWSLon7Y2vgjbRlSKzRLbHPiY2zXhm3Tmzh5ZockNsjjfHdx6Gjqi42zpU9Qra8njoSaZ0KLGiONP7FeneTGa4ZhnLu8GhTZtGzGZPGee3rJ2ssineR3hxbMmQcMopbZkSDKVKRbaKkbC3Vm0SpIoidBW1cEIulsKURYjQCtSToIsFKqypdkBUTLlNpFZXKPuQcXk9GCVqTMNuSvk07MnnyEyN95cYryat2cvZnPsvbfk15zcg0xxbFuc/k1ZZk2/JjdcpPwZa8OUvYOjHGIryZ93LO703LSa2zl/wDp8lHfaXqjKmXg59rr04R7/CuhOCN9V78Hj+m5zjpNnqMXLU0uTzdtr2/NrlbUYaC8mSOpIlQ5ODLZZXozzywUE0Y5U79jZjFItonHdXPs8sakaX8GX7HHKMy4Ld3BvN7my8caM8f9GJ47+Doa2zIq9on8zK+KOQ6WvYiVL7d6Oo6OfA/h9x1ovjuYZ+COOqiJUs6v8Kl7E/w8WdGGzrh2eGOK69D7LfsdaeLBLZp2yjXs6McnFs8cjnTq7XyV1yRkZcVJ8mCGTGUvJ1YvO/DzJ0sapykj1HTMdccHncCcZNHrem60jbF6vlw47NNOorg3qYa0YatOKNqCNpH0eifS5ZFSy8FnVUNkBkhWIBICUAkgCCNFgBBIAAAEgAAAJAEAkAQCQBAJAEAkgAAAAAAAAAAABJAAnY2QALFdFgVobMU+TI0UaJiK1rI8M599bcWdSw1LVtMvxx7sXhev4MpxbSPCZNP2bXtH1jqtHdB8HzvrGK1OT0c2zF5G6ccWFi7uDu9Ov7dbZ51R7LDpYtvbo8rfj9unx7OfT3vTslNx5PV4dqcUfOem5WpR5PadPyNxXJGrLj2tWXXpK5bMuzTx57SNpM9XTn2NrFkTohFkdDOhKIbCK9+1UkkEkpAAyBBjl+zJ7FP5mWg+e/Ufpv8AF9LsajvSZ+VOq0OjOsi1rUmftT1FhrJ6fZDW/wAWfk/1x0eeF1K2TjpOTA8aACAAAAAAAAAAAAAADq9CxZZPUIRS3yjlJbej6N9OOivLz4zcNrgD7z6B6d/D9Pr3HXCPfeFo5PQ8NY2JCKWtJHX0BCXJL5JIbAJaBCJAggkgAyCWQAAAAaBOgGhonQ0BGiPBbRDJiKLkiUNkosRZKmVrSpTME8ZNG8yujHPXF5k5ksOKNe3FjpnVt0jSukkmeb6MMY6tWd/08/m4sdM8/k0qMmemz7UkzzWXZuT0fPen4yvZ8+V59tRPTMndwY0tvZLXB5eV7XXJ1buIlIx70HInHDqmeXxg+TXutjBeS1lygnycXPy9J6Z6WjS8X1+34zjHnZi01s87lXOcnyXychyk+TU/mZ7ejTOPlvX67lWLt2y/aXUS2jvmHHkZZ21j0WLNFWW4qkqwAniCGiwJ4KDRbQ0TMTqpVlmRoujqoa2W0TGOwtKw9oceDZVO/YiVD0Fo1PDM1d2illTRi7WvkLSOvj5HHk2o5C+ThQm4GaN7QW+N47avXyWVy+TiLJZeOUwxywdyFq35M6sT9zgwy+fJtQyv2FZg63cmDQjlL5MiyV8guLdTRfjRorIXyXWQteQys42d8maHg0VamzYrsIVrYl4KrlkOWxDyFasTsrJ6K94Uq7Zjc9FZT4NadoVZZ2mndeyZ27NWx7IaSMdlrZhbbM3Y2zJGlv2C0jU7HJ+DPViOfsb9OG5a4Oti4K44DTGOVR0zeuDp0dNS1wdirFikuDP9tRXgNpHLeBHs8HMy8FLekemcd8GtdiqSfBTPDrXDZ8a8pCEqpnawMtppNmLKw+3bSNGMpVTXnycG7U9ny7nucS5TiuTaU+Ty+D1Ht0mzt0ZKsSezytuvj2te3sb/ANzRKs2YN7Qjwzls43+q209kpbMalwWjITI/HF0uTLFmLY7uS8qv44z+SyMUZot9xL3NsKx2YSLSjswySjsi3LhWnyji5/W41ppNHbqjzN/I28vMjXF8nmM/qmm9M087rTsbSZx7LJ3v3O3DF5G7ONi3NnObaMuPdNyT5MNOM2uTepxtHVi8nKz5O107Iaa2ez6Xf3a5PBUP7ckep6Pk6a5OnB2+fL7e9xnuKN6Hg5GFepQXJ0657NpHuaMvpmbJXgqWRNdn7AGwQSAACQAANDROhoCNEaLaIAaGhsbJQaGhsbAkEbGyBII2NgGACQAAAgkgAAAAAAAAAAAAAAAACxJTZbZFSFSWRsiKWsViNWZuWeDRtejSMs52NLLqU4M8P13FSUno99NdyZ5nrmNuuT0Y5vJ9GD5fkrsuaL1TaMvUaey+Rgq8Hn7sOuXXn8a7HT7mpxPbdMv4XJ4HEn2zR6vpuTpLk4r/AI173kz7HusO3aR0oPaPPYGRtLk7dVm4o7NGx6Nn020SY4z4Ldx6OOXYwqxJWLLMiX7AkgGiFgyAQI9mVitMsmJEjFkVqyqSfuj4X9V+gL7Erow5/sfefMTwvr3pyzOmWrt8ImD8gXQddji/YxnU67ivG6lbDWtM5ZAAAAAAAAAAAAAAM2LX93IhH5Z+jPpf0WNWPXZ28tH5/wCi0u3qFaS/qR+rPp9hurptTa9gPeUQUK0jKQlpEkCBokEiAGQAIBAEsgAAAAngWKkkdQkEEjqOgAAAgEq9SY5vtWyZS0jXus/FmO3P4xfGdUnZs52XbpPkm67XucvMyNp8nhev0PQ0aK5mfkcvk5M33szZM3KT5NZnzm/O5V62rXYJaZMvBT3IlI55O113OYxSb0a9tvb7maclo5Odd2p6Z6WjzXJ5Ps9UkYOoZv215ODk5bnsnKvc5PbNThnsafNx8f7fVbWNvukXiiyS+Aenrw+LxrncqhkFtEaRtUVUjRfSI0QjquiNF9EaJkT8lQSC0OoABPVVGhFF1HZZQ5K8T1Tt/Rlrg/gz1VJ+UbUaYpeCV8Y14QXwZHWteDOoJE9oayOfbT+jWdP6Ox9tPyh9mHwGkcSVD+Cn2WvY7cqIvwirx4/APnHDlW0U00dmeMn7GCWL+gpftzk2i6uaNmePpeDXlWgkWU0XjlNmu4cmSECeK3jdhkNllkPfkwxjouqm3sWMM23Xc2/Ju1Wfs5sK5I2IKSKsa6kJ79zYg18nKjKS9zLG2S9wrW9OSMDmvk1p2y+TH3yb8kdUsbFk+DUsmzKu5oj7W2OkjV22zJGtyfg3K8ZP2N2nEXwGsaNOLv2N6rB37G9VjJa4NyupJeAtI1sfDSj4N2ulR9i0UomVNBpIlcIhvYbK7DSJS0xKSfsG+ChPy4yz71itpVifBysrB09o7W+DBbHuRhnOuzRu+LzrhOqXDZ0sHMakotlrcdPfBqKp1z2jh26evY0+p6rHuUoLk2Y8s8zRlShpNnUozlxtnn7ND09W+V2PYrvTNeOVGS8h3o5/xcrrmycbsXwUlLRqfxsI+WYL+pVqPk0x1dZ57pG9LIUV5NPK6gq4N9xwcvqUm2oyOZZkXW8dzOnDQ4N3qkdDK6y57SbOLfbbkSfLM8MaTfJuV4i+Du16uPF9Hp65EMCcnttm5Xidmto6ax9eEW+ydeOPHk7dlrXqqWvBsRhpBai9FnJaNI5e/aO38kdfp0nGS5OI56Z0MK9RZtjXRq2ce96XbvXJ6CmafueFweoKvXJ3cbqkXrk2mT19Hpkeniy5yauowa8mzHNi/ct+3qYeiWNt+S3sa8ciLMqsT8DjabJVwV3sDi8WBXZG9jieMgKpkSloK/KL7Ib4MDt0VlkRiuSEXKM2x3GlLNgvcr/HQ+R1jd0jf7h3HNlnw+RHNi/cdU/sR09jZz1mLfkyRyov3HWmO2VubGzWV2zLCZLWVlRJCa0QwmLAhEhPAge5IOIBICEAkgIAAEgAAAAAAAIJGiRU2oBOhojjPikvBo3rk6Elwad0dkoyn01YLZzOr0qVL4On4ZgzYqdPJTLHrg3YdfJ+t0dlkno41T/E9d6ioWp6R4xKUZ69jn2Y8jyNs+OTcrs7ZI7mBk8rk83KWje6dkakts8zbj9vU8m7j6L0u/euT0lFv4rk8N07L4WmelxcltLkjDL4Pc15fOPQQnwX7zQrvXaW+/t+Tqw9U/S11OjCRl2aNVmzaUtnZrz+X2yynGQkqix0RRII9yRxHVQnssRpEJVjLctHK67jK/CsTW9o6/alyYcmtWVSi/dEwfkD6gdMeN1a6XbpdzPDn3/6pdAX27L4w92fBLoOu1xZNGMAEAAAAAAAAAAZKIfctjFe7A9f6J6VLKz4S7d6aP1T6Wxf4fp9cdex8b+mPQNxjbKJ96wMdU0xigN0AAAABDIJZAEEEkAAAEwABAEkEjiBEkEk8QAkaAjRVvRdmC2ekVyy5DjFbZo0bruHyWvu88nPut4PL9O7jq06+1rZV+m+Tj5OTvfJsZtvLONdZvZ876d3a9jRgrKfdJlJeCifJNj0jy8r2u6TkQ3wYpSDlwYrLEkbadVtcfo2zGMGTf2RfJ53Oy9t8m91HJ0npnm7rHOR73m18fLe71T7ROTlIhFox2W7D1cI+b3bPlVUTot2kNG0cyH4KlhosnvUDROgBGiGixDJFGiC7QUSRTRZR2ZFAvGvkCsK9mSNXJmhAyKJK0KoJGfSSKx4IlINcU6BXZOw0ixJXY2EjeivcS1sjtQ4rTSZjs0kZeEjVvnpMcGC+cVFmhKaLXTbbMddcpvwEWnlmxTU5Mz0YMpa/E6uN0/WtodZXNp1Ycpa4N6GFqPg6dONGKXBsfaQtY5Z9cb+E17E/wANr2Ov9pD7K+CqnXJ+x+h9h+yOr9hfBKoSIo47x5fAjjvfg7H2F8D7C+CDjmxo/RkjRz4N9UoyRpW/ATxrV4+vY3qqkl4LRrMiWgvItGCSLpIx9xZMLyJb5JTIaAXiWyNkkNBaJTEiF5DHEWI2NbBO9D4k+lHUmYbMaOvBsOZjc2zPLBtht451tLj4RhVlkGdOUVLyYJ0JnLnq67tfq4wQzZx9zI8+TXkxSxl8CGKn7GF0Oie1jsy7H4ZglZbM6EcOPwXWLFFsdLPP29c2FE5vlG7VhLW2jYjWo+DNGeuDow18cWz0da32FH2JSSM02YWdGOLizz6umiraI2Uk0acc+Skv5iG+CW0UchxzZXlVkTC1wKt7Mci0iJs43686Ufc3qOqSjr8jz6emXVujSVrh6OPYU9Ya/qOhT1jevyPBxyWvc2qs1r3LyurD28fQqerJtfkdSjqMZa5Pm1fUGtcnUw+pybXJaZO7T7uvpFORGaXJsdyaPLYGc5JcnZrydryOvU1eqVvsq3owLJXyYL86uKe5D5NsvRONmV6j7mGeXFLlnBzesQhvUzh5PqDW0p/+SOvO3eyR6vI6lCG/yOXkdZjppSPIZXW5z3qRzH1KyU+WR1w5fyP/ANeys6x/zGF9Z/5jx9mdP5MP8bMjrHL3de1/9Y5/mM1fVdv+Y8Ks2e/JsVZ0t+SOox9j3tfUO7+o3asxvXJ4jG6h45OxjZyaXJMrt1et62rJ/Zu1379zy1WYtrk6mNk92uS8r0MN/Xfrs2ZU9nOqt48m5VPZLtwz7GwgEww0mSCSCQt0AARQgkgIAAEgAAAAAAAJAARUgBBERLwa9kdo2WY5LaBXNnHTMV8d16Nq6PJilHcQ49seG9Q426pPR89yIuFx9a61jqVMto+Z9VoVd7Mdk+njen/05zbaMmLJxkjHtaIg9SPM2T7X8+XK9b0u3bR6nGt1FHhul3tSR6nHubguTl2fT6Ty5dd+GRx5M9d235OHG56Nqi57RzY58yenzsejx57N6tnHxbW0jp0y2ex5tnY5dmLbiy5igzKvB6WNc1NckgFkAAKAVa2WI9y0S8B9QenRyOl2/jzpn5U65R9jPsjrXJ+y/U+L9/ptq1/Sz8k+tMV4/V7VrXJI8uACAAAAAAAAAOh0en73UK4/s553/StLs6pVxv8AID9NfT7AVPTan2+x9Diu1JHl/RtPZ0urjX4nqhRIAAAjY2AZAAEEEkAAAQkAJ0WRUEjROghBI1oICRsMxykUyy4tITnpHPyLuGbF00l5OTk3cs4d27ka4YdYbruTSvs1BstZP3NHKv1WzwPXveno1NHKt22c6b2ZbbHJ7NdyPEzzuVephjyC8ix/iIsra+CMMe0zzkjBOWjnZeT2xfJs5NqhHZ5/Nye5tbPa8+n6fN+/0861svIc2zQ7NvZlktveyUj2NOvkfG+rfcslY8FthxI0dcjjmXanZUkgvFqjXJbQJ2SrKq0QyxGgnqgLdo7dEp6rovFBRLxWgjrJCBlUNFIy0ZPubRKV4rgtoiDL6JWiF4KyXJbu0R3bDXGoS4J0RslML9ToaGydhPQpJ6Mq1oxWEjBOzRq2NyMlj5KRSbCK1447nPWjpYuCk1wWx613o6taSIY5VfHxoxS4NtQijFCXBkT/AGVc+VZF+idkR0H5IZ9W2WRRIskExfgiQ0ToirxCROi0YktELyKIyR0U1yXSC3F00SzH4JUgtxJKkR5I0ExmT2iN8lIvSJ2FoyJhmNS0S5bCyd8kNkb5IbItLU7DZHklImVS1R+Syig0U7tMsp1aS0jDJmTu2Va2UsiZlWIunpjtGivwibnWVS4MUpk70ij5Exilzqd7Kt65G9FG9luKXKrd7ZD2QuCXMnqnyY3Joo5MtJ7KNE9RclXIo+S7iVfBaOXK/aCsizkUbJZVQhotvRDY6p9qF4y0V2Qx1b7Zlc0zoYWR+S5OO2ZsexwkWlbas7i9907J4XJ2VnKEPJ4PF6n9tI2bOtNx1st136/TY9Pf1pV/1HDzuvycnqR5/Kz5WN/kznynKXlsjrTP2fTo5fVZ2N8s5ksic2/JDW/cJaI64Nu+5LKTflltIx7C8kdct7VpLZCgGyVIjqPtVwJi9Evkr4I6mWstdzjI6eNmNaWziKX5GaFzgyZXTr2WV63FyW2uTuYmRpLk8VhZj2j0OJkOSReV62jba9ZjX92jq489nnsBs7mMzWPb0Zf4unF8ElIPguS6pQkDQXlAAFggnZAADQ0AA0AAAAAACQRsnYRUhABESyj8EtkLlBN/TUtiYnHg2L1o1u/fAcm2OR1SHdVI+Y9ercb5cH1fOr3W2fPPUOMnKUtFM59PG9OP28T3NPRmrWzFbxZoyw4R523H7Ya8+V0sOShJHqcSe61yeMps1I9LgZG4RRw7p9PoPFsdyL4M1UtSXJpRs/Ez1PbTPMt5k+gwvY9Bhz4R2KHtHnsSWtHcxJbR6nkz+2e2fTowMyMEDOj3MK4akAGioAwRQBJBMGp1CpW4s468o/Lv1Q6W6eqWzUeNn6psXdBr9HxX6qdF+5Rbcokj84NaeiDLk1/bulH4ZiIAAAAAAAAA9/8AT7pjyOo1S7drZ4SiH3LYxXuz719Luh/hC1xA+1dCoWPgVx1rg6xrY1X26opeyNhEUWIZJDJgEEkAAABBBJAAABKQAiVakIBBUYQIM8sl4SZrWz0ZZy0aGRdo5N+zkbYY9YMm/Xucu2zubM+Rbs0LJ6PG37/p3atbHfPSORk3b2tm7k3LTOTbLukeH6Nna9XTr5FVyUnEsnpFZTTOOd62zvxjHvRjsnwXm+Dn5F3anyd+jV2vJ9Po5K5mfk6k1s4dtjlM3cuzusZpOO2fR+fV9Pjfb6fllYqmXiiutEpnoY4PC2XtZGuDHou3wVL8UxRojRYCNLVdEaLkE2IiuhosAnquhosNA6glEAsdX2O7Rj2Q2DrYjboyfd48mltonvJWlbnfsspGnGZlVgXlbS5LJGurUXViC3yZSGyn3EQ5A+TJ36Rq3XaLyfBp3bYaSsc7uSYXLZrSrlsjtkgV1ashJo368tP3PNfcmvczVZEk+WGeUeqhemvJkV37ODVl/s2qspN+SOMMsXZjY2Z4vaOfTfFpG5CxaIsZ3HjOmWTMKnsyJlSRlGyuxsirxkTJbMaZOyF4tssmURKYWXZA2RsHWRBlUw2E9WTGymwE9X2NlBsJ6vshkLyS0UsVtRstsoSIhLkUIY9ieiwKNlWyei7KsjZGwi2DYIbJTCv0hoprkyNoo2iOq1DZRsnZVkMslGyrZZojtLSMrTfBjkyZPRilIv1lUtlGxvZDHUcQmGyNEMk5EjRCLBb4xRrkvGLRHuX7lomK3kSpuPuHa/ko2ioO0cm/ctFcELRZNEKW0IJbIBj+0BEhDromM4hglkBSYxJDLFWyEZYojrZMmiEuSr22Irjftv4XlHpMH2PPYMOUenwK/BePW8z0PT1wd3G9jkYMNJHax0bYvoNE/wAW7DwZCsPBYu64kkgkhpEMMMMLIJIJAAAAGAwIAAAAAAAgipJIJCIhkIs/BT2CzWyZcGonybWT4NNeQ5djHk/lW0eJ6/TuMz29i2jzPXKk658C/p5foxfLMuDjb/3KJ8G/1Gvttf8Ac0dHBsn28rK/GrVT1I7uBd4OBFaZ0sOzUkcW7H6ex4dn29TVZuKN/HlvRxcae0jq48taPHzx/wAn1OnP/F3MV8o7uL4POYlnKPQYstpHd5Pqp2Xrp1szrwa1TNheD3tdceSxJBJ0KpZBJBWoSQSQSGto8T6+wFkdIuetvR7c4fqWn73S7Vr+lkyj8Y9ex/4fqFkdf1M5R6r1vj/Z6xYta/JnlRQABAAAAAAN/pFf3c+uP7R+qPp7gxp6fW9eyPzD6br7+qVf9SP1r6Np7Ol1Nf7USPXxWoob5Ii9R5HllaLkMkhkgQSQAAAEEEkAAATEhJBJKlCSAitRIlsxylomb0a1tiRzbMuNcZVLrdHKyrdvybF9y55OVk28nl+vbPi6tWN6rOezTvnwJ2s1LruDwdmx6mnBrXz22asvktbZtmHubPPzva9LCSQkzE29mRmOSJ149rm9OXIpbPUTh5tr5OpkWJJ8nDy5qTZ7Xn1V8r7vRMe/bmWybmzHszyr29mNw0e9qx5HyG7b8s6r5GtFlwRI6sYz+qrskiK5L6FjOq6Gi2iRExXRGi/GipNWqNDRIIVRoaJAEMq0X0RokU0NFtAk6xtEaLtFQmURO2ieCHoLRHeyysaKNEaYT1nVpdTNTlF4yB+22vyDp7iKHs2Yohti1v4ZfBWWKvg3WiOQu5s8PjwYXjOPsdnSa5MU60/BJxyXFxLQslFm3Kht+DHKjXsSpYtXlSjrk6NOb+K2zkSr0RGcovRXJlli9LVkKXubkJ7PO41+mts69GRBpclGXHQTLIxQnF+5li0KskmJDJiQmVk0QyVJENohYZBPARIsgyUiHpECY+CeCmx3EnV+BwU7hsJ6yLWw2Y1IOQ4dW2NlUxscR0fktrgoT3cFeK2oZUSZXlhS5VJEuCUmT278kxW5VhbZKZdxI7RwlqjfBTuezK47Kdj2RxP2ghl3wY2WkVylRshsiWyj7jSSMbET8mJmfXHPkxyiZ39sqxkNktNFJbCqfJDREePJZtEn2qkWI0SSj5VVjTLaJ1wOotV0O0knu0SvjxGiHwWT2RIhe4xGySCQys4EoDaIPlUMrss2ihKcbVtlWwQQmr+xRP8AIt7CuPdMSIxn26uAvB6XA3tHE6fTtI9Pg43jg0j2/Jha7uDzFHXoRz8SlxS0jp0xaNcX0OnHkbcfBYrFcFizokSACF0MMAkQSQSEAACQMACAAAAAAIBBWpJIJCYMqkSwgs1747RqOGmdCyO0aso6Dm2RpWLRwesR3VI9Dbo4vVIqVMtC/pwbsfp8u6utXP8AucpM7fW62rXwcSPk5M48Hf8AVTvk2sSX5o1GtGbGn2z5OTdPp2+HPlemxHtI6tL0ji4U00uTsVPaPJ2Y/b63z59xdTEn+SPSYT3FHl8Tfcj02E/xR0+fkrbLtdepmzHwatJtRfB7OthksSQSdKiSCSCKhJBIJFO7nRp9Tr+5iTj8pm0995W+PfW1+hP2Pyj9TunOjqs5a9z5q+Gfevqx0xytnYonwm6LhZJP5LUYwAVAAAAAB6j0bR93qlfHuj9a+lquzplS1/Sj8x/TzF+51Ct69z9UdCh2YNa/5USOpJcCCJ9ySEBDJIYSEEkEiASRoABoaAEE6CQEaJSJ0CFRIhvRYxTekRbyL4zrHZPSOfkWeeTNfZo5eRb5PL9Ozjr14MN1nPk0bpbZe2zk07bdHz/o29d2rX9qWz0jnX2b2Zb7TRlLuZ5meT0tePFXyyfCCQb4MWmVUcuSsn+LLrRhumoxZ3ebD7eX7NvMa52ZLzyce1bk+Tfy7d7OZKTcj6PzYTj4L+T3W36TrgxTiZl4IcT0sY8LrVlEr2my4FHA0i0yYUidF+0aJW6oC2hohMqhBdkaC3VAizRGgJAGgBBICFQSQwIZXRfRDQJeKEFmUbDT9r64IfBXvCTkyqJjaeWXhS5exsUYzk1wdCvF7V4Dp14NOmpwRnjEyzgoshItGtwRohot4IbCOcUYSDZVBW1dpGKUUzIV0yOs7WB07NeVL7vB0VElUpsKftzVW4mWu1wfk3Z0cGldU0+CDnHRx8z9nQqyt+55iLlB+5u49735DPJ6KNuy/cc+i3u9zdjyiGfWTZZGL3LxYazJkCZGyNhHWbfBjkQpDewdTF6RDZBAT1dMlsoidg6hvRHftkSKp8hFZ4vgrJkxlwVlLYRBSLxjtlIoy1xbY4vJ1DgTGPJsKhyXgvHFk34ZHGk09YO3ghQN+OHJ+xb+Bl8MmReeaua6ijqfwdiOBJ+zMq6ZJ+zLcXnmrgfbfwOyXweh/wDSn8EPpT+Bxb+u85Kt/BCpfwehfSpfBMekv4HGeXneblS/gqqnvweln0l68GP/ANKlvwOOfLzV5uVL7vBP2Xrweh/9Je/Bb/0mWvBPFb5K8vOl/Bi+y/g9RPpT+DD/AOkvfgcZ3yV5yVDa8FVQ17HpX0tpeDDZ01r2I4f1q4Dhoq+DrW4Ml7M0rcaUfZkcYZ6LGtsORE4OJjT2Vsc9wrJ3ES5KMtHkHx4hPTLb2JR4IiuCVupJRBKZJ1LKe5Z+CF5CKq0Ei7RATjU64MbLtlG9smRar62jPj07mjFBbOphU90lwWkX1Y9rq9Op1rg9ZgVcI4/T8XxwenwaNJFpH0fjw+nRxYaRuQRiqhpGxFGke1jPpdEhEkrqgAAAAAAAAAJAAAAAAAAQEAiEJJIJCyGiUgSEKtbMFkTYKSWwpXNvr/FnE6gu2qSPTWV7Rwuq0P7ciXF6J9PmfXVubPMfyzZ63rlepSPI2p97Mc3zvpn2y7UkTGJihtGTv0cO08t5k7mBxFcncx5eDz2DZ+KO3jy3o83ZH1fjy+nZx56kj0eBPaR5ejmSPR9PekiNH/p6v+nfpfBtRNPHfg3Y+D3NUc2ayJCIfk6oyqQASqkgkghZDW0Q4/gy6IYHy/6i9N+/hWz7d6R+YerU/ZzJx17n7H9W4av6Xfx/Sfkr1Zj/AGOqWrX9TLX7g86ACoAAAWrj3TSKm1gV/cyoR/YH1v6Z9Ncrq59p+jOnV/bxoL9Hyr6Z9JUMOqxxPr0F2VpIIX9yxWLJ2BJDJIYSEEkEgNEoECNDRIAjRIAAgkpJi1VLka11mkXlLhnPvt88nLt2cjXXGHIt8nLvs5ZlyLfPJzrbDwfXvenow6x22cmhkW6Ml1hz7p7Z4ezZ2vV06vtWye35MaIYTOe1vljxd8IwzbMjZjkWwx7WOeXIxOTS8mnk3aT5Nq2aUWcXMt5fJ6/l1Plv5P0/HrBdZ3NmHjZicnJlkme/pw5HxPp2/OshKRC8FkdUcNqGijiZBovE9YHEhoyyRVosnrE0VaMjRDRC3WPQaLBohaVRoqXaKhboASE9QQSAIGgAhOirJbKtkIUkY2tmXyWjXth0ase1grrcpHSx8NvXBsYOH3yXB6CjAUYJ6Ienr8/Y5+PiKMVtF7oqCfBu2JVo5uTZvZC2Wv4tSctspsrvbIZaM7xLZVsEDrHKmy8Uimi6TIZctZNIhpFdsnlkdTNdqTJErGDZsV1NhrjoqqhtGOzHT9joQp48FbK9Eq56+OJbj69jX062diyvbNW7H2vAceeKuNfpo6lWQmji9jgzPVa0/IY2O5Gey6NGm3aNuL4COsuyGVTJYX6bLJmNkxYR1k2CuxsHUt6K95ScjF3g+TZ3sq1oxRs0xK1ELysnc17kd22YvuLRX7q2Sj5N6rlo6+LjqWuDg03raPQ9PsT1yTI212V1acBOK4NqHT1v+U2cNKUUdCFaZbj1dGErQr6ev9psQ6fH3ijpVVLXgzKl+xaYvSw0SudDp8P9qMy6fHX8qN+NbRlUC3xaf145b6ev9pX/ANPW/wCU7HaiOxfA+Kl0RyP4CP8AtRMcGP8AtR1XWFWPipfPHJngQ1/KjH/AR3/KjsyrKqofFH9WOP8AwEd/yot/6fHX8p1ftcllUR8V/wCtOOHPp8f9qMX/AKdH/ad+VG/Yp9j9DjK+WOFLp0Wv5TXs6Ytfynpv4f8ARinjr4I4zy8keRu6UtfynKyul63+J7yeMn7GhkYKafBHHHt8j5xldOcYvg4llLhJn0nL6cuyX4nkOpYf25PgplHk+jV8HAkyFLTJmvzaJ7ONleOHJZS2ToxrhmTfAZVVjZDYRPEzG1YjfIA4v+Op2Q2SiGgrceKbCWxoyRiWicZ1sUx3o7/TaNyXBy8Khykj1/SsLiL0aSPR82rtdfp+OlFcHfx60kuDSxsfsiuDpURZaR9H5tfI2Ix4MiQiuCxZ3xCJAISggkgkAAAAAAABIAAAAAAACAgEQhJJBIWCGyRoIQiGWKsK1isels5We1KmXB1LVtaOP1BNVSDh9H6fOvUWlOR5LtUpvg9f16DlKR5GxOE2Z5Pn/TPtE4JI1pJ7NiTbRhn4OLbGWi8ydLCeoo7uJLwefw3wju4j8HnbY+n8WTuY8vyR6HClwjzeP5R6DC8Ipo/9Pal/xd/Gl4OhCRysd+DfhI9vVWOTaTDKwZc6oxoACVRAkghYDAA5nWa/udOuX/Kfkv6hY/2ur2cf1M/XnUId2HYv0flj6pY32+qzevdlv9D5mACoAAAdb09V93qlS/5kck9B6Sr7+sU/9SA/VHobEVPTauPZHtdcHm/SlXZ06vj2R6UVAkTogkJCGSQwBBJBIlAIEAAABDJDAhMpNpIs+DXunpGGzPkWxx6xW2aTORkW8s2r7uHyci+7lnkenfx2atTDfYznX2vRnutObfb5PA9G3r1tOtjssbZq2N7Jc9sjyzg/29LXJEa2Uk2jNrgxTH+0bUJ7E9dpHgxXT7YM6tGHa8r1bPji0cy1xT0cS2blLk6GVZvZzXyz6Lzavp8H/KejtqYxRchIk9THHj5y3tSADSM6FipKLQS1sjtRZE6LJYnBFHEzNFWiKnrA4lWjM0Y2iq0qjRXRdoqF+o0QWIYT1BGiSAsaJSXuRsiT4CYiXkq3wSuUTGtylwiGmOHVIRlKS0dnCwe/Xcien4Dm02j02JgKEVwQ9Hz6GLDwYQS4OhKCjWZYVKJhypqMGQ9bHGSOPmz02ca6W2b2bd+T5OXKW2Q5N1iOSj2XXCI2WcGWX2JAtso97IJjavHRfRSuLb8G1Cly1wR1069HWKNezJGlt+DepxG/Y3a8HxwR126/M0qMXflHQqwl7o3aMRL2NiVagietrokjSlRCEDl5Ok+DoZVyimtnHus7pE9cG/GRjbWyk9NBlSXmZT7YLIJmrJOL4Og4bMFlP6JjO4KUXSTR1KbdrycnscWZq7XFolhljx2E0S5o0VkceSssn9lVG27ESrEc6WTz5KrJfyEddKVvPkq7v2c95P7Ku9sI63pXfsxO5fJqO1so5sI63JX/AAyv3GzVi3syp8A+S0rZIhWt+SrW2WjB/AilzW+/KL4OphdRnBrk5Tqb9jNVBxZeNdWz7e56d1WWknI9DjdQUtcnzjGvlDR3MLOltclo9nz7uPoePkRklyb0Zpo8t0/K7kts71FqkvJaPY075W8pE7McHsypGjsmcpsngdo0Qk2NkAkNgDQFkSQiSFbQjRIIIjZVpNCRKRHE8a84mvalrk3Zrg0MjwyOOfZjHNyu3skeL6zBPuPWZk+2EjxXVcjbktlMo+b/AJKcv083bHVjD/lItm3Y9FoQlNeCvHkfC1g9zLGLfg2q8Gc3/Kb9HS5PW4k8a46LXJjjyl7GevCk/Y9JjdH3/SdKroy4/Enjr1+V5enpff5ibE+i6r2onssbpCT8G9LpcPt+B8XTfJ9Pl93T51/0mlZU4+UfQuo9NjGL0jx/UMf7cnwR8XDt0ccVrk2Ka3JopGO5nWw8fua4LSMtev7dLpeMm47R7bpuOlBcHB6biNdr0evwKNQXBeR7nl0tmFfBs1x0FAulou9rXjyMgIRJDUAAAgkgAAAAAAAAJAAAAAAAAAAiEJAASBgMAVZYqwpWC16icrNfdB7Opd/KcrLX4MiuPe8L16KTlo8Pc92P+57vr0N9x4W+GrH/AHK14PpjFLhFHpl5rgxN6OXZHFrvMm7jSSaR3MSXg81TZqSO7g2b0ebtj6Lw5vR4j3o9DgPfk85iPhHewpHPjeZPo9f3i9BQ4m5GSORVbrRt13bZ6WnajLF1ISMqNWmW0bUT0cM+xhlEgkg06z4kgkgJPch+SfchkDFkruokv0fm76u4esxy0fpOf5QaPhf1cwu5OWvYvB+epLUmC90e22S/YKjGAAB6v0PX39Zq4/qR5Q9x9Pae/q1b/aA/Vnp2Pb0+v+yO0cvokO3Ar/sjqEVECSATEpIZJDAEEkEiUAgQAAADZDIfgrkT9qTekaORZ5Nm6WkcrKt1s4PRnyOrTh2tXIs4fJxr7fyfJt33eTkZFnLPmvXtr1tOtW239mhdLZM7NvyY5PZ5Nytr0deHGL3L70RrkNFpGmV5Fu4o+Q+AmRxXvYNaRo5ktVs3Zv8AE5edP/TZ6Pkx+3zn8ps+MrlW2bZhS2S3tkxR9P5sPp8B7M/lkjwF5DJidd+nn8T7AlkCKWBKIJReIXRJCJLBoq0XIZAxtGNxM+iHErVo1mijRsSiY3EhZi0VaMrRXQWimiGjJoq0FooQy7RCjsNMVI7ctHZ6fg/dabRr4eA7LE9HsOmdP+3BbRV6Pn19RiYKqS4OnXFJGR1qK8BRIe3q08jDZLtRxc/J0nydTKfbFnl+oXPb5IV25fGNDJt7pswxWyN90jIo6QeXtz7UKOyO0ly0Wiu5hnjj0UDJCnbMkKm/Y2qaHvwQ7dWlFWLs3qMTlcGfHx+PB0aaUvYPS1aVaMRa8G5HHSXgvBKJk7loh1zCRhaUDSyrtJm1c+DjZdum0Iy3XkaOXc3JmlvbMl0tyMXgmPD9Oaz8FG+Q2Q0y0eZcvtkjyTKKaMa4L9xeLd+mvbA15LRuzWzDKvZLmzrWc2Vc5Gw6iPtFWTW5Y0/2bkaC32QrWkot/JdVs3YUceC6pXwEVpxqZlVJsqvXsWUQo1XTwFUzdjFNkuC2BqxqM8KkZYxJ8BSxCqRPYkXiy2gY3iiWmbmPY4yRr6LR4ZPXXr28ekws/sS5PQ4PUe5eTwMLXH3Or0/McfLLY37ej5/RevoePlKXub0LNo8ng5fdrk7+PdtLk169fXt66SkSYIT2Zk+B134XqCQCetDQJII6ran2BKBKvEIkAJiNAN6G+CE2sczn5clGLN62ekcXqF/4vTIce7Zxxep5SVc1s8PkyldZLz5PRdQcrJNLfJpY3TJTntpkceN6cfyVw6+nSslvTOvh9Hb1uJ6LF6Qkk3E6+P09R1+I4pr8vXExejJJbR1KukxXsjsV4iS8G3XjpLwTx6OrxxyqcCMfZG/Xhx14RtRpS9jNGKRPHXj5pGtHHUfYWVrt0bbXBjlAni90zjgZ9G4Pg8N1mhRkz6Tm17rZ4XrdDcnwPi8v06JHj6692/8Ac9V0vB7+16OPjYbdy4fk9v0fF1GO0OODDX/k3sLDUUuDu0V9sUYaK0kuDbitIPe8uv6XRYqixDus5AEAlWJBACUggkAAAAAAAAJAAAAAAAAAgEQhIACQMBgCrLFWFKwWeDm5eu1nSt/lORmS1FlXHveQ64lqR4XKSVj/ALntutz4keEy5/6j/uRXh+ljnrRrzRkctor5OfY82X7Ur4kdrp8uUchR5OlhS1JHnbY97w37esw3+KO3hy0eew5/ijsY1mkefsvH1fn+46yu17mxTftnHdv7NjGtbki+jb9t8sXqMazaRvRkcnEl+KOjB8ntac+xybMWymSVXgsjslc4QSQXDQl4DekQntEf7FV4Z8t+qGF93DnLXhM+pNaPFevcb73TLXr+ll5+x+ReoQ7Mua/YNnrlf2+o2r/mBF/Y5QAIA+j/AE1p7uo1vXuj5zFbkkfXfpfht5VctfAH6S6VHWFBfpG/o1cCPbjQX6RtECAASAIJFAjRIK9Ahskq/JaCU9kkIklFQysiWzFOejPZlJEY961cqfamcPKu3s6WdZqLPOZF+m+T532+ix7Hl19YcizWzlX3bbNjIv2aE+Xs+e27LlXsYYcjDJ8kqXAaCRjY3iWwuRoeB1OWPYShsprtMjbMM2y+udrk3bPx4/Sl1iUTkZdvcmjdyZtI49025nu+TTHx/wDJ+i5dYNE70CD6HTjyPjd+X2PkmPBBJpXL8ktglLgaEiEFkQkXSLAkTokgsg2T5I9yUEGgSQRxFqko7MbgZ9FWhxrjetdxKtGdxKuPBXhaw6Ia0ZNGObEWxv2p5ZtYmM7ZpGtXBykdzplEu9PQsej59Pyv27PS8BR7do9JXVGENJGhhVtJHSfgo+g0ebHFiktlWtIvIwWz0mQ7Mr8Y53ULVCDPI5tynZJI7vU8lNNbPM2yUrWQ8nfnbSuPOzLra0K47RnhXtkObHD5VrfZk2buNhykbWPiOfsdfGw+32KWvS1eacadWA9Lg268RRfKOjGnSKyhoddWGrilcYpa0bEFowx8mVPSJdWOPFpPRH3NFJPZim9IkyvC6+KTOBmXd1r0b2TZrZx7ZbsZMeb6tvIxS22QyzKSeiXjbMvl+0J6L96MWyYkuSyMm0CvgsmW6j5GyOPgvor7jrPLlQ4ohQMnGiUiGSIolpFki3aFbFYrgt2lox4LBlesfaO0yEpIlMlqkY65JcW2Wl4IWwtZYJaGthpkcoMMrWSMdE7KpsnQVlTsskyqJTJ40lZEjNXY65LkwKRbeyZ9NMNtxrvYGeoNbZ6PE6nHS5PC12dpv4+Z2tcluvU0eqvoWPmKetM6Ndm15PEYXUPHJ3cbP7tLZaV7Wj0dd5T2WRpVXp+5tQkmi70Mc5V9hEMlDi1kqwIAQbJIGyAaIfgSZDfAVrTyW9M4eVGU20d+6Hds05Ym34HHJnh15x9Pdk09HTxunxgluJ0o4mvYzxp0OM8fPjWGvHiktI2K6NPwZIV6M0Vol0YacYRrSXgnSJ2A6JJEaJBIW6gPwSVl4ClrVyY7gzynUsdTm+D1tq3FnGycful4J65M8Pn+3ncXp35717nqMHG+3FcGHGxGn4OrXX2pEdZ4+XHvWSEGjMvBEVwWDs14/ERLZBIa/tCROiUAjnEaGiQBBIAAAAAAAAASAAAAAAAABAIISNAkhKG9EdxLRGgg2QyTHOekFbWOxbWjjdQXbFnSuu7VvZwuoZHcnyVcO+/TyfWp7Ujw2W/9R/3PZdXl/MeOyFub/uRl9R4Xoy+2BLY1plv5UVl4OTLLrjmP2KS2b+J/Mjmx/mOnhrbRzbsfp63ivK9Dhy4R2MdvRx8RaSOnCfajwvRne8fY+P7jZcuTbxZfkjnRntnQxFtojz5fbuzxekw5rtR0634OTiLSR1K/B7/mrg2xtJlikTJ7Hp4uSgIBdUktoiCaRYhhIee9U0K3ptq1/Sz0Jy+uV9+Bb/0stj+x+OvVtH2ur3LX9QN715X2dau/6gL+x4wAFRlx4910V+z779LsHUa5a9j4V0yv7mXBfs/TH02wvt4lUmv6QPquOu2qK/RlZWC1FFmQIABZKCQgRUAAKAQSQaQEGySsmRaKyZqW2aM85aOVl39u+TzPVu+Lo06+1p5934vk8xk2vuZ1s3I2nycC+W5M+Z9e3r2/Pr4wWzbZVvgrPyQ3weZ16WM+kNkplGwiUsmyNkEMjier7Rjsa0TsxXP8To0Y/byfdnyOdl2LTORZPczezJeTmS/mPo/Li+F/kN33WTZJRGRI9jD9PmdmXaEEkMvVIlMnZUlBKyLbKobJQvsFUyyJQEkglAQAFakaJRITMuMbRVoyMa2iEfJqz4ML5ZtWQ2UrobmuCHVox+VbWBi98lwerwcBRSejndKxXtcHraKe2pcEWvoPLq4rTUoozMvrSMb3so9rCcirW0aWU0oS/sbs32xZxs7I7YyWyFdl+nmeoWOVskcxVuUzcvl33S/uZsfHcmnoq87PDtVoobS4OjRiOWuDNRja1wdbFx/HBDbVpUw8TtjyjpV0pFo19pfwVsenr18isoLRgnA2WUa2ONpg0+3TKyejalHg1ZoLWciE9lbWlEjejWybu2JLh3bONHLmuTkWT/M2Mq9ts0XtvZMeL6tvWbu4KS5ITLJbLPNuaqiZYxCjospJEsrbVXERRbu2Nkqcq2uDG09mRPZZQb9gfGsSTMiizLGn9GZUv4J4vNda6iZFEyfZl8GSNEn/AEji802sPaR2M3I40n/SbFeDJ/0k8Wnltc2NT+C/2ZfB2IdPa/pMscD9ELTzccL7Mvgh19p6H/0/9HPy8ZV7IZbNXHN0ij0ZJIxSQcOzFaOiTEtmTfBLE2V2GyCUWrdxkhIwl4PQ6r8vtm2XhJplIvZbeh1tht46WLc01ydnFy9NcnmIW9rNqrLaa5LSvR0+vj2+Pnb1ydbHyk0uTwuNmPa5O5i5njkvK9bT6+vVxtT9zIns41GVvXJ0KrtryW69LDd1tkmJT2XUiW8vVtDRJDC8RrYaGxsFnVe0jsLkhncGPROiWgSp8UokgELyBIJ0F4gkgBKSslwSArYxSjwa8qU34Nxor2hn8WKulL2MjikWXBLWwniEuCSdcDQWiAAFkoBAIAAAAAAAAAAAAASAAAAAAAABAIISSQSQkZAZD8BFUnLRqXWGa1mja2yGda+RY3FnIyVuLOpbHg5eVtRZDk3z6eT6zx3HkLpfmz1vWm/yPGXSasf9yM/08H0T7RbLgjzEiX5IJ+xx39uRC/mOngvlHO7eTew5akjHd/5ej47/AJPS4z/FG33HPxp/ijchI+e9E+32fiv1GzX5OvhvlHJp5Z1sRcoaJ9vQzd/EfCOpWcrE8I6tXg9/zODY2YmQxxMh6uP6cmSAATVQkgn2ESg0upx7sG1f8rN01s3nDt/6WWiX5J+otXZ1q7/qBtfU2Pb1m3/qBNQ+bAAqO16bp+71Ktfs/VvojFVXTqeP6T8u+ja+/qtf/UfrP0rX29Oq/wCklD0y8EsBlUoADLJQiSARRIIBEioBoksmBSTJMdktIzzq0jXvlpHnuoXab5Ovl39sWeZz7u5vk+e92V69Ly4/7c/Iub2c+ctsy3S8mCO5PR4e3G16muyKSIa4NxYkpLZWyrtXg5fhY68cmk0EjJJaZVoni4Uk2i6IsIUt4xd5hus/EztGllS1E7/Lh2vA/ktnJXKy7OWaO9sy5O3JmKC5PpPPhyPz/wB+zuTLFGRIiKLHfj9PHtVIJ2RsuvijRZIglAq40VLIIR4LIgklCyDIJJQglABFSgQWSClVCYkQ3+ITjOsiipM3sXEcpL8TQxa5Ssj/AHPZdKxo9q2ilex49X2ydNw3HX4nf+121IU1RilpGaxfgUtfS6NXI1e3aI+2jI+EUctIh1841srUYPk8l1O3lpM9B1K7UWjy1+7ZtfsqyznXPqqc7W9HfwcPaXBjw8Btp6PQYuMoRXAZ46+1iqxEl4N2mjWjNGCXsW2kQ7dWvg4JFJRJlLbIfgcbX6Y2VZLIfgcPkpN8GrZyZpttkKvbHGeef01JRenwc3MT0z0Lp1F8HE6klFMceR6c3nL03JkKP4mSxrvZMIdyLSPF222tfXJlgZXSTDHk2X4xmFqkvBje2zoRw5SXhmWrpsnLwxxtjptc+uqT9jL/AA8n/Szu4/THx+J0aulbX8pPHRj5evKwxZt/ys268Ob/AKWerq6Sv9puVdKX+0njWeR5OvBm/wClm3X0+T/pZ66HTIr+lG1X06K/pRPF/wCtx4+HS2/6Tbq6R/ynroYEP9qMqwor+lFuNcPO8nDpH5L8Tfp6Skv5T0EcWKfgz/ZilwiLHXj5o87LpqS8FP4DXsd+Va34Mc+yEfCKVTPTI4N+Mq696PLdUkk5aPW9VyYqp6PDZ93fY+SteH7LMa5spvuG0yZL8WYU9SIePszZNFWy7ktFWvclzXNXZJHbyXjElS5CRDenwWaIS2KzmX2tGRZy4K60VaZVNyqe4yVz/IxaJSeyZTHZZXUot01ydfGv1rk83Bte5uVXuPuXlel599ewxsjxydii5NLk8TjZumuTs4/UEkuSZXt6PQ9VC1a8meE0zz1Wb3e50aMja8msr1te6WOqpInezUjbv3M0JjrrwzlZGEPI0T1qknZGxsdQnZBDZVeRCRcEbIbJF0yxh7yfucEKXKMpBh+6T91BX5Mu0RJ6Rg+5yZIy2gmZdWT2TohFkFuKssgAJBACAgkAEAAAAAAAAAAAAAAAJAAAAAAAAAgEEJJIJISMq/BZlJBFa9pqzjtm3NmtNohnWvZBdpyc2vhnXmuDQyo/6bKubd+niOsV8SPEZcdWP+57rrfmR4vJSc3/AHGf6eB6P21YeCI/zmVIq+Gcd/biWa4M2O2pIwKfJtUabRnun+Lv8l/ydvFl+JvQbOdivSR0a2no+f8ATPt9l4b9N/G22jt4i8HKx0tLg6mKn3IjRPt6Wd+ncxlrR0qjm43hHVp12nv+Zw7KzxMhjiZD08f05agn2IHsTVQexKIl4EShvg1sv/4tn9mbETDmf/Fs/sWg/K/1QX/7iz/qBk+qS/8A20/+oE0fLQAVHsPQdff1ev8A6j9ZenIduBWv0flb6dx31ev+5+r+hLWHD+xP+kOuGAyqUBgMsmIQCAKAAhWpXgFQyUxJr38IyuWjTyrUonPsrTGfbj9Ssag+TzORY3Jnc6hb3Jo5kMSV0/B5Ho1/KvQ1ZcjnKmVpvYvTZPTaOvjdM7Um4nQrx4wXg4s/O1/Nxyf4RQh4OVl1pN8HpsiKUWedzZLbOHbp469Gy1xrOJMp7C1/myIvg4c5x3yjejG3tlpmP3KRlsvIvLiJysufk6Vk9RONmT5Z6/ixfL/yef1WhattmOK5LSltiK5PptOH0+C9eX+S6QZbRDNuOFUFtEaLxeVBKGiSKBJAAsiSESShJJBJKAAMigidlQTFLEyZRLuloiTZnxod00TXTo19rp9OxdyT0ewwKeyK4ON0yhKKej0FTUEjLJ9F49TdjwjJ5RrRtRf7q0Zde9qx5FpRMFkfxMv3Eyk2mtBex57qabbOZj4jnZ49zvZlXfIjEx0pbaCnxZ8bEjGuPBtqKivBaK1FIiRVfHBBWRK8lmuA2n0xxQkN6KOWy0UyqNbYceBstHllpGVyYPt7kbNOO3ozU0d01wdSrFSXgvIzyvY5V1PbB8ex5TqsXt6Pe5VK7GtHmc7C75PgtMXBuw68S6ZOZs1Y8z0VfSO6X8p0aOjR43En4uG+fteaqwpS9joY/TG2uD1GP0iHH4nQr6XGP9I40w8zz+N0jaW4nRq6Ml/SdynEUfY3I0pLwTx1a9Di1dKS/pNyHTopfynSjWkZO1E/F1Y6pGhDCiv6TPHFil4NntJ0ONfhGsqUvYyRrXwZe1E6EitwiqikTpFtFWXTjjFXrZPkhoeBZ9NVJx4OTn29kXydK+1RizzHVstJPkwyef6Nsji9VzG01s8xbNymbufkd8mtnP8APJnXy/t29yTr8TDKPJl7/YrIh5OeSmmwXhpk9vJLOfaqLJllFDRK3w6xyYizJ2bHZoKzD7Y2wiziTGJCbh1CRKMqhwO1bJVmuq8kpsvpFlFEt8O4r1Tkn5N+q9pLk0FHQ72g6sN3Hfoy3xydfFy/HJ5Kq5rXJ0KMvt1yayvT1ev6ezpyE/c3IWo8nj5/jk6VWcmvI69HV6noq7UZPuJnEhmr5M0MxP3HXdj6HV7iNmispa8kSzIr3HV/7Df7iHNI5cs+PyY5Z6+Sek9Mjr/dQ70zhvqKXuV/9Uiv6ieqZeqO45oxyuSXk4cuqx/3GvZ1VN67h1n+frtzyEn5IWUn7nAee5e5kpyXJ+R1fHPr0EbO42KntnNxpOWjp1ISt8a2EWRVFkWbdAwGDoAAAAAAAAAAAAAAAAAAAACQAAAAAAAAIBBCSSCSEoZEvAfkiXgIrUvlo03ZtmfJZpbfcQzrO3uJoZkkq5G5v8DmZ8tVyKuXffp43rc+ZHjr3ubPT9as/JnlbJbmyMv08D0X7QYpyMu+DDJbZy/7cSi25HRxFyjSjHk3KH2tFNv/AJeh5P8A07ePHhHQqg9o52JPejrY+paPn/RPt9l4v06WPHhHWxI/kjmU8JHRxJfmiNH7ehm7uPHhHSqXBzsZ8I6VT4Pe87h2MqMhjRkPSxc1QABQD8AewgrEw5n/AMWz+xnRhy//AI1n9i4/Lf1TX/7af/UC31UX/wC2n/1AkfKgAVHvfpwt9Xr/ALn6t6KtYkP7H5T+m3/9ev8Aufq7o3/xIf2JQ6YY9wVSgMAkQBoEpoAQQrUhrgINipjDZ4Zy8vbTOlZJmnbX3mOeFrXHJw3Q7rGtHQxMFRa2jax8RRs2b8a0jC6Wn5fprupRhwas09nSnFaNK2Kimc23CSJwytc7JeoM8tmz3OR6XMsXbI8nlz3ZL+54vpzkep55WjNbkwlwJeSHLR4+zLtenjPokjFJaMndsrZ4GGFtY77zFq3T4ZyMt+To5L0mcfIsbbR7viw4+P8A5PbOVqOX5Gev5MSr7nszxXaj6PV+nxXovyyXbKNktkF65ecNk7Kkk4p/aQEuCdCxKAToaHAiWCiTonioSRokAVbLEduyKmCLKOyEi7lpExSX7UcDewKHKa4NSDc5a0eh6Vjp6bRNer5dXXc6djP7fg35VNLwZ8GtRr/7GxOKMsn0Xm18c7tkispNHQ+0mY54yZjx6uE+mvCTcSXLkzfZ7VopKonieNa2GzHB9jNmcXrwa04MhMxZo3bMm9o0W3AvC9+CLWkja3yS5cGKM015Lppleq2Kvkjs2ZO1Ihy0aY/alqjgZqK9yIh+b0dXDw02ma44sazYuLtJ6OgqNLwZqKVCJn1+jWYqOVfQ2vBz5YHfLweilWpFVRFMvziuWPXHp6al/SbCw+32OoopIlpMVSa40aqNNcG3GpaLqKRfZHGkwjEoJGTtWhonwSvJEdpOhsbAkjY2QEdCdsgDie9NsEhgkVIm9RJbNbIuUYvki1ns2fGOd1C9xizxnVMlttbO91XM4fJ4/Nuc5MyyeD697mXScpMjX4F3DuZLhpaMrHg7bcq1dvuMklwX+zzssoOXGiOOa6rWCD5Myi2WWP2vejYrpb9i0jTHz1r9rI7Xs6UcTa8Flgr4J46MfNXPhW2ZlQ2vB0qsBP2NlYXauET8Vv6mVcGWO/gmND+Dt/wW34M8emrW9D4pniycL7D14KOh78HoXge2iy6Ymt6HxXniyeb+zJexaNbR6B9OW/Bjn01JNpEcZ5+TKOP28GKUUb11Eot8GnZCS9iOuTPVlipvRaNrTMfhFfct8kY5ZYt6rJa9zdrzWvc5MeC8Z/sfJ16/Rx249Qa9zPDqT+TgOa+S0bP2T13YeuPRrqT15KT6i37nCV2vcrLI/ZHWl9kdeXUJb8lXnya8nFlkfsxvJkifkxz9rsTzZfJrzzpb8nOsyJKOykJuxk9Tj6Lk6H8ZN+5MLpTkjUhBys1o7OHg9yTaJdmqZZM2NVKaXB1MfGe1wZMPEUdcHXpxktE8ejq10xKtJcHShHSMdVfabCXBMjsxx4IsipOy6/EgjYCUgAAAAkAAAAAAAAAAAAAAAEgAAAAAAAARBOwhJJAIOjRElwTsh+AnjQyI7NNw5OlbHZqTjpkM8vpj7fxOV1OOq5HVckjkdUtj9uXJHHDvy+nz7rT/ADZ5mb/JnpOtTTm+TzU/5mUzrwPRfs2P2O3aEuEc/wDtyifJtUR20aUf5jo4vsZbb9PR8f8A6dPGg0js4iOXjs7GEts8L0T7fY+P9OnVHhHQxIfkjTrWkjpYf8yI0ft35uxjw1FHQq8GlS+Ddr5R73nji2MyMhRIuj0MXPUAAmxCH4C8EvwRHwRARgyv/jWf2NgwZX/xrP7F4Py99Vv/AOtP/qA+qr//AG8/+oEj5SACo979N/8A+vX/AHP1f0b/AOJD+x+TfpzJLrFf9z9Y9Fe8Ot/okdT3A9wVAgkEiCGSQwBBJAAeUNEgYpQ2U+0bGhpAYY16Zk0WZDK5IYZmjkvUWb8/BzsqS7Wed6b9OrTPtwM6x8nncj+ZnezpLk4F7/JnzPrv29rzxqy8lJFm+SrPM/29CfpVPkix8BmOyXB16XJ6r/i08p8M4138zOplTOTZLcme75Y+E/k8v2mCMuuDHWZfY93X+nymy/ag0W0RotWNqoJaIJxTFl4BC8AslJKKlkQhZElUSEJBACBkogBM/SyZZ8ooiWyIpJ/k2sWrumj1fTaNRXB57p0e6aPadPo/0k9E19F4cfpv434xM+9mOMe1F0Z5Pf1YsiXBKjyE9EKXJm78f0OCKOsyORGyUSsMqtmCdH6N7Wyko8FbFpXHuq0actxZ27Ktmjbj/orYt1pxtaM9dpjlS0Y23ArxFrf79kpdxo13cnRxo9+jXCOfK/bYxqdy8HocKrSRo4mPyuDs0w7Yo6MVGdLUSBsGsQAEhCASQVIEkEkpSGAwIAAAAAAgwSiRJDJKyZVdjseo7OLn5Dimda6aUGee6i3Leitce+djzvUchybOJYnOTOzkUSnJmGOC2/BV4u/TbXK7HFb0VSbl4O5Hprnxoy19Gl3eCljlx8lrkV47kvBsVYDb8HoKektR8G5T0/t9hxrj43nf/TXpcGSvpz+D1H8Ekl+Jkhgr4LSOjDyPP19PevBlXT/0ejjhpLwWWKvgtI6MfK4VWB+jaWBteDsQx0vYy/ZXwTxrPNxw49P58GxHBSj4OoqV8F/tIcWmhxXg8+DLHCXZ4Oo6lvwWVa14HFppcOeJp+DHLE2nwduyhN+DHKjS8FbGWzQ8xkYC54ONmYnanwezvqWnwcfMxe5PgzseTv8AO8dZDTMPhnUy6O2bWjnzjpmdeRtw5VN6RR2aLMwy8kxy3LjI7WWjM19llPRK+GxlnY0jA7Xss33FHANperRsbLd2zDvT0Z6q3ImL467kib2jYxa3JrgyVYjm/B3MLpr0notI9DRprDiYfdYuD0mLh6iuCuLg9rT0dqipJeC8e1o18Uox9exuwr0iYRSMy1ovHo4Y8VitGRFQvJZosAAkAAEgAAAAAAAAAAAAAAAAAAAAkAAAAAAABAQARUkkEhEQyGxJ6RrWW6IXWsaNO1iV+zG5dxHWWbBe32s851STUJcs9Lavx2eY6xNKMif9PN9FeE6rJub5OLr8jr9SmnNnL1yc2bwd9+0p8ETXBJEvBmwikF+R0cZeDQh5N/H9jm3fp6fjn+Tr4yO1hI4+Lzo7eJE8fe+x8c/xdOpcI6uGuUcuvhI6WHL8kR5v27c3bqXBt1+DTpe0btXg9/R+nFsZl4Looix3Rz0ABZA/BEfBL8Mhfykf7EmDL/8Ai2f2M0TDmf8AxbP7Fh+Xfqp//Wn/ANQK/VR//t5/9QJo+WAAqPZegZ9vWK/+o/WXp6fdg1/2PyF6LtVfV6m/9x+svS1yn0+pr4JHpgECoAAkQQySGAIJIAleCGyURrkCUSyESBXZPsRJBPgpl+hgvekzjZlj0+TsZH8rOHmSXJ5PqydmidcHMk3s4t75Z3MrTTOFkL8mfN+i9r29Ea2+S3sY/cyLwcXHZ/pjka9zNibRrWtM6dH7ef7cuYublM5kv5mdLKZznruPoPLHwP8AJ5/tlrXBl0Vr1oyHua59Pl879qNEF2ipOSlVKGRooximJIC8DRZZKJTI0SiBKJITJCADQCAsVJb0BKQaJiStSekQa53J2ekw3OJ7nCio0pHkOjUPui9HsaFqGiLX1Pgw+o2VyWSKxTL7SM7Xu4Y8QyF5G0CHR/oYTIZCJZsyDXBWLJckOLSsTjtmOda0bHBWa2iOJ659lSfsaV9LOtKHyYZ1pj4q2uPXVLvR6Dp2O3o1asZOa4PQ9PoUUuC+MZZVt41Halwb0YpIpFJIsjWKjjyNE79hsuI0SNgAVZYgCCSCQJDGyAAAAAACWVRLICySsmWKtBS1pZG9vRysilzZ3J1qRhlj7fgqxynXn1gdz8GeHTl/tOzHGS9jKqUvYjjC6euPXgKL20Z440O7wdP7SZCpXd4I40w0SNeOPHt8F4Y6+DaUEkTGOifi1mmMEsdfBMa0jYaI0Txea4xdhDgZtEaLcXmEY1HRZItoaHE/GCiW7QiSFfhFe0nWkSQSn4xjkuSso/iZNclnFaIsUzwlcq6DbZp3U7Xg7NlSZq3VLXBSx5+7U8bn4/8AqN6OHkVtM9hnY/L4POZlOpPgws+3znp1crjSTMMkblkNGtJFXj7cbKxpbKyizMoMrKLJimuXqIIzqtNGGMXs3KaZy0TI9HXrtjX/AIduS4Olh4jl7GanBnJrg72B0/tX5IvI9XzaOtPDwfz5R6CjFUILgy42JGMt6Oh9ldmki/Hq6/Pxgrq/HaRtVQaRkqqSjyZe1LwWkd+GvjGloyIaJRaNuGglyTtEEiQAAAAEgbGwAGxsABsbAAbGwAGxsABsbAAbAAABIAAAAAAACATogIqSSESERWf8rObkPWzpy/lZzcleSq/Wg5PZeEjFOSi+SFbFEdYZ1ntacDyfXXpSPQ35MVDhnjuu5O+5bJ79PK9OTx+dLdjNEz5LlKZiS+TnzeHtv2xtlt8EuKKsopimPk3sd8o0I+Tex1to5N/6er459u3h86O9ieDh4Vcno72NBxS2eNur7HyT/FvxRv4a/JGjXydPEj+SL+afbpzdehcI36lwadMeEbta4Pf0fpxbGVEkaJOyOepIJILB7EexI9iBWJizOMSz+xmRgzv/AIdn/SWH5Y+qMt9Xs/6gY/qdJPrFn/UCaPmgAKjsenbftdSrf7P1X6Hy1b06nn+k/I/T7PtZUJfs/SX026mrMWqDfsB9hi9okx0S7q0zIAABAghkkMkCCSAJRJCJAAAAzG3yZGYZeTPP9JjXyZ6gzz+XPbZ2cyeos89ky22eF7MnoefFz8l8M4uRLlnXyXwzh3y/Jnz+29r3NOP0xb5Lb4MafJffBzt8v0xzNazwbEuTXuOnz/8Ap5Hvy/xc3KZzv6joZRz/AOo+i8s/T8+/ksvutmpcGVLkpUuDNo9vXPp87b9qSKmSSKNDJFQzGy7KMRMQixAJXWBBJAEoglBCwACD3EkiGPIFtJIUc2iXgviQ7ritaaMe5PX9Hj+MT01a1E4vRaPwid9x7Slr7DwYfUSmS+THsumVexziNErySyq8kHfpLCJZBPVVtlX5GyGWStvgJj2BJVLPBg02zPPkV17J4pWXFq7muDu4tfajSw6daOtXHSLyM6trRZeCGRsvwVf8xYjXJJIAAlIACEAAAAAAAAAAAAALUAAZ1V+SCzGgjio0W0Roji8iEWAJ4X6SiUQghw6kABPUDRIB8kaCRICehJACLRkE7AJVSyGgE1Sfg1rF5NqS4ME4la5tk7HGzIb2edzaXt8Hrr6t7OJm0pJmVjxPTp7XkciGtmhLydjNhps5cq9spY8Tdo+1Y8luzZeNT+DaoxnJ+BxXV5/thpx9vwdnDxN64L42C3rg7eJh9uuC8j19HmVx8PWno6lVOkuDNTRpeDZhVovx6+jT8VKq9GzGOkTGGi+i3HdjghIkAmRrIEEgkqoXkke5KiQAQkAAAAAAAAAAAAAAAAAAAkgkAAAkAAAAAAABJUlkAqwHsQ2RVYpZLUWczIm+TdulpM51r3srVnOyJPZijtmxdHbKJJIp1z7K0MtuEGzxXWr9zlyex6lNKlngerS3OXJafp43ryceVm2V7inuSjLJ4my/a7ZZRTRibLKb0Uaa11BbN3Fj+SNGEm2dLEW2jh9H6ex459u/gLhHbqXCORgx4R2qY8Hjbb9vr/NP8WxVwzrYi5Ry61ydbDXKN/NPtrm69C4NyJq0rg2Ue9p/Th2ftkICYOyMKkkgkJGQGPYgDV6hLWFb/wBLNk0Oqvtwbf8ApZeQflX6ky7utW/9QMH1Cn3dZu/6gTf2PBAAqL1S7bEz7V9MuoNWVw38HxNcM+nfTfJ7c2tb+AP1Ngy7seL/AEbRz+kz7sOH9kdAAQSQVAhkkMsBBJAEokhEgAAAMczIzFN8GWz9LY/tys5/izz9z22d3PfDPP3Plnzvtr0vPGjlPhnDu/mZ2cp8HHt/mZ4Wd+3uaZ9MKXJL8E65D8GbTZ+mN+TBejP7mG5cHR5//TxP5D/w5WSjQ/qOhlGh/UfSeV+ffyN+62qfBmMNXgynt6/08G/saKSRkKSQyRWJsr5JkQisWiSGT7ENkrGyyKF0QgZKDCAsAAhDLRKslEpi05JI2enflcaViOl0mtu5FMnV5sf8nvOk6jVHg6k33M53TqmqUdDRlX2Xhx/xUaJT0WaKS4Iejn+l+4j3KJl0GMq3khkoMjq8U2NlWyyLRZOxsntHaXitUb5NnHjtowKHJ0MSvei0UrexoaRuxMdcNIyRRrGVWGiSCQ0QT7EBIACUoJABQAEIAAAAAAAAAAAAARw0NEoAV0NFgDqoJZBKf2EoglA4kAEJ4AAHAAhkVPDY2ARFcge4C8llYkBgNBmKSMpWSIZ5YtK1HGz48Pg71kdnNy6tplbHBu19eNy6nKT4NWGK2/B6G3E7peC1eF+iljzNmjtcWGFv2OpiYPK4N+vC58HRx8RR1wRIvq8/2w4+GklwdCulR9jLCnS8GRQ5NcY9bTphBaMsURGOkWRZ0/GRZBkkNBaKkk6AWCCQEVAAJUAAQsAAAAAAAAAAAAAAAAAAASQSAAASAAAAAAAAMAIFT7FJF2Y5MiqtLKlyaT5NrKlpmn3FKljsga1q7Ubc5cGre12spXNsrz3VbWoM8J1K7c2e36x/7UjwWevzZafp4nsrSi9mTRSuJk8GeTxsv2q0NcBsgrW2tkrXJ18Jco5NS2zs4MOUef6L9Pb8U+3fw3pI7FL2jlYlb0jq0x0eLn/6fXeef4tyqPJ1cVa0c6hbOlStJHV5183UqlwZ0zSqkbUJfs93TZxxZsyZdGJMyo7I56kACgPYAhIcrrs+zAt/6WdTZ531TkKrp1rb1+LNMR+WPXdnf1m7/qBperb/ALvV7nv+oC/seYABUD3f0+tcepVrfujwh7H0FPXV61+0B+tehSbwq/7I7CON6f5wa/7I7JFEkAEgAAA0AAAAAAAQzDYzNI1rWc26/S+H7crPfDPP2vlncz3wzgW+WfN+yvW80aWU1pnGtf5M62U+DkWfzM8bL9vZ1/pWPkmXgheSJMkzU9zHe9JmRmC/lHR5p/k8b3/+HKypcmlF7kbeUuTTh/MfR+d+efyH/qt2pcGx2mCl8Gzvg9jX+ni5KNFJIyMpIvlGEv2wSRXRaXkqUaxAAIXidEkEhASQSBKJKkhCSJJkotwyYmMTTO10WP8ArI5ajto73R6f9RPRWvR8k+3t8PSx0Zm9mHHWqEi5lX2Hkn+K22PJRtkOeijrzZNIGF2Eqex1EjJtkbKuSK94SyE70YfuD7hMGXvZKkzXU+S8Zo0ilblS2zrYkVpcHIx5baO1iLg0jOt9LgkLwC6AAACCSCQAAAAAAAAAAAAAAABAAAAAAAAAAADQBKAAAAAAAAAAAAARwAASJIJIIT0IJICGKaNW2vu8m80Y5Q2QyuMrmPHi34MkMeK9jd+1+i0av0RxX8WLXhRFexnjWl7GVQJ7dDi01yISLaQBZpJwJKlkFuAJGiEI2QydFWOrQHILEpqoJaIXkljy9SACGgACQAAAAAAAQAAAAAAAAAAAAAIAgEBIAAAAAQSCEJMUzI/Br2SIq0aeTFykazr0Z7bPz0OGiE5fpqT0lyc3MuUYs6V3ucPqPEGQ8/dk8/1fKTqktnjcmfc2d3q1n8yPNzbkylrwPXl9prLSKwWiJyIcNNbKpPuIjLkunyZbLxfX+2auD3wdnp8XtbOZj/k0drEjrR5PoyfR/wAfj9x6HFS7Ub1fk5mJPwdWpcHmW/5PrtOP+LfxzoQa0cuuxRM6yEvc3wz5+kZ4ugrNeDLC2W/Jz4Xd3ubNT3JHp+fOuPPF1KZNm3HwalK4NteD2Nd7HNlEghEk5IRLwRDxyT5GtIrEDaR8++omc6MCaT1uLPfvwz5D9Vcl148o79mbYj87dZtdufZJv3BrZ0u7Im/2CKNQAEAeq9Dz7es1f9SPKnpfRktdZq/6kB+vfTkt4Ff/AEo7j8Hn/TEt4FX/AEo9D7CwVJI9yQAAAAAAAAAAAiXg1bmbMvBp3+5yb/00w/bj5z8nDt8s7Od7nFtXk+b9lev5o52W+GcmXMmdTLOX5kzx7+3sa/0qQy8lwURaIzirMFr/ABZsyRq3+GdHn/8ATx/f/wCHJynyacX+RtZXk1IfzH0Xnfnf8h/6rdq8GxEwU+DZR7Or9PFy/Q0Y5GVmOZpXNP2wMoy7KMpXRIgAFVokkgkIAQwBYEEhCRHZBkiuAtitVzJHq+jwSaZ5Op/6i/ueu6U9Riylr0vHPt6iqaUNbIlYt+TSja0jFZa+4ytfY+Sf4t52r5MbtXyaf3GyNtlXTlGy7f2Fbz5NbTZaEXsgn6bDtKu4o4Mj7bJQt939j7pT7bJ+2xBZWE/eaKKt7JdTNIpXRw7W5I9Jh8xPM4NT70enxI6gjWM63l4BCJNEAAAEEkEgAAAAAAAAAAAAAAACAAAAAAAAAAAAAQAAkAAAAAAAAAAAAAAEEgACQKN8glrkaCOJ0gAQtInYbIATxAJ0Q+AlPsV2x3aKSsS9wi2Rk7iO81p5CXuYJZiT8lWGeyR0O8bTOZ/Gr5JWevkKY7nTJNKvKUvc2oT7i0dGOfV9gAlbgACqAAEgACQAAAAEAAAAAAAAAAAAACAIBASAAAAAAkjRVCsnwad0jbn4OffLyQtGra9zRdS1ExPnkq7PYhXO/TFkWaTPOdVyXGDO9ky/FnkOs2cSWw8r0ZvL9RyHOxo5q5M+W92Pk14ozrwfRl2smkkYLEZWyjJcvWJJ7MqS0V4QUtvRz7b9OvRj2uhhpdyO9jx4RwsNfkj0OKvxR43oyfU/x+v9Onhw5R1tqEUcqh9ujZsv4R5OefK+r04f4s87te5WOQ2zSlZsy0pykX1Z9pswdfGm5NHXx47aOXhV+Dt0Q0ke15Xn7Y36VwjY9jBUuDYXg9vV+nFl+0IkhEmtUR7k+w0GysgpZxBs+E/V7K1uOz7nky7aJP8AR+b/AKu5fdlOOzSQfHL5btb/AGCk3uTBUVAAA7npa37XV6X/AMyOGdHoln2+pVS/5kB+w/SV3f06p/pHqe78dnh/Qt8bek0tP2R7dfyk0E9ssViixAAAAAAAI9yQGgSQBDZp3+GbU3o0smXDOL0X6a659uPmPbZx7uNnVy3yzj5MuGfNeu/b1/NHLy5b2cz+pm7ky5ZovyeRb9vZ1z6S3sqNkNl4jMb2at70mbDZr3LaOjz/APp5Hun+Dk5S2zTj/Mb2UjSj/MfQ+d+efyOP+VblMeDYitMxUeDY0e1q/Twc/wBJaMU0ZSkjauWftrSRibM8kYWildMV2SiNFkiqwNk6BAjY2CAhZcltFYlmEKt6ZdS0ij8kvwKtiyUrdi/uet6W9xSPIUy/NHqelS8FK9Pyft6GNO1vZDo2zLW32GWMdoyr7Hyf+WsqDIqDYUTIolHTk1lR+i6p17GwohoIn6a/2h9kz6GieIYPsk/aMw0IMUaeS32TIvJljHZpFKy4dOpI72OtROXjQ5R1qlpGsZ1mSGiUDRCBsEAAASAAAAAAAAAAAAAAAAGhoABoaAAgAAAAAAAQAAkBsEATsbIAE7GyABOxsgATsjYADYRBIE7J2QAJ2CvuWRCQjZYaCeoAKSloK3Li+zHOSS8mGzIUfc52TnqKfJHWV2yN6y9JPk0bstLfJx8jqiW/yOXb1TbfJFrm2eh27+oa3yaFvUte5xbs5v3NKzMb9yvXDs9DuWdY7X5KV9acrEjzzv7n5JhZqSeyOq4bu177By/uJPZ3Me7aR4LpeW9pbPYYl6cFyWlelpz67cWmiO7k56ydPybEbU47LddkrZBrq0urCEspGyO4bJFgQSSGgNkMkSAgQAAAAAAAAAAAAAIAgEBIBIDQ0SgQIAKyekVSpY+Dm5D5Zt22GhbLbAwd2kzFrZM3plfYqw236aubLsrfPseF6zf3SktnrerW9tb59j531a9uyXIeH6c2lOHdPeyrWjDCxt+TLvZWvH2XtVZVoyaIkiKyn7a8i9S2ysy9C/I5N1+nqeTDtdfCr8HexmopHFw1wjr1vSPD9OT6/wAGv9N9XJIrK3uNbvMlX5M8jPLtfSa5yNiCbOhjQ5RqVQOni18o6PPjbVNtdbDr4R2KoGhhw0kdWuPB9F5df08rdl9ssFoyexVFkevhOOLKpAINVTu5Gt8jQctcEcGr1GXZh2P4R+Wfqllfd6nJb8Nn6b63b2dOue/6T8l+vsn73Vref6mX/wBDxb8gAoAAAGfEs+3kwl8MwExepJgfpv6YdXVvT6q2+T65TPvij8z/AEu6o4X11uXB+kOnT+5jxl+iRvPhBB+AiAAAAAAR7kke5IEkEkAY7PBoZPhnQmc7Jfk4PS21uNle5xsvjZ28n3OHm+58z6/29jzOJkPlmqzZvfJr6PL/ANvY1/pUhltFWi0M1WYbPBmaMNp0+f8A9PK9k/xc3KOd4mdPJXBzJL8j6DzPz3+Sx/yrex3wjbXJo0M3Ycnt6v0+d2raKyRk0VkjauKX7a0kYmjPIxSIrolYhsllWZ1pFtjZQECwIRYAuCdkEJ8hCxWWy65JcSUysdW+89T0jyjzVcfyPSdJ4aKWPS8l+3raI7gjNrXBhxpfgjY1sysfY+S/4iLJjROivHTlTZGwBIT9GxsgFuCdjZAHBZeTZpW2jVNvG5aNMYpXUxq+EdCC0jWx4/ijaRrIzqyBCJJQggkgAACQAAAAAAAAAAAAAAAAAAAAAQAAAAAAAIAASBBJAAAAAAAAAAAACQABIBAaHgkhg6bDZG9IxTtjH3CmWXFpT0aWTkqCfJiy82NcfJwM3qXD/Ira5Nm3jay+oJb5OJldQct/kc7KznJvk588lyfkp1wbN/G3dkyk/JqO1/JjlZtGpZfr3K2uTPda25W7NeyejSnl69zXnmbXkra57n1tTyVH3Irzlvyci66UvBSpWvlIjro0/deywM2Ka5PV4Oc3Fcnz3pld0pLg9t07Hn2LaLSvZ0R6Oq7u1ybcbHryczHhNPwdWFe618l5XfjPpKsfyZY2Mw/bfwXUWiyWzGwupmvFMyR2SNlPgsmY4vguiRYEIkkEAAAAAAAAAAAAAAAIAgEBJJBIEoBAgRsw2S4Mk3pGldckVSw3T8mpKXJa23bMO9kFYbpamisrVGLJujuWzQy7OyDIcm+/TldZyV2Pk8FnzU7JHoer5Le1s8ve3KbIfO+vJjjFaLER4LtEPO71G9FZSEjG2RUT9jWzNRH8jEmbOOvzOHffp7Xix+3XxFwjoRekaWMvxRtcngeqvsvFj9MqezbxY7ZqVRbOniVcnlz7ye1LzFuUVnVxa+UatFXg6uNVyj2fJq+3JtzdHFhwjowXBq48dJG4kfSaNfI8vbl9rIkEo6ucc3ehBJBKYbMc3+aMhSxc7Jg856uy44/Sb9vX4n5H9T5H3+p3Pf8AUz9EfU7q38Pi21KWto/MnULXblWSfuy3foaYAKAAAAAA9r6BzXR1Stb9z9X+nr/u9Prf/Kj8delLvt9Wq590frT0jb39Oqe/6USPVbJRD5REStosCQSIBIAr7kj3JAEEkMDHPwc3Jfk6Ni4ObkLycHqn011X7cvI8M4Wc/J3Ml6TPPZ9nLPlvXft7vmxce5/kzDvZeye2zDD+ZnncenheLtpFdoiZCXBMaZTsSzDatmX3K2Pg6dF5evL9eP+Lm5EeDmzX5HVyPDOVb5Z7vlzfCfyer7tZ6dG7WuUc/H8nUr4ie/p/T5Dfly8WaKSL74Mc+Tpsc0wYZGGRsNGKcTOtP0xFGWfkqzOtZUDQCIWSSgiWOnFWQvJII6qyIORVFnEtKjpCX5Ho+ktOSPNRjpnf6RPViK2vS8V+3tMaP4I2VwYMWf+ijNvZlX2Pl/8rbJ2YyyKujKpI3ySyrC0/SwKgsdWBUDos2bWK/yNLwbFE9MvKrXosdrsRtHLxruEdGuW0ays6yAgEoCCQBAJIJAAAAAAAAAAAAAAAAAEACQQAAAAAAAAAgABIEEkAAAAAAAAkCAWBAglEFgjqCQAlVsgPyUsn2oKW8RZYoxfJx8zMUN8mXLylFPk811HK3vkpa5dm3ivUOobWkzhZGU5Ipfa3J8mpOwp1523cpZOTZhcmjI5JmC6aSZHXn7M+olateTUusWnyYL79Pya07XPwRYpjjclb7OeDDBTnLSRsVYk7pfys9B03ospNNxI+Lpw8/XGo6ddal+DO1g9EsbXdA9dgdHUIrcP/B3cfp0Ul+CJ+D0dPl48/wBN6FCCTcT0mNgqCS0btOGo+xtxqSRaYPS165i1oYkUjLCDUta4M6Wi3BaYNuyKOtFftmUlMtxErEoFlEybI2TxIkSi3sRsK9SiSNjZKZUgnewEoAIAkEEoAAiWBAAAAAAAAJJIRIDY2QyAMd8tRONlXduzo5dn48Hn821vaMrU4/a6s7mZYs5+PNqfJtufOyOoz+oyW+GzgdUu1FnVyMrtqkeQ6rn8vkjrxfV6OOD1K1uTOVvbM+ZkfckzXgtsPB3bfnUvgbLNIxSI6wn0l6Ziki+yrZGX6Th91Vb2dHFr5Rpw8nUxlwjy/Ts4+l/j9PeOlRFKKM6im+DXrXBtUx20eDvz+VfY+bV8cW1j1HWxoJGpjw4OhRDlGOnV3J0558joY9e9HVx6/BpYkfB16Vwj6Dza+ODZm2aY6Rn0Ur8GY9zX9RwZ3tQCQasgAkqtKh8Iw3T1XKX6Mk/5TR6hb9rAsl8Jkw6+B/VzqX/+3KtSPiFsu6bf7Pon1Nznf1aa34Z84fktkAAKgAAAAA6PRrvs9Qrl/wAyP1d6BzVf0qrn+lH5Fx59l0ZfDP0T9LOsfcxYVOXwiYPtqf4bJg9mOqXfUtGSK7StFwASAAAj3JI9yQBDJIYGOx6RzsjnZv3eDn3HB6v021T7cnLXDPNdRXLPTZb1Fnl+oyXcz5b1Tte7579OPOPLEIcl0u6RtQx3270clwdmObSmhFcGS+PaY4vgxs46Jl9KSXJjsRkk+SkuTfVXB6Z2NHIXByrlpnbuhtM5OTDTZ7Xky+3xf8nh9VjolqR06pbjo5EHqR0KJ+D6PRfp8P6ceZNztKyiXUiJcnX1hjWLRhmbPaYbIlKW/bVl5KNGSS5KMzrXGqgMgheLJklNltkASESQrRF+7ZQhExXjJs6vS5f6qOO34Op0t/6qK16XjvK93hc1I3NaRpYD/wBFG7vZnX2Hkv8AihlkVLIq6qkhkkMNJPpAACoAALOPAjwwpE9xeK10MWXKOzR/KcHFn+SO5jv8TSKVsgA0ioAABBJBIAAAAAAAAAAAAAAAAgAAAAAAAAAAAAEAAJAgkgAAAAABQkgkK9SCCSAJI0SE8AwRsFUk9Ghl3dsXybd8+2Ozz3UctLa2RXNsz45/UMzTfJ5zKynJvk2c7I7m+Tj2SbZnXnbtiJz2zDLkuyraRR52efWKT0jSybeGbGRYoxZyrLHOegy/bXtbnI3+n4Er5Lhk4uE7Zx4PZdJ6UodrcSXXow6npnp/ai3E9Rh9KjUl+KNvCphXBcG7uK8Ex6GGMiaMaCXhGyoRj7I1HkKHuYp9QivctHXjlI6fdFEOxHGn1OK9zWn1eK9yy35pHfdq+R91L3PMy6zFe5il1uP+4dUy3x6t3x+UR9+PyjyH/ra/3Erra/3EdUm+PYK1fJZWL5PJw6yn/UbEOrxevyJlbY7pXqIyTRbRyMbNU0uTo12dyLNsb1nSDRCkGw1kSiSqLAqCCSAgJRBKAlBhBgQAAAAAEogleQHgbDIQFisnpMlvSMNk9RZFGrcu/uOHkVd1jR1fu/lLk0prc2zGpjQdfYtkSt7a2zPkL8Dk5M3GtrYZbsvpgzctfalyeI6pktzfJ2s++SjJbPKZc3Kb59w+b9eX213JykZ6/BijEzwaQeRlftVt9xWRlemY5IhHVCNbYk9FYy5M879NtOPa2qa9s6uPXpI5+Pzo61XEUeL6sn1v8bg2qoeDeor5RqUvejpUR8HjZfdfWav/AC3seHB0KK9s06UdXDh3M6fNh/kz3X6b2LX4OnVHSNfHr8G9CJ9BowednkyQMpSKLnp4z6c9AETssoDZACUPk4nqW1U9Hue9cM7T8nifX3UFj9Jvj3aeicZ9ofmH1nk/f6rY97/Jnlzqdcv+9nWS3/UzljL9pAAQAAAAAAnpn0/6Z9UlRm1193Gz5gem9G5bx+rVc8dxMH7F6Vkfdx4PflHRb/I856XvV3Tqpb29Hooru5ZFGQAAAABHuSR7kgCGSQwMVi2jn3rWzoz8GjkJNM4fTOxvqv24WdLUWeXzfymz1WbBdrPM5UN26R8/u19r19efI1KKHKa49zurDSpXHsOm4Sny0didKjWl+jP8P0t+bleOzqO1vg5zjo9P1DHWmecvXZNo8/bhyu/Xn2NeS5KS4My01sxyjtlMbxnunYxzW0cvKh5OpNaRzMrfJ63ly+3yv8lq+q5/bqRuY/lGm21Iz0Tfcj6Pz5fT4T2a+ZOpFcFtEVPuRlkjuleZVDBa1ozmKyK0ShpT8mNmxOCMMlopW2NY2QS0RoqvEFkQlstoLJXgkgbIQkq2WRWxaBIq5HW6V/7qOZGCfk6HT5qFvBWurzZcye8wd/ZRvrwc3ptqlVE6fBnX13iz7EFkRwyyKvS/YQyWyA0n6QCdDRXqqANohyQ6C8kTekVjNbKWz4Lyq1u4kvyR6LF5geVw7H9xHqMKW4GsUrdQHsDSKAAJAgkgkAAAAAAAAAAAAAAAAQAAAAAAAAAAAACAAEgQSVAkBEgQAQBICLaBIgAkhbiQQGwhLKsq5Mxzs0ieK5WcaWfb2wZ43qWU+9rZ6HqmUlGS2eKz7u6x8mdryt2z7a9ljmzXmiykY7JozteZtzUkzUuu7d8mxKWznZb0mVcdy+2rkZG98mHH/O1GvbPctG5gRXfFktcHquk4qfa9HsMWMYwWjyvTrVXFcnVl1GMI/jIl2aspi708r7UfJqWdYUXzI85kdUsltJmhPJnN8ktvzSPS39bXOpHOt6y34kcSU5PyU4fklS+l07OrTf8AUYJdSnL+o0JJFHpEsMvU3Z5tjX8xieZZv+Y1XMp3bYtZX02tt5k/kLNnvyaMpMqpFOpnorsVZs/k3K8ye1ycGE9M3aZttFpXXq39e16Zkyl28nqsWTcEeK6U+InssF7rRpHq6c+t5PkyJbRQvFlnbKlIkAg6ggAASiCQJQZAAAAAAToCCUNE6IFWEGh4IETekad0uGbFs9I519vDI6NWctSZE+I7KRk5yey1rXZozTleRrWST4ONmtdzR0LrO1s5GZdHbbYeb6Nv04HU0kpHk8iS+5/3PQdWyk7NJ8HBsjGUth896M+1WHKMiiyIRSMqeg8+1TTRWTMkpbRhkyKRVrYrrbkVbezYo8o5t2XI9Ly6+1v4tDeuDoRjpaMGM0kjfhFSPC9OT6/wa+MmNHckdrGq2kaGPTymdjGjrRw449r3sbyNmmn9HWw6tGvjV70dXGqSPT8ur7c27L6bdMDZSMdcdGwlwe/qw48+5CXBJBJ1KAAIQAEEpRY+2DZ8U+qnV/t121KR9i6heqcSc2/CPy99T+rO/qlsFLa2WxRXzPKs+5dJ/swkye5NkFAAAAAAAAAOj0W77PUK5b1yc4yUTddsZL2YH669A5sb+l1flvg97B8cHwL6X+oG6oUyl44Pu2Jb9yqLJG2ACAAAEe5JHuSAIZJDAxz8Gham2dFrZqWR/Iw24djTXeVwuoLUGcOun7ty/uei6jDcWc/Bxm7U2vc8vPT2u6bPp0sLEUILgzXV8G9CrtrXHsa9/gnLT9M8dna8/n1fizyWdDVrPbZsdxZ5HqNf5s8P14cr2PNl2OYnwR5J0R4PNdWU6ia4Odkw8nSfg0shbR6Ply+3gfyOr6rj2R0yKpakZLlpswQf5n0nny+nwXv18tdjGltI3Hyjn4r4Rvp8HpY14Gc5UaMFvg2FyYrImsVka7XBgmuTaktI15+SlXjA0UZeRRkNIR8likfJYqskAASvJM1vRA3sJifCL41jjaY2+CKnqZSrasuZPc9It3CJ30+DyvRb1+K2eog+5bM6+q8OfYyplisSxV7WNQNkNlJT0hW0v0yOSRSViRglaYZ2lENiVujDK4wubZCi2EskbXstKTaKxrMsatlorWbD4mj1GDL8Ueaoj2yR3cGzSRrFK7K8ArCW0WNozAASBBJBIAAAAAAAAAAAAAAAAgAAAAAAAAAAAAEAAJAqWI0BKJIRJAaI0NjYOp0gUcyO8nh8mQjZjdhjdyIVubO5aMbmYJ5CS8mpZnRh7ojrDPdx0nNJHOy8tQT5NO7q0UnycPN6l3b0yLk58/RONXqmc5WySZwbrO+WzPk2Oc29mo3yZ2vL27O1WT0jXlJ7NlraMMoFa5M71ictI5WbY3s684bRo3YveyGXHFjCU5+Dr4WPpJ6Jqw0pLg6NUFCJZfG8Z624RInbJmOVuijs2Svc1+7fkspIwd5DnoKXZWWczA58lZWfsxStSfkMrla2e7gw2T0YZZCXuYLMhP3CllrN9zksprRz3fp+SFlr5FTMK6DkmQaH8UvkywyU/cqtcbG5F8o38Z/kjlwtTfk3se1dy/uWjp0S9ez6UuInsMF6gjxvS7F2RPV4dy7FyWle/wCefTr9xeLNSNuzPCWy/XbzjY2QVTJTJWgCw0EqkjQAAAAAABJBIEjegQyA2Vk+A+DHOekVGDIlwzlXSbkb19nk51ktyItFoxS5MdvKJdnBinPgoz25cjQylpNnluqXuG+T0PUMlQgzxPVcruk+Q8P1bHGzL3OwwRbZMl3vZeENB4m3LtWiiZcInwVkwwUb5KSZdmKaK5L4T7I8s3KKzUr/AJkdTFSejh35fT3fFr7W1TBrR1caG9GtTBPR06K9JHhb72vrvJhyN7Gq2kdOirwamLHwdnGq3onRh2u3LLkbOJV4OtXDtSNfHq1o3org93z6ufbg259XgjMvBSKLnpYRygALgSARRBDJKy4RMS4HqzJ/h+j2yT/pZ+SPV+W8nqlsm/c/S/1E6lHH6NdHu09M/KfV7/vZk5b8sv8AqIc4AFAAAAAAAAAAAHuvQPU3jdRrj3aTkj9V9BvV2FXLfsfjH09kvH6nU9/1I/WXonL/AIjp1T7vYke2BCfA2QJAAEe5IAAhkkMCrME4+5nZWS2hZ2EvK5mRT3tojFxOx70b32dsyxrSRy3X9tvn9DWo6NHJjpG80zWyY7iM8ZxXC/bh5S2meY6hXuTPV5MdbPO50dyZ857cXu+XL6eenHRiaNu+DW2ae+dHi39vSiGa9y4Nprg17Tq8+Ul+3le7X8p9OTfHlmm12y2dO6vezn2rT0fRebbK+D/ktGUtbmJLZ0o+DjY1ig1s61NsZI9jX9x8rtx5WaKKWeDMvBisWzeXjPFryNaa5NqS9jBOJWp61mijRlktGNtFWmKiRIY2Q0WJRVMsiEDEVsNkwYOoaMcvx5MzRim0ylhh3rr9JyHGcVs9vh291Wz55gz+3Ymz2nTcmM6lopY+i8O2T6dpTJ+4aylwVdhR9Frvyn0zStMUrdmKTbJhVJsi1vEvkr9ts2FSzLGkos1oUszRpNmNei6ihw6wfb0ZIQRZomL0XiKq12m7iW6aNGb2ZsfcWmaRnXpseXdEzmjhWpxN1PZtj+lKkEbGy6vUkDYB0AASAbBAAAkAAAA2AABGwAAAAAAAAAAAAAAACTgNAkhCCGw2UkyVblIOQU0jDKxI1b8pR9x1nnskjastSMMslL3OVfnJe5oW9SS9yLlGF3x3bMxL3NS3qCinyefu6p+zn39Sck0pFblGOfojv3dVWnycjK6m2+JHJeTKXuYpSb8spa49m9tzz5Sf8zNezJb8sw9yXkw2S7vBS1yZ7LWaVmzE3yY1vZdeAx7VosSI0TrZAwzKaXwbEopeTG0hxVVJIlshplGmi0VqWtldEOWjBZkKK8kjPKSRq25Ciad+br3OfZlOT8hPwtb1uZ+zA8vfuaTcpEqmyT42GmOm1nnkt+5hlkfs2qumXWrhP/Baz0/la3z/AIHG2PnrmSyP2Y3e097N2XQ8lPw/8EWdEyIw3p/4HGv9dovIe/JaOW4+5M+n2w8p/wCDUtosj8jimWiulTn/AJLk7uFd3uJ4qrvjYtv3PU9KvS7dk8X1auV7zptrUY8np8PI1FcnlemwdkYtHpsbHn2Jh7nnkkdeu/8AZuVXo48VKHkzRu7R11ZOyrdmSMzk1ZS9zarvTLyqyOjGRbZrQsTMqkT1LJsFEy46AA2SjoARvkJSSQSBIBDK0Uslo0brdbM18+1M5l1m2ytqeKW279zVk9stJ8kexTqFJPSNe63UXyXsl5OZmX/bi9sccvozkjjdYytRlyeNy7nOb5O31XKU+5JnnLE5T2R1856dktTX4M6RhhFmePHkl5mV+1ZGJszSmjBKS2CCZD5HnwTFc8mWeXG+vC2kIcnSxU1o1qq+46OPVpo830bI+k8GquhRzo7WPDcUc7FoctHZxq2tI8fP/K/T6nTj8Y3cWvlHcxIaSNDEp8HXor0d3l1XptyjdqjwbMImKlGylwe/rw5i87O9oiRoG2KgASWAgAqJMGRNQqk/0ZdnJ67mRxMKc5P2LxD4j9U+ublbQpe7PhV0++xs9t9QOrfxnV7knx3M8KTlUgAKgAAAAAAAAAANjDs+3lQl8M/TX0v6nG/Arj3cr9n5ei9STPrf0s6//DZKpnPSJg/T9cu6CZc0Om5Cvx4yT3tG+VoBMeRolCQABBBJABlSxAVoixCRI4tFGa1/g2WYbo7Rhtn00w/biZa4Z53M/mZ6jLhwzzmZD8mfP+yPX81cLJT0zmtfkdjIhwzlWR1I8HL6r18f0exr2Lk2PYxTQxv2w34/TTtj+JzL46Z17Fwc7Jhwz1/Hl9vkP5PX9Vpxf5HTxJeDk+JG/iz8H1Hny+nwvrw5XZi/xKSK1z2izZvk4JeMElyY5rgztGKaJGnZ5MD8m1YjWkitb4IXIaITDZRrFki+jGmWTERVtB8Eb5EnslRDkFHZXXJki9IhpLxaL7Tu9LyWkkmeenI6HTLUrIrZWuzzZ/5Pa1SlKBkjFtlMNxlX/wBjchBbMsn2Hjz7iRqM8K9IvGPBdLRm7qhQJ7SdonZIgjYbIJE+5DQJLIV0ZIPRUhPRKHXwbNI61Uto87i26fk7mLPaNsayrZaIJ9h7mnVKjRYAIQwyWQyFogkgkRIACQIZJDAEoglAQR7kke4EgAlAAAAAAAAAACExAJIJSnZDZDZjnYkgzzyROzRp3ZXbvkX3aT5OPl5Gk+Strk2bGa/qCT8nLyupLf8AMc7Lynt8nJuyZSfkpa4tmx1bs/fuaFmXv3NCVzZic2ZuTLNtWXbNeUyu9hrgMcslozL9/BgSZYM7UyeyobI2ELqOy2tFYyDkE8JPRVSDeyugrYu5bRjk9E6Mc+CVVu4wX29qZSy7sXk52TmLTWyUIvzXF+TVeV3+5p3W98uGKa5OS4C2M6zyhK3wZsfpd1s+InU6ZhKyS7ke66R0eh9raQdWvF5Xp/pi21LcP/B6PD9Hx0u6vn+x7TFwaaYrWjpV1x1wXmL0dWrrymJ6Xphrdf8A4Oh/+O0OP8h6KMEi6SLcdmOmPKS9L47f/t/+C69LYslqVaPU6Ky3rgcX/DHiM30bjSi+yr/weP6v6NnBScK//B9mUdrlGrlYkLYNNInjLPS/OV/p7Iqt5h7/AAdrpXSJKUe6J9Oy+gV2T32+/wAF8T09XB77StjHHV9ud0rpzjXHg9JTjONa4NnHwY1JJLwbiqSWitjv1Y8cmdHPgwTpaOzKlM17KCvG/HI04MzV2tGW2jnwYvtuPsENuu/9m3Xbv3OSm0zZqs5RMQ6sZbMiZqV2bNmLLRDIGENFkCHbySiSSI0CSCE1GzHZZ2rZMno1cqf4FbTFqZV/nk58rdsyXvZra5M60W3sN6iyfCMVk0ovkj/bDPLjSyLuzfJ5vqmdw1s6vUchJPk8X1PJcpSWzS/p4/s3fTSysjvm+TWXJXmUjIo6RlXz+eXavBcFmVi9IlstIzrHMxNcmST2UZFTh+yKJ/qITMlce6SObb+no+fHtbmJFvR16KvBp4dPjg7VFS4PE9P7fU+HFsYqa0dvFr3pnNop5R3MStpLg59U+3uz9OpiVcLg6ddfBq4sdJHShHg97zSOLbkmEdGdFEi56k/TktSGAyQIZJDIoqnshvTEeBKO2ViKiT1HZ4H6idVWL0mf5c6PcZlqqx5Sb8I/P31Q9RfdU6Iz8cGuKHx7rWT/ABOfZPe9s5pe2ffNtlCKsAAgAAAAAAAAAAAO56YzpYnU62pa5RwzPiWfayYS34YH7I9GZ6yenVPu3+KPXM+N/THrcbcSutzTekvJ9hpmp1pkoZERJ8BeSXyiBEXtFiqWi3sBBBJAAABFESASKtGG3wZ2YrFwY7J9NMP25eUvxZ5zNX5s9PlR/Fnm82P5s8D2R6vmrjXrhnJyFqR2ro8M4+WtSPA2T7ezqvY19lWAUn7Ttx7GGxcGjkR/Fm/Yaty3FnpeXLlfNfyGnsrjWLTL49mmMiLT8GCqWpH0vm2fT4T3aOV3qZ7SNhPZz8efC5N2D4PQl68HZOVLMci8jGyVYxTRrTibbRgsRWtsWtohotLgpso1iyRbRRMvsQGERssSSJ0VbJ2RrZCLVdbNrCWromDRem7stRFbaMuZPcdOs/BI7NPKPK9Ny96R6bFs7omVj6nw7vqNxS0S3wYfcz9v4Iz493HLsUTLIJEpEpBokbJFXwRsSMe+Qhl2QyEyWSirVT7ZI7WFbwjg+JI6eHPwaY1nXejLaLI1qZbS5NleDSVSpBX3LF0DIYYYTEEkEkJAASBDJIYAlEEgQR7kke4EgAlAAAAAAAAASQSQIZVl2Y5EotUk+DTusa2bUjUvjwytc+zJzcq/Wzh5eRvfJ0s162efypcsztebt2caOTa22aEpbZnufJrNlOuDLYhlWyzMcgzuSykZE9mum9mWIVtXfBXZEpFVIIXKtF0Q0DqF4I2TvSKN8g+S6ZDZCYevklHTuKTe0Vk18lW1rySra0MvfOjkW1SlLwz0FkO4wqhb8BS5OLDClKS2mdLHw0tcG9CqK9kZlFRJ4vhm2MJKlpnpsDqX29LZ5P7mjNVkuL8kuvXsj6Ri9QViXJ1KMqKWtnzjG6s6kjr4nW3KS2THoadse/rsUl5MqZwen9RjOK20diGRGSWmi709WcrM2RsJ7J0S6fo7g0pBx2VVb35CtxlQ6UyHHs8IzLghv9EKfCKxXGyWT7DRHF59K9pjnDZn0V0V4t1pyp2YZ0fo6TiVdaZFivXFnS0/BWMWmdadCMEqORwYam+5G/BmrGrTNiBaIbESxWJYkESQSwRGyG9Ih8GKyekytqWO63t9znZORteRlXa3ycm2/b8lbUyNqUu4xPgiqSa8i16RVXPLkY7Lu1HOysvthLkyZE9J8nEzb0q5c+xEefu28jl9R6jtyWzzWRc7JszZlrlZLn3NOKbkWv6fO+nd2stcTK48EQWkS2VcEvar4RRsyPwYpF40v6V2VZYhozyqdePaozcxFto1VHbOhiw01wcG7ZyPd8ejrsYsdJHVx47aOZjRfB2sSvweLv2fb6nyaeOji1eDuY9aUUc3Hgkkb0LlFa2U05fb0ssOR1qGlo3oTWji1ZH7N6m7fue/5snn7Y6KZdGGt7RnR6OOTksSAC8AgkgmikvJb2DRVy0nsiRDznqjP/hcC1t64Z+UvWHUpZfUrfy2u5n6A+p/VI42BOKkttH5g6jc7suct72zS/oaYAKJAAAAAAAAAAAAAAJ6ewAPo304688LqEISlw2fqHouWsvDhNPyj8UdHy5YmdXNPXJ+pvp91lZPTak5bfaiR9FabQT9hB7WyFF9+yKhkABCUkEoglAACQIZLKsISUn4LlJ+Cmz9LY1oZS/E8znL82eoyluJ5vNj+bPC9kel5q5Fi4ZyM1fkdu2PDONmr8j5/dPt7eiucySJcMmJg6sp2McomKcODaaMc1+J06c+V5Pr09jkZMFp8HLl+Mju3VbTOTkVNSPd8u18X/I+b9s+LYdGM9o4tEtM6dMtpHt6s+x8f6dfK3IsPRjTJbN3JJxPBhsSL7KyWytXjSmuSjRsTjoxNFK1lUSLaHBIiypKDIQq0WRZFUXDLJDKLiWyzKtEVfX+3UwMjtkuT12BkqUVyeAqm4SXJ6TpWVyk2Ur2fJu5XsoPa2ZlLjRqY0++CM64ZTj6fz7Oxl2CiZZDjsGVLkaIDXBVxL74KthChKYZG9EIX42Z6bO1mm5FVdp+S0qtj0WNd45OlXLaPMYuTz5O5jXbS5NMapY39AiL2ixrFUEgjZYQwSNBKAAAAAAAAAAAABKAAAAAAAAEohkohkIQQySGiSsUjTyXqLN6Rp5MfxZWubbHn818M89lP8mejzYPTPOZcX3szseTvjm3+GaG22dC6O0zRcdMpx52X7Sg9EENhXqUlsycdpiTLJhKskRFcmRojQFk0kY5yJb0YpsK2p7iUa0rO0wzy1H3JZ9+2+5KK8mvbbr3OfZnr5Naebv3JWjou7nyI3fl5ORZl6XkwLNfd5JT8a9H9xOIjJM4Sz3ryZKs3fuSpca7TlyuTIprRyXlb9y6yf2RVeWOk5IqpaZpxv7vczxlsdTM7G1C7Rt0ZHK0zmb0ZK7O0t1vr38eswM2Udfkeowc1vW5HznHy3Frk72D1HTX5E9enp9L6Nj3KSRtJpnmOn56lrk7tNyki0elq9HW2SUT2WDtmXQABYAIYUtCAAr1KJIQIsWiGtlHFGQjRHEsTii0YltFkgJSBJBIlBsFWyKmK2PSOfk3dqZt3TSizi5tj50VqeNPKv23yc2TbZmtbbKRjzyZ2pv0y1Ta9y9lnBi2kY7p6gxHFv2cjRzshRizyXUc57aTOt1XJ0pLZ5DLsc5+fctI8P0b2OUu6bbMsEjDGLM0URXi7L2r74KSkWfgxSEUw/a3dwYZNsyR8chxRNro4xchJtiTSFabZybM+Orz6+1tUwXk6OPFbXBqUVt6OjTXpo8f1bX1v8f5/p0cZJaOtRNR0cmng2o2Ne5423Z2vpdGnkduvISRaNzcvJxo3P5N/G3Jo2897WuzHkdamTfudPGk9o0captI6lFWtH0Pm/Tyts+3SpfBsp7NaqLSNiJ6WDiyXQCBvFAgkgAc/ql6x8Wc960tnQfhnjfWvUP4Tpdv5a/Floh8R+p/qR5d8qYy4XB8jnLuk2dn1FmyyuoWty3+TOITlUgAKgAAAAAAAAAAAAAAAC0Jds017H2r6W9e7bIUSn+vJ8TPR+k+qTwOp1yUtLZMH7Pwr1bRFp74Np8I8h6O6qszp9cnLe0ev33IioTF7RJCWkSVSlEEogtEBJBIEMqyzIZIgrPwXKT8Fc/0T9tS9bicDMh+bPQ3L8TiZcfyZ4vrj0PPXFujpM4uZHbO9kLhnGyY+T5/dPt7fnri2LTIizJeuTHE5HfCTKNl2jHJFsbxz7sOxWUU4s5uXX5OtGO0amXVwz0/NsfLfyOn6rhL8ZG9RZrRrWQ1ImD0fRefLsfCe3XyunCWzL7GrTLg2l/KejP08bKfauuSWiH5DZWkYbUa8jalyYJopV5WH3GyWiNCNIBDQFXn6XiWKxJZEZf7QwiCUia1xidcm7g3/bmufc0mxGbjJFK6NOfMnv8ApuYpRS2dhSTjs8N0vKfcls9fi2d9aK19R4tnY20XRRFkQ9mfpYnZXY2QkZGi3sV3yVQnRjmtGRy0jBZZohCk5aMEm9iU+5mSEO4C9EmpHbxLvHJxow7WbuPPTRpipXpKbdo2FLZyMe3wdGuezeKVnKlkQy6EogIkhKASAIBIAgEgCASAKgAsgAAAAAAAAQYQZCEAIklaMcka963E2ma9q2gx2YuJmw/FnmM2Ops9fmQ/Fnls+H5srY8vfi41i4Zo2LTOjZHg59y0zPKPM2YsLZBDJXkox4EltENBPE7CZik9ERkEVkm9I1bLEvczWS/E5OXf275DOrXZC+TmX37b0zDbkSlIx8yLJmKHOTZVykbFVHc/B08fpLu1+Ib463C1OfBjdM9+D22N6ZlLnsNlelW5f+2S2mp4Bwml4JhOUXye7v8ASsowb+3/AODi5XQJVb/AlF1OH/E6a5M0cla8mPKwZ1v+U09Ti/BXJndTsVZK35N6rITXk85Cxo3Kchr3K9c+evjvd7a4Lxb1yaNN6aXJtxmmuC3XP9ys0ZtM3sfJcWuTmxMnd2kyujVnY9f03qGpL8j12BnKSS2fLsPKcZ+T1fSsxuSWy0r0tGz7fQqbe5eTYRyMC7uSOsnwW693VexYhsrskl0pAQCmUCCSAiYhIROgWcQNEgARsE6ISAaDekEjejBbao+5E7NHPybntkVaIyMrzycy2ffsrfa3IxRbZnVuKygYp/iuDal4Na3gzqmd+mvKbRz8zK7IPk2cm1Rj5PMdSzfK2THkerPkc/qWW5yemcjmTMt1n3JFIo0j5vfs7VkjIiiRdEVz5REmYpMySMMgYRDb9iJSaRaDXuJa0Uzv06JGu5Ns3MWCk0ayhuR0sWlrXB5u7N6/i19rfpqiom1BGGuLSNiEdni+nLr7HxYcjNBmeCbK11bNymg8zL7r29f1EQqb0dbDq8cGGqjwdbFp1o7vLj9st2X06OJWu1HTqguDUxoaSOjUj6XzYfTx9uX2ywiZEQlwSj0ZjyOS1KABaICCSAIcvxZ8i+rPUfsYjgpa2mfV8qxVUSlvwj89/VrqLvscVLei+MQ+J5dn3Mib/ZgL2PdjKFakAAAAAAAAAAAAAAAAAAAy49rqujJPwzEAP0X9LOuq7HrplPlI+2UWd1aa+D8hfT/rkun9UrTlpN6P1N6f6jDNxISUk9pE1Du7JIRJQgiSCS0EAAkCGSQQIKS5LsrJE39EYbY7icbLh+TO3Z/KcjLXLPK9eP07dFcTJXDOJlPWzu5S4ZwsuO9nznonHs+fL7ce57ZjXBktjqRjPPepitraMM21LRtQXBhsj+ReSKZog9IxXpSTMi4KTW0aYbLjfp5fr0TKORfXps1fDOlfWc61drPovFttj4X+T80lrZpnpG3Ge0c2uRuVvaPawz6+U26+VmbJS2VYT0bRzX6XcEkYJxMrkUlyVsXxa0lorsyyRjaIkaoGgSLEyieidkAqpYFk+CCrZCZav5KyWiIsmS4IaYXjdwLuyZ7HpuV3JLZ4KmbhI7/Tc3tklsrY9Xx+jKZSPdVtSRdrRzcLK70uTpN7Wyj6nVt7Ex5Ia0yqlot5Irsx+1nH8THpb8mRvg1bbe0qixa2XauDSnNyZMru56MldXdyV6orVV3cs2oQURGvtLpF4mIZeuWmY5ImC5LwsdOi3TR0qbk9cnDjLSNmi1po1lU49DCaaJbNKi3a8m3HlGkRxZMsRrQ2SipGyNghBsjuJ0NEhsbGhoCdggBKACQcQCSeAhUaJAQaIJAQAAJkNAAgQ47MU47MxSa4HajJzsqCcWeY6hTy2eqyFtM4WbVtMdedvkeTvXa2jm5D5O1m16bONkLkrl+nk7mo2TF8lZ8CD5M3Kzd3BVzHsY2+QdRJ7ZCWiTFZLtRKOseTd2x8nAyr3KTN3Mu8o5U33SHEcVhFyl4OljYX3NFMSjuaPTdM6c5tcF5G2vC2tbC6P3SX4nsekdE1rcTd6T0lajuJ63EwI1xWkiePY0eeX9tDG6TCMV+KNuPToLntR041KKL9q0OO3+tjxx7emwnHXajiZ/p6FifCPYuKMU6lJeCeMcvPHyfqfphdkmonhs7pU6Jy/Bn6ByenRsi1pHket+nYuMmoorli4t2rj4lbGUJNNFIzcWem6v0aVU5fizzl9Mq29oyscmWtsUZDT8nXx704eTzUZtM2qMpx42V65c9X/HpI2r2L9/cc3Gu7zfj4L4sOWVsVPtls7fTMtxtSOFXyzp9Pg/vI1kdfmt+T6P0nKclE9NXLuieM6Ptdp67H5ii3H0Wq2RsJE6CLB145VUABcGgAgROyAV6g2CdDRaIQTsaCAJlbGtFm9GrfdpEVLDdNLfJy8izlmTIv5ZoWy7lsyyq0Ul+TI/lIgm2TatIp1NvFnJa8mnk2JRfJWdrj7nK6nmdlXkced6N1k+mh1PP7E0meWych3Te2Z8/KdjfJzO5tl5Hz3o9GVrIqy6iUTMsfBaPNyvfsRYhlHIjIxvf2TZrybMzeyjiZ9bSRjUdrY9y7faiIrbMdmXI01Y21nor2zq48dJcGljx8HTpj4PH9Ozj6n+O0T66zwW/Y2qquStFe2joVU6PH2Z9r67RqmOKaqjdph4KV1m3VWUww7WmWXxZ6q96OtjVLSNKmvwdWiGkj2vJpji27LW5RXwbkI6MNK0kbCPf1YSR5ud6tsnwQiTdihSey2ymuSWKtUkNhFLZdkGycVa4/X8z7GJZz/Sfmb19nO/KsTfufcfWfVVXjWLu9j82+qMv7+VPn3N7OYojzEnuTID8gwWAAAAAAAAAAAAAAAAAAAAAGzg5MsbJhNPWmfo/6Y+o1k4ldcpc/3PzOe9+n/qKXTs+uDlqOyYiv17TNTgmjIcH0/wBUhnYcJJ72jveSLCAAISMAklCCGSGQlBEkSJeCyGGxcHLyY7bOtNcGhfDbZ5/px+nVprgZcOGcXIhwz0mXXwzg5cNJnznrx49bz5fbz2QtNmq3ybeUn3M1NcnlR6+F+mevlCcHsz49e9GWynSImScnOktFGbFkDXa0WlYbcOxhugmjk5MOWdqa2jnZFe9nr+Pbx8p/I+bsrmRepaN2mfBqTramWjJxPodWzsfC+rTZlXSUkSacLTPGezsxyeXnjysjIZPkgtVMapJGKSMzMcisbSsLJJaIJq8AAVLAa2gT7EKKrgvvaMbGyFpU60zYx7nCS5NfY3oh06M/jl17HpOXvt2z1FNinA+c4GX9uS5PWYGepJLZHH0Pn9LutErgxwsU1smUtFLHtatssWnPSObk2b2Z7LDVku9lLG1zhRFykjqVQUYmlTFR0bP3eNFKzucZm0Nowqwn7iLxH5IyPRCeiveiHNF4j8kZozMsJ6ZpfdSH3jSVW7Y7WPka1ydSm9NI8vVkafk6mPlLjk0lV/LHcU9onZoV5MWvJmWTEnpNkbOxs11kRLK+LJT84zbJTMP3YllYgn5xl2NmPvQ70E/KL7GyO5DuQPlEgjvQ7kSfJOxsjYJT1JOyECEmxsgEp4nZJUlMg4kABXgHygAixq3V7Rxs6GkzvzW0crOq3Fk8cO/F43OXLOHkR5Z6TPq1J8Hn8qOmUyn08ffi5dqKRfJntRrvhmThtZu7gpvciqkSvOyVerS4Rp3z4Zs2vg52RJrZKZXOynts1EvyM189tkVVuUiWmM7XV6TQ7LYn0vofTE64vtPG9Cw9yi9H1DotHbUuC8et59P110MbDVaWkdGtaQhFJIv4Qetq18gySm+S68BvYhojRbYCvxY5wNHJxlbFpo6L5RRxLOfbq68L1n0/GyMmoHzfrXQpVSlqJ95yKFOLTR5PrPRo2Rk1EpcXFs08fBsjFlVLlGsnqZ7L1B0qVMpaiePnXKEtMzuLg2YcdHFt7UjqVX92jgUt7R2MKqU2iZHPNXa7mHX9xo9L03B3NPRzuk4Unrg9j0/E7dPRpHbo08ro9OxuzXB6GlaiczGhrR1KlwS9jDHkZSSCyDaKgAL9AAFbQlEEoI6kkghshMSVfBDlow3XpJkWr8Rdd2o5mRkeSMnJ88nOstcn5KWp4W2bZi7tlW2yyjxtlLUW8XjpLZhutRMrEonNysjs3yQ5du3kY8y5Qi2eT6nnd+47Oj1HOTi0meTvtlO2XPBaPE9W8sfcyigQmzLEl4mzPtV0XjwToeCVIhso2TIpsip5wKynot5MU0ZZVbC9pvuZsUVbZrQT2dLEhto4t+zkez4/P8q3MejwdGmopRXwjdqhyeB6tr6/xaPjGairTRvRRiphwjajB7OHH/J7eP1GSuJv0V7aNemvbR1Manwd+jV2ufbmz00+DoVV6RWmrhcG5CGkfQebTx5uzYtXHRmSKRWi6PUxx5HNb1KJIAQkiRKI9wii8HO6tlLHxZyb1pG/ZJQjs+eetuuxxseyCnp6NMMVa+deufUHdKyCl8nxrqGQ7rpPZ3vUnVJZGRP8t8nlZS7nsnPLv0mRUAGaQAAAAAAAAAAAAAAAAAAAAANnCyJY+TCaetM1gB+mfpj6hWTiQhKfK0vJ9gptU4J78n5H+n3qB9PzYVylpNo/T/Qeo15uLCcZJ7RKHdb0SVaUlshP2K1K6AQJgABFaI0Gtliuy8QrLwadq2bc/BrTRzb8extrvHLyo8M4OZFJPZ6PIj5PP9Ri+TwPbr+npefL7eZy4ruZpKP5G/lJ7Zpb5Pn8pyva15fTexvY2ZraNfFW9G72FIvcnOtrNScNHVtrNK2GiJeVP7jTlE17KkzamYZM7NGfK8z16ZlK5d1OmzTsWmdS5bZo3Vvk97Rv+nw/t8n+Va8ZaZtVSRpuLTMtctHq6tnY+b9Oj41vxaZJrwmZlLZ09edceVDKtF9chrRMWjAymzJNmLQrWVYEEkJoSipK8EKpeirROiSBTQXklsq5BaXi0ZShLg7XTcztlFSZxopy9jbxqpKSeiXX591le9wsqE4Lk252LR5vp83CKOnLJ/HyUse9o9H0vO1OTRauUd8nPdj7myyvaKWOr+y6UrElwY/vpPlmjLIZgne/kpxS+l1J5K9mV/if2cr7z+SHf+yZGd9Lr/xf7IeWvk4zyH8lf4j9lorfS7Dyv2V/i0vc5DyOPJilkP5LxS+l345sV7m1X1FL+o8l/FP5LRy2vctFb6ntYdVil/MT/wCrx3/MeMWa/ksspv3LQnqezXWI/wC4yx6zD/eeHeU/kr/GNPyS0/svoEerwf8AUZodUh7yPn1ee17mxHqL/wBwTPS98uqV/wC4supw/wBx4NdRf+4uuptf1Bael72PUYP+ous+PyeEh1Vr+ozx6s9fzBaeh7dZsH/UXjlRfueJh1T/AJjar6r/AMxbrWb3sY3xfuZVYmeVq6r/AMxuV9UX+4daTc9CpIt3JnHh1BSX8xmhmRf9Q60x3R0uCNo1Y5EX7mVWJ+460m2Mu0DH3L5LKWyerzOVcbI2An5RIYQ0E/tVmrk190WbTMNv8rLRhtw68p1Kl7fB5TPj2y5PcdRi3vg8d1St9/gjP9PJ9Ov6caw1LPJuWrRpyW2YPHyikXyZ4sxa0TvRLGrz1o5uWuGbk5ts08jbJTjXFthJyN7CgnJJkSgtmzg1J3EunX+3tvT9CfZwfSOm1RjSjwnQK9KJ7/BWqkWj6Hz/APluBMINB3Yp7USCNhPUe5JJAJUbC5IYRZbhKKaNPKx4zg+Dd2VnHaDHPCV849Q9JVnf+J8s6x0+VGT2qJ9+6lh/cT4PC9W9OPIyO7sK2PP2anzPFwrJyX4nq+k9Js2m4ncxPTX25L8P/B6PD6X9qK/EjjPHT9tfpmD2KO0ejx6EkuDXpp7H4OhXwiXbr1cbFMNNG9BJI065G1GXBLokZNojkglBaI2ToqvJfYEANkJhWpJ2QQBcxzehKaijTyMnSa2VtaYxe26KT5ObkZD55MN+V5ezn2ZTbM7WnF7bm2UT2Yk+9l/5Slqty4yaQsaVfBRSbNbKyPtxfIjl3bORguv7d7ZxOp5sUnqRXqHUdNrZ5vLzHY3yS8j0b2HKypzm0mayi29sb29mVPgl4m7b2qqJZLRKDDk71O1oo3yGVJ6vimckkYO7kyTSaMXatmdyaWMkSWkyE+CyWzn2Z8b+fTcslqqe5rR2MPH8cGph1vXg7mJV44PJ9G19f/H+b9NmmlaRs11LZeunhcGeNejxN16+m1a/jGSqMUjZhFN8GCETdor20aebX1bPLjPRVto62NXrRr49Pjg6dMNaPd82lwbs2euKSNhR4McImZeD3NWHI87PJGiy8EoGysqANDWyqyURvkIxW2KuLk2WkRWj1jOhiYk5SlrSPzv699RffyJxhPj+59E+oXqJUY1lcZ6fPufnLrPUZ5ORJuW+TT/zFXPy73bY3s1g3sGSwAAAAAAAAAAAAAAAAAAAAAAAAAANnCyZY2RGcXrTP0L9MvVH8RTGmc+Uj84nsPRPXZdN6hDcmk2iYP2LjW/crT+TOo65PM+mOsV52FXKMk9o9LKekhRbZJEeVskggACtSkoWKF4rVZeDFJcGWRVopsnYtjWhfHycTqFW0z0V0TjZ0PxZ43sw+nf58vt47Mr5ZzZQfcdrNWpP+5oxr7pHze7D7e3qy+mTEi1o3kTjY/4oyzq7TKYJzz+2Ccdo0MiHk6EvBq3R2Y7Jyr68+uRatMwNcm9bWazhpl8Mk7MexrSq2a11PDOi1wa1y4Z36NrwvZ5Je1x7YaZjj5Nm+PJq+Ge95tnXxnv8/LWXejPXI1XLZmg+D08a+c2Y8rZUg3tGHuLRkaRlIrNcldGZrZRomrdYyCzKkHQlMqSQlcq2Q2V2QkZaFbm/BeupyOhi4u5eCDiMXD3raOnXhJexnopUfY2+EiW2rGysNUOwyvZVy0T3EO/DOxDRSTJlIxSY4vdyHMrso9ldkfFX8tXZRk92ijmRxF2Kso2TKRRyJkVuyp2UkHLgxSkTxndtVl5IbZDkRsszu2pcmT97XBRsxST2ETbWx979kfc/Zr8osmFvzVnU/wBlvute5r7JXIXm5sK9/JP3n8mvpobC83VtRufyZo3PXk56kZYzHV5ub0chr3Mkctr3NL2Ktsdaze69ee0/JuV9Rf8AuPNfcafkvG9r3HV56HrIdVa42bNXVf8AmPHrIl8mWGU17jrXH0PdU9V/5jeq6ov9x4CvOa9zZh1Fr+odaz0Pf19RUnrZtwy4v3R8+q6q4v8AmN2rrHP8xMrbD0PdxyIv3MitT9zyFPV0/c6NPU0/ct1tj6HolNMlSOTXnJ+5u13qXOy0dOG3rZfgx2LaLKSa8lZFovll1ysyru2eT6vj6fg9tfDZ5zq9G98EZfpweidjw+THtbNJrk62dVps5UlpsxeNsxUfBj3yTORj8kuPKLtJswZEeDLp7KXLglGLmz4ZsYMtXGK1aIxLVG4OvX+3070/pwge6xP/AG0fOvT2QnGB9CwZd1SZaPe89/xb8SSIkth34hA2SE2IRIAIjQSJI2Op6NBInyQOp/bHZUprwak8GEnzFG/sa2Syyw65ywYL2RWyiMV4OjKPBqXRDOYcrnuKTMm9QKzi0yJP8dBvJ9MtU+Tdrls5sHpm5VIIby5BSDLMJSTsgAQwkSVctBPF0UnYooxzvUUc3Iy9e5S0kbN+QteTlZNze+THZkuT8mvZPuRna1xjDba37mHW2RayKpbKWmX0zQ/Eu3tFGtk7UY8hybM+Idih5Zw+p5a/JJl+pZyrT0zyeZ1Fym1stI8z1buRg6he5TfJzVuTMtlv3JCMSXhbt3URiZEgkWDht7VWyNhsjYWxgyjZd+DFJkVb9IctkaI9zJHk58sm+ufKoUWzcx6O7RihHk62FXvXB5+/Zx7/AIvN2tjExdLwdnGp1orjULt8G/XXo8bds7X1vl0/GMkIpIyKKKGWuO2Y44fJ6PeRkrhtnSxqeUa9FW2dXGq01wep5tLh3Z8rapq0jahDQrjwZVE9zz6+OHPLrJBFiIljvc1QiSAR1ESQ+CSJCLdR4WzzPqXrMMHFm+7T0drqOZDEx5Sk9cHwf6g+qlOVlcLPleTTH/pXjvW3qOWbk2JT2tnzuybnNtmxnZUsi5yb2ahXK9oAAqAAAAAAAAAAAAAAAAAAAAAAAAAAAGXHtdNsZJ60zEAPvX0x9Ub7KZ2f5Z93xLlkUxknvg/GHpbq8unZ8JdzS2fqP0d12GdgValzpe5KHuE/YkpW1KKZZvQTEgjuRXllUrkNE+xGyYrVGiDJoo0MvuJka9qOZl190JHWmtmjlR/FnB6NfY6tOX28T1GOpv8AuamOtzO11KhNvg0cWlfc8Hz+7z216mO+Yx0cav8ABcC+Gkzo49Mftrgw5VfDOe6LIj83yrjSiYZw2bNsWjXbPO9F+NdmlpXV8HPtjpnZsjtHNyIcsy13rprUa4MU4bRllwYpb2dOvLlY7tcyxaV1Jz7a+1nalHa5NO6tM9rzb+Pk/wCQ8Ny65O+TYrfBS+vtfBSMmj2dW6V8b6vJcK2WTFmOM0/Jki0dmN68zLHjImGQmizZfKqVikUZleirSKplYy2uBwF5FT1SQgtyLzXAx4tzX9yF8ft0sOnua4O1RjpJPRhwaI9qejoa7VpFvi2x1qNdo3sl8lHwV+LeTgym9EuRRtE8X6lzKt7KN8lXJhSrS0Y2yHJlXIIiJPZRl9rRinNEcRckMqO9EOSJ4pch+DHIrOwxSsJ4pclyrkYnNkdzYZ2ruQ7uDC2yyfA4jqXJbJUkU4JTI4SsojLTKpkSfwOLTJl70Q5GNMsuRxeZLLkyR45MY2xxf5M33SHNMx6IeyvDq7kFIpyOQtMqy9w7zA29loscXmbOrGvcvG1/JiikS+Bxf8jP9168l4ZEl7mk2yU5Erzc61WbJa/I36eotf1HnVNoyRua9yetcd711XU2tfkdTG6uuF3HhYZMl7mzDNcfDJmTs1+qR9Go6kpJcm3DLUvc+c09TnH+o6eP1drW5Fvm6J6pXtZWqSOX1CKnFmjV1WLXMiuRmKxcMi5dZ7N0scDqVem+Dg3x02ejzZKSezz2U+WV64NmUrny/mLwXGw9bHdodcecS5LZS3TRPBEmSpPpo5EOODn1qSufJ1bvBzbF2y2vJLfDLle19O3NSgtn1HpUt0o+NdAukr47Z9d6JapY6J69zzZ9jvLwQ2QnwST162H6NkohEvgdTbxIK7JIVlSVJJBYhEsgBMQN6A0SlPlGOcO4yIEq8aFtP6NScNHUsWzUthwSs1FwzYqZry4ZmpkiFeN+tmUwQkjNGSCOL64IZDkY5WaItTFpPSNW23XuLLuDn33P5K3JeIychr3NCyxy9y1lm/Jgk9+DO5JlVe9lWW0xwVaRilDuMUo/bZstrXBim0luRHGW3LkUjatcmhn5yqg+RmZldcXpnleo57m2ky8xeP6PTMWLqHUPuSa2cazum97Mk25y2Rotx4/o9Mz+mKMXszxRCiZIorbx5WeXRIlrgPgr3bK/JSfdY5FU+SbHyYm2T104z6ZW+DDJkOTHkplkjn2hLk2KoNmOMd6N3GrbaOLbskej5PNbestNDbR3MHGfBTDx4vW0duiqMVwjxvRvfY+Hy8i9NXYtGzGJRL4MsDz/ALzr3sdfxiVDZs0VciqGzo49Pjg7tOmss8+L49XK4OjVDRWmnXsbkYL4Pb82n6ebuz7V60ZUiIR0ZD09ePHNahEgb0aKoBO0wRxCCtk1CLbLPhHmvVHXaumYk3KST0/ctjOo/Tyn1C9SxxMWUIz09fJ+b+vdVnm5U25N7Z6D1l6ms6hl2Lvbjvg8JOTnJtlsrz6WVABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWrm4TUk/B9d+mvqmVORXRZZxv5PkB0ek9QngZcLIy1pkwftrpWdDJojJS3s6Wkz5D9O/VUczGrrnZuWvk+s1W99akhULtcl1wVjLZLIBjQi9snQSj2KsuVY4likjWvh3RZttFZQ2mZ549i+GXHmM/Hbfg0qMZqzwekycfu9jWhial4PP2aO1rltTRVqtGLJp2nwdOurUdFL6vwZzbPP9L6tn28xfVrZzprTO/lVcM4t8NM+e9mjlerp2NWXg1ra9m0yjjtHBhPi7Jl1x7YamzE0jeyKuWzRntM1xrXnYxyRrzhs2VyVnHR2atnHn+rT8o5t9O0aU63E7Eo72aV9Z6+ja+Q/kPLftoJtMywkY5x0xF6PX1bOvlN+m41sKRbuMKkXizp71xXFZsq2X0UaLwkRsJ8k6IaIyieLeTcw6dyXBqVrckdnBr8FY0xnHXxYdsEZJPQhpQRjnI0l+m+NS5FHIr3ENkL9GyjZLZDCOscpFWyZrRhlLTKq/JdlJEfcXyYp2r5CvyJ2dprTu/ZW63fg1pyJilrN97nyS7tmn3MspMI6zSsMbmRsqwpat3FkzDsumFWTgq3yR3EBC2wmQiUglZMNkFkthMQjImV0N6C8ZEyeDH3BSCWchlO7gdxCerElO4nYT0a5IRJVhPWSMi2zEmW2E9W9y20YnIr3MhX5MzZG2UUiUFpmyKbQVr2U2R+w0x2NpXNLyWjlSi/Jp97Cew1m116c6fyb1ee9cs89Gei7va9wt+V2L8vuXk5F9nc2Vlc2jDKe2FMs0lZcEqXBE5cEscslO4nZQtsKdY7FwaVseTemalhLTGt3pFnZkRPq3p/I3VFbPkGDPtyEz6V6dyl2xWy3Hq+bY+gVvaRkNfGsUorn2Ngnj39OXYIlgDjTKdRokaJCsiCQBxa0IZLIYR1BKIJXgk6jwNkPyEAktmCyHBsmOxcAcy2HJFa5M9kDCn2sr8jrcgjImkaivSRjsy9e4+SW7O1JeTTtyNe5qzyt+5q2XNlbU8Z7Mjfua07dmJybKNmdq0hNtsqpErkq0VXmK29lWiYopbbGC8kstmyYkmorbOXn5sYxemM3qMYUySkeVyuoOzfJaPL9HqinUM+Um0mcadspy5Mt0+9mJJFo8D0b+piSRoslwT15/y7RFyo3wZ1Nx6iUiilyJspF8lZEfHiZcsromTKuXAy+muH2pLyIrYe2zNVW20cuzZx3afP8AKstFLk1wdvDxN64NfFx/HB3sSpJI8rfufUeTx8kZcfH7UuDehDSIrikZ4o8rO/KvofPr+MTCPBmhXtk1wNyijb8HR59Xa32bORbGpba4Oxj0cLgxY+PrXB0aodqPd0ed5u3avCtJGRREfJl0ejhr+Mcdy6hInQGzWKGg0TsgmUQloju50TJ6RRL3ZZDHmZEaMec5PWkfnn6peqHLIlTXZx/c+o+u/UUOm4NsVNJ9rPy36i6tPqOdOcpb5LT6nRyMi+V1jk35MIBRIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9t6F9QT6d1KqLnqO0fqT071WvqGFCUZJ7XyfirHvlj3RnF6aZ9u+mnrNqVePbP/LJRX6FitMyv+U0sHKhk0xmnvaNxvgcQiHkyFI8FyEoKssyGiUqkjRDQLVJQUjH9pIzrgMj4yq9rDrRjsW4mZx2UlDgx265xprv25GVXwzh5NfJ6fIq2mcXLx9bPnvbpenozcOUdMpo2LlpmHWz5zbPjXp671rXV7icq+vUjt2eNHOvr22yuOTrwc9LRE+UZJrtMTezaWrZa5lGCS0Yp19yNmcdlPB26NvHie3ySxzLqdGnJaZ2LYdyNC2h72ezo3Pjfb4+VqpmWEikodqIrnyelr2dfO79Vwrb3wUkFLgh8nVjk5EpkvwVSLtcFqvjV6F+SO9hrSOFjv80d/FW4mbaNxz0jHKWxIx7LSid6KuRO9lJIsn5DmQ7DDN6MUrNIK2s1lySNGzI5MVt+21s05zbfkqrcm68j9mGy41lNoOWwr8l1PZDKLgnuJR0CGwDqyZDY3wQwqbJRVIughGiUwRoC6LIomTsJXJi+SmyU9BLI2UbHcQFkgInYSlMnZXY2FerbJRXZOwnq68EMjuGwnoiWyAwdQnySU8Mkgq6LexRFu4IQ2ZE1owykQpaCesrRG9Fe/gq+Qn5MndsFI8Et7IT8l9lGx3Eb2EXNO+CjfJbZV8slX5J2TspolMEqJGvNGy+TFKJK8ya8Zfbls9P0LqnZZFbPK2PufajPg2Sx7oty8F46tGzlfc+kZn3alz7Hbi9o+e+merxnCMWz3uPYpwTXuiX0nk2djOTsaID0Z9rAjY2EVII2NhXqWQCNgB7ElW9EAyEPI4XuOpS2UbKztUTWnkoracZrNaOffYovyTblpJnLyMnufBl8lpizyyP2YJ2t+5q97b8lk9j5NJgyObK9xVsjuI6t8WQhohSLeSFbyKb0NoTRrW3KC8ksdm+Yxe7IVaOF1DqXanplc/PST5PM5mW5yfJLx/T6k5nUZTbW2cx2NsiW5MKBLwd3otptslIsoltEuK5dEiWQ3onygr+lGyNiRQr1vhekiq4ZLeijkOrZQkymw+SY1s59ufI10a7cmSuHc0dPFxttcGtjUttcHdxKdJcHlbtr6jw+btjNj0aS4OpRDSRirr0lwbdfB5GzZ2vrNOiTFmhE2IRMcJIzxa0ZY/ddFnIz0Q20dfFqOdix7tHZxVpI9fyxwbsm5VWkjOolazLFH0OjnHnZ0jEuRslcnTWYCG9BS2Z0SNkFIpqWxBLXJzesdRrwMOdkpJaXyb+RbGqtybSPiv1K9YKmu3HrnzyuGbYzqHhfqN6sl1DLnXCf47a8ny2cnKTbNnPy5ZWRKcnvbNQjK9qQAFQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADqdE6nZ0/NrsjJrTRywnp7A/VfoD1ZDqGLCEpra0vJ9MqmrIppn4+9E+pLOm51cXNqOz9Q+mus15+DW1NNuK9yyHpSy8GOtv3MhFQAAhKCCxDFvCoILEMmVMirKSLshlM/0mXjXsjtHKy6m0ztyitGnkVJpnmejV8o6tOz7eSyammzSf4s7+XR54ONfDTZ8v7NNletpzar5ZgthtMz/1EySaPP478MnHur0zVa0zqZEPJz7I6ZfCujHJiaMTRmRSSN8LyqbdcyjDKOzBOvZtNFGju17ePnvX4uudbVwzS7e1s7FkNpmjZS+T09G/r5D+R8NlYFPRdS2YpQaZMEz09ezr53bpuLYiyZP8SsSZPg65euf9UplqaO9iWfiefrepo7OJLhDjbGuhOfBiU+SZPaMXhkyFyZHPRV2bKN7Kt6JV+SLZ6Ro3X63yZrrOGcy6TbCOolZtlW9lCUVKsSkQidhHBkDewTBJJBIAAkHAAA4kEEg4EkAJW2EypOwLDZA2BYnZXYB1bYK7GyVV9jZXY2BbZKZj2NhLJsbKdxGwlZsJlSUQtGRMkomT3AGiCO4jYFtgrsnYQtsNldkp7IRVWwmSyOCFUtld8lmVJEtkdwZUJS5FJSJZjkSnqjj+WzFZNxezO/BgtjtMtKvry+3d9PdSdVsVv3PrvRc371UefY+DdPsdWRD+59a9MZe61z7Dr3vJse9jLuROjVx7dpG0pJk9e7rz7E6JII5HWlSB4McrEh1VfYNd3LfkffSXkjozuWjHKxGrZkpe5q2Zfwytq0jdneo+5rTzEvc0Lclv3NWVrbK/JPG/bl79zVsyX8ms5NlWu4rclpF5XuRgm9mVQ4Mc1oz61kUT5MsWarlyZYSI6t2RscFGuSE2zIl8loxz2SKrgh2JEWyUUczIzFB+S8ji2eiRtZOUoLyef6h1LSemYeo9R9lI4GTkSs9yePG9Hq+zKz3OT5NFzcnsODb2WUNIPK3brkIukUXDL7Dhy+0klNk9wWxxRIryJSIUloL5xWWyvdotKSMbMsrxOEJTRRSTZDi2Qq5bMMtvHZr1fJmjHZs1U7YxqW9bOlCjS8HDu3PZ8nitq2NUlrg6tCS0c6uLTN+l6XJ5O3b19b5PL8Y6kGlFF1ZFHO++0vJV3v5OO3r2McOR1o3R2Z4Xo4cLZNm3VKTNNWPay2T6ehxLlwdzEltI8vhd20elwU9I9rzYvL3V1YGZMxQXBlSPa1djhySvJYhIM6ZVKnhkaRKIbHOoCtnEdok4/W+r1dOxZTnLWky0iHnPW3qaHTenzSmlLn3PzD6m63Z1LOsm5Nps9P6/9WWdQzba4WPt2/c+bzm5ybZe3k5BV8sAGaQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZKbZU2xnF6aZ9m+m3rOVVkKLrOPC5Pipv8AS8+zByYzhJrTJlH7d6dnwzMeE4yT2jorwfFfp961rvprpst/JL3Z9hxcmORUpRe9ixVskkbCZUSQxtfIZFSIhkpBlsf0mKsqy7K6IynVMqo2YbFtGw4mOUSmWvsTrysrk5VW0zg5VT2+D1V9e0cXKo5fB8/7tHXraNjz0oakVbNq+GpM1JJ7Pm9mFmT1sMvphtj3JnPvr0/B1dbRqZECs42wyrky4ZRvZkyE0zAmbR14/cW0Q0XiWceC8y4x26pWtJGCcdm3KJRwTOvz7ePB93j+U/Tl2w0YH+LOpbUmjRtq0ezo2x8Z7/Hcf9McZkuWzH26ZZaPUwy7Hzeeu41eP8yOhj29powSM8Ho2jPrqxt2g5bNOuZnjNP3Ls7l9sndox2WLRjsnrwas7HsqtKWz2aslsyylswyYWiNEFt8FWQtAgEpEJ4IkaBIkkgkASQi2wIA2QEhZFSUBJGwAjhsIgBC2ySpIE7JKkhCNk7Kgk4vsbKkgWIC8BhKNklSUBdEldkbCLVtlWxsghHRsbJ0VB1ZMnZQkJ6tsnZTZK0xSUbGw0Eiq3Etld8kshok4lsgq2wmELFGi5VkoUaMVn8rMy8kTimR1OP7aNcnG6L/AGe99NdR7dJs8NOtJ7Op0jKdVq59yXq+bPj7Zg5MZ1xezoRyYR8s8RgdUUKI/l7Fr+tyj4Ye9o2Tj3Ucur/cJZVfsz57Dr9ndrbN6nq8rFyyOu6Xr1k81LwzVnl79zjxyXZ4Zk720PkVvSyv2UeU/k03JlNkdTGzO9sxObZRaZPCRW1aRWXJGg5DZVZDRCemWbTKNEJWczBY9l2Q47K8PlxqtPZeHBkcUjG2o+44yz2yM6koox2ZcYLyaV+XGK13HDzeo63qRaR52/0T/rrZfUYpP8jz2Z1Dbemc7Iz5yb8mjO2UnyayPI2+hmuyHY/Jh7jGtkNsV5ezZ8qydxKezGjLFEMrep7SrRk2istEI+mIbDa2QFoq2RyGO5JDq8nVJFO7kvKWyqi2zm25Rtr121eHJt0VKT5KUUb9jfrp7FtI83Zse54/Nlb+iEOx8G3U9+SK6lLyZvtKPg8/btfXeLycjKorRDk4+CkXLfg2IVKS5POzz7Xva9UxjGm2XjFstGrng26cZv2K49qbyK0UNtcHWx8XaXBOLiva4O1jYvC4PQ0ara492eMjFiYmtcHexKu1Ix4+Pr2OjVXpHvefVx4+7OMkY8F0gkD1MMZI4cshvSC5AXBaolPAZWW9kyl2xZaDBl5MMemUpPWkfB/qb6yfbOim3nlcM+g+t/UEMHCsXfp9rPy56g6pZnZ9kpSbTZpz4zo5eVkzyLpTk9tswAGVSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA7vp7rVvTMyEozaWz9M+hfVFWfg1J2pya8bPyUm09o9p6N9VXdJzIJzfbsmUfsOElZBNMun7HkfSvqKvquFCSmm2vk9bBrt2KqSjzstF7I2WS0V4mJABKQhkkMlHFH4KMyFWiMv0tGKcdo5mVDe+DrNcGlfXvZ5+/Dsb4Zcry+VX+b4OfZHTPQZOPttnJyKdNnzPq0/devpz+mjvg17uTZlHRhlHZ5Gcsr0NV65WRDfsaUo6OxfXwc26GjXXk68WKLMq5RgXkzxW0aZVasclso62bHYRJETLjDPCZRqSia9kODekjDOGzv0brHznv8svfpyrYGDbTOnOnbNO2rUj29G98Z6/Hy/pSM9GaNhruLRCbTPTw2deJt03FvwlszxbZp0yNuL4Nfk47PtEzWm+TPZI1LJcjqZjVWyrZVsDrSRPuSiqLIdX4kADqBEkIMASRsIgW9iANgSgQSBJAGyUwBGxsJSCNjYVqSSAEJJIAQqWRUlBKwIGwjq6fBDZCfBDYFgyEwwIXktsr7jYQsCuxsHFtkEbJBxKDZBDBxDZaDKkp6CZFtkbI2QFl0xspslMISypLICOpIZJVgCNltcFSqIw3DFs7Z/9y1kNmKK7WWjr1ZcenwcqTSXczcnY5LycDp9j7tbO5Wu6KFev59isW+43qLGmuTV7NMyQepIxyezpy69Jg2fidHuWjh4NnB1Yy2kVldXx6zdwKosW6mYI0PYkiRK3OKa2yzXBXZbYRap4ZZy/EhoNpLySzuyRXuKSsUV5Md1ygnycrKz1HfI45dnqjdvzFBeUcy/qijvlHKyuod29M5F2RKTfLHHl7/T10cnqDnJ/kcy61yflmv3ycvJbyiXlbd1qjlyNplZrkiPkly22rpaIaL+xGitZ2KpFvBKREmRxHx6bKyKd35EyZCZhVWRsNlWyty41mJJlVHb8lWxHezLZs5HRq1/KssatmxXQRTFs36q9+x527c9ry+X7+ymGvY3YLfsVrqNmus8rdufVePzyf6UUDLCtmaNWzYhT+jhyyte7rxmMYI1foyKltm1Cn9G1Xj7a4KzC2tMtnI1qcVvXB1sbE8cGajG8cHVx8daXB6Pn8/Xn7dzFj4utcHUox/0WqpS1wblcEvY97z6JHm7d1pVWorwZkidEnpY4SOPLLoSEGaRVDKkyW0UXHDI4irbOb1bOjiY8pOSWkdC2cYVuT9j5j9QPUCqxLIQlp6NsJ2ofMfqT6l/i7pVwnwuOGfJLJ982zpdZzJ5OXOUpN8nKGzLtTAAGaQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtCbhJST00VAH1b6e+tHgXV0Wzet68n6J6J1aHUKIzjNNNH4mxsiePbGcHppn276c+t+yMKLrOfHLLRFfoXTctrwZEczpvUq8qmLUk9nTTTXBFhEggkrVgh+CSGTEIRDLIrLySI1wYbY7M6KTXBzbMerTJy7609nIy6fPB6GyvbOfk0bT4PJ9Xn+nfp2PLXw0zWZ1sunTfBzZw0z5r06uV6+jPrVuW0c7Ih5OrOPBp3V8HHjeV6OF+nIa1Iz1clbo6ZWqWpHV+4ta3Y17RWVTM9HKNiVS0Z5fSvY5M62YZQOpZUjVsqLYbOOPdqmbnyRrWQTZvWVs15R5PR0+jjxPT4Jf8ATRnWa8o6Z05V7Rr2Vfo9fT6Ovl/b4Of6a0JaNhW8GCUNFU3s9HDb181t89xyZpz2YJPZZsqzf5M+cVLIr4J2T1Xp7lkQiQdSAAkQZAJQAgkkSB7EASSQEBYgEASCAEpBACEklSQJGwAhBIBKvQjYZDAsnwRsheCALokqiwEe5OyoITFtjZUBK2yShcCGRsMgCSGSgSACLaIFQvJLICBkEsqShYhkkMgR3BMjROiqVnpowyiZCGi0Wxy4yYcu2Z6LGsTijzMH2yOxi2/ghXo+fY6kpoqpfka33G2Z6+WZ173n2OrhT00d2p7ijz+KtNHapnwisj1dWU43orghsrGXBEmSvlskT3EORjcuSkp6Jc2e+RsrRDlFI0LctVryc6/qut/kS4s/TI6t+VGC8nMv6rGO+Tj5fU3JPUjiX5s5Sa2S493r/wAXoMjqyknqRx8jOc35OdK6T9ync2HkZ+ms07m35MblsqRphy5brWTjyQ5ledEaYZ/Lq3kdoXBOyOplBsjZVsJX2VkyvcQ2WTKo/IcgyDPO8bYTqGyNbJ0ZIQ2zj2beOvDz3JRVNm3TQtcoy1UprwbMaWnwjg3b3q+HxW5IqpXwbtVX6FND+Deqp/R5W7e+n0ePjHXUzYhU0Z66kjMoI87PZbXs6tMxjFCs2IV7IjHk3KK9tGunG5LZ5fGIqo37G9Tj8rgz0Y6euDoVY+muD1tPn64Nm/itGPwuDpU06SJpqWlwbkIaR7Onz8cGzb1SENGaKLdpOtHpYYSRzXLoADRmkMgMJDDN6exdkQpi3JpHlOuercXBrnu1Jr9lpOore671JY+PNKWno+C+suqTvdic9nV9R/UCq+UoQs3/ANz5j1nrX8VKTUvJrb8Yjjz2XLuul/cwFpy7pNlTBYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADd6f1C3BvjOuTWmaQA/Qf0+9cxujCnIs/Lxyz7ZhZ1WRVFxkntH4i6V1S7p+RGcJNaZ9/9AetVmwrqut5SXuW/aH2zyiIt7NXDy45FaaaZtpa5K2J6S4QXKAIgkhokFhXWirWy7KsrYhicEa19a0zdaMFsdpmG7XLi0158rgZdCezj5FXbs9PfRvfBx8ujW+D5r2ed63n2uBZ5NazlG9fXps1pQ2eHnqsr19e1y7609mn/LI6mRXwzm2R1Itg3+XW3jW8pHVr1KJwqX+SOzjbcScsesNufCyCMUqU0bc4Ds2jG42Iw2dce2rl8GnZV+R3LKds1bcf9FsM+NMsJlHJcdGKcUb1tWjVnE9DTv48j1+SZRo21mrKLTOk4bMVlK0erp9H2+W9v8dyWyNBbDZndejBYtHpY7pXzOzzZSsfcWXJifDJjI2xz65MsLizEkJrQ2bSskkbDYRfiYlckFlwiGQkSJ0EydgUJBDAbG2QwgLbZJUkCSCQShG2EToeAkA2NgTyOQAcNjZUbCvEkDY2E8AQ2R3BPxZENmLvLKQT8VmTHkqnssuArYt28FWXRLiEMRPcyzjoqAGgNg4nQZGyUBG2h3MlldhPE7ZJXZOwjhtjRIBxA0TsjYQlJBkbIbKrBOipI6qiSN3Fm+EaMmbOPLlEujTlyuvBRa2bFUkmjnxs1EsspQl5K8ezo3ceixmuDq0NHlsfqUVpdx1K+oRjHfciOO+erkehUoqPkwW5EI+5w7usqMeJHJyetuW9MMs/Y9Jb1GEP6jn5HWEnpSPLX9RnP3ZqvInJ+5Lh2eyvQ5HVXPfJy7ctyfk0u6T+SHslw5+q1mla5GGUedkJkt7Dnu61XRKRJKCtiCNss0QQzsQtliNhshHE7KNhsoyOrRdMq2IFZMj5cac7Ar3chsqvJW7OJmFrJ5Wyq2/BdLcTLRV3Pwcm3e7/ADefK1SFbb8G7Tjr3M9WNwbEKdex5m3e+l8nj6iulJcGzXVz4L1VbN6ujg8/bt6+h83kmH2x01m5CtCFWjPGBx5dyeljjIoomSENsyRrb9jZpo2/BGGi2rZbJIx1Y6kzo4+KlrgtTj8+DpUY/jg9bzeZwb9pRTrRv11LaJqo0bUK9HuadHHlbM+rQqSSMiWgvBJ6OGHHPaAA1VVk2mR3r5LS01oxfa9ytSvGT3yYsvIVNTltcEzsjGLbetHzr136wr6bjThXau7TXkmRLS9beu6cDHnCu3/U/TPgnXPV+Z1C+f8Aqy7W/k0uv9cu6lm2TlNtNnC8lu8GezKsse5SbZhcnLyyAV6AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHa6H1y7peTGcJNc/JxQB+oPQfraGbVCuyxd2vk+q42VG+Caez8U+nuv3dLyoSjJpJ/J+jvQ/rOrqGNXCc13a92T+1f0+nTelsmD2tmKm6N0E09pmTuSekVWi4IJLJCuiwCtV0UlHZkIa4IynYiftqzq2jmZmPtPg7T8GrdXtHmenTLHXq2cePzKO1+DQlHR6TPxtrwcPIqcdnz/o08epp2uddHaOXdVydicdmlfX5PMynK9PXl1oUw/wBRI9Hg0bijgwWrl/c9V0zUoo304/Jl6GO7H0vBruOjvW4+4+DQtxtew26uOXDY5clyYpw2jctqaZgcTjyx468Nrm3VbNCyl78HclXs1rMf9DHPjaz5RxZQ0YZrfB07qNGnOrTOvVu449/kmc40pQNeyvZ0XWYpVno6/Q8H0fxcn+nJsr0YGtM6tlJqWUnoat3Xzfr8Px/011MyJ7MTi0yVLR6GGzrw9un41nRJiUye7ZvMnPzi+yCEyyLdQgbJZXYEolhBgGQgwgJJIARUklSdkixEiuxsJAQ2Q5BK2xsx95DsCeMmyrkYnYUcwt8WZzK/cMDmVcgtMWx9wq7DA5FXILTFm+4WVpq9xPcE/FvQt5Lu056saH3GEXW6UbjKrlo5P3Wifvv5HVfxulK1FfuGh95v3JVv7B+Nvd5OzTVv7LK0H423snZrK4n7yCLhxnbI2Yfuoj7gU4zbJTMKsLd4OMuxsx95PeEcXBVSJ7gjiQV3ySmQhOiSNjYQrPkyUy7WQuSsn2hfGtx36h5OfkZbTemUstevJpWtyYdevOxmj1CcZJ7Z0KuqyktbZxIw2zbphoitMttdSWTKxeWYmpN+SkeEWUgwy21OtImPkb2WjElz5ZWskWtFZMeCjJZiJa4K+CW+AnhsJlSQv8k7DZBBWoWSDLL+UpJlUyDKlXIq5FerTFkb0Y29sb2TFbZlnk6NeHUduyYw2zYhVszQo5OLbt49bzeP5sdVW+Depx+3XBeijTXBvRqPL2730fl/jf8A4rVDg2YUb9i1NPJ0Kqf0cGe3r29PmmEYKqdexuQhpFlXpGaFe0YXLrr7JGNQM0Kt+xmrp2blONz4OjVh8mOezjDVj79jfoxufBs0Y36N6vH17Hr6PN1x7N7Xqx/0b9VOvYvCnRnjHR6+nzSOHZt6iMNGVIgk7ccOMLegANFOA2RsjZPFuEltlLrVXBtvRM7Iwjts8P6x9W09NxbEpru18iQ4wer/AFfV0nHsUbF3afufm/1R6nv6vlTcpvW/kv6p9UX9Uyp/6j7d/J5KUnJ7ZNvEDe3tkAFQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAT09o9N6Z9SXdKy4NTaimeZJTae0B+s/RvrGvqmLCPf8Al48n0Gi2M4J72z8ael/U9/ScmD+41FP5P0T6N9a0dTohGVn5f3JH0pPa2Q5pPRhpujOCafkytJ8og6v7bIUk3opW5N6ZZx09oCfcPwECUcY2nspKOzKyGjPZh2Jxy45uXTuJwcvFb3pHq7YdyOZkUb3weR6fPK7dOyvJW0uD5NK6KZ6HMxnp8HItoa3weB6NHK9bTtcaUNWI9F0bfucW6DVh2ejy5RPlw4nfs7HpVX3QXHsYLcfa8G/Sk4L+xZ1Jnp/1pnHmfkseZyqe3fBz5VtvZ6nJxFNPg5F+N2NrRw7/ACSOnVu+3KcdFJxWjasraZhnE8fbhca9PXn1z7oJ+xp206W9HTnDkxWVbiUxtjf5ONOBhcTqTo/Rq2Va9jow2MtmHyjRlAwTrTRuzhowyid2rfY8j0+GZuXZjvbNadUonYlWa9lLZ6mr0Pm/V/FuU9pl4zM1lD+DC62vY7sN3XhbvDljf0t3FlMwSbRCkdWOyVw5aPj+2y3shbMSmWUy8yjG48ZkWaMCnplnYW6j4rsIxqaZbuFqLiuDE7NFXb+yvUfGszZVyMLs/ZR2E9WmDO5oh2JGu5lXLZbq8wjYdpR2GHuI7iOrzCMrmVczG2RsjqfhF+4bKFkOp4EbJIZPTirYAJSjRGmWASo00SmTLwUQSsyvJZE6AqmWTZGhsC22T3MoSBbvfyT3spoaIRZF+9/JKs/ZjBCvIyqwsrDAS2EfGNhWEqw1O4lSZPUfBuK0t91GmpMnuHUfjbf3UXViNHvJ+4Sj8bfViHejSVhZWhH4m4p6MdliNd3fsxys2QtNbJOxGvKSbIlLZTYaY48WT5Nmpv3NZeTPWyEZuhW01yX1EwVszIlz2If6Ji3onRK4JUpySiuyUx1T7TojRbuRXfIlJ00Rslso2W+mnIttEbRXZGymViOJdnsVctkpRZbtRz5Z8bYYWsTGtmXs34Lwpb9jDLdx6WnyfJhVbZmrqezYhTpcozQr0zj2+nj2vN/Fy/aaaeDZhVz4JrWkZoxezz9vo697y+GYMldXBs11tsrVF6NuqtnDln17WvCYxlpq0btcVox1Vs266is12meUiqrbNmmhszVUJ+x08fFWk9HTp8vyv24tm3jVpxJfBv04zXsblVCS8GzCpI9jR4pHFnvrDTRpeDbjXpeC0YpIsnyexq88xjkyztFFE6AOiTjPqAiQSlDeh5RElsnaSHUIK2SUIttkykorZ4f1h6tq6XjzSnqX9y0+09V9W+r6Ol49ke9d2vk/OXqz1ZkdUyp6sfbserfVd3VMubVjcW/k8bObnLbYt4jqJScntkAFQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASm09o9H6c9SZHSsqDjY1HfyebCemB+rPRnrijqVMIWWru18n0mm5WQTi9pn4q9Peob+lZUJRm0tn6I9E+vaeoUwrttXdr3ZI+qrhbKxk3LRgoyYX1qUJJpmxGOnscQsACEoaIaLEEqqSXBq2Q22bmtmJw5Ofbr61wy45GTRtPg5N+L54PS3VbRo20bXg8rd5uu/Vt48hl42nvRm6TFqf8A3Ojm4z0+DX6fX22ePc58PP8AGtc9nY9TjQ3CP9jZ7GjHh/yI3GuD0tWr6efnn9tSde0czKxtyfB2pI17KlIy3+fsTr28rzF+Nr2NC2rR6fIxuHwcm/H5fB4O/wA329XTucWUOTHJcHQto17GnbBo4ctPHdhs61pQTNa6o3NFJR2Yc46plK5FtWvY13A61tOzTsp1svjnxNwmTRcSrrTM0otMqdWG6xxbvLMmtZQjUto17HTfJhshs68PS8vb/HSuNZRv2MM6nE7H2tmvdQd+v0fT5r2fxtmX1HJbcQrDNbQ/g13U0/B047+vD3eTLG/pk7yHMoov4IkmdGGzrkuFi33dFvums9krZvMurSSMzm2R3FNMgmoslZO4bKARHFgQSXkDRGiQKI0NFgVOqElu0dpKeoGiyiWUCx1i0O0zKBKrCesHaOxmz9sn7ZKPk1ezZH238G5Grks60OIubTUGh2m06yOwcR82v2FOw2+wfaHD5tTtHabTqKuscPmwaGjM6yOwcPkw6IZlcCjiRxaVQMt2kaHFlNE6J0BxaAI2RscTxJGySCvT4mx3MhlWE/FZzZVyYXIaBxGyUyNAJ4yJmas1k+TZrHGWcbdZnj4MFa4MyJ45coyENldk+wU6hsJkNhMjrTGSrbK75DKti3i9wnF3Iq2V3sso7M7tUwwtqpPJkjXsyKk589z0NPkuTAoS+DJGtv2NqMEkZYQRxbN71vP/AB/f9MFdL+DarrSMkYFnHRx5+h73n/jv/irivYmMS0I78mZQ0cOzZbXu6PLMYiETbqq2YI8M3KZaOTLOu3HVI2aqUjbrSNeNi1oy1sYZfacseN+qKN6mtM51U9G9Rek0ejpkrzt3XVoo2kdGmvtRzaMpaXJ06LoyS5PU0YR523rZgjLErBpoyI9bVhxx5Vb2IS0yUSdcUqPckAlQAIfgLIcis5RjHcnox2Wxqi5SaSR8/wDWHryjpVM412Jy17Mng6Xqr1dj9KxZpWpS18n5x9Yerruq5M0rG4t/Jg9U+r7+rXz/ADfa2eOnNzltsm3gTm5y2yoBQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAT0dronXL+mZMZxm0k/k4oA/TPoj6g1ZNddV1q3rXLPrGHnV5dSlCSaZ+HundUvwL4zhNrT+T7n6C+o0HXVj3z58bbLftD7zsnZzundUpzqYyhJPZu6e974KVLKVbI37FHGW97LSq1kTI9widEX7RKxzjtGJ0p+xstFWjLLCVrjnxysvF7ovg52PiOM/HuejnBSi9owRoin4OfLV9tps+k4sNJG41wYq49plOnXhyMM6prkq48l2C+WEsYy8rVur2mc26jnwdqS2a9tSfseXv87t07ePPX0fo5t9X6PSX0rng5mTj7XCPJ9Hn5i9HXtcCyGjCkdOzHZqyr7fY8TPCyuzDZWu4bRrW1fo3G9GOWmjmvY7MM+uTbTy+DVnBpnYnWm/BrW0rXg0w2Nf25qiHDZmsraZh00bys8sesUoaKOpSM7IOjDbYx2ePHOdak8VP2NWzE/R1GUcU/Y6sNzx/T/GS/wCnGsx+1b0asq/0d+ypOPg0542/CO3XvfP+n+L5+o47rCgdGeK0YXX2+x24bng+jy5YNbt4KOPJtOJV17N8dnXDyy/bW7SVEzusKs1mSbkwdrJUWbKrJcDWWKfNrdpPazP2D7ZZHzYe0lR5Mv22Ptsjh84r2DsMnayVBkK/NjUC6gXUCygyUfNRQJ7TIloEo+aiiSoliSUfNXt0Q0WZAR8lGiO0yaAPkqoE9pJIPkp2kdhkAPkxOsq4Gca2D5NZwMbgbbiVcUFpm03D9EOH6NpwIcCF5m0+whwNtxXwUcSWkzariR2mw4lHAheZsXaNGTtZDRHEzNiaI7TI0RocT8lNBk6GieLfJXQ0W0SieHyUS5NisotGVDiLk26/BmSNWuRsxktFbXNnVtENByK95ncmHKMjYb2V7WylzjTHDKrNldbLxrbM8KTLPbJHZq0ZZXjXUWZ4QM8aV8GaFa+Dz8972fP/AB1/4xwr/RnjUZIxXwX0cuze9/zfx/P9MP8ADkqpo2E0TpM4dm57WnxyKQiX0SoloxZzZZ2vU1aJGNcMyJ8CVZeFbEz+l7jyse3s2K5MtGn9GSNLM8vtHeCsaZmhkclVQ2ZYYrJwwrLPOM0L9mzXY2zHVhyZ0KMCT0ejp11w7M4vTOWlyzpYuRJSS5K04EtLg36MFxabR6/lxsv28/flP9Ojizcoo3EjXor7I6NhM9fD6cGSdEkbK8s26zq5BClzoN6WwqsYMjIhTW5SkkkjHl5lePRKcpJaR8k9cfUSvChZRVNOTTXDLyJdP1r67o6fTOuuxOWn4Z+d/UPqK/qmTNubab+TX6z13I6jkTlOxtN/JxW23tk2/wDEjk5PkgAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABs4mbbiWxnXJrTNYAfbfQP1E+zKvHyLH8cs+79K63Rm4ynGaf/c/EOPk2Y9inCTTR9V9CevZ411dGTa+3evJP7Q/TkZq1bj4Jc+16ZxOjdcxc/GjKiafHydmOp8yHEMsV7liF4LIqcQNEglPFNDsRcEXHp3iEgxshsmRbnUAlEtFmeWKpWUdlwZ54dTheNS2rfsaN9C14OtOJrWV9xw79HY7Nezjg3UceDmZFLWz01mOjQyMZPfB4e7x8d+vdHl5waZTtZ1r8ZJ+DSnWo7PJ3aOPQ17I02isq0zI1yydHHceOuZStC2n9GlZXpnYnHaNO2ovjkv2ObKJRo27K9MwSjo2lW6xaGg2Rs0lsVuMo48CNaZO9jejbHbxz7PLjlFZ0xa8Gjbj8+Dod+yHFM6sfQ8X0/xcy/05P8O9+B9nXsdR1IxSq5OnX6Hz/q/iLP1HOdRRw0dCVRhnT+jpx9Dydn8ZnP8ATT1ohszSra9ijg15OnDe4NniyxURZDQ8HRjtceWnKLaDRGye4vM2XxqpKJ0idIt0+NCdkcDaJ6ixII2Nk9V4kkrsnY6DRBOyC0oAAAAQOiQQB0SSio2OixGhsbI6I0Q48FtjY6licSriZtEaHVpWFwK9hn0RodW+TA6+DG4G21wUcSepmTW7CsoG12lJRI+S8yavaOwz9miVEj5NZetf7ZDjo2u0q4FfmvI1kuTKiXWWUGUy2F12/pMWZYyZWNTM0Kn8GOW5OPlyyRyyNPZsxo37GRUc+Dmz9Ds1fx9rWhFszRqZswoS9jMqkcuXqetp/i//AI14VGxGvXsZYwRft4OfP1dj1NH8ZJe8Y4wRkjAtGDM0azhy3va0+OT/AExqBKgZ41meNH6MMtvXpa9MxasaTIqTajS0/BljV+jK5dadkaX2WSqmb6qRdVRK/a02caUKHIzRx9exuV1L2MqqExtLtjTjSZoUb9jahQ2/Bu0YjfsdWrRa5tm6Ro14u34N2rC8cHSpwuVwdGrDS1wepo8bztvoc2jCXHB0qcSK9jdrxkvYzxqSPW1eSR52zfWGumK9jOoRSJUdF0uDsx0zFzXO1RIukNaIbNscUWrcEaKclnLtXJfiFZPng0uodTpwKJWWySS/ZpdZ6/i9NplOdiTX7Pgnrv6iW5NllGPa+3+5eY/7Veg9d/UatRsoxrP1wz4Z1Tqt2ffKdk29s18vOtyrHKcm2zVIt/4kABVIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGSm6dM1KD00YwB9G9Ievsrpt0K52Ps37s/QXp31fh9Ux4P70e7XyfjiMnF7T0ei6J6pzOlWR7LJaX7Ld6P2lTkwtS7XtGdM+KehvqOs1wqybUn+2fWsLqlOXBOE09/AuI6YKxkmvIciBICewR1WmipZlWR1eCZZFdFl4JlKMgs0NEqcVaKOBlDRWyVfvI07IcGpZVv2OnKPcYnSjl3apYnDblK4WRjNp8HJvxmt8HrLak14NC7FUkzxPT5Lf079W+x5OdOmYZR0du/E1J8HPuoa9jxN3myj0de/rSa2Y5V7M7i17FWceUuLrxz60rad+xp206Ou4pmtbWmi+Oc46scpxxZwMfab9tetmrJaZtjl1brGkTrZLeyFwW5WkR2jei3cV1sntibrlSnshk70RrfJbHOxhl5cL+ztTKupMyJJE7N8dlcW7w4X9RrOhMw24/HCN7uIf5HTj6OPG9H8VMv1HLdD+Cjpa9jquCKSqTOnD1x427+Hy/45TrZRwaOpKlGOVHB0Y+qPN2fxOU/05+2G2bLoKug6p6cXn5fx2c/019sjuZmdeiPtl5vxrHLxZxjUh3Eyr0yrgaTZKwy8+UW7h3FNMh7LTKMrprIpE7MS3svsn5xW66tsbKbJ2T84r8KtsFdk7HyR8akEbGyfkjiSfJXuCkPkcW0CO8dxHyTxII2NkfJPEtkbI2RsfOJ+JsjuIZBHzi011PfyW2Yu17LpP4KXbFppyqsnoqnsy/ZciY4zRnd0jpw8uVY+3ZPYbMKTIqNmWXojsw8GytNVllVs3Fjl1Toyvpjpx/jdjR+x+i8aDdVReNKMc/VHd5/4zL/casMczRoNqNZdVnLn649LX/Hc/wBMMKizr58GdRaJSbfg5M/T16GrxSf6Yo1mRVv4Niupv2NiFH6OTPda9LX55GlGp/BmhQ2/BvRx0ZY1KPsY3ZXTjrjVhi/oyfw+vY248exbW/Yz+fWsx4041aZsQrRl+yXUGiZ2pyzkVVcS3YiyrbZmhS2a467XLnta/wBv9Eqp/Bvwxd+xt14e/Y6sPNlWF3xzKan7o3asbu9joV9P7jdpwVE79Xiv+3Ns9X20acL9G/TiJexvV4yXsZ41Jex6Wnx8cmfota9dCRsRhouo8l9Hp69MjlyztQuC2wVXLN5jxmsmN8h8ELl7JQs/BVEt8Gnl9QoxK5SssitfLJiOti2+umLcmkeM9Tes8bplEv8AVSevk8r62+oVeJGUKLot/pnwr1B6qyurWSU7Ja38mnJJ9pd71b67yupXzhCx9m/k8BffO6blJttmOU3J7bKlLl0AAVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABuYPUb8G1Tqm00fUfSP1Nvxp11Xz2lxyfIi9dkq5bi2iej9l+nvU2P1WmM1dHb9u49TXdGS4aZ+NvTvrHL6VdD/Vl2r22fdPSH1Fp6hCFdk0pP5ZP7Q+stbe0ydaNLDy4XVqUZp7/AGbbsTK2EW7iHLXsIcsvpEcSqpb9i5CSJJAAANEMkMFVIa4LDRFirXnE151+TecTFKBz7NfY1xvHJux974OZkY3ng9HZVtGldj73weT6PP126tjy91OvY1Jx17Hob8Xzwcy7Fe/B4u7y16OvbHJm9Mxtdxt20OLMfZo83PXca7cMutGynZo3U6O1OK0al1aZbG8dODjSjplGbttevY1XE3mfW8Yi8RonwT+1vlwKsORePKIs4r8+qcgzKGyftj5KVi0NGVw0R2kfJT4ysbIMjiR26JxyZZ6eqduw6y3BO00deGf04M/L3/TC4r4McobNhwKaLfmsYZfxsv8AprOnZX+HZuJIn8TTH0WOPZ/F/wDxoOjRV0m84pkdi+DWeuxwbP4n/wCOe6CHQdDsRX7a+DSexy3+I/8Ajnyp0U+2zoyrTXghU/o1x9fWGf8AE2f6c/7bH22dD7K+CPtL4L/2mGX8Vf8AjQ+2x9tnQVK+CrpXwT/aZX+Jv/Gh2MhwZvun9FXT+i39tX/8m/8AGh2slRZufZ/QVP6J/txM/ib/AManax2s3Ps/on7P6K/2k/8A5F/40+1jtZu/Z/Q+z+iP7RP4m/8AGl2MdjN77P6J+yvgj+00x/ib/wAaP2mPtM3/ALS+B9pfBF9TbH+Kv/GpGr9GSNX6NhVF1WY5eh2a/wCI/wDjFGpfBkVS+DIo6LKJjl6Hdq/i+f6YXWvgtGsu0Wijny3u/Dwyf6U+2SqzMo7JUDG73RPLIxKsntM6gWjU2Y5bet9fnjDGJmhU2Z66P0bVdGvYyyzbzTGrHH2Z4YyXsbka0l4LdpjcqvNcjWjSkZFBIzKJPYJ1P1GJIvFbZmjVsyqngvMbVcs5IwdpaMTYhjtmxXht+xvh5rXPl6GtCvZnjRv2N2rCfwbleH+jtw8drnz3ufXh79jarwv0dOvF4XBswx9ex3avFXJnvc6vD/Rt14uvY3Y0pexkjWkenq8nHLluYK6EvYzRq0ZVHRJ2Y6eMLnahR0WIBpjjxVJEvI0GaSoW9ivhkOYivdkq1byismorbaRhysuvGrcpSSX9z556q+oWPgVzhCa7l8MmTqHq+ueosfpeLObsjtL5Pg/rL6lXZNtldFjS8cM816n9c5PU7Jxja+1/s8JdfO2bcm2WtkTxt5/U78yxyssctv3Zz29gFLepAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAb0dDp/VsjAtjOqxx18M54A+yelPqjZjdlWTY37cs+0en/VuJ1SuLU1tr5PxrCbhJNPlHqfT3q/L6VdH/Ul2r9lu9H7OhOMoJxfAUns+P8Apb6oY+TGuq63T17s+n9O6tj51cZ1zT3+yeDqreiyMTsTX4stCW1yVsFwRvQ3srRIIBAkhkjZZCCGifJOgnrDJGCcNm24plXBHPs1ytMcuOZbTv2NG7G37HclWma9lG/Y4tnnldGG55nJxf0aFtDj7HqbsbfscvJxXzweL6PJ9vQ0+j6efnFmvZDZ1rcdpvg1LKdex5mzTcXoat0rk21bRozraO3ZUaV9SMJ2V2Y59cmS0yvLNiyt78GOMVvk3xpax/bbNqvGk470Z6aVPR3MbBTqT0a/H5Mss/i4cceS9i/2H8Hclg68IwyxWvYrdVU/NHIdD+Croa9jrOjXlGOdSOfPGxrhtlcv7P6KSpZ0/tIpKoz+djeZSuTKtox6aZ050/o150muGxPxjUlIx92zYnSYXW0zbq/0mK2HElcIiUmOs8sJULgbK72OSWN0ypIJ7WRplpFL54hkxIfJaKHyuKt8mNH4Mb8mVoxuL2PyVS+LFaJDRaMS2h+Wqf0sWPQ7TJ2k9o/LT+jiw9g7dGftRWUR+apnhxYu0ntLaJ7Sfy1b+jip2k6LBrgj8tP6OP8AxTgaBKJ/JSeLFGidFki2kR+Srzx4xi8Fk0VkvyLJEXOtJoxi6GiUiySKXKrTXIr27LxrLQSbNiKijO5VFxjHGr9GRU/ozwUTNFRMrazsa0aDYhSvgyrs+SUyvaiXiYVJexkUEiIyMsV3Ez7VuxiaZaCbRnVWzNVjt+Ea4ausM93GCNbZljS37G7XiSfsbdeH+jr1+W1y5+mxz66H8GxHHb9jp14a+Dahhr4OzX4/tzZ+q1zacTnwb9eIteDdrxlH2NqNSR6enyxzXfWhDHS9jPGlL2Nn7aLKB6WvzSRndtqkKkkZFBFlwSbzXIxuVV0kSQ2Fyac4r1IDCB00ToDkqHgjhkOWvJpZvUacSDlOaWv2TINuxwgts4fVfUuJ0+uTlNJr9njvU31FxcOE4V28/pnxP1J66yc+yahY+1/s0mMn7Q936w+pLanXRb/hnx3q3XMjPulKdje/2c7JzLMiTc5N7NYi5f8ADiZScntsgAokAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbOLm24tinCTTR9M9J/UnIwXCu619qPlRMZOL2notMuD9een/XeF1GEd3ruf7Pa42ZXkJOEk0fibpXX8np1sZQslx+z6z6W+qk4KFV80l8st3qH6K2n7kpaPIdF9YYXUK0/vw3rxs9HVnRtS7HtP4K8G05aJ3wU1tbJjPnRWw6smyfI2h4RVKVwVlJrwVc3vwWXJPUJRJGiSKIaMckZSGitx6nrXlXv2NS6jfsdLRWUNnNs0StMdljzt+J54OZfjNb4PXW0Jo5uTip74PL3+V3at/Hk7adb4NG6o9LkYnD4OVbjPng8nb5ePS1ehwbavPBo2R0zvXYz54OZfjNPwc/4rHZjtlMSepI9d09KdMTx1cHGSPVdJu4jE6vNj2sPTl9Os8VNeDBPD37HZpr7ob0JUbfg9D+v15n5687bg8eDRtxe1+D1tmKu3wc27F23wc23yfTXX6XnXS17GOVZ2bMTXsallGn4PM2eayu7X6HLnA151/o6c6f0YpVfo57rsdOO9zJ1/o151nVlUYZUkfOxtM+uVKsxygzpypMEqi+OxpK0HElcGzKoxyho0ma8incVlLYaI0azNb4oXkuVSJF+z9JXJdQ2RBbZswhtFLFLWHt0R2s2vtlvscFbFLk09E9v6Nn7HJZUlT5RptaINydBidI6n5Rq65LLwZvs/oOpk9PnGs/JK8GR1MmNfJPU/Ji7R2mz2FHAdT8mAbMjgVdZKvzYydl/tsq4lj9pTL7MaRkSITxaD0X+4U0VaK8Pi2IWmeNpoJ6ZkjMr8Vfxt1Wc+TN91a8mgplvuGeWKmWt0K7E35Ojj6lrk8/C5pm9j5nbothi58tb0ddMZI26aVE41PUFrydDHzoy90ejpwjh2a67FUFo2Iw/RoVZcdeUbcMqPyj2NGGLz9mFbsI/ozQjz4NevIj8o2IXRb8o9HHXjxyZY2M3aSkQppljbXjGXUgMjZ0AR3PZKXIb17EWoNbIf4rgnaaHsU7UcVi3LyXXBVS4MM7kt9z0i+M6hmcjFfmVY8HKySSRw+s+psPplLlK6O17bPj3q36pTmp00SWvlF/iPpXX/AF9gdOhNRvXev2fHfVH1QyMtzhTY9M+cdV67kZ90pzslz+zjyslJ8tj5SDo9Q6xkZtjlZNvf7Oa5N+SAVttSAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL12zre4tooAPQ9J9UZnT7YtWy0n8n2P0j9Ua3GFd7W/G2z89manJtoknCTTRaUftPp3qXF6hXFxtjz+zt12wth+Mkfjfo/rTPwLI/60tL9n170t9UK7IQhfP8AL9sn9ofcIxa9y3clweb6Z6qxM2Me2yPP7O5G6NvMZJkcGx2p8kpaKVy45LtlbEpJ0RvgEcE6GiAOBoAgipQ1swWVKS8GzojSMstcqZlxy7sVNPg51uEueD0Uq00a1lCfscW3zyujXu48tfh+eDl5OJ+j192Nv2NC/C37Hm7fO9HVveOnR2vwdHpj7bUjdvwPPBgxqnXka0Z6tdxq27Z2PX4T3Ujb7E34NHA/9tHTUT1dWPXlZ3lY5Vpo1JY6bfB0HHZX7Z1XRLFMc7K492KmvBoW4n6PRTq2a08dP2ODd5Y6te7jzNmI/g154zSfB6WzGXwalmMtPg8zb5XZhueanS9+DBKr9HesxP0almNr2PNz8167sN0caVZgnWdadH6ME6f0YZabHThujlSrMM6zqTp58GKVJSSx0Y7I5E69GJrR1bKP0adlWvY1lafkao0WlHTCReVPerQ4NquRqeDJXPki1XJvRWzZUVo16eUbMfJnaxqPt/ons0ZlHgq0UuSnWJ17K/ZNiMdl+zRX5IuTU+x+ijoOh28GNxWx8qiZNL+H/RV0aOiocFJQRPyrSZOf9oh0m99r9B1FvlU9aH2SPsG/9sj7ZPyR1oOn9FJUm+48+CPtp+xPyq8zjnfZJVLOj9n9E/ZXwPlT8kc51tFHWzpujfsSsXfsT2n5Y5DrZCi0dh4f6KfwfPgdp+WOYkyy2dNYXHglYL34J5aXbHM7WXipI6iwXrwP4J/BfHGsstkaMJzXuzZqyJx92bEcL9GWGFz4OrX2OXZnFqsuevLNqvMn8sVYXHg2IYT34PQ1bLHBssZqc2fyzcozJOXlmOnBfwblOC1Lwd+vbbeOPZZxu0ZDbR0Kp7Rp04zXsbsK3FHo4VxWsmwyu9Fk+DeI6pGX5aLvTKd0W2l5Ne2brbk5JInnRsOD3wyJWQqX5SS/ucDP9VYmBB981tfs+a+qfqhVFTjRPT/TLTAfUOp+o8TAhJythx+z5v6i+qtOPGddWm/G0z4z1v1rnZ9stXy1/c8vfm3XybnNst2Yq2PUeofWOX1S6b+7JRb8bPKW5Flr3KTZibbIKXK1IACoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABmpyraJbhNr+xhAHpul+sM/Bsi1dLS/Z9V9K/VJPthk2v8AyfBDJVdOqW4NplpkP2Z0z1hhZtcXCxbf7O/RnV3pOMkz8YdO9WdQwZLsukkv2fRPTf1RvqshHItev2y3ZUP0vGaa4J7kjwvRPXnTsyqO713P9nqqOp42VBOuxPZWwdBSiyxghKL52ZXLjgiw6lkJlVL5LEcR1JHJVuRMW/cixMW2Ua2W0hopYvGCdaZgnSn7G7oq4GOWvGtMc+OXZixflGn/AAMVZvR3nUmUeOt70U/BitlttamPBwSSOhB8GNVaMkVo1w18Y29ZEgESzaRCjjsq4IyBorlh1PWtOpGCVMX7G7KJjcDny0yrzOxzZ48X7Gpbix+DtOrZilQn7HLs82Lox3V5y3FS9jRtx9PweosxU/Y0rcNb8Hl7vM6te+vNToe/BjdTO9Zhc+DXnia9jzdnnyd2ve4k6v0altC+DuWY36NS3Hfwc905OvHdHCtoWvBrupo7c8b9GCWLx4I+8f26sN2LjSi9kxaTN27H17GnKtp+C0yiblK2K7ta5OhjvuOPGL2dPEm+ERbGGcrodstcEwrblybePX9yKNyOFvnRfDT8nHszuLRVMdeBGnflHVhhb9jI8LXhHR/SvOsPz/bkfZKuhfB2P4N/A/g/0R/UqfzuN9nRH2dnZ/gn8BYT34J/qVP9hxv4f9D+Hfwdv+C/RZYX6Jnkp/ZcH+GfwR/DP4PQLBXwWWAvgf1Kf2Xnv4PfsR/Cfo9KsBa8EPp6+DSeKn9uPOLFfwXjifo9Aunr4LrAXwWnhqv9uPPfwf6LxxH8HoVgL4LrBXwXnhqt9cefWHv2LLCXwehWEvgt/Br4Lzw1W+uPPLCXwZY4S+Dufwa+CVjL4Ntfjk/al9XXGWCn7GWPT4P2OusdfBkjQvg3nkx/4zvprkR6dD4MsOnQf9J1lQi8a+16N8fLj/xjl6LXOjgRXsZYYkE/B0lWmh9qJvj5sWGW61grxopeDMqUi3a0uCO6W9G+GiSscs6lLTLuaXkxuxRfLNTJ6hi0JuyxI6pjIy63O6L8GOy6EFtvR5PqvrTpuFVPtvXckfKfUn1VvUpwxrnrxwy/EvsnUvVWDgRk5WJNfs+YeqfqjXFThj2vf9z5B1L1ln505d9smn+zzt+VZfJuUm9lvlIPT9X9Z52dZL/Vlp/s81dm23Nucm9msClytSlvZABUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC0Zyg9p6KgDq4XXcvDknXZJa/Z7Pon1M6hiTjGdraR83JTa8E9H6g9OfUinNjFXXRTfyz6FgddwsmCcb4Pf7PxRjdQvxpJwnJa/Z6jpfrvOwNf6kml+y3ZUcfsKN1VvMZp/9y/dpcH536J9W7E4xukfSeifUHEz1Hutim/lk8/4h79Te+TImjk09ZxL4Jxuht/s2q8muT4mn/wByODZbfcXMcbEzJspcU9SCrZGyliercElUSRIdTojRKBeQPBDDCLJCSNABojtJ2SU4KaI7dl9FSLhKj5KSrTRrzp37G55KSiY5+eVrjnY58sdP2NezG/R1nAxyr2cmfkjfHdY4VmJ+jUsw/wBHo5Ub9jDPFXwcuXkjfH0vLXYnavBqyo48HqL8TcfBoWYevY87f47b9N8PTXmr6PPBz7aNPweptwt+xpW4D+Dg2eXKPR07+vO/a0Z6UoyN63Ca9jSlXKMvDMJry79urLZOO7gWR4Wz0OPGM4nisa91yR6npeUppI9byYf9eT6sv+OuqdexkjT3exs1RU4mWNej3cNWOUeTltvWn/DL4J/hl8G72E9hb+rEfmrS/hl8D+GXwb3aO0n+rEfmrR/hv0T/AAy+De7R2kzyw/NWl/DolUI3O0dpP9WI/LWsqET9hfBsaJ7TSaMYr861/sIn7KM+hot+HFHzyYfsofaRmBP4sVbnkw/bJ7DITon8WKvzyYnAr9sz6J7SLqi+OdYFAsoGTRHCE1J+SO0fjvlkOyK9zWturUtysS/7mk1xX5NzS1wVckvLOTldcxMStuV0eP2eI679S8XCUlXbFtfsvMFevpFmbTUvzml/3OP1H1Jh4kHJ3Q4/Z8F619Wci5yjXL/B4nqXrfOzk07JJP8AZbkiH3Hrv1Opxu5VWptfDPmPW/qdmZUpKFj1/c+c35118m5Tb/7ms235YuX/ABPHazvUmbmSbnZLn9nIsunY9ybZjBXqQAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtGcovabRv4nWMrFknC2S1+znAmXg9x076gZ2Jrdsnr5Z7DpX1csrcVZz/3Pi5Kk14ZPyo/UvQ/qhi5s4xlKKb/Z77D69jZMU1ZHn9n4nxeo34s1Kuxpo9X0317n4vbu6TS/ZPZVbH6/hfXNbU1/kyJr5Pzd0z6tzq0rZyf/AHPadK+rOFf2qctP9yHOofX0x3c6PJ9P9aYOYl2zXP7O9j9SovScZL/JHxTG+NlFbCS4ZV2JPyOLMr4RCkmysbE0Gt/ykDIQ1oolJeS/cgK9xKZPBG0itEtlSe5MlaIlOCQ0H4MbjP2LiziOwiMZa5LaZFiequKRRxTMmmO058sT5Vryp37GtZjp+x0WuDE4bMrql/bXDNypYqfsYLMNP2O06yrpT9jPLyY5OjHfY81bg7T4OZd019zej2csZP2McsBS9jjz8MdE9f08FZgTi+De6f3UzW9nprOlb/pMK6S4y/lJw81xYZ7vk3cLJUoJHSjLSOdjYsq9HRhF65PQ042OXLi6kiy0yvaTo6+s+J0NFeRyOo4kDY7kT04bJ2V2h3IJ4kjY3sOJFgbJI0yHNR8jlFiGY3fFFu5SXDHKLaI3oo5a90a9/UKceLc5Lj9jlPpu7RV2JeWeQ6n66wMFPumuP+Y8b1P6vYMdxr8/9RaRD67PIriuZpf9zk9Q69jYcG5WR4/Z8E6p9WLLe5U2SX/c8Z1P11n5ra+/LT/Zbkg+59Z+p+NhylGMotr9ngOr/Vmy2UlU9L9M+SZPUcjIk3OxvZqOTflkfIez6n68zszaVskn+zzGT1LIyZNztk9/s0gRcqJcm3yyACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAT3NGarKsqe4yaMAA7+F6ozsRrsuktfs9Ng/UrqNCSldLj9nzobLfKj7d076u2Q0rbZHqsD6t4FmlZN7/ALn5o7n8l43Tg+JMfIfrnC+ovTcjWrP/ACdzG9VYeRrtsX+T8b0dXyaNdtkl/wBzr4frLqGM1q2XH7J7KP2LT1Om7xJf5NyFkJryflTp/wBUM6jSlY/8npMT6v3RSU7Byf6H6K3Efiz4hifV2ueu+07+H9UcCzSleiPih9QUUHx4PIYfrvpuQl/rx5/Z2qPUOBdFON0X/wByPinrpfkWXcasepY0/wCWxGVZdT8SQ4jrPsjZi+9B+5kU4v3HDqwaIckR3EfHoePI2mPPkjtRncPs+SeBpDQ8GkxPkdiK6ey+yHJiyHyqVHZVwHdIdzKzCJmSO3RZbI2NlvhE/Jbkjkdw70vcfE6nkkxO6C90Y5ZlUVzJD4nWw0NHMu61jUpuViOXles+nY++66P+Sfiden0iG4r3PnuV9S+m1NpXxORkfVbAjvVyJkR19ZUo/JSdmvc+KZH1eoi32WnJyvrBZz2WFpirevvU8yFa/KS/yc/K9QYdCffYuP2fnvL+rGZamlYzzXUPXudlb/1Hz+yeYn2/RWd696Vjb3Zyv2eX6j9WcOpNVWP/ACfnrK65lZDblZL/ACc+eRZN8yZHZE8fas/6uXSb+3a/8nl+pfUvqGSpJXy5/Z85cm/cjZHyOO1neos3Mk3O6T3+zlTyLJvbkzECvUpcm/cgAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANk9zXuQALq2a8SZlhm3Q8Tf+TXA6OtjdezKGtWy/yd3D9d52Pr/Uk9fs8YNlplR9Pxvqjm1a23/k6tH1ey4pbf/k+Odz+R3y+Sfkjj7pR9YLnruaOjT9YH7yX+T89/ckvdk/dn/uY+Rx+j4/V+D8zX+TYr+rlD82R/yfmj71n+9k/fs/3v/I+UOP09H6sYr82x/wAmSP1VxH5tj/k/L38Rav65f5H8Td/9kv8AI+URcX6mX1Twn/xo/wCS/wD/AJRwH/xo/wCT8r/xV3/2S/yT/F3/AP2S/wAj5RPH6pX1PwP/AL4/5D+qOD/90P8AJ+Vv4y//AOyX+R/GX/8A2S/yVvKl+qP/APKWD/8AdD/JSX1TwV/xo/5Py1/F3/8A2S/yR/F3f/ZL/InIjj9QT+quGvFsf8mCf1Yxl4tj/k/Mv8Td/vl/kfxFr/rf+SexHxfpOf1cpXiyP+TSv+r6X8s1/k/PH3rP97I+7P8A3Mn5RPH3PI+r9vPbL/ycrJ+reXJPtf8A5PkHfL5ZHc/kfM4+gZ31J6hkJpTa3+zzmX6ozsltytlz+zg7BFytONyzqWRY+bJf5MDyLJeZsxAr1Kzsk/6mR3N+7IAE7fyRtgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/9k=" alt="Avatar">
                    </div>

                    <div class="user-details">
                        <div class="username-row">
                            <span class="username">{{ member_name }}</span>
                            <div class="vip-badge"><i class="fa-solid fa-star"></i> VIP0</div>
                        </div>

                        <div class="uid-pill" onclick="copyUID()">
                            <span>UID | {{ uid }}</span>
                            <i class="fa-regular fa-copy"></i>
                        </div>

                        <div class="last-login" id="current-last-login">
                            Last login: {{ last_login }}
                        </div>
                    </div>
                </div>
            </div>

            <div class="main-padding">
                <!-- 2. Wallet Card -->
                <div class="wallet-card">
                    <div class="wallet-top">
                        <div class="wallet-left">
                            <span class="wallet-title">Total balance</span>
                            <div class="balance-value-row">
                                <span id="account-balance-display">₹{{ balance }}</span>
                                <i class="fa-solid fa-arrows-rotate" id="refresh-icon" onclick="refreshMasterBalance()"></i>
                            </div>
                        </div>
                        <button class="btn-enter-wallet" onclick="location.href='/deposit'">Enter wallet</button>
                    </div>

                    <!-- 4 Shortcuts -->
                    <div class="wallet-actions-grid">
                        <div class="w-action-item">
                            <div class="w-action-icon arwallet"><i class="fa-solid fa-wallet"></i></div>
                            <span class="w-action-label">ARWallet</span>
                        </div>
                        <div class="w-action-item" onclick="location.href='/deposit'">
                            <div class="w-action-icon deposit"><i class="fa-solid fa-sack-dollar"></i></div>
                            <span class="w-action-label">Deposit</span>
                        </div>
                        <div class="w-action-item" onclick="location.href='/withdraw'">
                            <div class="w-action-icon withdraw"><i class="fa-solid fa-credit-card"></i></div>
                            <span class="w-action-label">Withdraw</span>
                        </div>
                        <div class="w-action-item">
                            <div class="w-action-icon vip"><i class="fa-solid fa-gem"></i></div>
                            <span class="w-action-label">VIP</span>
                        </div>
                    </div>
                </div>

                <!-- 3. 2x2 History Cards Grid -->
                <div class="history-grid">
                    <div class="history-card">
                        <div class="hist-icon-wrap game"><i class="fa-solid fa-gamepad"></i></div>
                        <div class="hist-text">
                            <span class="hist-title">Game History</span>
                            <span class="hist-sub">My game history</span>
                        </div>
                    </div>

                    <div class="history-card">
                        <div class="hist-icon-wrap trans"><i class="fa-solid fa-receipt"></i></div>
                        <div class="hist-text">
                            <span class="hist-title">Transaction</span>
                            <span class="hist-sub">My transaction history</span>
                        </div>
                    </div>

                    <div class="history-card" onclick="location.href='/deposit-history'">
                        <div class="hist-icon-wrap dep"><i class="fa-solid fa-bookmark"></i></div>
                        <div class="hist-text">
                            <span class="hist-title">Deposit</span>
                            <span class="hist-sub">My deposit history</span>
                        </div>
                    </div>

                    <div class="history-card" onclick="location.href='/withdraw-history'">
                        <div class="hist-icon-wrap with"><i class="fa-solid fa-circle-dollar-to-slot"></i></div>
                        <div class="hist-text">
                            <span class="hist-title">Withdraw</span>
                            <span class="hist-sub">My withdraw history</span>
                        </div>
                    </div>
                </div>

                <!-- 4. Menu List -->
                <div class="menu-card">
                    <div class="menu-row">
                        <div class="menu-row-left">
                            <i class="fa-solid fa-envelope"></i>
                            <span>Notification</span>
                        </div>
                        <div class="menu-row-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </div>

                    <!-- Gift Code Modal -->
                    <div class="menu-row" onclick="openGiftRedeemModal()">
                        <div class="menu-row-left">
                            <img src="data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAW4BdwDASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAAAAIBAwQFBgcI/8QANhAAAgICAQMDAwIFBAIDAAMAAAECAwQRIQUSMQZBYRMiUQcyFCNCcZFScoGhFWIkMzUWJTT/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBAUG/8QAIxEBAQEBAQEBAQEBAQEBAQEBAAECEQMSIQQxE0EUIlEFMv/aAAwDAQACEQMRAD8A/P4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEpbIAA01QTfk09q0c9TlHwy+GRLwxhodexlUkTVNTXku0vyBprribsfGUmjnuzsN2HlruQw9LhdM+pBcHTq6M+5FXSM2HYkemx5Rs00XJDR0zoMpNPZ6vD6J2RW9FfSVykenor2kbZkVGGrpSX4NUOnpfg6Eay1QK7FSsCwUJLBizp/TFcGVNQ+uNd06Li9nl+tdJhKMvB7u2uTjpI4XUMOyxP7Q7Kb5D1Tpig5aR5XNw9b+0+w5nQbLm/sORkej7LN/yzLWZUWPjVuLLuf2lKw7G+Is+vx9BznPmv/o6WN+nMZa7of8ARn8puXx3G6ZbJr7Wehwej3aX2s+tYv6eVQ19n/R18f0XXVr7UOcg4+V43Rb5NLsf+Dr4/p+7j7H/AIPqFHpmFf8ASv8AB0aeiwiuYr/BX1D4+R3enr2v2v8Awc2701c2/t/6Puv/AISmS5iv8FU/T1D/AKV/gf3k3wK705av6H/g5OZ0G2O/sf8Ag/RVnpmmX9K/wc3L9H0zT+1f4FdZpcfmjL6VbXJ/azl24s472mfojO9B12N6h/0cS/8ATaFm/t/6M7Imx8Gsra9irtf4Ps+Z+lz57V/0ci79M8iG9Qf+BfCXy4D3uR+n+XW3qt/4Obf6NzKt/wAqX+BfFDygHau9PZdW91S/wYbOnX1vmt/4J+aGMC149i8xf+BXXNf0sQIBPbL8B2sAgCdMjQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWQtlH3NEL3L3MZbSm5IA1PumzfhYtk5LSZf0vps8qaSg3/AMH0ToXpKdna3W/8FSG4vSMC5uPDPc9K6Xa+3cWeg6V6SUHFuH/R6/B6FCpL7UVKbh9N6bOGtxPRU4rUVwdKrChX7IuVKXsVNm58aPgtjQbVWl7DKC/AvsdY1R8EPHN/aiO1fgPsdYP4ZNiTwlLyjpdodq/AfZ9cj/xsN/tQ3/jK/wDSv8HTcCVAV0OuZHptcX+xf4NEMOtf0o19gyjwLpWqI0QXsh/oR/CLe0b2J6XVKrj+BvprXgntGSJ+h0igHaiwjQ5odV9qFdSfsXaDQ+jrNLErkuUiv/x1X4RrcXsZcIX0XXPn06p+Yr/BTPpdTX7I/wCDqyjslRWhylXnLej0zevpR/wY7vTVFif8qP8Ag9c4L8CuC/A+lHzvL9F0W7/lR/wcHK/Tiu1vVa/wfX5Up+xCx4+6Dqnwy79Lk9tQ/wCjn2/pPOT2o6/4P0G8etr9qE/hK/8ASg+jfnK79JbtcL/o5mR+luVXvUX/AIP0+8Op/wBKKpdNol5ghzUHH5My/QWZRv8Aly/wcbJ9NZdCbdUv8H7ByPT+Jauaov8A4OHnejMS6LSpj/gf1Cfka3p11fmt/wCDLKqUfKZ+lOqfpzXNS7Kl/g8V1L9M7+XCv/oLIm2PjugPcZ3oHOo3qqX+DgZPp/Lx2+6uXHwTcjscYC6zGsqepRZU017EmgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZQlLwmX14N9n7a5f4AMwHXo9P5lzWq5f4O90z0PlZM13Qen8D4HjoUWWP7Ytmyno+Xb4ql/g+ydF/TSOoysh/wBHuMH0Hi1QSda/wHA/O2N6Uzbmv5Uv8HpOlegr7Jxc6n/g/QOL6Sxa9arX+DsY/QKKtarX+AN809Oeha6O1yq/6PovTug1URSUEdinDhUlqKNUY6FaGerFhWuIl6jofQaF0+l0GhiA6OoAAK6AAABAAARAAAQ6CUQSASBAD4EgQAcCQIAOBIEAHAkCAFwJAgB8CSAABwAAAYI0SQHCt4AAA4n7SQ47RID4O9Z546l5Rns6dVNcxR0Npg0gHy89lenca5PdaZ5vqXoXDuUn9FH0NoRwUuGg6fw+DdX/AE0rl3Our/o8ZnfpzkQk+yp/4P1LbhwmuYoxWdIqm+a1/gY4/JmR6Fz696pl/g5OV6czMffdVJf8H7Bs6BjTXNcf8HD6l6KxcqL/AJa/wH4rj8jW4ltT+6LRQ015P0N1r9M6pKThD/o+ddX9AZONOX0621/YOf8A8D58B2sj03m0t7ql/g59uBkVfurkv+BcpMoDShKPlCiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGjXKT0kwBSUm/COjidHyMmSUa3z8Hr+j+hMjIcXOt6fwPgeErxbbXqMGdjB9N5OVJL6b5+D7J0j9Oq4KLnUn/we16d6KxqUn9GPHwMPkXQv06lf2ysX+UfQenfpzjVwi5Vxf/B9Bwuj10aSglo60MaMVpIXT48Vjei8OtL+VH/B1sb0zj0tONcf8Ho1jpFij2h04w4/T66lpRRqWPBFyFcG35DpVCrjHwMmyUtB3CIyDZCew1oQSBABwJAggfDDAAGYAAAgAABAAACAAACDYbAAMbDYAMDYbAAA2GwAQAbAgFJ2AAABJACJIAAAEEkMZWdAEEi6XwA1skA6fEKOgYzZAun0jbI2yzghsOj6J3PfgfW0StP2JaDo6rdaZH046H7WGtB9F1luxYWLmKObd0DHvT7q4/4O5sE/gPodeNy/RuHZF/yYf4PLdV/TjGvjLthFf8H1qUO4rePGS5Q5sPzJ139NbKO6Va/6PAdQ9N5WJNr6cuPg/ZmV0ejIi1KCZ5nqPofDyNt0xf8AwV3pyPyFZi21v7oNFTTXlH6N61+mtEoyddUV/wAHzXrX6f5ONKThDhfAcHHzsDp5fRcnFk1KD4+DnyqnB6lFoXCIAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlJvwasbAuyJJRg3v4AMiWy+nEtuklGLZ6zpXozJypRbrlp/B9H6D+nUY9sp1/9D4Hy7pXpDLzZR/lvT+D3/Rv0zlLtdlX/AEfWukekqMWMf5a4+D1ON0yqpL7UBPm/S/0+oocX9L/o9jgenK8dJKC4PTQphBeEWaS9hGw04EK0vtRqjVGPhFgAC9i/BOiSBmA0AABoAABUkcAAJHCDZAIDTvRHcSyNCNOyGTohiATDZAD4E7AjZGx8HTAL3IO9AOmIFc0K7EBLCSh2Ij6qDgtaCCj6yI+sh8T1eRvkp+siPrIOH1o2GzN9ZB9ZBwutOw2ZvrIPrIOH1eyUZ/rIlWoXB1oRJn+sg+qg4XV+ydmf6q/JKtQ+H1eSUqxDKxBwdW6FYfUQbTFwdCJI2Gw4Po2wYobDh9ToNE7JDhlDQxAgESQABIEbDYEnSDRGyQ4QDYAMgK4p+wwCOM1uLCxaaOPnenaMpNOCez0Ow4Dpvl/VP07xchSf0keB67+mChGTpq5P0ZKuMlyjHkdPrti9xRUofjjqvpDMwZy3W9L4PO24ltMtSi1/wfsHq3pDHzFLda5+D5/1v9MapqUq4Pf9g5KH53aaA931v0LlYUpONUtL4PH5OBdjTanBrXwKwMgA015AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACTfg3YnTL8qSUIN7+ADCk34NmL0+7JmlGDe/g9f0f0Lk5LUpVvX9j6V6f8A0/VXa5VLf9hh826N6Gvy3Fyg+fg+ldC/T2Nag5Vp6+D6T0r0xVjwj9iWj0NOHXTFJRAnmel+l6ceMf5a/wAHpcfp1VMV9qNcEkvA/AugkYQj4Q/9iO0lIXQNgAbEoBsAYwAIRIwAJI0MAgYVgVTsBWyO4fE9OAneR3hwdO2LsSVi/JW7V+RyF9L+4hzM7uX5K5Xr8j+S+mn6qIdq/Jz55HIjvY/kfToO75Fd/wAnPdzEdrD5H06Lv+Rfr/Jz/qsl2MPkfTa7/kV3mPvYrmHyPpsdz/Ijuf5M3eR3hwXTV9Vh9V/ky95PcPietP1X+SHa/wAlHcDkHB1d9V/kPqv8lHcHcHB1f9V/kPqso7g7g4Or/qsZWsy9xKmLg+mr6rD6rM3cHcHB9NP1X+QV/wAmVyF7h8H03LI+RlkfJzu9h9Vj+R9On/E/I8cla8nI+swVzFYLp2lkL8jK9P3OMr2WRvf5Fwvp2FavySrF+TlLIf5HjkchxU06nehlNHOWR8lkcj5F8rmm/YbRlV4yuF8n1o2TspjZsnuJsLq0BFIbYcPqSRdkiNIEAA4kCAADQEgxUITJbI9wa2iemjUZGe3FhNacUaIx7RuBzQeZ6n6cx8uDThF7+D5v6g/TWu9ylCC/4R9scNlNmNCa5RU0H5L656ByMNylGDaXweKy+m34s2pQa18H7J6r0GnJTTrT38Hzr1B+nkcjvlCpf4KJ+b2mvJB9B6z+n+Viyk4w4+EeOzek34cmpwfHwLgc8Aaa8gIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHhXKx6imwBPJqxsC7JklCLezudG9MZGdZH+XLT+D6z6a/T+MVCU6uflDD5t0X0Xk5U4udb0z616Z9BVVRi51c/2PedK9LUY0Y7rX+D0+Ng1UxXbFB0OF0/01RRFarS18HdpwKqktRRrUUvCJERVFJaSDXJICNDXBCTJ2AcCQaAB8CNBokgXD6AAB8HRskVkOeh8T9HIb0VSuSKZXr8lTNTdNXcQ5pGF5K/JTPK+R/KfpvlckVPIRzp5LfuVO9/kqZL6dKWSkVSy0c6Vz/JX9Rt+SuF9Og8rZW8jfuZO8O4fE9aHc/yI7G/cq7g2PhdWdz/JHcJ3EOQcHVncGyruJUhcPqzeg7xO7ZGw4On7g7hNhsODp+4Vy5DYvuHB0yZOxEMHAnuI7xWQwB+8nuK0xkw4Om2HcRsUB02w7hSA4XT95PeVgHB1Z3i94r8ED4OpcxXIGKVwdHcCkQGhcK06mMplQbF8p6vVhP1tGbuDuD5OaaY3lscgxJonuD5XNOhHKLFlHK+pr3JVvyHyr7dqGYkiyOWmcaFvHktjboi5L6dqOQmOrjkQvX5LVkfJPyqadVWpssUtnKjkc+TRHIX5F8qmm8jZnjcn7jqexfK5pbsj3IT2STYOnTAhEMkdSSKhkTw+lfJEVofQDmTBGgArgDhGXlFF2LCxcxRoAXeE89n9AoyIPurT38Hzf1T6BhkQk6qVv+x9paTRmuxK7U04oqUPyB1r0RmYk5NVPX9jymTgXY0mpwa0fsvqvprGyq5J1p7+D5f6m/T2E4zlXVz8IfJQ/PPgD1vWvSOThTk1VLS+Dy92PZTJqUWhWBUAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmMXJ6SLqMWy+SUYtntfTvoy3MshKcHp/AB5fC6LkZckowen8HvfTfoOy6cZWQf8Ayj6d0H0NTj0wbqW/7Hvenen6KILUEv8AgfYHmvTvoynFrg3Wj3OL0+rHikorg0VVRphqKHi3LyTaSGtcRQ8d6I4ROwkNIEAMJBkAIDQEoBgARsVyGE7eyUyvvQsrkvcfE2rm0iuViXuZLctL3MVub8lTCLp1J3pLyZbMpL3OXZmt+5mnlN+5pMM7p0p5fyUyyvk5kr2L9Zmkyzu2+WS/yI79+5ic2yO4fyX21u35I+p8mfZHcL5P6ae9P3DuM6kPFhwdXdxPcVbJ2HB1b3Bsq7ie4As2RsTuJUhGYnYuyHIAfZOyruI7wC7YbKe8O8B1d3EbKu8nuEcWbJ7iruI7wNbshsTuBy4AG2SpFXcR3gF/cHcU95PcAW7I2V9wdwyWbDZV3E9wEs2GyvuDYwZsjYvcQ2MG2Q5C9wjkOFTuZHeVNkdw+IW9wN6K1Ine0HB0ymxu4rXA2w4X0kZIr7iVMOD6Wp6Qd+ipz2R3B8q+l6tZZG75MmyVMVwc02q5r3LYZD/Jzu8aNhNyr7diGT8l8Mj5OIrtFscjXuTcn9u9DIX5LY3J+5wYZL/JqqyN+5Fwua67MbE/cfaZzq7vk0xtX5I+V9aE0TtFKmmMmTxUq0BO4nYlSpANgLqkoCCRWdCQIJAiTimjFdhQvTTimb2uBUu1D6HjOteksXLqlutbZ8g9Vfp72d06Yf4R+jp1qzho5+Z0irIg1KCe/grofi/qPQcnDsknXLS+DkyhKD01o/VvX/QeNlVzarW/7Hxn1P6EtxLJyrg9L4DnQ+bAbMrp92NNqUGtfBjaa8kgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABoxsSzJsUYRb2AURi5PSR1+mdDyM2yKUG0z0/p70Xdlzi51v/AJR9f9Oegq8dQbrX+Bl14z0x6BcuyVlX/R9e6J6Vpxa4/wAtLXwd3p/R6sWtLtXB1IRUFpIVCinFhTFJJGlLjgbyg8EcMuiU0AFSEWUWyUtIkB2nP0ABIdNAA3oRyDibT7Bsrc9FcsiKRUym6WSloqlYvyZbsyK9zmXZr50zSeab6OnZkpbWzFdma9zlWZUnL9xRO6T9zeebG+rZbltvyZ5Xt+5llN/kXvK/5o/6NE7HryIp7Ku7fuGx/KbrqxsFIq2Sh8SviydlCbLIsAt2K2R3BtBw0qRZGRVtE7J4fV3cR3Few7hcPqzuI7hdk7Fw+nUuBlIp2T3BwdXdxDkVdwrkHyOrXIjZV3E9wfI6s2GxFInZKobYyfAmxlJaCfp/4GyNkOSBNBwdMmS3wRvgRsSuJ2RsEToXQhMdMUlDJOyNkN8kNjg4bYbKnIXuKmU1oUidmX6mvcPq/JXyn6aWyNmf6vyHfsXD6u2BWpE9w4VokVtkuQkmWlKkN3FLZHdoE2tKmDkZ+8n6gI6tcgUir6hH1ALq7uJUijvJUy5FSr9kORV3E7CwdWKXJYmUdxPeTYfV3cHeU94dxPyf00xn8miu/tRzu9kqxr3JuTm+OvDK17mmGX8nCja/yXwu+RfDServ15O/c1QuT9zzsMjXuaK8pqS5IvmuejvqSGTOXDK37mqu9Mx151pNtqJ2UxnsbkxuKuaWgJF6HT2Vzi5UgRsCaaXyiEgRJIAPkCRwlFtEbItNHA6n6doy4SUq4vfwemFcU/JcJ8P9T/p3XNTnVWv8Hx3rvpa/Asl9j0vg/Y+VhQvi00eK6/6KozoSf01tj6b8i2VSrk1JNCH1v1R+ndmK5zrhx8I+bZ/Sb8OxqUGtfAuBzQJaafJAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACUm3pIauuVklGK2ew9N+kb+oWRbg9f2AOJ0rol+fakoPT+D6p6V9APuhZZWet9L+ho4/Y5V/9H03B6RVi1x1FLQ+E4vRPS9OLCL7FtHq6caFUUkiyEVGOkhgHBr8EJDAI0PwAMCTAEgUViCSNkNj4X+JBsRzSKp3pLyOZTdLJS0UTtUUZrstL3Ofk532+TXOGettt2WkvJzr87XuYLcxteTDZft+TaYZXbbbmSfuZZ3t+5mdmyO80mGd2v8Aqiuwocg2acZW/q1zDuKyUA6s7idleydiHVmyUV9wyYldWojeiFIVvkQ6fuJ7ivZOwLp+4nuK9hsR9W9wdxV3B3CPq7uDuKe4O4D6v7ie4oUuA7g4Oru4hyKe8O8ZLe4O4q7g7hVUXdxPcUqQyZFaRapB3MrGRHeL5022xopkxhsujWTdqmC9r0R2M0RrHVRF2r5ZVBjdjNap+BnT8B9D5YHFkaZslT8CfRH9J+WSSexWmapV6fgqlAuaFjOxGXSjopkaSs7CS8Ccjtito0jOxG2T3iNkbHxK5TIdnJTshvkJB1ep7BsqjIfY+F0Nitg2K2HEWpDYjkK5MfE2rdhso72T3MfE9O5PZKmKuUK3oqQ+r1YN3mXuJUw4OtPeT3FCkT3i4fV6kTspUxlMXB9LQK+8nvFwdWJjKWinuDuYcErSrBlc0/Jj7mSpPYuNJp0oZLT8mynL+TiKei6F2vcz1lrNvS05Sfua4ZEdeTzNeU17mqGW/wAmVwubegVil4LIs5NGUmvJuqvT9zO5a502EiRsTXkbZlY0mk7AgkniugZCkgaQ2QQxkZ+CmUYy4aLRXEV/DcbqfR6M2txlBPZ8y9T/AKeV5EZyrr5PsritGPIphYmmkKbhydfkP1D6OyenWSarev7Hj7KpVSakmj9feoPTVOfVJdi21+D4r6q/T+3HlKyuD18Iv8pWPlAGzN6fbiWOM4taMYiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASk29IAgvxsWzImoxTezX0/pN+ZYlGDe/g+p+k/QkpuE7auf7AHB9K+i7cq2Ep1vW/wfdfTPpKrDqhuCT1+Dp9A9N04dUf5aTSPU10qtaitD6SvHw4URSSRp40S/AsU0xdCSQIYKGyGwADQSABIDCuQNlU56KkRaZyKp3aKbL0t8nOvzkm1s2x59Y73xstyu051+f8mLIzU98nNtyW35N558YX0bL85v3MFmU5e5mndv3KvqbZpMM7tdK1v3K3NsrciEzSZZ3azuI7mCBl/KPoyY6KtjKRFg6tTJ2VqRPcLg6s2RsVPZIj6nZKkISHD6s7idlYd2hcHVuw2VqROw4OrNhsTYbFw+m2RsjZHcLh9NsjYvcR3C4OrUyHIr7yHMY6fuDuK9k7BcWbJTKu4ZSJtazK6JZFFUS+C2Y3TWZSolsK9kxrbNVVRjvfG2MlrqNMaSyus0xrML6NfhnjUWKo0Rhr2H7Nk/Y+VEa0P9JFyqH7BTZXLHKordRudYrqKmy+XPlRspnQdR1oSVW/Y1m0WOLZUZp1nasxzJZjs1ztncuRZDSKHs6l1H2mOVOjbOmWssrZGy2cdFMuDWVlYnYrfIrmR3bLTVikT3lTkR3Ald3BvZT3E9xSKsYjYjmI5D4mrNkop2CnofEr+/XArlspbb9yVPQ+F1YHgVTQOWw4OnUiSlS5Le5BwdNsnuE7kHcg4X0fuHjPgp2Q2Kw5WlS+RkzKmx1IXD60AUqehvqIfyr6PsnuZX3pjbC5P6Wxs0XxuZj2MpEXCvt0qshr3N1GW17nDhZovru17mOsNs7empy9+5srv7jzVOT8nRoyktcmWsNc+juKW0Tsw15cXwao2JmNzxrNrUMInwTvRnY1lMBCeyQikNkNklcpaI3eQ4ic9IzyntjTmUye0cO/TlazJ3CMkcnqfSqsmqUZQT2dKDa8ssTT8lefudy+HerfQDvU51V8/CPj/V/TuR0+ySlBrTP2ZfiVX1tOKZ889Weia82E5QrWzsz6TTKx+WZRcXpkHsvUvpHJ6fkTarain+DyFlcq5NSWi0EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHrqlbJRitgCxi5S0kei6J6dvzrY/Y9N/g6Ppz0nfm2wbrem/wfcvS3oyvGrg5Vrf9h8Di+kfQ0aownZXz8o+r9N6LTi1x1BLRrwun149aSiuDcuOBUkRgoLSQ4ASAAAOGAIDYzGg0BDloabpLK5S0RKxL3Ml+SkvJec2s9bWWZCj7nPyM5R3yZMrNS3ycXJzd75OrHk59eroX9SXPJy7s3uk+TnXZLbfJmdzZ0Y8+Offp1usyd+5S7dmXv2NGRr8Mvte22KlyEZIZ60HyPpDCJBMRksRLRCZLYdHC+4EPySRQkZCbJ2LhnTJ7ivYbEZ+4O4r2CYuGt7iHITZGwC1SG7ilMnYiW9wdxVsEwNdsjZX3BsXDPsjYuyNi4ZgI2AKkMhhEPFEWtsZTrY0YgkWxiYb26c4NBGquJVCJsphyc2vRvMLa6zbVVwLVXwjbXDg59+nWuccRXUXKGhoocx+1WEURlHRJJP0ihEkIZDmiRoNDAXNBW48kdg7AqbRYplXszWU79je1srlDZpn0TcuVdR9vgw2UP8HenVtGWyjjwbZ9Gdy8/bS0Y7IaO7fR54ObdVrfB052yuHMlER8GmdemVSibZ11jrPFTYncPJFbNOsuG7g7yvYN8FSpsN3B3CbAuJsS2GyAKQHIXuCRWxpq1TJ7ylMGx8Jap8j95mUuR9j4S36hKmU7J2HE9XKY6lszqQynoVglaNk9xQrBu8Uh9W9xHcV9xGyuH1fGZYpmVMsUgsPrR3EplCkPFkWH07k0TGbQr0HBNyuaaq7mvc115LXuctS0Orde5FwubdunL+5cnUpzE9cnlIX6fk2U5TTXJjrDbO3sKb1JF+00ecxs3xydanJUkuTn1h0Z2270SpFampDIz41mjtlU+SW2I2c/r/jbNZ7Cnu50aJrZQ48nm+kdGTJjJlZKZlPxfGiLCdUbI6aK4suizpxuxlqPIeovStOfVP8Alp7X4PgvrH0TZhWznVW9f2P1RNKUWjznWPT1XUKpqcE9r8Hbj17GVj8a30Tom4zTWio+tet/Qk8WyVlNba88I+W5OJZjWOE4taNZepsZwABkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADRjYtmTYoxi3sASmid01GKb2fQfSXo23MuhOcOPlGz0d6KsyLYWW18f2Pu3p703Xh1x1BLS/AyZvTnpSnDqh/LW0e1oxIUxWkuB6qVVFaLd7QdJK14BLkXtZKfsKmYAAXDAAA+GNCktlU56HIi08pJIzW3pe5XdeknycfLzNb+41zhlrbXlZyhHycbJ6lw+TDmZraf3HHvyW/c6/PDl36NmT1Btvk5tmW5PyZLbm35M7sZ14w497bXbshS2YvqDxuNvnjL6bUMjLG4tVguKlaYssTM8Jl8JbIq4ZgiGCIq4sTJ7ivZDZHVcWAKvBIyTsNkAANshsgjYGnYbF2CYjPsBdhsQOiRNk7EE7I2Q2QnyAPsNkEoRpAhEiPhl4AleCRVpmBItihIovgjDenV55TGJfCGyIR5NNcDj9NOzGDV1G2moWqs21wOLe28yeuHCNEVoWEdFqRj9WnTIkEiWhVnSkoEh9C6zqCQI2OUk7I2Q2K5FzUPlP5ATvWhZTJux81bsnhmf6nySrBzY+VsktFMobG70xlybZ2Vyw207Odfj/B3pQ2jHfVx4OnG2WsvOW08vgxWQ0zu3Vc+Dl5FepnV5ac/pHNmjPJm2yBlnHk6ZXPYp2TsGg1o0lRUgLsjuLiLDbDYjkQ5FJ4d8iMZPaFZcRYgVk7FY02I3pk9wjIKTVneCmVghpXKRDmISFiTqZZGRShkxcHV/cHcU9xKlyNUq5MdSKUye4mrlXKRZGRl7h4yIp9aHIO4pcyYzKkK1bsnYikOmKwdTFvZap6Kid7M9ZaZ011ZLi/J1MXOfHJwN6HrvcX5MNZdGdPaUZiaXJvqvUl5PGUZjWuTrYubteTn3hvjb0LkmVyejNTepLyWykmji9JXXilchW9kPyBxemXXgpKBgc9jQ8SxMqRYgiNLEk+djcSWmUveyyJU9LGVjldV6Nj5tUlOCls+Ieu/QaqU7qa0t/hH6F7fyczqvSKs/HlCUd8HZ5eqLH4pzcKzEulCUWtGQ+6+uPQHYrLaqz4z1Hpt2DdKE4taOqXqGAAAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGrCw7Mq6MYxb2wB8Dp9uZaowi3s+r+jfQ8pyhO2v8AyjR6F9GdyhZbX/lH2/o3RqsaqKUUtDDN0L0/Vh1x/lpaX4PUV1RrjpImMFCOkhxECNEgABGiQDo4EBDI2xhLYrYNlM7El5HJ0roTt0Y78lJPkoycrtb5ONl52t8m+cOTfovzM1pPTPP5eZJt/cLk5re+TkX3tt8nVjDl36VbdkOXuY7LH+Sv6jbEmzqzmObW6G9sjQux0aM+q5IlIZogJSMmWwZQh4sKcrZBovjIxRmWxs5IrTNbExkZ4zLoyIsaSn0RolMCONOoAgNgDEi7DYAxGxZPgXuAzkC7J2MJBvgjYrZNOJ2NGRVslMR1fwK2KmAJSmx4ipDImqzDokhDJbItbTIiWRjsIxL64bI1ppjP6iEDRXAeFRZ2aOP009HywjS1wX0LbRTHl6NlEeUcO9V0/PG6mC14NcYopqXBoijC1FpkiSUg1yELqUTshEi1UWgnZDEcjG1HOrHIRzKpTKZW69zO7a4x1fKxFUrTLO/XuZp5PyL7rpz49bnfr3Ed/wAnOlk8+SuWT8k3dbf/ADup9f5JV/ycj+K+SVk/JP8A0qf/AJ3Yjfz5L4279zhxyefJpryl+TbHom+DtRnsJ9rRiqyE/cvU+5Hd5+jk9fKxRbWm/ByMqn7/AAd1w2Y8ijbfB2+e3Hcfrz11ejn2x5O5k062ci+DTZ050x3lhfDIk+B5rTKmzqxXLYTkjYwrNoniGxdjMVspnTxfANiJ8BsYS2AuyUxpsD8Fex5PgrKZ1Ow2K2RsbOrO4ZMo7hoy4KiVuw7iruDuGS5SG7tFCkT3cAOrlYhlPZmTY8ZC4Or9htlakT3BwdWKTHUijuGUhcPrQpFimZlInvEcrT3kqZm7/kfbFxcrR3EpozqTGTZPzFzTTGzXgvqvmpLTMOyyueiNYlXndehxMuS1tnVqyVJeTyleRr3N1GY9+Th9vN3eW3p4yjJCvyYMfKUkuTYpqS2eR7Yr0/Pc4cBUyxI4rK26lIfwKg2EZ6hvIyYkRkV8pWJjewiGTCWwq5/U+mV5tMoyins+O+t/QUJxstqr9vZH3TyjBn4FWVTKMop7Ory9eIsfinqnSrsC+UZRaSZzT9E+tvQcLYztqhz54R8K6v0q3AyJRlFpJnbLKnjlgADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABqwsOzLuUIRb2ARiYlmTYoxi2fWPQ/oz6rhZZD55Ro9G+hnONdllfnk+1dC6BXh1xSglr4GFnQ+jQxKYxUdHo66lXHgIQVcOENGXcHSCYwrZK8AEkEkE04CUQAjDFbSIlLRkvyO1M1znrLeuLLr1FeTmZGalvky5mdrfJwcnPe3ydWPJy79GvLz+XycPKy9t8ma/Mbk+TDba5e50Z83Jr0WWXd3uUSexO4lM3zlhrSFHkiSHRDNZGVqolMloXQA2yCdBocFQSidBofCiUxoy5K9EomxcrTCZohMwqWi2MyLFyt8ZjbMkJ7LlImxcqwBQIrSJ2GyCNiNMmISRoDSmTsgA6ZtkCkpiqoNEokGAShkhUP7Co4lDEJDaItaZymKLoQ2VwXJtqhsytb5yIVmqqomus1118GG9urz8yRhpCTRfPhGacts4vTbv88fha1uZ0KY8oxUrczpUx8HFvS9RsrXBciutcFqRn1ho0WPrgWKHXCH1npGiRWyHInVTJaJy0UTnoLLODFddpGGq38/Lqyy1L3MduRr3KLcjjyc6/J+TK16Pl/O1W5XyY7Mv5MF+V8mCzLe/JH09Dz/mdaWZ8lbzfk4ssp/kqllP8hXbP5Zx3P4z5Hjl/J55ZL35LoZD/JFRr+WO/HK58lsczT8nBhe9+S5Xt+5WdMdfzPS42btrk7GPkKSXJ4mnJcWuTr4md45OrHo4Pb+d62M00RZFSRzsfJ7kuTfCfdE7vH0/Xl+vlxz8qnezi5NOt8Hp7a+5M5GXTrZ6GNPP9MPN3Q1syyXJ0siGmzFOJ2Y049ZUMRlriJJHTms7FTYjY8kVtFstQyfAbE8BsqJPsExNkpjiadi6DYbKjOlaFaHYrKRYQjehtCPyVEm2GyEToaU7BMgAI+yVIr2Gx8JcmTspUh1MXB1ZslMpc+SVIVg60Jk7KlIbYuH1YnyWd5RsO4XFdaFMdSMqkOpC4rrT3B38mdSHT2thxWdNMZlsbe0xKzQ6nsx9PProx6cdnFy2muTtY+UpJcnka7HGWzo42X2tcnne3h12+fs9XCafuXxfBxKM1PXJ06bu5I8318eO7Hr1q8kqOxYvZYmclzxv3qNaJBsB8/C4ZMZMQnZnqlxZsjtTQqZE7e18EzfC4yZuDHIqlFx3tHx31z6GV0J21w55fg+3qyLjyc3Oxq8qEoOKe0dPn7WJuX4v6r0uzAyJQlFrTOafdvX3ozbstqr/AMI+KZ2HPEvlCS1pnfjc1GdnGQAAsgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAW0UyusUIre2ANjY08i1Qim9s+uehPRbsnXbbX5/KOd6K9HSybYWWV8ceUfoP0/wBCrw6IJQS0gC3ovRIYlMUopJI9DCtQWkghFRWkMTaENNsnWlwSA4CpfklMkheShUvgXfIzFaQudHU6Im+1CysUTDlZajHyOYTrXFl+Qoo4mbnxW+SrMz+Hyeey83ub5Orzw5PX0W5md3N8nHuvcm+Rbbu5+TPKWzuxlwb2rm25bFYzFZtIwtLolIglMpKXwLsJMUOjiWyA0MoitPgRHuPoNIJT4UNjaRPaiul8q9guSztX4Ia0T1XC6JTF2w2yem0QnovjYjHFlsWJUa1PgbuM6lwMpGdaxcGitMdMSonWiA2QxKidkbIbIF1chiUhdjJhKfDewrZOxWHQaLLE9lUSyJNqpFiHXIsUXQhsy1p0YyeqttnSopb0UUVPg6lFekjDWnTnBYUtclyaii7s+0z2cHJ6bdvnhTdNGbu2xrpFEJbkcfpp15z+NtEfu2dSleDnYy20dWmPBzWo20QWkOuREhkxOXS2KJbE7iHLgaOdRJlMrNBZPRjut0Z2t/Pz6m69HOvv4YuRfrfJzb8jh8mWno+Pia7I88nMvyPPIt+R55ObddvfJlXseHhBfk+eTFPI2/JVfbsyub2Lj0seUancVSvE5aEa5NJn8bXMi6Nu2aa7DFCPJqriTcsdSNcJ7L4zMsVodSF8sdZa1M149klJcnOhLZto8lxwe2Ho8K/SW2dzHuUkjy+PPSR2MS7hHT465Xkf0YdxLuic/Mp2ma6bNx8i3x7kejjbyfXDy+VQ9s51kNHezK2tnEyNpnf56cG8srRXJDsrZ2ZrHUJKJTItkymTNY59QrWw7QWw7iuo4GtEJg3shIfU2H3wR3Eb4DRUqbEijCsrqbka2LJcjJkNlSouUaJ3oBWPqOByI7iGQPqbD7RDE2Gxp4bTJSYqY3cMk8olPRCeyRcB1IdSKfBKYuBf3BsqUhu4XDWpjJlKkMpBw+rUx1NKJT3EOYSHKse2yyD15KFMdSHc9V9NCmPG1r3M6YyZjvz61x6Onj5Di1tnbxc1JLbPLKbiWRzJQ9zz/bxd/l6vc1ZcZe5phan7nh6epST/AHHRp6jNr9x5np4vR8/V62P3LyS+Pc81HqVi/qLF1CyX9RyazxvL133NL3FdyRxFlWv3GdtjXkw1KuSOpLMiuCv+KT8nJbsczRXGTI+Kr5jVPIb8MK7+eRY0yfsWQxnvwbZ86VkYOq4VedjyUop7R8I9bejrIXWW1VPXnhH6PhjbWmjlda6BVmY01KCbaO3wljD04/GOVjTxrXCaa0UH1L136Qli5Nk663pfhHzC2qVU3GS1o6WJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmMXKSSAGqqlbNRittn0H0h6Ssyrq7Jw43+DL6O9L2Z+VXOUG1s/Q/pv0xViY8PsSevwAXemugQxKYah4R7OuEa4JCY1EaYJJFk1tjIyJIXgknhgAI2PhpI9yQAkN6Kp2aRNk9I5+RkqKfJpnPWerxGVk9q8nDzMze+Sc3LXPJwMzL88nTjzcm/ROXk7T5ONda5Ma69yMre2dWMcce/TqXIrlMfXBVJG0YW9OntAxY+Biup4jQD6DtDpyK5LaIUS3tJUSeq4VRG0MkDQunwojT2WaGUeBdVIqSYyiyztJSD6V8q+1g4bLkg0H0XyzfTI7DS4iuIvocUpaGRLQrDo4tiOipMdMS4tiWIpix0xVUOxSdkaJaRDI2S0RolSSUQSg6ZvYglINC6OJiixIWKLlEjVa5h61s20170Zao8nTx4nPrTq8400VeDoVQSRRVHSNClow1p2YyackkYbp+Sy23kx2z2cm66sRntlti1LciJ8stoj9xy7rpjo40daOlWYqVpI2VmFYejSgIQ6HHLSN6ElPSLJmaxjqsRXbMw3WeS+2RgukZ13eWWPIn5ObkS4Zsvb5MF22jOx6XjHPul5MNnJutgzJOD/Avl6nleMFsdlKhybZ1iKvnwV8uvO1KjpEdhe4MXtZX+HdIhA0wRVGOi1cE1nat9iBHIFLZFTWitcnQoRzq5G6mwOuT1y6lb0jpY0/Bx657R0caXCNfO/ry/fLv40+DZpSicvGn4OjCfB2+enkeuWHNpTTPPZVOpPg9RkcxOLmV8Nno+Ved6RwpQKJRNtkTJM7sVzbiiSKpRLpCM3jl1FajwI0XewjRXU8IojdpPgnfAdLivXI2idcjpFSlYraK2i+SK5IrqflWDH7SO0fU6yQND9pDQ+s+EaFaHaFZUqLC6I0MxWyupsBImw7iuo4tT0HcVpk7KHD7JTK9jJgRyUxdkbFwLUyUytMZMXAsTBiJjpioShkxdhsJRVqkMp8lPcGyr+iVolYvyVOeyrkjRhvHXR5742U8s6uPFNI4tUtM6FGR2o5N+HXZj2egxsaNiOjV06L9jl9OzUorbO/i5UZJeDy/Xw/Xoeft2Ih02K9i5dPil4NkLU17FyaZhfBvPRzHgR34LIYiRvceQ7QnjFf8ASs8aEixVJFug0aTzibulUNBOClFrQ6JfgvnEd68Z6m9OV9Qx57gm2mfnP1n6Ss6flTlCD1/Y/XM4KxNNHivVXpinOpnJwW9fgqB+PpwlXJxktNCntPWPpuXTcuclH7dnjGtPTAkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB6H050WzqGXBdja2c3pmBZm5MYRi3yfe/QPpGNdVdk6+QD0Pon01DFprbr0z6XRTGqCSRm6fhRxq4pLWjo6Jt/QRxbY2tDEMqBGgJAY6gCCQMbK5WaCctIw5OQoRfJWc9RvXzBk36T5OBm5et8jZedy1s4WZk92+Tqx58cm/VXlZe98nJutc35C21uXLKZyTXB1YnHHvXSvbF0Mh0kbRhYrBxHaQjGXyr9x4olJDpInp8CROgJQU+Ia0QWPwQo7ItEIMlsdQLIVmd9ONc+d0qUCxV8GiNXwWqn4M77R0Z/nrH9MPpv8HQjRv2LFjfBF/ojT/565f02HYzq/wvwK8X4J/+mD/5q5naQ4HT/hvgV42vYc/oib/PY5jrFdZ0JUa9iqVTXsXPZF8bGTs0Somh1iOJpPRP/OkSGQumTpj+unMmSGYq2NoOq+StBoYOCaZdEpEkpC6aUiUgJRNpyHii1IrgjRBGWtOjGD1Lk6eOjJTBbOhXFJHNvTt8/NqhwhZT17lUptIonY/yYa07ceZrJ8lDeyHJtkPZyb02zhDRfQvuM2zVj+TDV615yOlT+1GytGSlcGuCZm5fSr0PsrXgSUmhxh/prJcGWch5SZRPbY7+tvPCqzkyWQ2bHHYrr2L5dObxyLatmOdHwd2dK/BmnR8E/Dq8/fjg24/wZJ0fB3rsfzwYbKHsOcdvn/Q406BFSdWWO/wZ51NC668+vWCVIn0ja62VShomt5vrP9PQOPBY0xZE2Liia0hYPkeS3wVuEkyadaYM01S5MVSkaI7QmHpOupS96Ori+xxsVvjZ2cb2Kx/rzf6M8jsYyOjWuDm42zpVb0dnnXjesLbHg5WXD7WdmcftOdlRXaz0fKvO9MvPWw8mKyJ08heTnzXJ34049xklEVxNEoidnJvNufWOqNB2Fso8jKJpP1PyzuIvaa/pjKpfgOn8dZVDgNG1VIV1fAvs/wDkyNCNG36W/YSVPwP7H/KsnaT2mhUvfgiVTQ5tN8aztCNGh1srdbK+mV8VDE9y9wFdfBc0y1jipxEcSzskK4MuVhqcVtEaLHFiPg0jK0JcEiORJYTsjYrYIOjp+4NgtaIBPTKQ6kVbJTDg6t2T3FWw7hXI6u7hkylSRPciZkvpcmT4KlMdSRXB0/eQ5iuSI8hxUp1YXQt0Z0g5JuWk26VGY4SS2eh6fm719x4+EteTdjZTg1ycvp/P39dXn/Rz8fQcfJ2lydKmzZ43BzvG2egxctNLk4vTy47fP267kXtEmeq1SRcns5b+OvP7DEAGuRQWIIctcDNEdo6U/wBQlrkoyqfr1uJq0RpEz8W+SevfSSy8aUowTevwfnTrnSrOn5k4Si1pn7Y6hhQyqZRkt7R8O/UP0ZFxsurr+7zwiifAQNedh2Yl8oTi1pmQQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABdjY88i1Qim9sSut2TUUuWfRvQ/pWeXfGydfG/wAdv0F6QcrI2WQ8/lH3rpHTI4VEEopGD090KvFohqCWkeqjWu1L8BQeC1EYEtIkngABsgcAfAEMleBhAs5JIJz0Y770k+S5nqbriL79J8nBzsp88l2Vl63yefy8ruk+Tp8s8c/rvqjKyG5Pk59lncTfZtsySmzpkceqSa2xGh+7bJa4NZGGqrQyYNEFpDI1snQyQKKkWKIItiTVZz1X2gol2tkqBGtcdGfHqpR2WQrLq6tvwaq6Pg5t+rSfzM8KN+xfXj/Bsrx/g114/wcm/V1efhxihjfBdHF+DfCg0Rp48HPr2dU8nPhi/BdHFX4NsakixQSMb7NJ5MP8ACr8EPFX4OhpBpEf9lf8AJzf4VfgrlifB1exE/TTKnsjXk4c8T4KZYnwd6VCZW8dfg2z7MdeLzc8ZqXgpljv8Hop4m34KJ4nwb59md8Hn5Utewjr0dm3F17GSyjXsbZ9Wd8WDt0DLp1tFbizWejLWOEAbtBRK+mVhdDpEqIyiPoiNEqI6iNGJNbZymETRXHkWETTXHkx06vPK6qOjXHhGeC0WOWkcu69DzymyZknPkeyZknLk5tV2Zy0Reyxrgpq8F3scm7+qkVPyasflmdrbNWMuTO0adShcI1RM1XEUXxkT1x+i1vgrmyXLgqnIOozCSYoNgPvG3eQaRPahRkw+imiygmUyrRocuCuTQ+tM1jsrRjspR0Z6M80Ta6vPTm2VoxW1nWnDZnnTsiuvHrxxbFpmeezszwu570Uy6e/wS6M/0RxnsrakzsPpz/BK6d8A0n9McRwkhe2TZ6D/AMZteCY9J58Bwr/VHEqrl+C5Qkd6vpKXsWLpa/A/ljr+mOPRGSaO5hpuK2NX0xL2N9GF264NMY/XF7+/Y0Yy8HTqjwZqKO32N0IaR14w8ze+lnH7TnZcftZ1LNaOdlacWdvnOOTd64GRDyc+cOTr3Q3sySp2zqzeMLjrnuAKBuePv2Hji/Bf2n/k5/0d+w6of4OlHH17Fixxf9+Lnh1y/oP8Eqh/g6n8OSqETfdc8HOVD/AOh/g6saEEqEL/ALH/AMXJVD/ASx/g60cdEyx0VPRN8nGWO9+BLKHvwdpY62RLETfgvPoi+bgyof4KpUv8HoHh/BTPC+DX7Z683AlU/wAFbrejuTwvgpnh6Xgubc+/JxuwSUTozxtexmsp0bZ05d+TDNFEos3SrE+mjaaYXxYu0nwXWQ0ypo1lY6zwjI9yWiBs6bfBGxdhsaU7J2JsNjJYmQ3yKmGwFOmGyEwbAjJliZSmOpAazYyKu8ZSA16IckJ3CyYGs7gjY0yjuGi9k6h5v66mNlyi1yd7Bz3tcnkoS0dDFyO2S5OP1x12+W+PoWHl9yXJ1qrE0eIwM77ktnpsXIUkuTz9+b0fP1dhcokqrntItMLOOiXoZBL8CoXVcMBAwghrZw+t9JrzqJRlFPaO6LKKktDlJ+Y/1A9GvHssurg9L4PkV1UqrHGS1pn7L9VdDhn4s49ibaZ+cPWnpG3p18rIwevPgYfPwGlFwk0/KFEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJbA6PSunWZ2TGMY72wDtek+hTz8yDcdx2fo/0l6drxKIar09I8p6A9J/QprnOvk+xYOLGipJL2GF+PSqoJFjl+CX44EhFp8k0LF4APCDYwCNkkCppFk9IlvRnutUUVmJ1VORdrZyMvK0nyW5eUlvk4WXlp75Ovzw5N7Z8vL5fJyrbe5t7JybXJvkySlv3OnOOOe76LJbKXHuZMk2yY8eTSRlaj6eidDOSaIjFyZcZUug7R+xoND6JCdoaH7SNE2tJEJclsUTGJbGBlrbXzz+ohDZorp2TXUbaq9exyenrx6nj59JVRz4NldA9UFLjRqhVo4PX2dufKIrp+C+Neh4RLNHDv2azzkLGA6XAb0Rsxvr1fyYhkbAm7OZGyNgHkj7VwyZYipIdMc2m5WaI0gTAuelZ3COxMSVKfsWoZaNs+xXMYLMbfsY7cTfsdtxTKpVJ+xvn2Zaw87fiaj4McsfR6W7G7o8Iw2YTR049XPvzcN06F7NHTsxmjNKlo6M+jn14syiRrk0fTYjqezSbTPLhEh4oFBlkYMd01zhZXE0wiVVrRojwjLVdXng3grnMZspn4OXdd/lhXOWysWc9MmEk2cutOzOGupfYS2TWvsIktHJq/pWcTFbZsx48mOvyb6CLWOm6H7SxFUGWdy0Sw1Opcimch5SM9kyjzlLmOpcGSU9Eq9JC0u460OQrs0Z5XbK3YTBPJplcVSuM0rGJGTci4uY4097ZDWwr5NddafsPguuMf0vgPob9joqpfgPppewuIvtxjhQteBv4ZP2Napb5Q6r0HwX/dgeIvwCxF+DoKA6rX4KmB/wDRWBYiXsWRxV+Db2L8DRgaTCb71kWOl7B9Bfg39mw+nov4R/2rJGlfgvrqS9i3UUQ3+C854i7ujqKRLlopdmimd+vc1lT81bbZwc6+e9ls700ZbJ7NJ6cH/PrPJbIVaJc0QrEi/wDsqeJuxFkIIpdiCNmib7NJ4L5RWyUkVfU2Mpo59ev61nlw+kCQveSmE9KVxFiS0KxojqOzTOqzuYSEdjuva8F8Ky5Vprwb5rDUjHGr4LY08eDZCn4LVUvway8ZVg+h8CPG+DqfTX4IdXwX9M6408X4KJ4vHg7sqF+CqVC14Lm2Wo85Zh+eDn34b/B6ydCfsY7sVP2Ns7Y6y8fbjtPwZpVtex6fIw/PBzLsXT8G+dsrhxLI8lEkdK+hpmKyto6c7/HD6Y/WZoVosa0IzSVz6yrfkCWgNIxsKyCWQNIDYAMVKZDYbAOJCY6fBXvQ6aDgG2SpA2hA4fVykS5FK2D2HB07e2NGWhI+Ab0HB1f9TSJhfqXkyuRClyRrHV59OO5h5bjNcnq8DP3rk8DTdqSO3g5bi1tnL6eTr8vZ9HxMnuS5OjCe0eQ6f1CLSWz0WLeppcnnevnx6Xl6ddANCp8DHLx1ygNhsAoGySAEFd1UbItNbPnvrT09XmYljVab1+D6I3ryZc7EjkUtNeSpQ/FvqTo1nT8ye46Wzz5+hP1E9IqVc7YV88vwfBc7Fli5EoSWtMdDKAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACYxcpJIAsopldYoxW9n1r0D6XlOVVs637ex530b6XszcmE5w437o/RnpnoNWHjVxUEtIYdronToY2NFKOuDtJaQtUFCKSHFQAABBBCJ0CQwkhskqsnocnStLdZ2o5WVkaT5NGVfqPk4eXk8Pk3xhjvbLmZPnk4eRftvkuy8jbfJzLLNs7MZce6SybbK+7kHyQlyb8YnTBohIYCoUSyC0xUWIE8LIXRZojRNq5kKJDiOhtbMtaa5yWKZpqg2TVTv2N1NHwcXp68dXl5Cmr4NtdPHgmqrRpitHB6+z1fHHCV19r2aIoiK2WJHB6ejq4eJLISJZzXXR0rF2OxdClMIYjRIdMaDQdxHcLoNsjuF2RsXQs7ye8p2SH0XF3eMpFK8E7KmkWNCkSUKRZGRpnabD62Vzq2izuJT2dGPRNy59uNv2MNuO17HecUyiyhM6c+qPiPOyqaK3BnbniJ+xksxdPwb59Ge8Ococlyr0i76On4JcdI1noWcqEtFseQ7eR4RSYrp1eeEOOim1pJl9jSRz8i3Wzn3Xf55Zr5pMqhek/JRfY2zP3PZyartzj8d6rJTXkvVnccSix8HRqnwc9Z7y3V+ToUI5tUuUdKhkOLcakS56EctIost0HEzPVk7DPO1FNl/yZLLypG082mVpRK7kz/VbYeSvnrTOV31xlZsoUNl9dTY5hVkixLuLa6tvwPXV8GmuvTLmGOrEV1GyuAsVoti9D+HNurOzgV1jKZPeg+GFlEY6QaRHeg7kXMl806ghu1CKaJdiK4VlNpE8Iolcl7lcshfkf4PmtfekJK1IxTyde5nnlfI/qLnna6Er1+SieUk/JzpZXyZ53tsnWmuPJ0p5XyUTyN+5gdrYrm2ZfbeeTW7/AJFduzNsZPkP+ip5rhWL3E7JvpVzEAEpbJUSfur5ExLIiqJbFDlZaCRZGJMYl0ImmWWqiEOTTCoIRRoikdGHPuojWWxjoaKGSOrEcu9CKLERFD6NeMbpCRLJSJ0SjpGhJItaEaHKVZ5QKZ17NbRVJFzSeObdRv2Oddi7fg7s47MtlaNZsrl5jKxWn4OTk0tex6/Ix1JPg42Zi+eDox6Offm8zZDTKmjo30NN8GScNHTjbk9MM0itstsXBQdOa4tw2yNkEbNIxTsN8C7IbHBU7GT4KtjJ8DSlsaLKm+SYsC6tbI2K2RsZdWpkNiqRDYh1ZFktlSkT3BwdSwF7idlyItPHhmuq5xaMKkT9TTM/TDXz29Pg5va1yer6dn7S5PnGNkal5PSdOzNNcnnevm9Hx9X0THv74+TXF7PO4GYnFcnbqtUlwzz/AE8+PR8vTrTokRS2SmYWOlIAGibDQ0mD5Wgb0CQ4HA6902vNxpxcU20fmv176YniZdtka3rf4P1bZWpb2eE9Z+m6s/DsfYu7TKN+RZwcJNMU9J6m6HZ07Mmuxpb/AAeba0xEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9B6a6NPqWbBdu1s4lFTutjFLe2fa/039P9rhOdfL17Dge/wDSfpuvEx6n2JPSPo2LjqqtcGTp+EqqY6XhHTXC0FJIABJgAAYAbIbEciZ/oppS0jBk3a9zRbPUWcbNu1vk6PPLHemfNyePJwsu/afJfmZHnk42RfvZ2Yy5daUXTbkUa2ErNslSN5GN/SOJKQORKZaeG0DRKARVCHixUhktE0pDEASltmWq2zExjs0wqb9haYbZ0qad64Md6/HRjPaimrhcG6qsK6vg1Qr0jyfXf69Xy8pwqjodIZ6RC8nB6bduMcPCPJZoiBZo5NXp6iCGSyGEQgkgVsnV4vMNsVsjZDZH0riHIhSIYrYfR/KzuDuKnIVzJuj+V/cSpGb6nyH1RfR/DV3h3GT6vI8Z7NJSuGlMdSM6kOpFSouF6lsdMzqQymaZ0ysaVIneyhSLIs3ztlaftTKbKUy9E6TN87Tf1zJ0fBmsr7TtOpNGPKq1Fm2dnmOPOfaxJZSivJRmzcGzj35T8bZp9Ovzjq25q15OdflbZhd7fuJtyfky3Xf5Re59zI0NVU2XOl6ObTszIio30vgwwXazbRzoxrP05x0KeTo08IxY0N6OglqIuPO3/qbLNRMF12t8l10+PJy8izl8hxWImd2yidmyrv2Q3suR0yRfXyzRFFNEds6NdO1s1xlnu8RVDfsbaqhaqtGqEdG0w5teiYw0OloN6IcuCvljrdp9iueipzKpWfIuFO1p+tr3F+v8mKdvyUu/XuKxrPProvK17kfxfycuVjfuJ9R/kjp3zdhZfyQ8v5OUpv8AI6bfuTdIvm3SydlUrmURT35JkiLtWfNE7mZ5WsaaKWjO7dOPOB2Ngm2R2jxjwKb62+JEbBD9oKIxxMUPoIxLFElNV6GjEs7BlESLURiWqARRYgZ3ROwsjElLY6RcqLRFFsBBos0zWel8XwWwkURZbE6MVz7aIyLEymJYmdeK5Nrok+4kWNs2jGnQxWh0OwuBislsj3J4fCyiVSRdNlMmB8VSRTKOzQytoqU/lmlXtHPycbuT4OpLyRKtSj4LzoXH48hmYut8HFyK+1s9jn06T4PL5kNSZ1+enB7ZcixcGdo12IoaO7Feb6ZUtCssaK5HRHLYXZDZDD2LTUbGT4EHXgElb5JiQyV4GSWyNitkbAliYNipg2BDZOxUNoDGwcgYrKjOp7hG3sPclho5V1MtM6uLkuDXJx4S0XRu0/Jzbx10Y3x7Xp/UNa5PWdNy1ZHyfMMLK01yes6Vna0tnD7+f49H+X07p7yuSkizwc7ByO9I6HdtHmanK9eWU68EsWJLM6pDWyJy7ETHyROPcggCfdHZgzKFduLW00bt9i0RxJb0VDfGP1A9IQvqsthBb1+D8+dVwZYWVKDWtM/afV+nxy8WcXHfB+bf1C9Nzoy52Qr42/YCfLgGsg4TcX7CiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLbA19OxZZWVCEVvbAPUejegS6hlwk47Wz9KeluhQw8ev7Uno8J+nnp36FMJyhz/Y+zYVCrpS0MmmEe2KSGTJ9hYrkAlggZCEZhXsYjQzR7FVk0kWTaSMGTbpPkrOep1WfKye1Pk4GZl8vk1ZuR55PO5d72+Tt88uT00TMyNrhmCU9+RbrGypSOvMjk1TPRCI2Si+JlOophrQ0UDRnpcKh0hUiyKFCo0SkNohhUwrLK47FjHbNVVRzbrq840Y8FwdOqK0jLRV4OjVWcfpp3+eIsriWS4RMY6QS8Hk+2v16PnFDb2WwQmuS2COHVdU/xZBDixGFGWqVkbJYknonVTmJbKpS5IlMplYc9trozgzmL9RlMrV+Sp2r8hGs860uwV2mWV3yUTv8AkrjXPk3O75K3cjA73+St3v8AIrGs8nRd6I+ujmSvf5E/iH+SeL/4usreR42/Jyo5HHkdZPyXKi+Drxu+S2NvyceOV8lscr5KlRf566ytHjYcqOTv3LY5HyVKx1/PXVViGVvyc1ZHyMr/AJKmnPr+eupG0tjM5cb/AJNFd2/c1xtn/wAbG5z4KZ/euRfqceSFNG+fRFxWDMw4zi+Dzebhab0j2U9Sic7KxozT4N5tt5R4iymUSuG+7k7+ZhpJ6Rx50uE/AXT0cf42YyT0dKFUZLlHMxXpo7NC2kZ2w9b4q/hU5eDRVi69jRCtGqutC+eubfpSU1aLLdxiXxjpFOQnon4c112uTlWSW9M503OR0ra3KT4Eji/A5htiudGuTZqpx2/KN0MRfg010RiaTDW6VUYySXBsjBJaGj2xElYtmuc8c+rasWkT9TRndpVK0rqflqdwjvX5MMrWVu1k3SpiNk7/AJM8rn+SiVjYvcZ3S5mLXY2VylIEwZF00kQpPQ29i9rY8YMztV+cTHZbFSCEDVXBB1lriqMZJjNM0di0K4CqPpllArcDW62I62Z2Nc7ZewZRZa4MaNfBMjX7VKI8YFqrHUCk3StQHUSxRJ7QRdEUSxRQKI6QM7UdqDQ+iGhotQhkKkSJNOh0IhkypU2VZHyXRZnTLYs6MVjqNEWOmUxZZFnVmufUXxHKostRvmsbEolMgDTqaYCNhsEhoRxRYQ0JUZ5IqkaJIqkgXGdrkda0EkLsUv6dYs2tOLPK9Qp02extj3o4PUMbhvR0+enP6ZeQvjrZkfB1Mqrtk+DnWx0d3npwemIonJFTe2NJPZHadmK4N5Rx7ivXsRJipm3WGoGCbDYIGfDCtksRsZDZKFQwySBGwGSdkplbZKYBaIw2QwhUoN7BlexpP3aJUnsTYJ8hwutlVjj4Z3ul5bi1tnmYyN2Lc4+5j7Yljfw3Zp9M6X1CLSWz0lFymlo+W9Nz5RkuT3XSstTjHbPH9vPj2/D1teji+A8ldclJcFiOC/69DN7EpAABBUaTJ7UkBIURVZWpRaPBesvTNWdjzl2Lej6D7GPLpjfVKLXsKU34y9U9En03NsXbpbPNH3z9TPTXe52Vw9/wfCsqiVF0oSWtMoKAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATGLlJJH0X0F6cll5ddkobW9nkugdLnn5sIqO1s/RvoT0+sSituGnr8DD2PQelrFphFR1pHpY6itFdFahBLQS39QQWtkojyiIsXQZkaGICACt8BJ6KZz0i5CtV3W62cfMyNJ8mrJuS3ycHOv88nRjLn3thzMnzycS+7bZflXbb5OfN7Z1Yjl3pDl3MFEhLTLEdEYWo0SkNojQ6cOh9bQiG7tIiqGtDITuHiIjbF2NohR5I1VZyvpjtnRoqMmNXto7FFPByemnb5ZPTWba48C116NEYcHD6aeh55VyekUynyWXcIyuX3Hl+uv16GM8i6PJdEpr5RekcmlW8NEZsWKCRPWXe0spGeyY1ktGSywnVdHnnqZ2GadvIs5mWyfJEz12+fmslcVStKpSK2zSYdM84slayqVuxWVyKmFzEP3iuZXshsPhpMQSmVuwWTKpSJuGs8131Q+uY5W6YruI+Ws8o6Cv8Aktjf8nKV3yWRv+Q4V8o60L+fJesj5ONG/wCR/wCJ+R8rHXjHajkfJbG/5OJDJ+S+GR8gx14x2FkfJoryfk4X8R8lkcjXOxyuf08Xoo5Ca8jq75OFXl/Johlb9zXOnLfB2PrceRJ2JmBZPyDv37m+dCePDZEVJM42VjpPZ1ZW7Rkv1Ir6bTNjmVrtkdfFn4Oa4aZppn2i6nTvUxTSZrhFJHMx8lKKNayFo6c/45Nyta0JOKkvJleSR/Ej4y+TSqinsXUUVWZHBQ8gcka5jY5pFcrtGOV2yt2NlxVbHkFUrzN3hvYt3ic5/VzuFdpUxdMx+2vytc9i72KkyVFk3Q4lIdQ2NCBojWRdEzqtjKpmqNZbGtE2n1mjVwMqzT9MZVk9TdqYwL4QLIVF8KymGtqo17ZZ9FF8a9Ddr/A+MbtkdCElSjc4FcoB8qnowulEfT0apRF7CbGufTqjsDtL+wjtFxX0r7SdD9oaDhfRdEkkNhwrQQRsNiLoBAAlQxOxNhscFWKRZGRQmPFm2ax1GqLLIszxZbFnRnTn1GmLLUzPBlqZ0Y0w0s2AqZKNesjEryQhg6RiGRskOnCSRVJFrEYdXGeaKZcM0yRTOJH1+tJPwkVsx5tKlBmxPTFuj3QNsaZby8T1GjtbejgW+We06lj7hLg8nkUOLZ3+enD65YO3Ys+EWvhlNvKO7Gnn+mWaT2yAa5J1wbyuTULslMWQqY08WsV+QTAqJ4glEElJsTsXYMgZcD5JSBBsCSiRdhsCEvBWkWN7F0NKCBnwI2MqZMurnozpjxfJOp2DN5XVxbnGSPXdI6i04rZ4eqZ2MC9wmuTz/fzej/P6/r6rgZX1ILk6KkeP6RnfbFbPU49qsSZ5Ppjle15b7GteAD2AxbgNgAAMTs4Y78C77gDy3qLo0M2izcd8M/NPrn05LAzLJqOls/Xd9Ssraa9j5N+ofpn+Lx5zhDb/ALFB+YWtPTIOn1jp88HLnCS1pnMJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeqDssUV7iHf9NdKnnZ0EotrYB9K/Tb0yrJV3TgffulYEceqKUdaR5P0N0eOLh1px09I+g1w7Y6GSEmpfBLjsYCaosU15J0SQyQkCCGy4m1E/Bivs7Uy66ztTOPmZOk+TbGWWtMWZk6k+Tz+Zk7b5NGblfc+Th5F+5Pk7cY/HFvX6rtk5PyVaexZWEKZtnLG1ZpjIVS2iUzRJ0ydEIdE1UCQNMbQPwLqqRJ7LorgrXktTJtEiUx4R2xEaKY7ZjvToxlvxK+Udmivg5uLHwdilcHF6ad3nldGA/CRMVwRNcHF6V2+cYsiXkyLmZfkPlmeH7jy939ehPzLbTB6LdaIp/aO0Z2OfeghJ+B34KZvgzsTn9rPazDazVbIx2PkJnru8/xTJmea5NDK5I1z5uzGpGZoXRa48gomnw1/6RS4iSgzV2EdmyvhU9GT6b0VTWjbODSMdqexXLfGus82Z7JpF800mc7Ik0RY6sfpbJveyiVuvcz25DT1sx25L/Ivh258+x0vr/I6yUvc4TymvcV5b/IvgXyehWWvyH8ZHfk88sx78g8znyHwy15vTV5K/JojmRXueXrzXryWfxjfuL4Ya83qI5Kn4ZcshJa2edx8qX5NayXvyHww3h2o3/JbHL17nFjk/I6v+RzDO+cd2OXv3Lo5OuWzzqyte4Sz9R8msyzvnHonlxb1sdP6i2jzVOY52Lk9BhS7of8ABXGVyaUdFfJqnDZTKKQ+I+OrKZtLya4XceTFFpIl2JFzXGV8u1sld8kfWMf1U2W18j+y/wCK2U20Uuei9w+0olAf2i44jvJ3sTtHSD7T8hjRYaLYV7RG99OZ4VLYygWxqLFWZfR2qo1liqLYwLIxDrO6Vxr0XRgPGBbGAmd0qVTHVbNEYDqAIu1UK+B1UWqOiyKFxlrauNRbGGh1EbRpIx1pEUOooEixIuRldF7EJKsvUSHEfB9Mkq0UyjpmyUTPZHkmxpjSnQrLHERonjf6KyCWg0Lh9K0K0OKxKIyCWKI0phsjZGyTNsjYuyQFNsaMhEMtFys7F0Zl8JGRMtjPRrnTHWWyMi1PZiVhdCzg3xtjvLSkOihWDKxG/wBsfir9h3FP1AViD7P/AJ1fshyKvqr8iu1B9n8Vc5Ct7KfqoPqr8h9iYppFNk0gstRlnZtmd1+unOPw6e3wO1uJRGXJcpbRrjSd+bn5lHdFnluoY/bvg9pdHugzzvUqHzwd3ltxevm8dau2TKJPaN2VVqTMM1o9Dz08z1wolpMVtNDSXImuDrzXFrKuQo8kLo0Z2JT0T3IjQDibE7JF2TsqIsDIJ2Qxp4EDZGyGxlwbI2AaAuJ2MKhkNJZFTZdJFUojLiIssT0IkSxo0urk0zo496i0cmLZdXNpmPrjsbeOuV7LpmY1OPJ7jpmVuK2z5b0/J7Zrk9j0zO04rZ5Xv5PY/n9XvYWJpD7OZiZKnFcnSjzFM87eePTzrsMShfcYhSGCSQaJAFkto5XVcGGTjyjKO+DrlVsO+LQ4H5g/Uj026Miy6EOP7HyacXGTTP1n686D/GYVuobevwfmT1B0ufT82cZRa5ChxQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABbj1O66MEvLPtn6cemVuFs4+fg+X+lunSzOoQ+3a2j9Pej+lKjEr+3XAyr1XScRY1KSWuDqlUF2RSRYvAEYCCSapAAQyQkrnLSGfBlvs0ma5nWWqzZdqSfJ53OyPPJ0c2/h8nmc6/wA8nXjLn1pgyrdyZzLXtse+/cmZ3PbO/Ofxy6/0rBMbyQkVxCyLLEyvwiUxBfFlsTPFlsWRVRcJIlSIZPT/ANQvJaitItiiLWmYeEdm3Hr2zPVHZ08avlHPuuvzy2Y8NaOlUuDJTHRurOPddmIviuBbPBZHwV2eGcnp/jpy5ORL72iupfcTdzaxqo8nla//AOnb3/8ALfSuC1oSpcFzXBcjk1f1VIzWvSNM+DJc+CblfmxWvZna2Xz8idppjHXTNcU9okomhoRo6Z5rz6sziQol0kLoPlX/AEIR3aJaKp8IVjTGyW2cGC6xo1TZhyPDMtPQ8b1jvyu1M5GTlN7NGXvbObODkzKvT84yW2tyZnm2zd/BuT2WR6c37B13Z9JI5Li37E/Rk/Y7lfS2/Y1V9J+B9Tr2jzaxZS9h44E2/wBrPV19J7XvRrr6Yt+BsN+8eTq6bP8A0s1Q6XL/AEnrq+nRX9KNEcGK9kPjl1/Rl5fH6bJf0mn/AMdL/SemhiRXsi/+Gjrwh8c2/wCiV5JYMl/SOsKX4Z6aWPFeyK3TH8D4merzU8OX4MtuJNLwz1zoi/ZFN+JGUPCGNbeaxKJfUXB6vAr1Ax04ajNcHYogoRDrn1pElwZbeDbLTM1sNodqsVkdmkUzu5Gti0zLJMytbTPV8beTdRZ4OTF6Zqqs0OU9Y/HahJSWhvp7MOPduWjpQkmPrj9JxRKrQnZo2yimimUeSbWHVUYGmuPBEIbLowJ6W9ciYxHUBowLVAGF2rUC2FY8YFqhofGd2RQLYwJUS2KHxlraIwHURoxHSHxndk7RlEZIdIfEXSFEbtJSG0XIztKojpBokuRKUiGidgBK3Ez2R5NbKprZNaYZZRKpI0TRRIXG0qshksVvgmxcLsVsGxWTWsQ2K2DYuyVyJDYbFbEfyNhsrciO8Sphd3aI7yn6hHeHT/5tKsHUzD9TXuH19FSpvk6KmiyNyS8nL/idEPKNM6Rrxdf66/IfxK/JxnlCvL+TT7TP53b/AIlfkh5SS8nD/i3+QeU37h9rn87sPM+RXl/Jx/rsn6rYfZ//ADuv/F/IfxXycpWMdTbD7T/wdCWR3MX6mzHGQ6kH0qefGuMy+EtmGMjTWzXGkaw163E5mfSnFnSi+DPlLuizu8tOH1w8R1CnTfBxLlps9X1KnzweZyYakz0/KvL9sMEhfYsmtFUjtxXn7ySTF2EhdmzGw+yGyNkMcRYNkpikopnYYNgA0VDZAPyAyBKBEjIE7F2A002xWRsBpI2CZEgXgOjnTbGUioZBzpc43Y1vbJHoMDM1KPJ5avho6WJa1NcnN7eX46/H04+mdJy+5R5PVUzUq0fOekZfb28nt8HJU4RWzxvfHK9nx310/ckSL3yNs4q65TAQiQMAAB0MHUcOOTRKLW9o/Pn6oemfp2TuhD58H6Qku6LR4T110eOX0637U32sqB+QLYOFji/YQ7XqHps8HNmnHS2cUQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWU1u2xRXuVne9NdPll9QrXbtbAPpP6b+nG5RsnD8M/QXScRUURWvY8f6L6RHGxK/t09H0CEO2vSHSP5JRXXvb2WChVIAAU4CGwIk9IUFLOekcvMu0ma77UkcTNvWmdHnlz7rmZ2R55POZmRtvk3Z+Ry+Th3WdzZ24w5daZrG3JsWK5GbTYI65/jG1PsCfJJGh0um3tEpiEbZNgaIssizNBsviyLk1yYy8FPch1Lgm5VKtiWxXJTEvgY6nG+L1qojydbGj4OdjJNo7OLDwcu9O3zjRBGmsrUUh4nJvTrzlpj4K7Xwx4vgqtfDObd/GuZ+uTZ/9rL6UUWP+Yy2l8o8q3/8ATrs//Lo1Ita4K6fBdLwb5jk1/rLa9Iw2yNt/hnOtY7GuKok+QAWT0beeV60JFMnyO22J2ts6/n8ZzfC+RlEaMUP9pFyuenVLgVWVOS4NEmit79jHTp8659tEl7mK3Hk0ztSjvyZrlFJmGq9Px3x5zIwpMyfwMtnetSbKvpr8GNejj25HPqxlFaaNVdEf9JpjTz4L66fghlv+j9Z4UR/0mquqP+kuhSvwXwrS9hyuff8AQqVMWvBdXjr8F8IIuUC+ufXvVCpS9hlUaFAns0UxvpapVPAODTL/AAK0VKUtrPKtlUq2jVIqk0PrfNsZ1BjOvgZySFlPjgXVW9J9NKRb3aRVtkNsXUfJ+/bIm1orexW2HWufws69rZjtrOgv2me2OxNs6YNaYyeiyUCuSaH1p9dW1WdsvJ1Me7euThdzizbi3eOQ65/Tytd+L2iGuSim5NeTRF7JcWsXK6uJpjWUVo1wFxz711MayxQGih0hxhaWMCzt4BIZIqRlaVIsiiUkMiuJsSkMkQhh8ZVKQyEGQ+EdDCokqEGRsAH0k7DZACA2RJEkMFSqLDLPybJoyzQq1ypbFfgmT5EciLW2YVisHIRyRFrfOQxWxZTK3MXWswsb0JKRXKzgonYxdXItlMrcyrvYspC40kW/U17iu35M0psXvDjSZaHb8iOx/kq7iGxzJ/Cx2P8AJH1H+SlthtlSFcLXN/kjuf5KuWNpl/JzEWJ/JK2VLey2K4HMVfzIZSHTESHRX/OpvFsSxFMWWxYf8qi8WrwSQmSh/DHSyD5NdZki9GiuRrnLLTUnwJZzFjQaYW60dnlHF6uF1GG0zy2XX9z4PZZcU09nmuoQitno+V48r2jz9kTPJGq5/cY7Xzwd3nevO9ZxXJC6HJ4OlzE0Q0M2hXyOJsQMiO1jJMpFykA8EOQdZ3KGuSUiE9jIPovhBDGYrWypU2cQvI7XAna9C7kUzqWSgT/JO0HSI0R4RLYrF/o7wrlyNGQdqI0XPwreroy5NVNmpI56bLqpNSRG72L8/wAr0+BkuMo8nt+kZPd28nzbHu7XE9V0fNcZLk8r38+vU8PTj6PTLcEWpnKwcnvguTqQezyvTHK9PF6sRIoGcrUwEewFcAOf1TEWTjyi1vaOgV2ra0E/Cfmz9TPTX0ZythA+N2wcLHF+x+vfXPRIZvT7H27emflfr+DLD6hbFx1qTHf03HAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANXBzmkj67+nPp76soWyj7/AIPmvQsJ5edCGvc/TPoPoscfDr+3nSHIHt+kYaooikvCOvv2EprVcEkTP9wqR9E6BeAFBwAQSABTa9Isk9GTKt1EvMRqsGZdpPk87nZPnk39QydJ8nmMzJbb5Ozyy5t1jzLttnMnLbLr7G2Zdts7sRyao3yMmQkMkaIMhtib0RsAsIYikTsRmXA6noq2TsRrO8shIzlseEINtb4Lk+THXM1V8sw9HR5x0sPlo7+LHhHDw1yjvYvhHn+r0fKNOuARLF3ycO668xcnwVWvhjxfBXb4Zhq/jSf65Vv/ANrLqfKKrF/MZbSuTzrP/wBOm3/8unT4LZ+CujwXyXB0ZcumG7wzn2nTvjwc61FnmswsizQskbearVPuMvAaDR09/GRWI2y7tEkkjPVbYyQE0vJXOxR9zPbkaXk5912+eF1tiS8mC63YlmQ5FPMmc+q7sTif3MsjXsmus1wqIrea4SFaL4VoaNZbGGiGWqVVlsYEpDrQ2GkxjotSRX3JIV26H1n8tHAspIzu8rldsrqphfKxCOxFDnsrc3sfWky0SsRTKZX3MN7Dq+Btirex9EqIdNGg0OojKIuhU4kdpf2kdodPqrt4KpQ2au0hwGcrDKsqnWbpwM80DXNYLoaRVXNwZrtjtGG37WDb/Y6mNk8rk7GPLuSPKY9+pLk7+FftLkHJ7Y67cOEXwZihZtGqp7QPN9M8a6/BfFGetmiLHI5N0yQzWkKmNvZpGXUEoNElH1KGFQwmekoZCphsOpWJk7Ku4nuDoO2RsXZGw6OLNklakT3B0cODF7g7uB9ORXMy2cGmbMlrJtbYjNORTKZNstGWczO11YytlYUytKpWFM5kddOcLpWi/UMzmR3g2mF8pbEbK/qCStHIc86slJIqlYimdpS7GVI1z51e5oVyKO8j6hUy3nkucwU2Z/qr8h9eK90XML/5NSYsu7fBn/ioL+pDfx1aX7kV8p15VfFz/A+5aMf/AJGv/Uif/I1/6kVImeWmlylsshKXuYFn1t/uRdDMg1+5FyFfOughkYo5KfuXxuT9y5GG8aaEWxKIzTLoMfGFli6PI6QsWWJh8oSkXQK0yyDKkRqNEBrOUJFkzlwdPm4/WOfleGea6j7nosyzSZ5rOsTbO/yjyfa8cG9fcZZcs2X8tmSXk7fPLzfWq2iNMcnR0dc8V9oOOuS1Int3wT98XM9Z+5jLbNEcXZojhN+xF9Vf8nP02R2N+x1Fgv8AAywH/pIvsX/FylBonTOv/wCPb9g/8a/9If8AYr5VxmmTFHVl01r+kplgyXsVPeIvjWPS0R2xNbxJfhiPEa9jSe8Za8KyuKFaSNMqWiqVZpPTrG+VinaFbXsO6WxHW4mmaz1gbBh2shovvUTPAiyPDKt8jpi+enLxrhbpo7HTsxwmuTz6ka8W3UvJz+vm6fLb6h0bL71FbPWY8u6J846Hlacds93hZKdfk8b3w9jw26YCwl3IY4bOV2T9HsSR7ElmCHySAqTn9Txo5GLOPnaZ+bP1I9NPHvsujDy37H6fnHaZ85/UHoqzOn2NQ5CB+TZwcJNMU6fW8R4ufZBrWmzmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASk20kQb+l4csvKjGK3yAez9CdHldmV2OPGz9M+nMP6GLDjwj5x6D9OfRx6puHP9j69h0/SoSXHAw0PyOtMIx45Ja44FQSXPgn2FhFpvYxJwLyMxfAOSaHCqq2Wjl5tuos3ZEu3Zweo5CUWjoxlz704/Ub+HyecyLNyfJ0M+5vfJxLZtyO7zy496LPkp0M2yvTOzMc1qzYbEJQqZmQyQAyodIglNCNJGyW9iiM6ZanwUJ6HjLkRxoh5NlL0zJW0aYctGHo6vOOxhveju43CR5/C8o9Bj8xR53q9DyjS3wJvklie5wbrszF0XwLZ4IjLQT5Rz6q5HPmvvY9T0xbF9zIhLTOSz9bf+OrRLg1eUYMeWzdHwaZrDUUZEftObbHydW5bic+2DNIhj0LKJa1ohx2a5qv9UdodukPJa8iTlqJpdHM9Vzmoox3ZCQuTdrfJzLbm35M9adfnhdbkb9zLKxy9xG3IeqtykYa07/PCYQcjVXSPVVo1wgvwY2tucV11aNMYEKJYmkT1FplFDcaKXPkHYHUHlLRX3iSnsRsXRxbK3jyVuzfuJLehUHRMmbbI5GROkHWkiET27J0MkEqidodo+idD6RNDRXIyiMo8j6XUJDJE6JBPUaI0ORoZdQkDiMkDKg6z2RM0o7ZtnHZRKOgaZ0xzr2jnZVbWzsSaRjyIKcXobpxeuGm4SOvhZGtcnMvh2SHxbfuEes9esou2kdKme0cDFm3FHZon9qG8/8AoxyOnU9mqPgxUzNkJJoqPK9Mn0SuCUgkuC45xsnZXySNUP3E9xWGxWlYt2Q2IpaRDmRaXD9xKkVb2NsXRxb3BsrUiXNB0/k/cR3FfeiO4Oj5Wdwd5U5CuQdORZKZlumPKZltkTa2xGW6ZjnYXXsw2SJd/ngzsKpSFciuVgcdmPNMpiOwrlYitzRUjeea53aK5Xr8mS6xr3MVmV2+WazLox4ddN3IqlekcifUYx8sxX9Vjykypl05/md6eXFe5nnnxXujzdnUXJcSMssyb/qNJl05/lejt6ml7mG3q34ZxJXzfuVuUn7lzLbP8rqz6tL8son1Scv6mYf7g0h/LSfyytL6lZ/qZK6lZ/qZj7UDSFw7/HG6PUp7/czbj9Tl3LcmcLXJZGbiCNfxx66rqe9cnRoz+73PE03y2uTr4t745Ljl9f4o9hTlb0b679o8zjX71ydaixtLkuR5nt/PMuzCey6MjDVaktM1VzTNZn8eZ6Z5WiLLYFUS6LF8sdLk+BLJaTHXgz32KMWbeeXD7Vys+3SfJ5vKt3JnZ6hcns4F/Mmej5R4vvWSx7KHHk0yWivt2ds/Hm6/aztDRg2y5VNs2Y+HKT8E62ecs1eM5GmGBJvwdvE6Y3rg69HSvH2nNv0dOMPNUdPk2uDp09MbS4PSVdLjHX2m6vDhFftObXq6c+TzEelf+pdDpS/0npXjwXsR9KK9jG+zWeLzz6Yl7Df+OX4R2rIJPwJ2r8E/90/8HFn01a/ajLZ0tP8ApPRutP2F/h9+xN/oVP5nl59L0n9pkswf/U9k8VNeCt4MH/SXn+lGv5ngrsJ8/aYp4sk/2s+i2dLhJftMN/R464idfn/Q5PT+Z4T6OvYouq58HsLukNPiJyszpc4y4R2Y93Lr+d591lM4nUtxZQ8oxWw0dGfXrn14sbXIIslBiqL2dWNSuXeLAW0y1ISXAQkth6SWJxeV6XpeX2SXJ7rpWb3xS2fMMS7tkj2XRcxJR2zyvfzep4bfRcWXdA0nM6dkxnBaOlGXceR6Z5Xq+euxJIaI2R1olsVPZPkXfaIGl4OT1jEjk4k4tb4Ot5RTclOLjooPyV+ofRZYvVLpqGl3M+fNaej9MfqV6ejfiW2xh9x+cM/GljZMoSWtMKTKAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPd+gemvJz4Nx3yeIpg7LYxXuz7f+mnSOx12OPlDgfZvT3T40YkFrXB6SMe1GPAqUKIrXsbRBIEAADI0SArDRLkql9qLTPkS1Fl5iN1hzb9J8nl+pXrnk6uffps8x1G7hnZ55cXppzMu3ezlznyX5Fm9mJ8s7sZcmqfuJUisaKOiMjDIVEkVcMBAbEYYIgBGYkTYwjA8RSyCFV5aKkbKo8memJuqic3pXV5xvw48o7uMuEcfEXKO1j+Eed616PlF0iv3HkIcG3XmJQN8EEMw0uRRZHbKdaZrlHgy2cM5tNZGrHno6Fc9o4ldmmdHHt2TNJ1ltktozW18GmMtoWa2jfNc9cucNMTWka7YGaa0jTp5ZLpaMF1+lrZrvb5OTcnKbJ+3T546yZNrbZkSlKRveP3MeGGkRdOzGeM9NDl5Rsrx1HnRdCpQLNrwZXTqz+EjDRZHggVy0Z2q/wBWdwrkVuYrkLqLDuQvcI2AujhthshEpB0+JDRKQ2g6aEiUhkiUgPpdDpEqIyRUTaXRKQ3aSkNPUaJSJ0MkOJtR2k9o2idD4VpO0nQ+g0VxPVT4ILHHYvaMdI0VTRformgPOv1jsgZ7FqJtmjLavI3b56cXNjyYK7Oyf/J18mruTONdDtmJ1T9d/CyNpcndx7NpHlMCXKPQY9mkhub+jz7HdpnwbK5nIot4N1Vg5Xj+vm6kZcE7M1c+C1S5K64NZ/VhBGyNh0SJYbFbI7ibVcMxSd8CNmdo+Tpk7Ku4hzDp/Kzu5ByKe/kiUw6r5Wd4d5ncw7w6fyulMR2FMpkdw4LhbKZnsnwM2Z7ZJIfG/l5sl9mtnPsu5Lcq1LfJyrLl3eQmXq+Pj1pd2imd6/JjvyVHfJy7+odvuaTL0fP+e12LMmK9zJZnKPucS3qLfuYrcyT9zSYdef5XXyep6bSkcy7qDk/Jgstc3spfLNZl3ef88karMly9zNOTbBIND+XTnxiFvRJIFSNZiRGg0SBSuQaI0SAU+IIJYpNFoAgCU9W1eUdPHnrRya3pm+mfgcrH1/x3Me3WjrY9+kuTz+PLbR2caO0jWV4f9Njt49ncjpUexyMZNJHWx0+DWV4Xt/rfDwh1pFUXwS56Nczrh9dcXysSgzl5eRw+S2+/UHycTJyN75OjGHl+3ox5l22+Tmyntl98u5szOPJ2Y/Hl+t6hpsautseENm/FxHNrg1u+RzTParxsNza4O9hdPfH2mrp/Td64PQ42AopcHNv0b5wy4mDpLg6leKkvBdClQQ7moo5N7dWMK/ppA9ISzIS3yYLszW9M5tadWctsrIopldH8nJtzpfkzvMmyGskdmVkGI7II47ypv8h9eb9jLXVSR1vrRJV8fycf6tn4I+tP8Gd60kjtq+P5HjZH8nAWRNMsWXJClsO5ld9TixZqMkceGZI0Qy2zfPrYw15Sr546l7GHJwYy9jdG/YzamdPn/Q59+Dy2X0xPeonEyOmtN/ae/njKa8GO/pqkvB15/ocm/wCd86uw5R3wYZ1Si/B7nM6Ylvg4eT0/W+Du8v6HB6/zvOzTES0b7cZxb4Msq9Pwd09Oxw68uVNVmpHo+lZGu3k8zGLUjp4dvZox3nrXF4+pdFyVKC5PSUzTSPnPROoduls9x0+9WRXJ5Xv58en47/HU7idbEQ6OHUdWdDwJNbYz8h5FFxMfBW47kWENe5Qec9T4EcrAsj274Pyr646c8Pq1i7dLZ+ws2v6tMotex+ef1Q6BL+JtujACfFAHtg4WOL9mIIAAAAAAAAAAAAAAAAAAAAAAAAAAAAmK20gDten+nyy82tKO+T9Kei+j/wANi0/brg+Sfpv0f+IujNx8NH6P6Phxqx4LXhDDr1R7a0vgfZCfGidk2nwbDYAEoBJBIwSUu1GDKuXazXkS1DZw8u7zybecYejldQt5Z5jqNvDO5n2eeTy2fZ5O7zjh9KxWz2Vb2LKRCZ2ZjmtWDxKe4eMjQlnuAICKobIbJFbEadgQgYjGx0VjxEaxGiuJRE2VR4RnqtMRopj4NsFooqRpRy7rr8424z0deiXCOLRLTOpjyOD0ej5NjZAuxkcenXlIrHFZhVof7THcapvgyWvk5PRrlQnpmyizRjHhLRj39VZ+OzXdx5Le/aORC7Xuaq7t+50edcu8tM47M9lfBcp7Fm+DTVGI5d9Zz50/cde5Ix2JGPXd5Ri7UvYbaCxclT2K11SHk9le9MnZEmZ2rlDkI5ARolpEbDYMUFcWaDQR8EkWlwJDpC7JTDpWGSGQqY6KTUoZCoZFItTodIUePgpHQkToklIZdCQaG0GioXUEoNEpFcT1CJJ0BRJS4FcR14FkA6raKZovaElERS/rLJGeyJssWkZ5LYOzy0wXQ+1nFyoafg9BbHhnKyq9jru871lxbOyR2se3aRwNOMjpYs/tQqfpOx6Cizg302HFonwdCiYo8v3w7VU+C+L5MNMuDTCXJXXmbz+r+4hyE2Q2K1Ehu4juEche4jp8W94jmVuQrkT1Xyt7xXIr2Q2HTkN38g5lTkI5B1Uyt7ie4o7htgr5M2R36FbKpy0XhpnHVk7dGHIv0nyTZbw+Tl5d2k+Tbjs8fLtZM7L1vk4d+d2t8k9QyHzycC+9uTWypHu/zeLdf1By3yc269yfkrbb9xGa5y9jy8ZIHJv3EbZIaNpHRPOIQaJBlcVxBJA/sHDISQwFwJI2AAVoAAAS9QyCWQTU6iCGSBnaWYI+TVU3sphDbN+PTvXA81HrJxtxN7R6DDjwjl4ePyuD0OJj6S4NY8D+rjbjV70dWmvSMuPXrR0ILSLzXh+1D4RTbPSHsnow5Fuo+Ts848j+jbLl36i1s4tt22+TTlXbbWzmWN7O7GXj+uz93cHbsSHJpqhsv/HLf1ZRT3NcHoumYm0tox4ON3a4PUYGL2pcGW9fi8Zb8HHUUuDppKKKqau1DTbRya1105yJySRiut4ZdN8GKzblow1W2YzWTk9+THZCUvydVY+/YsjiJ+xDWVwViSk/cth09v2O/HES9ixUxj7FTKuuFHppbHpp21CP4J7Y/gLg/pxf/HfBXPp/wd3tX4FdafsTfMfbzs8Fr2KHhtHp3jprwVSxF+DPWFTbzTx3EFFxO7ZiL8GOzF17GOpY1llYVY0aKcjXkSdDTKpVyTIlsp2SutVepF+4yj7HGrco+5rrtf5NJ61nfOJycZT3wcjK6duLejvwl3DzojKD4Ozx9nJ7eMfPcrp7TfBxcjEcW+D6Nk4Ce+Dz+fgdqf2nsePr15Ht5cePdXa/AKXab8mnsk+DBOL2dssscdlldHpuY4WRW/c+j9Cy++MeT5TQ3CyP9z3XQMnXatnH7466/LXI+iVy7o7LEzDiWd8EbUeVucrsxTPlBFEoHwZxvKGCAHwNRZw7keF9b9Ehl4F0uxN9rPeJ7OZ1mlW4c4tb2mKf6T8X+osF4fULIta5OKfRv1K6b/D9RlJR1s+cvhjoAAAgAAAAAAAAAAAAAAAAAAAAAADVg0O/JhFLe2ZT1/ovpTzOoVtra2AfZP016M6caMnHykfXqV9KCR5f03hwwcWuKWuD0Fl/4Zz+vpxrjFrc7FolWI5ryH+RlkfJjPVp/wAnR70CsRz3kfJCyHvyaT0TfN0+5CuaMccj5B3fJefRPwMu37XyeezLeWdTJsbizh5e3s6/LUYeuXHz7XzyedyZ7k9nczk+Tz+SntnqeVjy/XNZZtEIVp7Gijrjn5Ukx3sloIhVRYm9EbZGySANslckIZAEPhC7HkKyauBFsFsqXkvqRna0kXwibalwjNBGqvjRlutcSNUNJFm+SqL4G3yY6dOGqlnRom0cqqRvolyc247MV065bL0uDJVI1xfBxemXTmhkDMjRyajWVVMzWI1SiUzhs5txvmsTJTLZ1lTi0YXLafp0y6EmjPHyWJl5lRrMa1YyJWso2xW2VejOYmc2zNNvZa2VyRm3yzyRTJGmSKpIVrWKHsV7LGhWiLWsIBOiBLgI0SRsagTsgDOgyGQg6CFTIsK0OXEUyGQqGQ0VJZETQyLylYgIRJaKE2MiEh0hpo0TolAPqeo0BJA+hO+BWSKw6AJIcVi6UUz8FMorRdNlMnwHXR5styOfdFPZ0LWYrQ67/Jx8hab0GNc1NLY+SuWY4ycbA631Ox6fFmnFHSofg8/g2t6O7jy4Q+uL2y61T+1Dxm+8y12F8Ze5NrzfTLT3snuKFIbuJtYfhnIrc2EmVSkSqRb3h3FHcQ5g0mYvciuUyqVnyVytHw/hd3kNmaVon12VMrnla17ZHezG8nXuUzzNe5Uy2z4V0XZwZ7bWc+Wfr3Md3U0nruNPPLfz/mvW+6/W9s5OXkx0+TLkdR3vTOXflue+To49Lw/n5/pM21S2cixJyNk5OT5KJV+5Uj1/HEjPoVxLu0jtNZHbLxncRXs0SiVSRR9pEydkATa0n+AnZAD6mgAAVOAAIYrTAAGxdJA2uCNkOXArQBlHYkW2zXRU5NcEJu5InHpk2jtYuM+OCvExeVwd3FxlpcFSPN/p/o4tw8dLXB26KdJcGbGo1rg6tMEkjWR87/T7W01cdeS7vSRXNqJjvv7fc3xl43t6rMi9JHGysl86Y1+S3vk51tjkdvlHje/paqsscpFUuQfkmK2dc/xwXtp6lydLGq7muDBXHk7nTqu6SI3Wucuz03HXHB6bHqUY+DndPx0op6OvGOjn1etPni1PSKrGyxCTRlTjM2yFBN7ZY48kqJFjWJUUhk9EEk8V0ybJFRJULoAGyNhR1IEbDYgnfBG9g3wKTw+oktlU60/YvDt2T8xU1WGVCfsU2Yy/B0/poiVSI1iNM7rh2UuPgrUZJnYsoTM8sfnwYay1mlNTa0a4z2tFH0+32DbTJlsLU6unBSOdmYcZx8G+M9lkq1OJ3ePrY4/XzleDz+n/AHvg492H274PfZmEpN8HCy8LSfB6vl7V5/p5R5P6SjI7PSMhwsS2ZcjGab4Jw067P+Tptljl5zT6d0u9SqjydiEmzx3ScrUYrZ6vFmpxTPM9s8vXf5NkfBLQuxjkroQT5IJQJGkijKrU6ZL4LxZra0EU+B/qj0R2ylZGPsfBsqp03Si14Z+w/VvRoZuLY3Hf2s/LHqrp7wuo2x1pbYw84AAIAAAAAAAAAAAAAAAAAAAAAAHqg52KKPs/6bdI0oWuPufKOi4ryc6EUt7Z+j/RPTf4fBr+3T0Z+mvmNMZ7XtKYdlUdfgti3JMdLVWhFwmeZ6ena7c5I5ckqbFSbY3aZTTTkT3sFJgojqBrN1nYaMmN3kKJDi0VPRnYSz7kc/Iq2mdBlFsNo6/L1Ybx15rNp3vg8/mUtb4PZ5OP3b4OLn4TcfB6nj7OP08XlJR0yFwdC/Ecd8GKdbiejj064d+fCNkJismJvL1z38NslMjRKRIMmSpCkbA1myGImOnsmriYrk0VIqgjVXEzrXK+C4LovRXHhB3cmelxpjIZSM6kWRZlY2xWquRtonyc+DNVMtM59x14rr0zNsJcHLokb65cHJuOrNaUMkVplkTl1lrKhorlEtZXIy15tM6UziiiUDS+SOzZlfNtNsjg0TGLZqdOxo0aKnmV0oVZEqzZ9PSK5xFrCs1ilHRTI1TXkyT/AHHNucdOFcmUyZbIpkY1vCNi7JYrZna1gZAbIF1aCGMRofTCAAJNKHQg6HEUyGFQyLZ0yHQiLENFSMiEOkVlFpkSCQGiLUpD+wiY2xppg2LsNgSWxdkNitjVIs3wK2VuehHYLqvlY5CSmI5lcpB0TKZTK5PgVsSUuA66MZV2sx2F9kjNNg7fOMGQvJga+86N3uYJLdhNrqzHQwnrR38eX2o8/iLWjs0T0kKac3vl0oTNcJcHOrma4WLQPJ9ctaZPcZvqA7R8c3xbV0plUplMrimVwfLbPlWiVgjsMzvRVPISNJh058a0ysKpWGOeZFe6KJZ8fyiphtnwrfKzRRPI0vJinnxa8oyTy0/6jSebq8/57/8AxstzNe5z7uoNe5ntvT9zDbPe+S55u7z/AJo0WdQe/JksyJWPe2Z5+fJU7VDgvOOOnP8ANGlzb9ytspd6ZH1dl8b58eLWxXLYimDmtD42zngaFbFdhXKwprImUiiUiZT2Iw60kCJIRJCvqRAEgVE/SCSCUFqoCCWQRadBBJAuol/Qw7Gx4QcmbacVy1wCPTfFGPjd0vB2cXD8cDYuHprg7WNja1wEeb7f0cV42NrXB2cajxwFOP44OjVT2mmXjf0f0dNTVpIvclBC9yijJkZGkzbMeJ7+xsjI17nMyL9+4l97b8mOybZ04y8j19S2T2/JU3siT5F7jqw4d66Ghq4kLktqXJt1Oc9XV17aPQdLhqSOVj192ju4MO1ow3pvMPT4S+xG45+G9pHQ0c/0difYV8kkBamQuga4GFbJaQoAAjSGyCdjAbI2LJ8kbAH2GxdkbED7II2MI0olMQExGt2QxUMg505+FcdiOBaDRnrLSaZJwM8o8m6cTPOBhcq6zpaZrhrtMzWmWKbSNMXiNTqba1I5uXiKSfBv+puRM490fB149eOfXn147Mw+1vg530u2Xg9ZmYvcm9HAyKeyTPQx6dy8/fnzTRgXdkkey6Xf3QSPC4+1M9Z0ibSiYev638/x6fWxhK3uI5x1t1BJBKJAIZJDRRsPUqlPHmteUz8yfqh0z+HypWKOts/UeRDvra+D4f8Aq10tzo71HwP/AMN+eH5Asug67ZRZWSQAAAAAAAAAAAAAAAAAAAAatd00vkA916D6U8jOrm47Wz9IdFw1Riw49j49+meD3KuTifdsWpQx4r4OP+jX/jo8/wALLzojtLJR+4O3g87U7XRNK+3ZPYx4LkfQ85V9KlBjqI+idGnym6KohJLQ+hWiai1RKJXKJoaEaLxrg51jnUn7GLJx1KPg6kolcq+7ydvl6o3h5XLwuHpHCysdxb4PdZGOmnwcDPw+G9Hq+Pq4PbzeRnHTIijblUdknwY20j0Mb687eP0b0SpoSQifJoz4v8isjfArkM+G3oeL5KtjxJq5Gqs1QaRkrZoizOtZGhTRC5ZXsaLIquLoxZbFFUZFiZnpeV8XovqlyZol1a5Ofbqw6VE+To1S4OTTvZvqkzm1HVmuhDkvijLXJmmLbMblp0OS8CNbLfp75GjUL4KbZ1W2XQqNEaixQ0T/AM2s2oVQOCRocdFc0V8D7ZpmaxmqcTPZEw9MtsaZZsyT/ca5oyzXJwesdnnVEimRdIqkc1jpyraEaLCGZ1rFeiByGiFlAknQzJ7gTrkNAYHQqQyQ4ip2SmRolIuM6six0ytDoaKsTHiyoZMqIsX7DRWpDqRaOJ0SL3C9wxw+yO4rcxHMZzK1yK3YkI5lUpg0mDTnyL3FMp8i95LSYaO4hzRR9QSVg1TC2U0VSlwVfU5EnMfG+MCyZmnMmczNOY+OvGCWy2ZeO8snMqTXdsnUb846FGtG2uzRzK568GmubZMy5/SddWu00RtObCeh/rxj5Zcy4d+Pa6au2Ds+Tkz6hXBfuMGR1qMN6maTAz/Na7tlyXuZLMuK9zy2T6gfOp/9nLu69Nt6l/2XMOzz/l//AK9hd1OEHrZhv6xBb+48hZ1Syb3szTzJz9zWYdmf5Y9Lf1qP+oxT6xt8SODKxy8hH5KmG2f5o7EuqTfiRX/5Cz/Uc9JAaTLoz4yOh/HTf9QrypP3MSYyZcy3ziRod8n7lbnJvyIMh2N8ZhlJ+431BNEC4u5WObF75fkUkOM7lLkxG2SQI5EckjJDqAuLVof6bZdXTt+DXCha8C45t75XO+myfpM6X0F+BJVpIfCzpzXFog02xSM0hV1YqCG9DLkZVdxnTtVp7L6qu4tqxG/Y6OPhva4E5t+sinHxG2uDr42IlrguxsXxwdOnG1rgbzPf+lVRjJa4OhVUl7FlVGl4NEatMJXj+/8AQemGtGruUYlC+0qtu0vJrh5Pt7dTfkJHLvv7m9Mm+3bZjlLk6cvL9fTolL8iSYNiPk6MuDdquXIiT2WtEaN81jwJcF1K20VGjGW5Id06fPLrYdb4O1jx1o52HDhHVqWkcvpt0zDr4cktHT7k0cfGl4OlW+DGa/U7wt2BCJNOseBoVjNitjMpGyWKATsNkEMDDew2QgEaQAkAgbZACMAgARmTDexSUOCmRKYoD1BKZ6YkorQwPwYayuVmnBFUmkjTJGWyJnZxZE13GiDTjoxt6ZdXIJrg+TW1xcHweezcOTk2kel/cjHkVbTPQ8fT8cPrj9eYrr7LNM9L0tcJnFsqaufB2MCXZBG1/Yy/x6WmX2lxgxrd+5uT4OXc5VSpJIJRl1cSyAAoyafJ4b1z0j+Owprt3we80c7qeOrqJpr2HA/F3qTp0sHqNkWtJM4Z9P8A1N6b9DqFs1HS2z5g/IUAAAQAAAAAAAAAAAAAAAGrApd2VCPyZT0PpfCeT1CvjfICPuf6c9O+liVSa9j6pFKNaR5D0lh/w+JWta4PXex5vvr/APTpzPxGtsbt4IXksXKOZoqjHTH0TrRKNMwI0Ghg0XSqNCtFgjJ51KtohxH0GibOLlUSiV9ppkhO0edcqqyWQ37GDKxe6D4Ow4lN0U4tHf4+rl9M9eB6pi9rfB5+yDjJnu+qY3dvg8lmUdknwep5eji9PNzmuBfcsnwVb5PSzexw6nKbYrY2yPcoolFkPIkUXQRNVFsOC2LKkh0+TOtcr0WRRVAviRWkhooughIrZorhsy1WucrK4bNVdeyKan+DdTTz4OfVb5ha6jZVWx66Pg2VUGFawtVRrrqHrq0aoQJ4rquNXBZGtFijoZBxn9fpFAHHRYIxyLmlc/BTItn4KZDsOaVyM9iNEvBnsOP1dPnWOwyTXJssXkzyief6O/zrLJFMka5xKJI57HTKoaIZY4itGVjWUgrQ7IM19LoNEhoD6XROhg0A6hInRIDhdQSiGCZZHQ2xNh3DTxZsO4r7iO4qFcr1MbvKEye4ovla5iuZW5CuQzmTuYjmI5CuQ1zB3MqlMiUimUgazC3exGxPqaRVKwGkwuciqcit2lUrB8aTB3PTEnYVOZVKZXG2MGnYZ5zCUtlUmVx05yScypWPuJkVb1IqZ60uOt1cy9ZMYe5yp5HZE5uT1BremVPNP/Lr0lnVIwX7jn5XWtRepHmLc2cm+WZnZOT5bLnmJ/O7NvWJyT5Ofdnzn7sy8sOw0mG2fCRErJTfOyFW2Oo6HT0XMN8+chVWkT2IneySvlrJEdhOiUMkPjSSFQ2idACpEEk6DQ+nwDIjRIzz+G2QQSJp1IAADgaIGF0HC4aJdEo8DKWg4VbK5pGiFy0c5T4D6rQuMdefa6TuX5KLLjI7W/cRzbDhTHDTs2ytrZOi6mvuJsX9cJXU2/B0KMbeuC2jF8cHUxsbxwZ2OX19+KaMT4OnRieOC+nH48HQoo0vBLyff+lXRjJexuroSHrr17FqWhWvK9f6BGCSGekQ5aRRZboUrz/T16m2aSMF1mxrLdmactm2a5N3qqfJU0XMqkb504tqpeSCX5A6c6Z3HYVojQwaNJpjc/pDZiL7kZdGvF4aJ1pv5x6HEXCNyekc/Elwjbvg5t6d2MttFmmjqUT7onBrnpnVw7NxM839L1xyOlEb2KoSLd8HRK4rCsgbYJFxJWhdFjQgwgVjCyJUgCESBpJIJAAjZJGxGNhsNhsRjZOyNkbDvBw2ydibJ2HS4bZLfAmydhzolGtlNseC9CWeCLlpK5tnDCuQ9seSpLRlctJW6qW0FkE0ymqRp3tGvnrjH0y49tH8x8EqX0om6Ve5M5efP6SZ34/Y4N/jq4GR3Ncneg9xR4npeVuxLfuezoluuP8AYy9YWavQAgOX/wBbxJHgED8lUJ9ii6PdBouK2t7CB8E/Vvpuq52pe7PgVi1Nr5P1R+qeB9bpc2l+T8v59TqyZxf5KoZQABAAAAAAAAAAAAAAAErlo+m/p10v6+VGbj+D5pSu62K+T7z+mGBquM9eyJ1eRWf9fWel4yppikjqaKqIdsUXHl+k7XVP8KMmGiUjOZPqWQSw0aQugAAql1IrJFYT8JBKIGSFqdEJJCMtaK5GfyuUrXBRNNs0S/aL2prZ0ed4nWXMysbvg+DyXVMPt3we7sj9rPOdZp+x8Ho+O/1zek/HgL/tm0Z+7k2ZkNWyMLTTPZ89/jy95/ViZKYsfA6N5+szxNEEZ4l0GKw5V2gXkmPI8YbMdXjfMWQLYrkSNcjXRU2+THW22cnqhs6FFO9cD42MmlwdOrHS9jHW20hKMf4N9OP8DU1aNtUDDWmkha6Pg0wp0NGOi2JmpEa9FiWgAfCtMQw2K2HGf/qdigA5DlRJbRTJF0vBTMNVeVEkUzRdIqkjj9f11ed4zTiZ5x5NkkUyijh3h3eemOaKJI1zRnkjn1HTnTO0LJcFrRXPwYab5VMUZisytaSACNkph0+AA2iG0VwcSArYvcHBw7ARSJc4l8HDbDZW5oRzHxUwu2SmZ+5k/U0VIfw0phszfVB3fJXyP+bQ2JJlP1kK7d+B8OYWSkI5FMpsXvY/lpMLXIqlISU2JtsfyuZNKRTKTGk9FUmV8tJA5CSYrYrbH8tMwNlcmM2JJorjbMI2IwlsRtjkbyIkjPYuS9yKbZLWzXEa5jn5Umkzj3NuR0su1bZyrJbfBtxtJEJL3JeteBFsYci5waJI2BUhpAkCz4ExkQkSI5E6DwBIlyJDQIkGkBKQAhK4kgklIC+Skk6DQ+HIAJ0QPigSkAD4BohkgPieBPggkBcPiBX5HI0BWGjydDDr3owVa7jqYzSa0TY5fW8jrY9K0uDp49XPgw4kk9bO1jqPBlY8X+j0saKadrwbK6tCVJa4NUNEWPH9t2hQ4IaLdrRTJk8efvVVz4RjsfJqm+DLPyKzjntUSiVSiXSKZMJviKqkVSRcxGjbO3PrKloVlkvIjR0Z9B/4UlE6JSNZrrDWQkaKVpooRdV5Q6vEdvFfCN6/ac3Efg6Kf2o59u/zMuGdDDnqJzV5NmNLSM839aemOx2Kpl/dwYKZmyMuDolcGvPh9jxE4J2axz6nDsRh3EFplQJIdiMni4hEkAHFGJEDYuA7FDYAYAhkCMxDIIZNhpJFJCQqbYCBvk0iVos+USnwS0hU4yWRKHHRsnEzTRlY1lLX5NSfBkW0zSn9qFifpbv4ZLbPOdcl2qR6TfGzyvXpNuR6HnPxwekYejXt5EVv3PpGK90w/sfKOmWOOVHX5PpvTrXKmG/wT65RmOovBLFT4JXKOOz9bwIkBXvY/wDwjLyDQr4RKe0E/DeQ9bYf8T02yOt8M/KXqrDeL1OyOtcn7H61jq/EmmvY/MX6k9N+h1KySWuS/wDwPmgEvhsgkAAAAAAAAAAAAAAA19Pq+rlwj8n6X/TzB+jgVvXmKPzt6dq+p1Cvj3P1J6QpUOm08f0oz9L+Lx/r1kVpEkpcEtHna/10oJIJEEholAxlSkbJZAyGyfYVk7DggGQmxkwgoZVMsbK5ck2qySX7SY+AmvtIh4DN/VUShtHF6xUvpv8Asd72OR1f/wCt/wBju8dfrm9I+bZ8NXSObKP3HYz4bvkc6UOT3fL/AP5eZv8A1SkMojduiV5OnNYWDt0PHexlpoeMeR6qs5PXs2VR2VVVbOjj4+9HLvTpxlNdO9cHQoxfD0PRjeODq0UaS4OXWnVjJcejSXBvrpJqr0aYxMbprMCuo0xhpCwLt8GVp/KEOhNk7CUrFmw2ImTs0lTYfZDI2Ay+QAANPES8FUkWsSSI1GmVDiJKJf2iyic+o3yyyiZ5o2yRmnE5vSOrzrFYjPJGycSicTl1l1Z0ySRVJGiaKZI5dZdOKqaEaLJMrbMblvkjI7tA2UynyEy0Wd3IdxX3iuZch8WOYrmVOYvdsqZP5Wqe2S2jPKXbyKrmaTC5he2I5srdqElbH8mk8mkwu+qxlJPyzG7o/wCpEfxEP9aKnkv/AJtu4/kVtfkyfXh/rQfWh/rRX/NPxWltfkhS5M7th/rRH1YR57kP/mfxV85vZX3srd8X7olWRfuhzzP/AJ0zmyYzYjlH8kKUV7j/AOZ/FNJ7ZWyXNCuaH8NJkrQmhnJCOQfDSREkVNFqkmyJaH8Ll4pZXJjyRVIPlrKqmU3cVsukzNk2JVtF4nGudOFmWPvMi5LsuW5lETVr1ZrgXfIN7JSGqAZEEpDXIknQJElLkCXBOgROiVSDQEhoFQDEIkFQEgAKBKAlBBaAACi6AAAHQAAM+gAAY6AAGHC+gQQSlsOH01fk6GO+UYoR5N1HGhWOb1nXYxp60dbHv1rk4VUtaNlVj2ZWPI9/Pr0tN6a8muFpwsex6OjTPgz1Hke/lx0e/YjYkZbRIo8v0yWRnn5NMlwZ5rkjTmsZ5FMkXyRW0YWjiloRlrRXJGmdM7lU1titFmiGjfOmVhNAkNoNHRisrEJcl0OGitLksj5Nenl1MSXg6kOYo4uPPTR1qJ7SMduzzWtaLap6EfKIiYz8rot/HQpsNtdhyq5aNddhpnTDWeulGY6ZjhYaIzN86cu/NaAvcSmazTC+fAxWhyND6XOKwGa5IJ6pAEgLpoJAGLpoZAAHT4CGMkQxWmgkEiQlIoEsgfUmTG2IhkK04WRROO2aGI4kWrkZ1Dkt1wT2jpBi/pan4SXETyfXZcyPV3vtgeL67aty5PS8v8cfo4+Db25cP7n0zpdu6oc+x8jov7cyHPufS+j5G6oc+w/SM5Xq4vcUOvBRRPcUaDg1P1pEe5Otke4woZJ+CV4IfI2uB02fJh30yXwfn/8AVfA1ZZYkfoWa+xo+Qfqnhd2DbPQ4H5msWrGvkQvy49mRJfJQIAAAAAAAAAAAAAJityQB6r0djfUz4PXufp/0vX24Fa/ET8+egcJ2ZMZa9z9HdCp+liQT/Bh7X8a4djXAMlsg4a2QAAI07DZADIAADJDRGhiNjOIJSAZBSKytotZWzLS8ll+0IrglraJi9Bk7/g1wcjq3/wBb/sdrzHZw+s2RVb/sd3jP1z+l/Hgs1r68jDJbNGbJ/wARL+5l7j6Dyn/5eVv/AEkkV65L3piqKbNup4iKbNVNbbCmtN+DpY+Om1wZ721xhOPQ3rg6+Nj+OAxsZccHXx8fWuDj3t14wWmjxwboV6Q0IKKG2jl3t2eeDRWixMq7kT3GN22+F8ZDqRnUh4zRH0m5X9wdxV37GTLzWWsrUx0VRkWJmsrKxJKFJRcK0wAT2lItKQ0P2shk05SaEkWMrmYabZqiRnmy+Zmm+Tl9a6vL9UzM8y2yZmstSOTVdmYrmzNZLQ9lqZmssWjDTr88lnPRndpFk9meUnsjjqzhe7CmcxHIqlMcy2nmd2kfU2UOXIOaSLmGs8lzmR9VIyWZEYryYbuowj7mmcNs+HXXd8X5Kp5EV7nnruqx19suTHPqM5L9x0Y82+f5noLs9R9zn3dV17nEsybJ+5Q5Tl5ZtPN1Y/mdWfVn+Sh9Sm3vuZhSXuT2o0/5tp/NG5dRn/qYy6jP/UznpDIP+av/AJY6H/kZ/wCpgupSXmTOeQw/5j/5Y6a6o9+TRX1T5ODzseLaH8Ff5o9A+pr8gupL8nB7pP3Hi5B8Jv8APHoY5ya8jLMT9zgxnNe5dCcn7i+HPrz47P8AEp+4O/5ObDvfuWqMhfCfhs+v8k/X2YvuRK7n4F8lxt+omLNpmdRmTuXuHyRbGcvMm0nydVrZgy8eU09IJleHn7ZNyIii+7FnGXIiXb5K43hF5LUvtE1yMvwDbMTolIEhtDaSIJ0ToNAuRKRJCJQK4NEgToD4gkNE6YGgkNMnQGgkNAEAAAGXAAAM+AAAY4AABjiCSBu1jTwuiyERdaLID4FkYmmpaK4I0QQWMN1qqNtRiq0jbVJGdjh9XQoejo0vZyq5HSxprSMtR5f9Gfx0a/BakVVPaNEVsiR43rkklwZZrk3Sg2jNZW0zPccWoytCOJc0I0cuhIpcSmSNMkUyjsJorlVohodxaIaNs6ZayraI0O0Lo6caY6yjwNBkaJjwbylI01y0dLGs3o5CkbcazTROm+K7UHtDJFNNicUaFpmOvxvKlPRZGeiojkiaVxtrtNELTmRnovhYa52V83TVhZGZgjaWxtRrNsN+bcpDGWNqLVai5tzawd+SCO9MNj6z4kAI2MJFJ3wKMwABsfD6ZEMO5BvYWC0IAAnieggkNBwuoGQaDehcVKPYhk72GhWLhdErgZeCiy2MN7Fmfp2fjL1C5QqfJ4HrWVuUuT1XVsuP02kzwHVbtzfJ6vjPxwermQu1mQ59z6N0PJ3CHPsfLoT/APkxfye86HkKKjtl+mfxhK+lYdu4I6MXtHD6bcrIxSO1B6jycG5+ts04MhPYzMllS5GZCI52KmJLg+f/AKh4f1+k3cex9B9jznqnE/iOm2x1vhjgfjfrVDpzZrXucw9f62wHi9Rnxrk8gOgAACAAAAAAAAB6VuyK+RC/Dj3ZMF8gH2X9N8HfbJr8H3TCj2URXwfLv06w1DEi9eyPq1EdVo5fZthb3E7Kt8jpnHWxwJQAEADIGSQABkBdDaAZxBOyCBUqkjt2SifBFhyl7dCNclyWyJw0tmnnjtF0qlPtrZ5XrmTpNbO/lXKMJcni+tX9zfJ6Xj5uT0089kS7rJMo9x5y3Jiryezicjz9X9GiyEdshLZopr2x2rzF+NVtnaxKPHBkw6eVwd/Ep8cHN6adXnlbRTpLg6FUdIiFWkWJaOH007cYSxGMxG+Tk9NuvGU7JTEJTMPtpYsQyK0x0xzSLFkSxFUSxG2NMNQ6LIlaLIm+aw1FiRIqZOy+sKZcDJlew2Po4tT2LITu0Q5ka0vOBIpsloaUzPZNHPrboz51XZYZLJj2TXPJhtuSbWzk9NO3x8kW2mKywLbvkx2XfJzWvRx5Jst0Z5Xb8sSy3fuZpzJ47fPxWWW/gzTulsWVnyUWXRXuXnzdmPJd9d+7Id8PdnMvzFHemcu/qclvTNZ5unP8/XcuzYRb+4wX9T1vUjg2Zk5yb5Edjl5ZrPN04/njdd1Ox8bMc8mdnllfan7h2pe5pnDoz4xD55BEkpG2cujPlICdBok2kaTMiNEgBcgv4AAgfCmgDANC+R9IJDROg4i7CLoCRgXwrDjK+h4w2XQqIgtGiJPGN/RH7Ru8GiqT0TxPFm9lkGjHO1RXkrWXr3FxNy66cdCtRZzHna9xf4/5JTcOsoxJnVBxOXHqHyEupca2OFMUubXFb0caxJSOhflfUMEltg6c5QooO1DqOkHuJvnJUhtEpDKImkyXQaH0GgPhNEk6DQHwIkEiQARIABgAAACGSRoZwAADMAADhdToNAmSNP0UCdMlQbGX2VDoaNW/YeNQF9wna2WV18lsKjRGrRUZ69CVwNMYBGOi2IVzb2aEC+C0JFF0ERXHur62dHFfBz4I34/GiLOuL2/x1aGba0Ysc6NURTLyPaG1wUWxNyr4Kra+DL0jztf65U4lbRqshozyRwbPLPMRPkssRV7mXV8RPyVssYjRedI1kjFHaFOnGmOso8CuQzXAvadWdMuJUjRTZyZdFkHplqldmi3SRurt2jiVWaN1VvBG8/jXNdJS2SUVz2aFyjDjeUoylohiSekLvGkXq7XuNG/5MDkyPqND+yuOurC/5L43L8nGjcWxyPkc9GV8uuwrvkthbv3OPHI+S6GR8m2dufXj+usppjLTOdHI+S6OQaTaL5NuloUpjfsfvLm03zPoNC95KkXNIuB2kpaDYNj+i+aAI2ArovhJOxNhvkn6HwdsjQbQvekL6VPOn1ohySKpXJe5nsv+Q61nmttv7V5OVl5mk+Rsm/h8nDzcjh8l+c7RrPIx9Sy9p8nks+3ukzqZ2RvfJ57Jt3Jns+GPx5nupgv5yfyeu6Nb+08fCa7j0XRbfuXJp6Y/HJL+vqPRbP2npovcDxvRbP2nrqHuCPL9pyujFXx4JI8IEznbJRLIQE0AwdUq+pizXwbynIj3VSQZD8vfqjgfSzJS0fKZcSZ9+/VrBWpT17HwO5dtsl8lUEAAEAAAAAAAAGzpce/OrXyYzqdBh39SqX/sgD9K+hMbs6fW9f0o+g0r7DyXoulLp1fH9KPZ1w1E5vWNs1ma+5krgslHkrfBx2NoZSJ2VbJTEFmwFTJGRiUQShkCBhBdOJI0SuSdAKhA0T4I2OTqemg0mU5WRGEHyjNfkdjfJw+odQ+1/cdnjj9Z70TqPUEtrZ5HqGT3yfJbm5rlJ8nHutcn5PW8fNxemg3saJWmWQO3n45v/V0FtnQxq9tGKtco6uHHbRntviOnh0+DuY1etGHBr3rg69UNI4vSu7zi1LSFYzEZwemndiFbEb5InIXZx+ldEh9gmLskx6DpjxZWh4FSpq2JaiqJYjfFY6h0WRK0PFnTmsdQ6GRX3B3l9ZfP6tF2VStKZXfIrpWfNplIpnYkZp38eTNZkfJjvbqx5NU79e5lsyV+THbk/JjsyH+Tl3t2+fg12ZXk5t1+5Pkrsuf5Mlt2kY29dvl5cW2XfJiss+SqzJWyidyafIvl3+fkslbp+Si3JUFtsxZOUoLycXL6i5JpMvOHf5+Lr39QST5OTkdRbfDObLKnLyyrvcvJvjDv8/GRpnlSn7spbcvchLZOjoz5x0zzh0loVoNMlfJXy0mScjJDbQbQ5lUiNEgBcikgBJUTdIJXggn2Lif9BBIDP5QBOiBD5BZCOxEjRUhMtZW11l8YLQsPBZsTnuUa0HfoqnZplM7dCPjY7kkZbshIx2ZGvczTucvcm0cX2ZG3opdj/JXvkCafEux/li9zfuSSiR8hOX5YLub8k8Ep8jhzJvAJk62HaNrnJt7Qa5JSAmt5AkSBIlAgGQJFToNEoko4jQEgBoAlkAQAADgAAA4OhkE6Y8YbGm6Jons2aIVbLo0jZa2yRpbLlQa4VL8F6qX4Gy16OesctjjG1VIuhV8AyvqwrH17DLH+DpKjfsWRx+PAmd9nMVWvYbt0b50a9imVXI0/9us0VyXxiSqtcjIabvqUiyJCHjEmoq2DNtEvBjhE20RfAuOX25x1MaXg6tDOZjR8HVoj4L48f3ao+BLFwXRjwLZHgx9J+PL3/rmXRMclyzfevJhn5Z5vrDyomihrk0yRS1yc1bQgrRZoSQSlYqYrHZWzpxWOoNkAB14rGwrBS0DRGjeJXwno1VWmGJYp6ZVi8V2KbTZC3g4lVpshb8mWstpXS79it7M8bNlils59RrmokiuSLRZIwtb5/VLZH1GhpIokT9N5iVfG7XuWxv8Akw7HU2VPSpvlHSjf8l8Lvk5Kt0WRvLnpWevJ2oW/Jcr1+TixyOPI6yfk0now15O0rl+R1avycWOT8lscn5NZ6MdebsfVQfVRylk/IPJ+S56Inm631UH1UclZXyT/ABXyF9Ff8nTdqIdqOVLK+St5fyZ30OeLryyF+SieR8nMeVv3I+s37h9rnk2zyPkzTyPkolYZrLC5ppPOGysjzycLNv4fJvyLOGcHOt1vk9D+fPXJ7SRzcu3e+Tj3tuTNeTdyznWWJs93wz+PG9xHfcd3pFvbJHBjNHQ6fbqa/uX65/HF39fVOg29zie3xn/LR869NWd04n0XG/8ApR439EdPnWnyiIhHwMcjogQAgZNAFmtxYxEvDFkV8e/VPH7sSx69j81Za7cma+T9UfqXT3dNtevY/LfUFrMs/uXf8DIAAIAAAAAAAAO96Xr7+qV/3RwT1Po2rv6nX/dAH6h9JV9uDUv/AFR6/t0uDzPpiHbhVf7Ueog9ojU6cqiUCicDc4lM4GGvNrnTDKOhN6NM4GeUWjDWG0qO/RCt5EnspbaM7mq/G2Ni0T9RHPd3ait5Wn5F8VNsdiM00K5LZzIZi/I/8SvyHxoux0VNA7IpeTmPLSXkz256Sf3GuPKlbHUsyYr3MWRnqCfJxcjqev6jk5fU20+Ts8/FlrTpZ3VOHqR57L6g575MeTmylvk507nJno+XjI5t6XXXdz8mdyTZXKTZC8ndjHHLqrky6rkpXgtq8mtn4UjfRHbR28KpcHKxY7aPQYNfg5fR0+cdbDh26OjEy0Q0kaoo8/1ru84mRTJ8l8lwUS8nBt24I1sXQ4rOfTaIJQEoz4KlDx8ioaPkIzq6I6ZSmP3GuazsWKQ6mZ3LQrt0azRfLW5x0UzsRlleVSuFdlPK9aJ2/JnnaUyuM9l3yZa9K6/PxXWXceTJZd8lVt3Hkx2XGGvSu7HlF87t+5ROaZnla2yFJsxuq6JiRM2Z7Xxyae3ZjzX2VNlYrXE/XNyr4Q3ycbJ6j27UWZ+p5rjNrZxZZErHydmJHs/zecsa782ye+TI5Sk+SPJKN5mO/wCJEpDJAkMh8bYhkGwILjWp2ySNElAaJ0SgGBonQEjhDQABRDQASVBCkDNBoZ9KSkSkNFciTaeENl0Y6FhwWpoGeqaOyJyaG2kjNbbr3BlVdtnJkstZFtu5FLezG0g22w0QMT0wGiQBcg0ToCQVINDJIjQyQRUgROwJ0Uvg2w2BOhGCUACHQGiQDgAABUgAAA+GGCAnwHANEaJ2CDiaNDKDY0Y7NFdfAcZ2q4Vb9jRClDwgkXxihVjrauNWh1DTLlEntJ6yuiRSRbFbFUS6EQ7WeqmMNl0a2NXA0RghyuXeqSuDNUKdrwNTVs31U7XgqOTfrxgeOmVzxV+Dsfw/HgWWNx4Gx/71wLKNexmlBpnfuxePBzrqNPwDo8/brDFPZdCIKHJfCBNb/cNXE20RXBRCBpqXKDLk99/jpY50qX4Objo6dK8G0eP66bIvgWzwPFcCWeDP0n44r/rDat7MFq0brX5MVp5fsvLPIraLJIrZw2tCsRjMVlRFI0VtFjEZpKmwjITJYp0Y2zsSytsZsrZ140ysPFj7KkxkzeVP+LYz0X13P8mPY0ZhYuV1arvk1RtWjjwtaNEbjHWGudOmponuRgjcWxt2c+8OnGmh8lUo7JU9jHPcOnO1LikGkTPyKHF/XRpEb0BDEae8nvaK/cGwlK56tVrLFazJtjqRc0m+caHfL8hG9vyzO2K3oubR/wA42q75Id5kUmDbFdqnm0fX+Q+ptGbklMntq/iNEZ7Yzm0iiDHlLg2xm1nvkN9R+5XOcTPZd2mG7M17nb5+XXLv1kWZl6inpnnM69vfJdnZu35ORff3e57X83lJl5P9HrbWa+e2zJJ7ZZbLZR7np+c487011bBcm/FajNGGHg0Y0vvX9x+n+Ob/ANfRfTVmpx0fS8GfdSj5V6cn90T6d02W6keN/TG/nXUWkMIMjzv/AF0xIAAzAPwABIHgf1Cp7+k3f7T8odYh2Z1n+4/X/rWj6nSrlr+k/JnqSh1dRtWv6mP/AMDhAACAAAAAAAAD3PoSjuz4PXujw8eZI+l/p5jOWVB69xwP0f6dhrCh/Y79aOT0OHZiwXwdpcE0AVxGAOHKonDZmnUb3HZXKBFw0zpzpVGW6GkdacODn5S1Finl1X242Tb2b5OZbmafku6jZ2tnnMnJab5NM+CL6Ov/AOR17kPq2l5PM2ZbW+TJLMlt8m+P5us76vVWdX+TJb1RteTzryZP+oj6zfubZ/m4n/q6d2c5e5isyW/codmymyR0Y8OI16Gsu2V92ytsaPg6s+fGOtJbGj5ILIo2mWNpk+C6nyUe5fUZ6VHXxGuD0eA1weVx7NNHoOn270cvo6fN6ar9qNMUZMaXdFG2KPP9I7fMsvBRPyaZLgzz8nFuO3FVisZiNnNuN8p2Auw2ZK4sTJTK9kpiTYt2T3FEp6E+oOUfC+UyidhErODNZYP7VPNZKz5KZ2lE7de5nncZa9HVjwaZ3fJlsuKJ2tlMptmd23z58PZbsq3sTlsshBszumsnEKGyyNZdGsdQF0/pWoGDqsNY7Z1ewwdX0sRm3meNf/qPmPVpfz2jDUtmvq7/APlMyU+Ds830H8s/FzWkCXJJKR0x3WJSGSISGQNMJI0SSVGlRonRKQaGQJABgEkIkcIAAFEAAhsqHEgLslMZU6Q0fIiLK/IItOh0w7RtaQmdVWT0jDdZvZovloxSe2TamkfJGifckypI0SACVEokEidAuDQyQEgqAZEaGSBURonRIaGpGiSQAIJAAAJAAAAkC4EASAGglkMAIDRW2QkWwjyCLVtceC+ERK0XxQMdVMUWxIih0ibWGqZErySkToisrTpFkEVJMughI00QRfFFNZoiOOT0rZjLhHTpitHLplrR0aJmkeb7aa1DZP0vgspXcalT9pTg168rmW08Pg5eVRrfB6KdRzcunh8A38vZ5yVemWQRddXpsqXDIrvnp2Loo00w20UVrZuoh4Hn/WHtr8bMeHg6dMTHRE318G0eX6VoS4Kbn9rLHLSM10+GZen+OW/6yWPyZLDRJlMuTyfatMs0kVSRqlEqlE8/V/WijQrRd2iNFZpKJIrZfJFUkXNEqaFZa0JJG+KmxUxWh2Ro7MaZWEJUtA0VSZ05rOrXIFIo7g7jVPWqMy2MzEpjqzkXz1U03KwuhYc9WDxtIvm1z6OnG0tVpy43FivM74tp6ui5dwIxwv4LVcjHXk3z6NGiO0rVqGViMr51rPRLiK0S5kd2yLitJsjiQWMrb0HzVdhhZeSO8O4LmiWDYdwkppFf1BTFVdSL+4jvKHaiqV6SOjz8rWO/WRu+okJO9a8nLszEvcy2Z3yej4+Dz/b3bMrJ0nycXJy+XyJk5m98nLtucn5PT8/53nenua+5zfkyTmyZTK3yeh5+fI4t+nSt7YdoLyPv7TqzHLvSvu1waMZ/ejJP9xoof3In0n4yj3fp6epxPqHSZ7qifJOg2anHk+odGs3XE8f+iOnD0q8Eiwe0MeXf9dM/wAADMAAAHF9RUfW6fatf0n5R9dYf0OoWPXuz9d9Tr+pizXwfmT9T8L6WTKWvdjhPlLAmXkgRgAAAAAAB6luxI+xfpvi/fCWj5Bird8V8n3j9N8b+VB6HA+3dLhrHjr8HRezJ0+PbjxXwbNk0ACPckZAGgAXTV2Lg5ObNKLOra9I4OdLybYhXTznVJeWjyuVZyz0nU5fazyeZL7mdnnjrDW2O6Zkc9sstkUa5OvHmx1tYmye9or3ohs2+Ij7O7GL3P3FXIzQ5B9obJTFGiUXTcjRk0SlsO0OhZF8mitmVPRfUzLS42VvTR2un3JNHDizfhz00c23Rh7jAtUkjqQ5PN9Nt21yeix5bSOL0jt8zzXBmn5Nk1wY58M495deaRlTfI7ZW/Jy+mXRio2R3AxGYcbH7w70UtkORNhyLJT2VOehZSKZyM7WucLZXIonamVTmUykRdNs+abJGacxpzKZPZhrTqznkQ5BrYKGy6NZHStVwhtmqFegrr0y9RCVndIURlEZIGXGd0jSOR1naxmdZs5PWpf8AxGb+TXx/dR8w6pzlMz1JaL+pc5LKa0d3m+n/AJZ+H0MkwJR0R22JQyFGQNMJACSoqpQAvBIyQBIDCCQBDhACSGUSNkMloEMI0SMR7lFamKbLYQaexYGiK2HGVqE9DSlwyHEhrgmpYsjbZl8M2XmNmdoK/IEkozHEaJSJJQHIn2ACQaQDaIQwKgGRBIKBJBIBJDJIYwAQAhhJJCJAI9ydkAXAnYbIAAHyQkT4DYJtPEugiiJogDO1fAviUQRfFcCrHSxFkUVxLYkVhqnSGSBEkVl0ySLIlaY6Emr4sui2Z4miBUcu2mts347e0c+DN2O+UXHne2XbxV42dKKTicrGl4OlXLg0jyPX8qLIHOyq9pnVfKMeTHhlcV46/XmsmvTZi1pnTzFrZyrJ6bMtPX8p2NNUkvJ0KJJ6OGr9e50MS9OPkWb+q9fP8d6ho2wfByKL1+TfC9a8m0rzPTzrTJ8GW3ehnbsrnLaMvRy3zUMRos0K0eV7RUyrZVJFskI0cOsnVTQjRa0I0KQKZIqkuS+SKpeRwcVNCSRayuRrmlYpaI8DyK2dWNM7CyZU+R5FbZ1Y0y1ENCsHIrcjommXDpk7Ke4HPg2ymr/qEqwy94d5pMl1tjaOrUYFMdTH8KmnQjcWRuOcrNDK1mevJpPXjqRuHVpzY2MsVrM74tc+zo/VJVyOerWN3kXwaz2b/rRK5WoyfUElZ8i/+dX/AHanckQ70YZWfJVO7XuVn+bpX+jjbO/5KZZGvcwTyX+TPPJf5N8/yMb/AFOjPK+TPZl8Pk508h/kone2dPn/ADOff9PWq3K88mSd7b8lE7Cnv5O7z8eOP09urLZyfuZ9vfI058FDnydmcccutdNN7fA0VwVd3I6kayMrRLgXuCcivfJtGWjtb5LaGnJFK8FmP+8y9Ex63osu2cT6b0OxOET5d0h/dE+j9Dl9sTyP6HTh7Wp7iWGeiW4mhHl6n66YAJAk0ASQAVZEe6qS+D4B+reD/LckvyfoOxbgz4z+q9G8OT1+S4T812LU2hC7KWr5L5KSTAAAAAAAGrp8e7Lgvk/Rv6cY6WJW9H526THuzq18n6Z/Tyrtw6+BwPqGLHVS/sXiUrUF/YsJoQAAA4AJIAKrlwzgZ68nfueos89ny8nR5Rlp5fqX7WeTy/3Hqepz4Z5PLn9zPS8subdYLVyVFlkirZ1ycY2hojtGQ6RSSJDMlrQqYi6VgmEmQJUXxY++DOmN3iaQ++S6tmdMthLkinGyLNWPLTMUGaqjn26MPR9Mv1I9VhWqSR4XBt7Znqen5G9cnJuOzD0L5iZLVyX1z7oldkdnJqOrNZGK0PNaYjOb0jpxSSK5MeTKpMwsbykbFbBsVmeo1yWTKJyLZszWM59OnEVykVSkE2Vt7MNV1ZyWT5BLYaHijKnVlcNmiMBK0XIXGGqlLQyFTGQ5GNOKydiSkaSFIVnH61//AJWdaUjj9Zmv4ZnR5Orwn/6j5r1Ff/JKay7qD3klVfg7PN9R/LPw5KDRKR0R2VJKAAVlJOiBi4qgkgkZAAACDIJDRUAJII2USSCdkMYSMkIWRQ4jR4IviVpDbKZVZsWXhkJhL9rM9FGLIfJkfk03vkzGOlAA0SSYQxCGBUCJ0CGBUQSBILgJIJFQPckgkAkhkkMcABACKgSSQiSggAAqEAAACH4IQxKiCKaKNFaK4RNEIgy1VsVwWxEiixInTK08UWRK4lqM6x0dDCpkkVmZFiK4lsUCdLIl8CmKLorgcc+401+DZT5RirejVTLlGkcftPx2MZ+Dq08o42LLwdeiXCNsvB/o/K0taiYsl8M2t7iYsiPDKpeF/Xn85+ThXy5Z3s+Pk89k8NmOnvfzz8U9/JqovcVowOXI8JGXXbrz7Hcoyn+ToVZO9cnnqp6N1V2vc0zpxeng70Ld+5cmmjkVZHya68jYbcOvJr0HaVqzZYpbOD1yyuOElEqcDU1srcTluGOozOIkomlxK5RMrlLLJFUkapRKZRJ4fGdoSSNDiVSiOFYzyRW0XyiVyRrmosZ5IRotkiuXg6MaZ6imSKpFk2VNnVnTKwjFbGYjOjGmdiCUQMjozU8SixCpDpGsHEpbLIxIih4xGimSGBIhhwSp2HcIxWypiH9LHYVSsElIpnM0nkV9FkrSmdmytzKZzNc+cjPXpaLJmeUwnMokzbOYxuqaUiqTBsrkzfOIy1qonIq3yROYilyazKLVkvBS/I7lwI3yURXwxkyHySOVNgYuuRidGkrOwIvoWpIpRbVLUjL0pSPTdJ/dE+i9EelE+b9Kn96PoPRrOInl+7bD3GM9wNaOfhz3FHQXg8zc/XREgAGagQABAJftZ8q/VOju6dJ69mfVn4PnH6mV93S5/wBmVCflDOWsqf8AczGzqa1mWL5MYjAAAAAAAHT6HHu6jWvk/UXoOrtw6+PY/MPp5b6nV/uR+pvQy1h1/wBh/wDge+g9RRYVJcIsJAACCjSAAImfI/azznUH5PRZH7TzfU3pM6fJlt5Xqb4Z5PKf3M9H1Kx7aPN5LW2ep5Vy7YbHyLvgmb5FOrrGjuLIyK+1DJaESzYjeiUS4oXS4q2Shu1EeAVDJAyNsNi6uUbHhLkraGgZ1cbKpbN1Zzq3o1VWMw3G2HSx5akeh6fa9rk81Q+TrYlzjJaZy7jrxXs8ae4o1tbRx+n3dyW2duLi4HNrLpzpgtWjO2bL0jG1yc/pl0Y0rkxJFriL2bMfhvnTOxJGt1opnBIz15unFZJsy2M03NIwW2I5PTPHb5zpZsr2Vys2xo8nHquqT8WrwPEVaHjojrPVXQLUVRaRapIOsdGiuRyvuRDsKiPk8nopnMSdpktv+S41x52rp2HE61d/8d8mmzIfPJxerXd1L5OjynXd4eHa8dlz7sgatcC3JOzZMW0dmPx73hPlYSmIyxJaN5XT3oJIJQ15AyFDZUM4EIkZACAGDLyS0KmDbKhcDFJZAyGySEMtDBV5L4CJIsS14KiNLV4J1yImx0NjTRiE48MmLeybP2sjRRy8jyZzRc05FWkY6yvpQJ0TohUQhkQkMgXIleRhUMgVIAJ0GgNBIaAODoJI0SHyEkMAHwAAJKkARJAFAASlsNICQAAM+JXLLYxKl5Lo7HxGosgjRFFMUWx2T1hpah0JEsiibesdU8SxFaRYkTYytMiUCRKXJnYg8UXRRUixMEaq6KLYlEWXRY2Ol0TVSuUZYcmyleCpXH7X8dPFXg61CekcnGfg6+O+Eb5rwf6M/rT/AEme/wAM0rwZ8haiy2Xj+Vwc+Pk83lx5Z6LOb5PP5XlmWnv/AMtc5rkmL1wEvInuY2PXzPxqhM0wmc+Mi+E2PP4z9MddGFj/ACaqrHtcnMhYy+uxplWuPfi7MLPBprmciF645NVd/wAmOsdcm/F01IkyQv8AksVvyZXycuvGrtbFlEmEtosSTMdeNYXHGSSKZRN0oIplWjHXlU8Y2iuSNc4LRnlFmVxYTNJFUkaZQKZRDvE2M0kVSXBolERxWuTTGv1Nyw2Ir7TZOCKZRSOrO2dypceCpx5NLTI7OToxtncqewlQNCrGjWdWds7FKgWKBfGsdVo2miUKKQ8Uh3Xz4GUC5UWE4FlotcdIpkXE0kmVSY8nwZ5SZtmItRORnnIaciiTOjMZWolIpnPRMmUWSNPnqOiUytyFkytyKmKV1DykiqUhZSKnI2zGdLMVeR3pkaRrIhPsL7jBofAhADeiNi+RUkibDbKjOw+xq/3FPJbU/uWyNzsKR6LpL+9H0Hoz4ieB6V27R7rpEuY6PN9stMvcYP7UdVeEcrp7/lo6kXweX6f63yYCAMuLAEgIIPA/qNHfSZ/2Z772PD+v493SrP8Aay4T8j9WWs+z+5hOj1la6jb/ALmc4VMAAAAAAAdr02t9Uq/3I/U/omOsKv8Asflr0x/+pV/uR+qfRa/+FX/YA9svCHEXhDgAyCWQMzIhgAiZcp8Hm+p/tZ6PK8HnOpftZ0eTLTxPVHps8zkz5Z6Tqr5Z5bJ/cel5ObTPJ7ZKYpKZ1xjViAhABGTG2VjIQSxSWyAMEkDCOIZMBZMIsmtI0xZfVLkxqRdXPkx02y6tLOhjy1JHIosN1Numc246MPVdPt1rk9DRZuPk8bhZGtHoMXK2kc2nRmunZHuRllD7jRC1SRDjt7MdRtms0oi6NMocFTgRxtnSuXgzW8I1yjwY8jaRnqOrz05eVPWzl2T2zoZKb2YJVtvwcXrl3+e1S5ZorEVTRbGLRwby65v8MMnolQeg7SPllq/qVPQ31Sppork2ifkmn63yLK4y9zQkrGVI1znq2y4xW3EWTZlslsuOrGEWWvk43VLX9JnSl7nJ6kv5bOnxeh/Pn9efk9yLIIRx0xovk649LMPJDJ8ES8AjXLWQxJAFyLSSQiRl9JRIpJUHUkAAyukkADKkL6QBADkHUgBOuCpDkTFmiC2UQXJrrXA0bSoEpclnsLH9wrWNo1yLc9RZY/JVf+1kWlHLtf3MQez9zI9ibVyIQEkGVaRKGQqGQlxJKD2BApKJIRIEGAMBwgAAUYAAAJAAKAAAADYbIAC6kkUZMo+miuS+KKIvkthIbPVaIotSKoMuiRXPqmii6KEii1EsLUpFqQiY6FWdMkToESRUVKQ6FSHRKKZF0SlFsQZ1prNlXBjrNdY44/aOjjvlHYxnwji4/lHZxvCNsvG942rwZsn9rNK8GXJ/azVz4/1wM73PP5Plnfzvc4GT5Znp7f8AIwT8lbLJ+RGjOvaz/iEy2MiklMQrXGZdGZjjItjIGeo1xmzRXYzCpFsJ6Bzby6ldhfGZzK7tF8bwc+sOnCzRohZs5cLtmqqwmxx+nn+t29oVxFjLaLYrZlrDn1jimUNoolWdD6exJ08HPrzYWOXOJnmjpWVGadRjfNPWFxKpxNzqK51CmeUdYJRYjrbNzrF+nyaxNY1SMqfg2Ksb6fBtms6yRp37Fqo+DRCHJeq+DpxWVjB9LQyrNUqwjWdGazsZXWQ4mucCicdG+ais8jNM02GS1muUVVKRnmNORTZPg6MRnVNktFEpk2zM8pnTmM6aUjPZLklzKZy2bSM6WUhHIiTK2y4hMpFbfIzEZUJPcGxNkpmkI+yRExkyoCzfIuyZ8kaAjIZIVEpgim0THiSF2NDmSFonf6VN9yPe9Ge3E8F0xco910aWpRPN915e/wCnr+Wjpw8HM6a91I6i8Hkel/W2UgAGbRKAEAghnjPXi30m3/az2Z4/11/+Vb/tZUD8h9cWupW/7jmnU69/+nb/ALjlioAAAAAAAHc9Mf8A6lX+5H6q9F//AOGv+x+VfTH/AOpV/uR+qvRj/wDhV/2AParwhxF4TGT2ASyCSACQAGAZMr9p5nqctRZ6XL5ieW6rvtkdHkjTxfVJbkzzOR+49D1Pak9nnL5LuPS8nNqM7ehVLkJsVJnXGNi+LGEiPsEpJI7kG0xHwAACNKJFQ6A+FaISLNcEa5JqoUsg+RdDQXJjprlrplo2Vz5OenpF9djObboy7eNbrXJ2sXI8cnl6bte508bI8cnPpvK9ZTftLk3QsTSPOUZHC5OlVkLS5Mq0ldbaYdiMleTH8mmN0Sa0zUWV8GK+vaN07Y6Mds0zLVdONOZbj79ij+FX4OhOSZVI5PR1Y2xPHX4BY/waJPkmMkvJyay6J6KPo6IdJq3Fg0tE/CpthnUZp1nSmkZ7IE3LXNc6UCmcTbOJktaRPy6/OMdhnmX2TTM02Pju84rl4OT1D9jOrJ8HKz65yi9G/k6/L8rhSQsfI9kXDyJGS2dUduNxc/BKIb2loEax05vTAAFxQRJBI0XIAgB9VxIEbJLiLAAeA8lyI4gA0A1yJJS2HktrrbFaW9fMNVXs2118E0U8eDbCr4JunLv2ZXW9Cqp9x0VRv2J/hm/Yi6c19o5zreym+D7WdZ4st+Cm/Dm4vSF08+0eYtWpMXfBsysWdcntGRr2E68a6EAeEBLaJGQqGTBcSCD2BApKJIROwIMABBCAABRgAAAkAAoAADYAEE7RDaGXEEkE6Yxw0fJdFFNf7jVHQdZ6WxLYlSaHUkTWGo0RY6KIsvhyhMdRYiyJWixEVlTIZCoZEVFOh14EQyJRUryWxK0ixDRWipm2ow1m2n2HHL6z8dHHXKOxjcJHIx/Y61DWkbZeN/RG1Pgz5K4ZdForyNdrNHJj/Xnc5eTg5K5Z6HO9zhZEeWRp7f8AK5so8idvBdPgq7kZV7Ob+K2tCljexNCUaJbFlcR0BWLkx0UxZZGQMtZXxY3c0UqZPdsGdw2VWGuu05kJaNFcy5HPvzdeq021S2caqw6WPPY/lw+uOOjHlBKPAVcmjsTRnrzef6fjnWQM06zrTqRnnUjHXmx65biI4bOhKn4K3V8GOscEYXWL9M2ul/gFS/wRw6yKob6XBsVPwP8ATRWaisUatexb2Gj6ZHadGKzrLKAutGiaSM05JM6c1nSyaMtskWTnwY7pnThlpXZJGS2aHsmYrrToxGdV2zMs7CbJ7Ms5nXjLOosmUSkE7EUymjpzGdEpiOWyJPYm9GnEUSZXsmTEGk+xWRsO4qEgknQaKhAADZRBgQGmAAASkCKgtrX3IrXDL4abWha/xLudM8o9t0ffdE8T0z9yPd9GS3HZ5vu0y930vf0kddeDl9NS+ktHUXg8n0/1tlIABmtKAgkQQeP9c/8A5Vv+1nsGeP8AXT10q3/ayoH5F69/+nb/ALjlnU67/wDp2/7jlioAAAAAAAHc9Mv/APtKv9yP1T6Le8Gv+x+U/Tb11Sr/AHI/VXol7wK/7DD3K/YRDyTH9gRQgdkEsgACH4G9hX4CBkynqJ5Tqkv3HrMpbizyXVVruOnyTp4rqr25HmbluR6TqnlnnLn9x6Pk59RmmgTFtlyRF7R1xjYuTJ2VoYEpbJi+RQTEazYbF2CYj4sTGQiHQj4sXgGCfBJFq5EJFkUKkWJGOq0zExWyyMSI8FsTm3W+YaPDNVFumZkiyC5OfVbSOxTk6S5NsMx68nDrbL4zZla0kdyvMf5NleZx5POQta9zVXf8mV21zl3Hlb9yuV+/c50bt+431DDW2+Y2/V+SO/ZkVg8ZnPrTaNHkjQsZDpmdq5pMY8ljXBERpPgFzaibM1ki+wyWkWOnz0z2zOdkT3s2W+5zr/cnj0PKs7kVzkS2Vy5Dj0MUjlyO6FbDkTs2zdStRRrhprXHIv6RGe3o5t3SnX+2J7BafGiJY0bPZHRE5/os/wBeCsotg/2ixU0/uR7W7pMZeyOZl9I1H7Uax1+f9ea8+2kCezXZ0+cf6WZ3VKt+CuuzPvKjRHgfuFfI+tZuVBOiNBsqL6nSI8Eok0hcRvZG9DaEkX1NTvZDeiF4Fb2ybUXXF1e2zpY9W9cGbDoc2uDvY2LpLgy3vjk/o9fxFND14NddD/Boqx9LwaoU69jC+jyfT2ZoY/Hguhj7fg2QqRaodvOhfbkvteufPH0/BTZXqL4OnPn2Ml7Siy86befpa8t1Ot88HAlFqbPS9TsWmebun97NI9jxt4VkAntADtyEMhUMhLiSSCdgsIkgkZJAgAIxIqJGYIJYoBIEbDZQSBGw2AD8gBO+AHUb0NF7K2xoJ7Fam6XRhzsvihals0RgLrLWkJDJDqBKiHWV0mKL4cIqSLIhay1ViHTK0OiKxqxMdMrQyIqKsTHRUixEoqxFiQkSxDRVlb0bKXyjHBGuleBxzev+Orj+x1aF4OTjex1sd+DbLxv6GyK4Kb39rL48xM+RF9rNXHm/rhZz8nFua2zsZyfJw7t7Znp7H8umS5JmftNEyvRk9nF/FTiGh2iNCXKhIZAhkM+hDIEAJqR0ysZCKrUy6DKEWwZcrLUbKnydTGfg5NT5Ori+xrl5vu7FPg1wjwZKDdHhFWPJ9L+knHgodfJpmytPkx3GCiVOxHTr2Nmk0K4nNuGx/S+AVRr7A7DGwusv0xXA1yjopkhJtUNFcuC6fBmnI2wiqbXwYrZGi2fBz7rOTqwhXbZow22j32HPtsOzzjHRrbTn3W8j2WGG2fJ14yiplbwZp2bIlLgzyZ14jK1MpbK2yHIjZ0SM6HIRyJaEaKQnuDYoDCQ1yRsnYEZEvwQidlEVgiGwGQY68CMlMAGMvAobCIqH5LqXyU+5dSuRaS73Sn96PddIfMTw3So/ej3fSI8xPN92mXvelv8AkI6kTmdLj/JR1EtHlb/1rkIkhEmbQAACJB43149dJt/2s9meI/UCWuk2f7WVA/JfXHvqVv8AuOYdHrT31G3/AHHOFQAAAAAAAOt0B66lV/uR+qfQ0t9Pr/sflLoktdRq/wByP1P6CsT6dX/YA+hw/YhkJU/sQ4BLIJZABPsK/BJD8BAyZb1FnlOqvfcery+YnlupR4kdHkmvC9V/qPMXP7j1HWFruPJXz1M9LyYaVWcsmIjlslM64xq5DoqTHTAjEBsgQSMhUPERnSHSIih0hGEMkCRZGJjqtZBFFiRMYliiY7rXMIol0IhGJdCJy7rbMQkMkP2DKs59VrImDLUgjUOtJ6Md1tiISZZFtAkhuDn1pvmLISZdGTZTDRdE5tabSLEy2LKkWRMbpfF0WWJlcSxIOlVsCxrgK4cF3ZwWia/WOcDPZWdKVZTZBaFXZ5VxcivSOVfF8nor6u5eDnXY+/Yl6PlpwJporbOrZi/Bjso17FSO/GlMWaqnvgzKOhqp9thUXu/joKt+Roy7RI3R7QUlJ8Gma5tarUpKS8EKqM3ykRFaQdz3wazTH7sVX9PhNPUUcfL6O3tpHoYT/Jbqua8Gnetsf0ay+f39MnW35MkqpQfOz6DfhQsT1E5OR0je2og7vP8Ar68n3Jewu0zrZHTJxk+Dn248qzWPR8/aWKkgfAvdryDls0jpzuUbEkyWyth0taT3FlVTnJCVR7pI7vT8Pv1wZ604fX040dOxdJcHdppS9iujHUIrg31QOX108329emrr0vBaoDwjwWKJzfbzvTSIRLFHY0IDSg9cDmnN9frNbFRTOLnXqKZ1siE3FnCzMaybZviu/wDnv68/nXd7ZyLI7Z6C7p1j3wczIwpw3wdOXueFjAlpANKLi9MUbsliUSKMmDSJAABQJIAAkkgAIyDZBIzDIAgYGw2ADA2AABWobJSbHhX3GynG37E2sNbkZoUuXsaIYxuhja9i2NS/BFrLXrGGNLiy+KNX0trwSqfgn6Y31UKGxlWaFV8Ddmhys76KY1EuGmaIoWS5K6U31UojJDJDJCp2oSJ0MkTozqKVIsQqQyEirYliKojpgitFZrq8ox1vg11MqOb1/wAdLH9jrY/scnH9jrY68G2Xi/0N1YXRTixq1wNODaNHBL+vPZ9fk8/kQ02eszadpnn8rHe3wZ6ev/LqOHYIuTVdSylQ0jKvZxr8UtCMuaEaBtKRDINEpcgfTpE6BIYC6TQyRKQ6QJtQkWQF1yPFEd/Wer+NNPk62IuUcmnydjDXKOjFeZ/RXYx14NqXBko4RocuDb/x5Pp/pbWUKXIXTKYz+4x2zkbIvgsS2Z4S4NFb4Oeq1PwygHZwOhiLGNrLNcGafDNdrRiskZ8TaqtkYbbDRdLg510zXCarts4OdfZyaLZ8HNyJ8s6cRNUXW+TBbaX2S3swWtnoeU/GWiWWmO2zksm2ZLG9nXiM6lz2VzZCCS2deWdUSlyCkTKO2CgaM6ZMhrYa0GxxCGhWNsCgRke4+iO0YMvBLFRLAkNkIGCGQZGyWJvkAtXgVsleBJPkcRTJl9D+4zxNGOvuJ1/iXo+kr70e96TH9p4fo0NzR7/pUOInne7TL2nTOKToowdOjqk3o8nX+tchEkIkhYAAEQZ4L9RZ66VZ/ZnvJHz39SJa6VP+zKgflPq73n2f3MBt6o951n9zEKgAAAAAAAbely7c6t/J+m/09yO7p1Z+YMF9uVB/J+jv03u7sCC2MPsGNLdSZcnsz4n/ANKL4k0HIJICAAADDNlJdp5bqekmeqyluJ5TqiaUjXzpV4brPPcePyI/eew6v/UeTv8A3HpeNZVjktAhpshHbP8AGWodMdMq2TsEcXbRK0U9w8ZCJah0VpliEcOmye5kJDaEuRZB7NEEjPDyaYGGm0ixIsihEWwRz7aZhox2XRiFcS+MTj3W+YhRHjAZRHjE5taayJjEPpreyyMRu0x1ppCKAyrLFEsjE5t6a5VxrG7Wi5RQSjwc2tN4SKLUiIxLFEz6rqYGuuCZRCPJrqXguM9VojBKI2iYrgl6RqyxLdK5aSMl1iRbfZpPk4+XlduybXp+OOr52x/JmnZFs5V+fKLejL/5GbkHXdnHHZmotGG6CezK+oS0VPNlIqOrzlRdFx8GZz7XsusvbRnsW1s2xOuzOeh5fb7jV9RinzI5eTtb0cyy6cX7mvyr/j17enqNUlzI1Qvqn+18nz6vNsi/c6GL1WdUtscZa/ln+vZ7bfBfXwuThYnVVZrckdSvKjJfuBzb8rG1zF+1+RISjL3JlH8D/XPZqVTdi1z9jmZXTYST4Owtizin5KmnT5euo8ZldOcW9ROZbTKt+D3V2NGSfg4fUMFaeivqvR8v6OvMOxJ6YL7npD5OLKM3pM1YGHKbW0ybut9ev4twsWUpJtHqMDG7EuCvCwFFLg7NNKikYa3Xne/qeFfCLVDSLIQ4GcTn3q15+tki2aK1sqUeTRWiIx1VqjpBrb0MlwTFfcbZc+qy3QMUqVJ8nVthsyThpmkXj0sYZ4kGvBz8np1ct8HZkyiaTK+69Dy9tT/14/M6S+5uMTkX4dlcv2n0KdUJR09HPv6bCzfBc1Xd5/1X/wBeF+m15RD4PT5HRly0jj5PT5Vt6iypp3eX9ErAuRu1kShOt/tJjY35LldufWUa0TtEvTK2mXKvqfPglIhcDb2KnkEbAAh6RslEE7NUShgte4eRXvfBFvDt4mXwX0USm+UPi47sfKO3jYK0uDHW3H6+3GWjD48G+nE17G6rF17G2rH+Dn16V5np/ReufHE37DrD+Drwx1+C5YyfsRd1za/priRxH+CxYnwdpYq/A6xV+BfdZX+muJ/B/BXLE17HoP4Zfgrlir8FTdKf0PPvHa9hHVryjuyxF+DHdj6fgubrXHs5MoaBI1WU69jO4NMv6dOfTpWRvkbQjXJXW0/TbJUhGCYqfF6Y2yqLLCes60VPaNVZhrlrg3Uveglc3pHQx5Pg7OLLwcal60dTGn4N81439MdmrwWS8GaiTejVraNuvI1eViur7jmZGKmnwdycTFfFaJrs8PSvL5WOlvSOTdHtZ6TMS5ODkr7jLT3f592sMmxdDyXIaId0qp+SUTJAhtIZMZCIeIyp0hgSHSBnaIra5GS5BcDRW2Ln6x3fxpx4bZ2cSGtHMxocnbxYcI2w8z303VLgtlrtFitRFm/tZrXnX9rDlWNeDNC59w2ZLRgjb95z7rXGHZhbwa6bNo49dm0bsafBz2q3j8dOL2WpbMtcjRBhL1x6hLoLtOXkfbs61vMTmZUeGPjJyb7WtnNtue2a8ltbOXbLlmmYfIS216MNk9vkttlwYrJcnZ5yI0S1/gxWmmT2Z5nVn8YVlmtmacTXJFMkb5qKyNaYsmy9w5FlA6c6Z1n2yUM4gkb5rOwrRGh9EdpfU8Jogs7SO0OjhOSdMbRL8DSqDZLIGVQSkGiUNI1tCuOh0RIX/oV9zRHLG0SomsRUJF9Uu2S0V6GrT71/cj0/wo9f0PmcT6L0mC1E+edAj98T6V0iv7Ynk/0Vrl6jCWq9G0zYsdQNJ5mv9awAAEVQAACEWXg+Yfqlf9Ppkkn7M+nWvUWz47+q+T/8Fx3+SoH5vz5d2VN/JmL8p7vk/koEAAAAAAABbjvtui/k+9/pll//AB4R2fAYPUkz7B+meVqcI79xwP0jgy3Sv7Gs5nS591Ef7HSRNBiCSAgAAAwquW4nl+rR4kept/aeb6pHaZpgq+edZWu48hkvUj2XW1ruPE5UvvPQ8azsZbJcjxlwVSewTO+M7F2xkVJlkWCOH0SloEyWxFw6ZbFlES2LEci+IxUmOmKrkWx8miBniXxMtNYuT5L4GZMurZzbaZa4PRdGRmiy2BxejbLVFlsUUQNEGce62i2MR1AiJdHWjm3prIRQHUR1odROfWmkhEhlHZYoDqBhqtYrjAsjAZRLYxFDpYQNMI6CEC1RNcxCVwiuyekWPwZbnpGjbyx+smVbwzh5UnJs6WTLyc21bZna9TyzyOZZW5NlP8O9nTVXcxv4Z7CV0yOTKhpFcans7E8Z68FDx9expmN/OxzrI9qMs70uDblx7Ys4N1jVjWzp849PwzNLbrFLZz7Umy9z2iibNuOyeSnSTInFyWkyXsIvtfIcF8YsotnS19zOrR1Nx1tnFk9vgaO0vIcYb8JXrcbq64TZ2cfNhYlyj519acXwzZj9VnU1uQccXr/J19BdkW/KK5M81jdYUktyOpT1CE15I/8AXHfG5rXNnPyuV4NqtjNFN0FJD6vPY4TxlbY1o6mFgKGuCK6dW70djFr4XBF0N+tkPVT2rwXxgXwr4LlUjDdcO/VVHgGTYtCowtc910LyWwZWMglTWhSLIvkzxZdHya5rHR5LZRZAtctFNlqRrFYjLZDRmki66+KMNmVFMb0PPN4dxe9gpa8hC6M4kuvu5QdGuyh9s14RjyMGNi8I1KEosffHI5o8+1y85k9G709I5OR0iVe9JnuIqMpaaFuxIWL9pc07PP8ArsfOZ0yrfKYRf5R7DL6QpbaicPJ6XODekX9PS8v6pXLcUxXwWWUzrfJUypeuzPtKCNkNiNmsO76fZHcVuRHdt6C6Tdroz50bcbHdrXBmxcaVkkem6fguKW0Y725vX25E4eD26ejs0Y+kuCyjGSS4N1dGvY5dejyPb+jqmvHNNdGi2EEi1JGF28/ft+ljVoujWiEWRZP059eqY1obsQ0Rmhysv+qvtRDr37FqRYobRU0c9GGdXwZbaN+x1ZVlEqtl502x68cS7H+DBbTr2PRW0bT4OdkUa3waTTt8vbriSjplbRrur02Z3HkqaehjXVLRCLZRK9chdNfo8C5IStGiMSbWO9CuHJvpgZ4RNlMQlcfp6Rqqj4OljQ5Rjorb0dXFqa0dGK8n+jfW+ivg1JcCUx1E0KPBtK8nX+s1i4OfkeGdK56Ry8ma0xWurwjh5r8nFu8nay5J7OLkNbMrXu/zRll5I0EnyCE9GEa5BIZoEgX0KIyRKJKK1MSxCItigZ2pS2XV18iwRpqjyEYel/GvGr5R1qFrRgx4nQr4Rtl5PvpsT4KrpaiwT0Z8qzUWVXLP2uVn363ycyF+7A6jc9vkw0SbsOfddfnl6Cie0jo0SORjP7UdTGe9HLqq9Z/+XTqezXAyUo2VorNeds0luJgyofYzp9u0ZcmvdbNI57Xk8uOtnGuemz0GdDWzz2QmpM0yOstj4MVnk1z5M1keTs80arOyuUS/sYfT2dMZVilEqcDfKor+ka5qaxfSFlX8HQ+jwJ9L4Ns1nXNlUVuGjqSo+CidOjaaRWJRJUTR9MWUNGs0lRKJW0aHFiOJXSUNEMu7CHDgrqao0Q0O0KyklAGAyTsVsliiIbGTEDZrE1apFtTTmv7mXZZS33r+5l6X8KPdeno7nE+mdJh9kT5r6bTc4n1LpEPsieT/AEVrl3qVqJamLBaiMjzL/rWJAgkDAAAiUZU+2qT+D4J+q2butx3+T7h1S36eNN/B+bf1MzfqXSjv3ZcD5Tc92NlZMnuTIJAAAAAAAAF5PpP6dZary4R37nzY9f6JyHX1Ktb90OB+tOiT78WD+DtdyR5r0zZ34Vb+Eeja3oVCxPZALhAIAAAYLNbicHqkPtZ334Zw+qL7WXn/AEPnHX48SPAZm1Yz6H11fuPn/UFqxnf41FjDtsZMSMuSd8nfKzsWpjoqiy1MaeLEydipg2IuLFIsiyiJZFiORoTGTKUxu4S5GuEkXRkjFGRfCRFVGlMugzKpFsZmG40y3VtMvi0jFVPTL1M4fSNstsJIvgzDCZohYcHpG0bYyLFIyxnsvgzk9G2V8WXxZniy6LOfTWNESxIpgy2LMao6iWRQiY6Y8hfFFngrg+BpS4N4XBJrRjvfDL5TMl8+GOuvyjmZL5MMk2zZkPbMvuZWvRxfwVxaZd265IgtlzjuApV/SiS2jNb9qezZrSMeX9sWzow2872uF1O7sizzVtjlY2dPq+QpbWzjJ7Orzj2v5VneyO5shck6Ojj0YgnSAELi0qKFlv2GAfE2RWo/klxiMxWLjO4hY2ThLg2U5tkNcmPXIcmVjn1/PK7lHVdfukb4dVrkuZHkXJpjQua9ybHL6eHHtMbKrts0md/E00tHgul5H85cnten3bS5M9PM9s2O1GL0WJaK4WcD92zDTyvS1XYtlO0uC22WkZ97ZnUeX7VhIqYbCR0XK2LLoySM8WWrk0yyuUXWaTOZfe/Zm25cHLv4ZtmNvLH6x5F89Pk5ORmSi3tnRyHwzgZvuaSPW8fLsdLE6rBNKUjuY+bXZHhnzudjrltMvx+sW1SS2TY03/L2PovepeCVHZ5np/WvqaUpHoMfKrsS+4OPP9fCxpUEg3pk961wxfLE5eXJ1BTXJnvw65rlGyGkgnpoOtceljzeV0mM99sTzmZ06yux6XB76XBgycONu3o0867/AB/pv/r5/bB1+Shy2el6l03y0jzl9EqpPg3+nfn26qeyzGrlbakimHdOWtHe6ThN2xloz1st+rqdLwNJdyPSU40YpaRVh42kuDq11aRzb28z+j37SU1NM1KKS5JhDQ0lwcmtPL9PS0vAyaK/BK8kdY/6uitlsa2LVE2QgOVlpXGBLrkaYw5HcOCoxtY1FryWR0ixwEcdFHKWS2R2DDx5RUp/fGeda0YMmnafB1pIy3Q48Gkrp8vX9ebyKWm+DBOGmd3Kr88HKtg9+B9er5e34xyiVOLNiqb9h1it+wdbX2Za48myuttcF1WE9+DoU4etcE9c+/Zlqx5P2N+PiS/Bqpxtex0KKNexWXm+vt+qsfF1rg6dNKWuCa60jRFHRhwenp08YpIlvSDwiqyekbRhJ2s+RPhnEzLtb5N+Veknyefzb975FqvT/l82HLyOXycydmy3Ik22ZdbM3t+WeQN7ZKkRojQOmJ2mxkIlyOkNRiQSGQJtTEviimKL4IbLVOlyaqU9lMI7NlMS45vXX420R0bYNJGWpaRoRrHk+t7V3cYs6ajF7NHdo5HVL/PIaLzx2uJnTUpMTGhuezPfPun/AMmzE50cvpXfnPI6tC2kl5OpjRcUtnNxY/ejsQXg5rWXtr843UaNtaMNKN9ReXl+lXKPBRkL7GakuDPkL7Gbcc1rzWfFcnm8mH3M9TnR8nnsmv7mVkSuVKBTKs3yrKnXydWKVYXDQKBrlVv2I+idE0njI69i/S5Nrq0K4Gk0msv0+CtV6NjgK6zXOmdjK4LRROrZulAqlE2mkVgdLK5VNexvaKrFya5qKwyrKZQ0bpRM84mvSZZLQjfBdOJU46ZUqVLTEZfJFMi4kjIJFZZDYEEoCQ0KM2KUmhcs10QXfEyrybMfcpxMfS/hR7v01Bd8T6p0mvVUT5j6Yg++J9V6bxQjyP6K1y6a4QIhMY8//wBaRCJIRIzAAD8ATg+o7fp4Nj+D8tevMv6uZNb92fpb1nd9Lplr/wDU/KPqnI+rn2c+4w84/IAAgAAAAAAAA9B6Vs7eqVc/1I8+df09Z2dUq/3IA/XHpSf/APX1f7Uerqfcjxno6zv6dV/tR7OpaQwtACBAAAAA/BxupR3BnYfg5WfzFlZ/03z7rlXEj551OGps+mdahtSPnfV4amzu8U159vTJUiq2WpMlPg78osaIssTM8WWplI4uTJ2VpkpgXFiY6ZWmMmJUi1SDuK9hslXF8Zl0ZmSLLoMmhqUyyMzKpFkZGWo0y2wsNNc9nNjI0Qt0cnpG2XRjIthPk56tLYW8nB6RtHWrnsvjZo5ldxfG44/SNsulCZdGZzYWl8bTl1GnXRhMujM58LS6FhjYcrfGY6kZYTLYy5HFNkJEylwVQfATfBrFSK5z5Mls9otslyZrGFdXnGS3llajyXSW2TGBjp2Z/wARXEuSIS0R3aYp/qiT4kc3qUu2mX9joWS9zg9ZyVGuS37HV5unxn68VnXud81v3Kovgpul3ZE38jxfB2eb2/55xoixymLLUzd2yoYEsgGkqQAlAfUNC6HI0BF0DQb5Bsm5V2KZxKnwy+RVIi5c3pOtGDb2W7Pa9Jv7lHk8FXLtls9N0fLUe1bMdR5Xv5veVT3HyXQkczGyFOK5NkLDHUeN6+a6yO0U9ujRBqSK5x5M7GGM8qpsNktAoika2ngXRK4ofwaZR1Ve+GcnIlyzp3vhnIyXyzfMdfgw3vycXLW9nWul5OXktcm8y9r+eOJbHc9FUqFrezRd+8pk2Fw9D5liuu2VD4bOxgdYlFpPZx3DZMYuHKJuXN6eH093h9UVmk2dWrJjP3R82qy51S/czr4nWHHW2RcvP9f5HulNP3Hit+55qjrUXrbOnR1SE/dE2OHf89joThwZ5S1xosWRGxcNCyr7udhPxGc/P+sWRSrU+EcTN6Qp7aR6OUdMeNUZrlB9t568jwkOkOFvhnpul4ShGPB0pYUW99qNOPj9uuDPWk79vxfRUkkataQsIaLO0w1Xnenp2oT0ROXBLRXIwrDnUpbQ8YlSlosjITT5/Gqrg2VyMEJGquRcjDbXFlutmeLLos0kc2qZw2iuUDRHkHEfEfTDKAR4NEoFDWmBXSUti2V7RZAuUdocVjfHEyMbe+Dm2Yjb8Hp7KU/YzPFW/BTrx7ccGGHz4NNeJ8HV/hkvYFUkDX/uxwxkvY0wp17F8YIdJITPXraiuCXsaq0kUKSQytSLy59S1ti0WKSOf9dFkLtnRlhrLbKXBiyLOGXd/cjLetpm0GJ+uRl2Pk4mS22zuZNbezk5FXkmvV/mrk2R2yvt0aLVplOtozr1/PXYqaI0NJEJA2gSJROiPcajJDJEJDpDRpMUaIIpijTBAw1V9UTbVAy1LlHQpjwa5cfrpdBFvsLGI8uEaxwanaptlqLPO9Tu3LWzr5t3ZVJnj87N7rdb9ydOvxwft7pHSw6+UYMT+ZpnaxIfcjj9K6NzkbceGpI6tUd6MtNfg6FMODnn7Xm+219UTZUimqBrridGY8/0q6PgpvX2M0JaRnyH9jNXNb+uBmR3s4l1e2zu5POzmWw5ZK8uXKopdR0pVlLr5Ns6Vxi+kQ6zY6xXWb50mxhlWVygbpVlMoGudIrH28kuJfKOips3zUVTKJRKJpkymTN81nYzyiUziaW0UWPk1ymqJRKJxNMmUTZrKhmnEqlE0SKpeC5SZpIokjTNFE0aRKpisdoRlxJGSGgHAhi+4zIS5Gmpits6WFXucf7mCC5R1sCP3x/uc/rfwo+g+matSifTMGOqUfOvTUeYn0rBX8lHkf0Vplo8MYGiEcP/AK1SiSESWAD8AQ/AE8N6/s7OlXPf9J+T+uWd+fZ/uP1F+pN3Z0q1f+p+Vupy7syx/If+BiAAEAAAAAAAAG/pE+zqFT/9kYDRhS7MqD+QD9X+gshT6fWt/wBKPolb+1Hx/wDTXN78SCb9kfWqZd0FodDUQC8EiCAJ0QAQ/Bzc6O4s6UjJlR3Bjl/TeG6xX9sj531mrUpH0vrC+6S9jwHW60lJnZ5aLjw+RDU2LFj3t/Ue/wAlaO/Gk2LIlsWVRLEzTqOLExkxYliigLiUxkLrRKYjkWIkRNjonq+BeS2BWkWxFS4dDxKxk2Z6q8xch02iqD5LUcvpW+VkZMvgzMuCyMmce51rGqM2i+FhjjIthJ7OT0y1y3QsNEJmOs0ROXWGnGuEy+uZhjLRfTJ75OfWVSOjCRogzHXI01y5FMrjdX4Jn4Fq5RbJLRpI0jBY9MzTZquXJlkuSdOvziosiK0kR3aMNV15i1+DPZLRY5cGScpOevYMqzkWT/lNnjOv5TUtbPU5k3XRI8D1e/6tvP5O7zy7vDLlt7m2XQ8FTRbHwdWZx6vktTHUipDo066osTJFQwdXEokhDIaoAYEMZ8K0Iy1+CuQ+xneq2IyxoRoio0raNuFkOuaWzJ7i97hPaMtRyeuevedMyXOK5O9XLaR8+6X1CcJJbPZYWWrIrbMrHl+3m7VMy18mKNn4NNc9+TO5cG8cS1yNGI6imhu3RPGGqXt0QywRtDiJWa5cM4+V5Z2beTlZaWmb5rv/AJ5+uLfLWzlZM/J0sh8s5uRFaOjNe74Z/HNse5Fb0PYvuE0au7MqNBoYCLF8I4Ji9so+C0GRcp1iUsLLY+Ga6c62t8yMu2K1si4c+/CV6TE6vrScjs43U4WaWzwUZOL4NFOdZVNaZGsVwe/8l/8AH0VSVi2i2taPF09dtjpd3/Z2MHq/1X90jO5rhv8APrL0kUmaa4I5+PkRnrk6lTXamZaji9u5P2kpBskyrztb/SSWjPJmmS2UygtmdjXGoqS2WxQqWiyJLS08Xo0VzM6LYeS5WG51trlsviY620zTCRpNRzby1RYzYkGPophqcVyM819xpkZ5fuCxMES+LKEPFsUVItfIjitj7WuSudkV7ldXJUSiUvgS3Kivcx2ZqXuDfPlqtrnoplel7nNtz/kySzm35Djoz/LqutPL0/JW8v5OPLJk35GhY2aZy1/+ayOvHJ2/Jtoscmji0vbOrivwdOI5PTz461fKItW0FT+0slHaNZHLbyuXdXs59+PvfB2rYJGadSZNjq8fTjzN+Ny+DDOvsPS5FEVs4uVXqRlqcet4evXMkuSEi6ceRe0jr0JS6F1yM9ij+lHQ6Kky2HI5UaWQXJpgimKNNUUyo59Vopjyjp0x4MVMFtHQhwkbZjg9r1ZrRVbLUSxvgz3yio8svvGGZ2uN1W3WPPk8HfdKWQufc9R13LUYyimeRrkrLk3+TPWnpeOeR6rpcdxX9jvYsdSOJ0pcI9FjV8pnLv8AU++uR0qF9qN9CMtEPtRuphoyzn9eJ67/AFqqiaYRKq4miK4OjLj1rofETHkP7WbZeDFka7WX1lxyb15MM4G63yzM0TxplknApcOTXNLRnfkqfjRTKOiuSLptFE5I1zUVTMzzlossmZZyN8IqJSKpBKSKJ2tHViIqZszzkLZcyiVrZ0ZjOnlMqlLYjmI5muYmpkyqTInZoqlYayIEmVtg5CORciSzRRMtbbFcdlwqoYjLpRE7S5Uqg0NKOhR9IrJS5B7IWx2pq+tbkju9Nocpx/ucPH5sR6zpVfMeDl9dCR7r07j67eD3+Iu2tHjPT0XuKZ7alarPJ971pla2AR5BnJJ+tAiRdslFUJIl4ZIlr1BsXSfK/wBUru3p9i37H5gzH3ZM38n6J/VrMUceUU/KPznkPd0n8jv+BUAAIAAAAAAAAHpfbbF/IhKemAfdP0w6gu2MG/wfesCxSqT+D8sfp31H6OXGDfufpjoV31MaD3vaHQ74ELlEkgEMkGMBozXx3Fmkps5Qp/px47rFf3SPA9br3GZ9I6xX+48D1mvcJcHV5m+cZUe2yX9yhM2dRh22P+5g3yd/nS0tTHUilSJTNus7GmMi2MtmWLLYSH0mjZKK1IZMmqixDoRDk9UZFkSlMtiFo4sJRCGSMdVch4osQsSxI5N1rmBDxBIeKOfVbQ8EXRQsUWRRz7rXK6D0aIyM0S2Jzaq2mLLq+GZ4Gis59KjVW9muozVLwbqY+CYuNdK4LpLgKocFko8GkVK5t3lmST5NuQuWYp+SNR2+ZJMrbHa4KpI5tR1Zpt7KpcPY8PItseB4a5rj9WyFGmS2fPc6xztf9z2nWVLtkuTw+THVj/ud3lXd4iL4LIspjyixcHXL16PnVqY6KkyyI5HTmrExhEMPjWRKY6YhKGs4NEIZAOkfgRlkitoSaURj6IaBNiplUkXtC9pNYbyim51yR6HpvUmmls83OGmW49rrkuTLUce/Pr6Th5SsiuTp1z5PC4PU+zW2eqws2M609ojjzf6PKz/HbhPgdSMldykuGi1S37iuXm7xV7e0Vtch3aFU9sXyymL1Rc9M5eU9pnRyHyzl5EvJrmPQ8OxyL4bbOfkw0jq2eWc/K8HRmPZ8dVxbP3iFlv7xDR6mP8QBIApAaJJ0TQQgdoVokFZVJa5LiuSEz3OxS5yTN2DlyhNc+5lUE0EX2TRlqOP0x+Pf9JyHYo8npaZ/ajw/RMpbitnr8e3uSOfceJ/Vh0ovZdGOzPU9mytcHPp4frn9VuPBTKJslHgplAgs3jOojqJLjpjpEtpUJFkVyKPEBatgi+DKIlsWOVlpqgy3ZmjIdSNJpz6ysZnn+8t7iib+4drOZWIhvQvdpFNlouts46ey/tRgvy9J8i33cPk5WTfrfJUdnn49Pflvnk59mW37lF2Rsyue2XI7/Px40yyGxVY2yjY8XyXHXnz41wkaamYoSNdTNMs/SN9PsdXF9jl0+x1cb2OjLyveOpT4NG+DPW/tLV4NXmbn6rtWyr6ey6XI8IbJp51xzMijafBwc2vtm+D19tXB5/qFP3sw27/5vX9edsjyV6N1tPJQ6jF62fRkkhS+VYv0xN5tUo8l9cQUOS+EConW0Ria6YlcYGumHJpHLvbVRHwbVEppj4NWjoz/AI8/09P1XNaRy861wizrW8ROH1CW0ydVflf14bruS3bJHHwW5Wr+50utxbtbMfS692r+5hqvT8/8e26RV9sT0mPXwjj9Jr1CP9j0FMfBna5P6dN1EPtRtqgZqV9qNlIZ/wBeF7X9aK4lyQkCzwa8c6ux6RgyJcM2Wy+05t8/IzjFa/Jmkyy2zyZJ2DXEWS4Msp8hbb8mSV3I+KW2TM85izuM9lqNc5TUWWGSdgW2mSdp04yirZWFM7CmVpRO75OzGUVZOZTKZVO0qlYdGYirXYVTsKpWFbns0kRTysKnPkSUhe40Qtche4jZDYyOmN7FSY2+Ck0MjQMENKucSvtNDW0J28jKq+x6I7OTUo8CNcjt/CNiw3bE9t0mjajweSw693R/ue/6NRtR4OL2oj1/Qqe1xPWwWoHA6RV264PQR/aeV639aQ0fBJEfBJioaAAFQDNmWdlMn8Gn2OT1u9U4dkt+EGQ+C/q3n91rgmfE5vc2z6F+pHUf4nqEl3b5Pnb8l6AAAJAAAAAAAAAAAD0fpTKdHUa+fc/VnpG/6vT6nv8ApR+P+kXfRzq38n6m9A5qt6dSt/0oYfSY+CRK3uCHJCPcGADCSvW2PsXQg4PV69xkeD6tTuEz6N1Otyrlo8N1apxhLaOjzqnyzrFfbN/3OG39x6brdf3S0eYmnGbO7zop0xkVxHRtKixbEtiVwLYtD6XFkfJbFFcdF0BWqkOkNolIZIi1UhVEuhEIwbLo1sm6OQqiWRgOq2WRgY700kVqI6iy2NeyxVfByb01kVKLLIRZYqy2FZza00kLGJbGBZCssUOTHemmSRgWRgWQgXKBzaq1cIaL4RJjAurhyY2mupidGmHgzUQ5OjTWOG0VR4GmuCyEUkE0tG0ipf1zb4GGcOTrWw2jFOp78E6jrxpk+ntFcqzd9J68CTr0Yay3ztgce0NbiaXBe5VKOlwKZbZ24fU8R2RlpHhep4E65t6PqE64yWmcXqfTIWxbijbP47fH1fNYpxlpjpnUzel2Vzk1Hg5couEtPydXnp6PntZFlkSqKbLYpo367PPSxDorTHTF115MBOyB9WlMZMQZJjTYliNFnsKxETRDQ5DGfFUkLot0Q0KxFyqa2I468FzQuiLGOvMsbZRfDOph9VlWlFyOZ2oFDT2iZljv+eaexw+sLS3I7FPVYNLk+exunDwXQz7o+4/ly7/hlfRl1CEl5D+Nin5PC19UsXmRcuqSf9QfLD/4ePWXZsXvk592VF7OBPqE2/JVLMlL3NJlv5/ySOtO9Nsw5NiaMf8AETfuJZa5I1kd2PDiqzmQocsBumTkABoNCUCdEaGJBWKxxSQUWURyH4DhWKXwUz3vZfJci9q1yTY5fSN3S8p12Lk9z0zJ74Lk+bUycLOD1/RM2O4xb5OfceP/AE5e5on4OhXLg4+PanrR0q58HNqPD98NLkRwxE9jpMyscNvKrlH7gUSzsb5DWhLm1ehoobQyiTT+kxHFRLYi6fuG7ynuDY5S4u7xZS2yvuDu2yul8mk+DLbLRolJaMV8uBx0eWWPIs0mcjJt2mjblWeTj3z+5muY9bx81E29ixZEpJkJmsjuz5yLiUImPFlcVZxbFtM2Usxx5ZspReY4/SOjQ/B1cZnKo1wdXGa4N8vN946tL4NKS0ZKnwaU+DV5XohrktqKmXVEact1wWrg4PUI/ez0U47Rxc6v72c+66P5vTmnn7o8maSOjdXyZpVmPXsY9YwSXJCjya3S37BGh78A6M+sZ1WXwrLlV8F9dXwVKNekURrNdNY8aN+xqqpa9i45t+kPTWafpMamvwbY1po6Jfx5npv/APTmX1PsOBm1N7PXZFS7Th5dUdvZlu8dP8++vnvV8Vub4MfTMVqxf3PVdRxYy29GLAxYqa49zn1p6mdcjv8ATanGETt0Q8GPCq1FHUphpoXXB/RvrVVD7TVVErr12mmpcGmP9eN6X9WwRE3odLSKbZaN+M4zZFmkcjIu5ZsyrFpnFyLeWJpIrtt+THO7yFtqMVlqGuRN1xjndyFtmzJOzkqQ1ll+vczTv+Sq2xbM87DpxEU1t/yZZ3fItkzNOR1YiKtld8lMrfkrlLgpbZ1YiKudgrmUuQdx0ZiKmUhe4VshNe5XEUSYuyW0KNJu4nfIoDSuiOUxkN3FFTMEytyDuGlbvgiK2yI7aHh5GVWPiJR3feXze4mZRl9QnVJ1+nQ7rYn0fodG4x4PAdIqcrI8H0/oVX2x4OD20I9T0+ntijqa1EzYse2CNPlHmbvauBA2CQaJUgZEInfAqA3pHi/W+f8Aw/S7nvXB7Gx/Yz5V+puaqumXQ3yOQPzr6kzHlZ9j3vlnDNObZ9TJm/kzBQAABAAAAAAAAAAABbjy7Lov8M/Qv6ZdSdlFcN+Ej87RepJn1/8AS7qKhkKDkOB+lsWzurRpOX025Tqi0zprwSAAAMIZPsAAGTLhuD4PFddq1GXB7y6O4M8j12ncZcGuKp8l6zV90uDyGStTZ7/q9O3Pg8TnUanI7POmwwfJZvkrjHUi1I2lKxbDwWVrkitcFsVpj6XFkUXwRXBGiCFaciyMRlDkaCLoxItXImEeC+ESIxLoozulyIUSyMBoxNFcDDWlyK4V6LVAtUNDqBy700kUqBZCHwXKstjWc2tNJCQhwMq3s0RrHVZhvSophWWqsujWWqsxtUphWaK6+R4wNFUOTPoNTXz4OjVDSKao8m2uPBrmAa0hJF0lwUzN5DlVyWypw2y0eMdisa53xn+l8FdlDfsdKNRLp37E3B/9nCnQ17CSo2js3Y3HCM0qNLwRcLz7ONZTplM6U0zpX1NPwZ+x/gXOOzy9nn83p6sT4PL53Q9Sc1Hk+izqTXgxXYsZ8aRpi8ej5f0cfK8jHtolpQeiqE5b+5aPoGd0WNibSR5jO6NKpvtTNft6Hn/RK5m468gpclc8eyD04smMH77Kmnf5+8XppjJJlKhodcFyunPpKfWiO5r2I7ie4rq+9TvYEbAcAAAKhgNEokfAraI7SwjQrC4r7RkhtAT8jnC6I0MTofCvCaJW0Nont2VMs7IXbGiHaSkVIIsXgholMhsuLlKAATVAAAQAACJCGQxhWSCshjaFYQqRormXFcwrn9IoXEjq9Mu+lens5bWmWQtcOTLUef6+fX0jp2appcnerntI+d9GzuYps9th5CnBcnPrLyf6PB16rOTbD7kcyt7NkLO1GFy8b18uVofHCFe2TGXcSRYymaIxJaSDYsnsin8jjZDYq8ktk8VMl2TsVsVyHI0mDOQd2kVOZVOzXuVIvPn1dZbpeTn5F60+Rb79J8nLyMj5Nc5dnj4kyr975OZZZtj3WbZml5N85er5Y4ZMZFaYyZcjp4tQwiHQ2Wl1T0baWYYG2kqOX0jpUex1cZeDlY/sdjF9jbLzPd0aY8Gkpq8FjZo8j1o9y+sy75NVJnpy2L9cGDKx++Tejob4K5taOfasdlcG7D+DJLE58Het7fgzSUd+xg6s705P8L8B/DPfg6bUfgT7d+wOjPpphWL8FkMfXsbdx+CVKPwVC16aVV0/BojV8BGyK/BbGyPwaSsNelW016Ro0oozxuSItyUl5NJrkZcuqXIsWvJxMyW9l+RmbbWzDZLvRz+m3d45+XMyV3RaKsGjUvBrsr3PRrxMbTXBz/TqvpyN+LXqKOhXEqor0ka64muf15/t6La48GmtaEhHgvhE6MR527+pb4MWRPhmyfCObky8mtLLm5VnDONkWcs6OVLycfIfknrfMZbZ+TDbYX2yfJht9xytOK7LTHbdyXWJmSyLNICSs7iqUiWtCSOvH+MqqmyiTLZFUkdOE1WxGWOIjR04ZVUw0M0GjeVNI0I0WtCtFdQrIGaI0MgiSNDaGmoSH0CJKIrQJEtkocSeL1EWMuSfYSK5GVXqWxox3ISC2zdRVtoy3Uu10Ot90eD6b0WvUY8Hg+hY/wB0eD6Z0mjthHj2PN9tHHcpX8tFqFgtRQ/scFq4AI9yQUXQPwML7iJXdLVTPhX6sZeo2Q2fbeoWqqiTb1wfm39VupKzPnCMhwPklr3ZL+4hMnuTZAgAAAAAAAAAAAAAAAPZ+heofwvUYc62zxh1Oh3OnPrafugD9f8ApnMWRiVy37Hqo/tPnHoLK+r0+rn2Po1T3BCBgABgBohvRK8ACz/aee6xT3Qlwegkzn59PfXLgvKnynrGPpy4PE9Sp03wfTOuY6TlwfP+r167jr86qPLS4mMmRYtWAkbyhfXLgui9lFcS+KGXF8DRFlEEXRFTi+DNUDHB8muszrSRoj4LooqgaIIx1WkiyCNNaKYovgtGGqqRakWRQkS6COXdaSGjEtjEIxLYo5tVUTGJbGJEUWJGOqqGjEdIiKLEjGmaKLq1yVxRdWuRQNVRsr8GStcmyC4N8EmXgomXy8GabOmf4Cp8l1ZSlyXQJT9NUOS5RTM8GaYPZUiNaDpUvYpsx1rwbIhKGwuUT0/XDuxtvwZJ43b7HoJ0b9jHfR54MtZdXl6uBbHRRKva2dS7He3wZnFLhmOrx6Pn6uZOvfDRmtwIWp7idmVS/BROGhTbqz7c/wAeWzOiRe9QOFmdIlWm0j6BKvu8lFuDXNfdE1zrrq8/6bHzOWLOHlMpl9vlH0DI6RVJPUDi5fRHy4xN816Pj/TL/wCvL96Y6WzZf0q2D8GSVNtb5Llel5+sqHxwBHPuBcbyxIABpD6lAAFQ+gAJ0HDQAaAXBRokgkfE/IJ8AA4PkNgiNEoovk+hWhkyGwHyXwAMNk1cgAAJAIJZBISGgRIgTQrXI7I9xDhdcFckXPwVtch1nrKlxK5R4NXbwI4ck1jfLpsPIdMlyep6d1ZLScjyTg14LKr51PyZajl9vDsfUsLqEZpcnVrujJLk+XYfWJVtJyPRYnW9pbkY6jw/f+b9e3jZx5HU/k85T1VSX7jbXnKXuYajhvjXX+okH1Uc3+J37iu9+zI4n/jXU+ohHP5OYslp8sHmL8i4c8a6Dn8lcp/JgeYvyVTzF+SpGs8a3Ts+TNbdr3MU81fkyW5ifuaZjo8/G1pvu88nMyLfkW3K37mKy3b8m2cu/wA/HhpWci9xS22xls2kdWccWJjxZSmWxK4uxdEsRVEtRFjHUX1o20oxVs2VMqOX0jo0PwdXGl4ORS/B1Mb2NsvH/pdemW+DQ1wZaPY174LeP6f6RR5NFfCKHIHbpGWk5z1onaoowX5ii/Jlyszt3ycLKz33eTn26/D+f6rr3Z6/Jll1Ffk4F2c/yZnmNvyYPRz/ABPSS6ivyVy6ivyef/iJP3D6sm/INp/G766j8jLqHycKEpM0R7mVEb/kdeOc9+TRXmN+5yK4SbN9Nb4Ljk3/ADSOgsl63sy5Ga0vJb9PVbOPmNqQtXjOeclP9dzn5N1Me6JzMWPdM7dEEoI5d1pzin6O5+DbRVrXAqiu41VxM5f1j6bXVrg1VxKYI11ROvzjg9NrYR4LVwCjwDR1yOfVV2y4OTlT8nTu8M5OV7hRlysmW9nKuW2dW+O9nPshyZV05c2yvyZLKzq2Q8mWdZWa1cydZlsrOtKrfsUWUfBrmlXIlVsrlUdR069iuVKOvF/GVcmVXwVupnUlV8FMqjpxUVznVwVSrOm6uCmVXwdGazrnOAvYbZViOs2lRWRxEcTU4Fco6LlQzuJHaXOIrRoFWidD6Ia4Gml2Q2SLIpKO4lMR+SYjJcnwLF8h7ERXI01op5mdrDq7tcHHxobmep6bR3JcHP6UnoehY/3R4PpHT6u2uPHseO6Hja7Xo91ix7YR/seX7U5GhcIkhk+xxrR7gyPcYo0ewa9wl4BvUSSeY9WZv8LgWS3rg/K/rbqDzOqWPu3yfoL9TM90dMs09eT8u9Uvd+XOTe+SgwgACAAAAAAAAAAAAAAAAvxLPp5EJfJQTF6kmAfpX9M+oKzBpjvnR9hxp91aPzT+l/Vuy6upyP0P0zI+pCP9gpOq2wT2iX4FT0BjW2MGgAFaM+RHdbNRXZHcGOU3hOuY++7g+c9Yo5lwfXOsY3dGXB8265T2uXBvitMvnuTV22Mz9zTOjnLU2cqU9SOnNVY2VN6LlIyU2cF3fs1iWqEy+EtmKL5NFchVUjbBF8ZNGWEy+M0ZaXI1wmaITMMZl0JmNW6ELC+EznxsL4WGOoqOhCRdGejBCwujYcu40jfGwuhPZz42F8LDl3Fx0ISLNmOFhep8GNi5F6myyEtmZSLYTM7BY1xLqvJlhPZorlyGYlvq0a460Yama0+DfMITZnk+SycilsrtVw6HiVxLooqUXK2BqrM8EXxei5WG40w0OZ1PQ6nstjYsa2imytMdy4K5TFyKz1jtojyc63HSkzrSezJbDbMfTMdfnuuZOGiiUNnRnWUSrOe546s7YXXoVw2bJVidhPbHRnbDOv4KJUd3lHSnAqcSp6Vvn0rkXdOhNPg5OT0aD3weqcUUzpUjSeldPn/TrP8A68Hk9IcW+2JzLsK2D4ifRrcSMl4Rgt6ZGfsjebej5f3fn6+fuqyPlEb15PY39FTT4ORk9Eab0mXNurH9crj90dcMNmi3ptlK2oszOuxeYs1zt1Y95TbJKlteR00azUdE9JTEMjuaI7nvwPsP6hkmGmSp6Ic9gJUhtC+Ru3QfqkbJ2QBP6LDbAUnYfqOVAAQLq5RskgBdPqQABdSA2BGyeqkAEbJHKYI7SSAICsnZAJqGVyjst0K0LjPWeqlHT4NFeVOvwV9pGifmMNeGa6NPVbY+51MXrM+NyPNqJKlKPjZF8o59fyY//j3NPV00tyNK6nF/1HgYZU4/k0QzZ/Iv+UY6/jy9rLqEWv3FDzt+55iObJ+7Lq8lv3F/yif/AJcx3pZr/JVLNf5Ob9RteRHJh/zhz+fLoSyW/crdrZli2x9jmIueUh5TK2yWxS+RczDIdMrQ6A1iSHSK0x4gm1cvA6ZWh0hVla0VPaNlPlGKrwbahxyerpULwdbGiuDkUPwdbGl4NsvH/odWlJIubWjNXLgeb0iq825lpbbe33MN2W17hkWHMun5MdOny8pVeVlN75OLk2vuNl73s5l29mGnq/zeUlUTm2Qtk9vJdGBnx6PJCRbRdDbZCgXVw5KmWerxdVF7R0KKk9bKKa96OjTDRpMxxeu6sroia660iuCNMEXMxwb3UTX8tnFyobkdyz9rRzLod0jD0RlRjV6Z1at6M1FWmb64HHpOqsrht7NUIIrrjo0wQ8ZcfppbVBM211pIz0xNsFwd3nlw7o1ojXBY0Vy4N5GF0zXHNvhvZ07FsyW17JsXmuJdWYbKzuW0mKyjhmWnViuROoolUdOVZRKsjraObKspnWdOVZTKpFTQcyVRVKpHQsr0yqUDqxqosc+dKKJ1HRnAzzgdONIsYZV8FEoG6ceDPKJ1Y1WdjJKtFUoI1yiUyibyosY5xKZRNU1yUyRcqKzSQhbNFTNZSQQwbFbNIRZFbZLZGuS4ihLZYoohA2MjpEwSbEj+1hTLc9Dt/CbcRP6p7PpFTajweWwatzT0e+6Fi9yjweb7bo49d0LGTrTaPTwioxRzOlY/06lwdZI87eumHyHsAGYQRt7JJQU0a2V2vUGO2Y825V1SbfsEJ8a/VrO7cScEz872y77G3+T63+qnVfq5dlSlvlnyJ8sdCAABAAAAAAAAAAAAAAAAAAAeu9E9QeL1Svn3R+o/S+X9fEhPfsfj3pOQ8fNhNPwz9N/p71JX9Or+7kZPqUZbQa5KqX3QTLlyKgxAAIwQ1tEh7FByupVd1cuPY+Zdfx/vmfV8uHdXL+x8/wCvY3M3o2xWuXyjqVGps4N0NSPXdVp7Zy4PL5S1I6cqUQejRVLkyKQ8J8m8JuU0WxsMKmyyNgWKjowsLo2fJz4WGiMzKxUb4WF0ZnPjYXRtM7lcdCNhdC05sbS2NplrKo6ldpfGw5dd3yXRu+Tm3lpHTjYXQsOXG4uhccu8rjrws+S1XfJzIXfJYreTG5XHRVvyWwtOdGwthPkx1k661dmzZRLbOXRLZ0sbyLMS6dKNWuDPT7Gl+DeQcUTE0NN8kIKvhol0ClFsGEFaIjp6KoscuMNQ3cPGRUkS3orrL5WymUymJKZTKYutM5X9xVOS2V/U0VSs5I1Wucmkyp6Icxe4x02iJIqaHkyqbMa2yGtiSgSpDdyE0lZ3WR9M0cMNIqVX2xyp2yPofBs4IlHgPsv+9YpUx14RntxYP+lHQcGR9FsuelbY93EtwITWu1HLyujKSeoo9XPHfsVOjXlGk9XX5/1Wf+vAX9CnvjZkl0myv8n0WVFXvEz2YVU/ETSerqx/bXz2WNKHlMrku1eD3F3RlPeonKyeiTTeomuPR1+X9kt/15aT5IjHZ08jpNsN8HPlRZU+Tb7dufeUduiNh368kdyZU1G+fWUwC7J2W2mpTARsNgYIYMgilYCSAJokSAEE1XEkABA7wEkAOIugAAWXagCQA/0EaJAD4XQaGABxC4AZINFSF8oSQySF5GSY+IuEoshPQuhWmL5Z3DfXcmXqSZzK5NM2Vz4F8ouWjvSGUtmd7ZZB6QrEai0lIVPY6IZpUR0gQ6QipdDxROiUDO08UWpFcS6ImVqyC0aqmZYmmoccvo6FL8HVxn4OVR7HVxjXLyfeOlU+B7J6RXX4Itf2luL5/WDKs8nMts5Zsy2zm2bMdO3xwptlsyWR7i+wq9jGx6fnOM/ZplkUQ/I0ULja06Wy2ERIovgi5GG9NWOdGtcIwY8TpVrhFSOH0q2CNMVpFdUSyb7UU4d1TdPT0ZtdzC6e5llUdnH639OX8XUx0a4oqrjovijmrHellfk1wiZ64/cba4+DXzjj9NLqomqKKq4ly4O/Ece6Yrmhtg2a8YWqJQKZwNUiiwjS81htijDckos3Xy0jnXS2c+nXisM1yymSNE/cokzNvFMkUyRdORRORUUpnHkplEulJFUpI6MIrPNGaaNNkkZbJo6sIqmS4M8kXSmimbOvCKpmUTLLJGeUjpzGdVz8lMx5yKpM0kSpmUyLpsoZcSRsRsdie5rCRoh8DitFJqExlyJrksghkaMftYtMGrP+S1PlI000baeiN6/Euv0ynuceD6P6eo4hweO6LidzjwfRui43Z28Hme2g9NjwUIL+xehIrSQ5w00AAAaAABCkXueT9WdVjhYk33a4PV2Ptg38Hxb9UurOmmUVIcS+L+sepvO6ra97W2eXNGZc7siUn7szhTAAAgAAAAAAAAAAAAAAAAAAGrl2zTR9x/S/q/2V1OXufDD3n6f9U/heo1QcuO5DgfrTBs76E/g2Qezz/QsxX40OfKPQwSSAGFXknYEBLIJIKgV2x3Fnkut4qnGWkevkto5OfiqcXwaYrTL4x1zFcZS4PFZteps+seosD9z0fN+pY6jJnTiree4Q0dE216ZW5aOnNNdsZMzqZbGRVNohJoujMzRZajOhpjMujMyxLY+CbFxpUyyMzOvJZEjUVGqE2WqbRnrLTm3GkaIzZdCTMkTTWzm1FxrhJmiDZlhI0xfBhYuVohI01+THXvZuqRjqH1tx0zq40Xs52Mjr4sfBEhdbqU1ovk+Ba1wFhrDimT2yYka5HSJq4NclkRUMhwqtix0ypDIbLS5NCTkhRWHSkJJlbkNIpkTdNc5RKRTKT2MxGZ3TeYRsO4Visi1cwZyFen5FZDIrSZDS9iCCdkH8p2DYrZGxl8ni+SzcdFGyUyeJ/wCZ9LY3sImMpD4JixCTbCVaYykN3DV2xlnjp+xTKhrwjo+SHErqp6WOa4WL2KZ0yk/uR13D4K5VJlT0saY9eOJZhVzT2jl5XRqpb1H/AKPUSoWxHjp+xpPZ04/ps/8AXgcjojTfbEwXdKtgtqJ9FsxV+DHbhKXGjTPq7PP+x86njWQ/cimT7fJ7vI6PGxPg4Wb0Ps21E2nq7vP+yPP95PeNkYtlLeosyNW7/azSerqz/VGpSWidozJyS5Qym0V9db5/oy0EbK1PY6a92JpPXNMRoncdcMVyYmk1KkBdslCFnRskNIAKZAAAdV8wAAB0+AABjAAAGi1KJFAuU+n4IcvwKAdKmUnsbeysZMXUU6L62yhMugxdZ1qhyN4EgxnyxWstHiy2JVEsTIZcWpjxktlQLhiTWjZKK0y2LBlo0S2LEQ6QmNWxZqqMkTVUwjn9HRo8o6uO1wcmj2OnQzXLzPaOnBrQlstJkQfAlz4Zo45P1zcqXJzrJG3J8nNsZlp6PhFU5bKZNjyZU3yZV6En4hbbL4IqRbAJE1YkW1+RIlsF9xcjm3W6hI6Fa8GChHRq8A4vRqr0iu+SSZDsUV5Ml9298k2uTUVvcpm6iBjp5OhSjj9L+p/8XxjwXQXIi8FkFyYxz7q+uPJsrWiiqPJrjE6/KOLelsB2LFDpHbmObVLyD2MxXLRbMjKbHwWTkZrJ8Gel5jHkS8nNtmjZkz4ZyL7NbObTqwmczPOZRO8onkfJEjoi6czPOwpnk/JmnkfJpMqaJWFMrTO7t+5VO75OjGU1bZYZLJsiVvyUTt+TqxlFS58izmtFErV+SqVp14iKecjPKRErCqVh0ZjOiUityFlMqczRJpFTGcyqUioQbEYrlyG9lwjJjbWitIGyupqdoeJSlyWwQuksjGTmvwdrFrU1FLyculcnoOk0uVi4Of00ivXdAwpbi2j32BR2JcHn+hY7UIcHrqIaied66DQvAwsSTmMAADNAEkN6EGbNsUKJP4Pzb+q3UY22uEZcpn3/AK9mRoxLG3r7WflL13n/AMV1O1KW+WOE8Y3tkAAgAAAAAAAAAAAAAAAAAAAAAADpdFy3i59c09aaOaNXJwmmgD9U+g+r/wAViw3Lekj6bVb3QR+b/wBMOtNarlL8H6A6Zd9WmL2Oh1UiSE9kmdCfYgkgqBDM90e5Pg0lc0mipVR4f1Djbrk9Hybrdfba1o+5daxu+iXB8j9RYbjc+DbGmseCvj5MDe2drIp0nwcmce2TOvFUWKLoFSZZFmnTXxLUURkOpEWpaIsuizNFl0GT1cXplsSqJdFEWqi2t8lyZXCJfGHJhqtIeEdmuqvZVVA3VQObS4mFRojXwNCBohXsyqulqqNtVYU1Gyusw2XV2NX4OxjV+DBjQ8HYx4eDODq6MdISzyXtaRmtfJXVyq15HSEXktXgm1cqPcZC65LIoqFaZIklLgNDZ0bFbJfBXJ8E2nkkmUyY85FEmZ2unEQ2VtjNiszumsK2I2M2IyetINitkkMFRGw2ABww2K2DFYcBthsheCRqTsnuFARG7hlIqGRNqbF6kOmZ0xu8XUXK/aIbKe8ZS2ibU3KWg0G0MmhSidVyr37GeyrS8G3aFcVI0mmmd2Oa4rXgotxo2p/ajpWU/gq+no0m63z6PPZPQ42bekc6z0/FPwj2MkteDNbBP2L/AOjfPvp4m3045T4K/wD+My/J7SNK34Lo0R14NZ7K/wDpseF//jMl+Si7oE4L3Poix4P+kW3p8Zr9qKnq1z/bY+W3dPnRzyZm5L+ln0fJ6KrNrtORkenZJPUSp6O3y/vjx/f8DKSZ1crodsG9JnNswLa3zsr7ej5/2ZpPJG9CNSh5THjJNeA62/8AoynuJ7iO5fgNopU9pU7BMgnQ40m+pAAKV0AAFIoAAHwgAAHDDBAAuFYZMtjIpGi+RcRctkJF8XtGOEjTCXArGesrUOmVJjpksuLkxitMeLEiw8S6JWiyIMtRbEsTKkxtiYWLorZrqRlq8GyoUc/o20LwdOj2OdT7HRoNcvM9m6HgrufA8fBVd4NXLP8AXLyWc21nRyTmW+5np6HgokytvkJvkTfJlXoz/FsS2LKIlkWKM9Rqgy+tcmWuRqrfJbm3G6njRthPSMEGO7dIVrj9Ituu1szqTmxG3Nmmil8GOq5tZaceGkba1oprjpGiBza/1jpcjRVHkogjXVEUn65PRqqiaoxKKkakdnnHFupSJJQM6owpGU2PRaymwfSkUzmZLrNIuulo52RbpMjTbOWXKt4Zxr7uXyasu7zyca+7yYWOjMFlvyZLLvkrstfPJittf5DOWrRO/wCSmV3yY52v8lLuf5OnOA2Tu17lMr/kyyt+SqVpvnBNUr/kond8lDsKZ2HRjKauldyLKz5Mjs5Idp05iKvlYVuZQ7SHYbSM6eUytzElMXu2Ulb3FcpBsVjgRsmPkjXI8VyXCO1pCFkvAsY8jSIxL4RFjE10V70TSWY1PdJHs+g4XdKPB5/Dx9zjwe+9P4uu3g4vXTOvWdKxeyuPB24x0jLhw7a1wbfY8/0v6EJki6GMjAABZgSx6g2OY+oXKrGnL8IA+bfqL1xYePOClraZ+ZurZTyc2ybe9s+ofqn1l25ThGR8hnLuk2OkUAAkAAAAAAAAAAAAAAAAAAAAAAAAAA9X6N6m8LPgu7Scj9ReluoLIwq3vyj8d4V7oyIST8M/Qf6b9dd9NdbnvSAPt1b2iwyYlqnWmmatk2BIEIkcAEnwOLNbHTlYsylWUtaPmnqfA/myej6rOO46PKdewI2qUtF5vGma+LZuJru4PM5lXZJn0PrGG6pSSR4zqVHng6saaxxUWRQri09Dx3o1mhVkYliiJW9l/wCASmCNFaFhBaLYR0RVRdCJprgVVxbNdcGZa00kPXA0QrCmttm+nH2zDW1yK6qjfVRv2LKcZfg31Y+vYwtV1nhR8Gmuj4NdePv2NcMX4M7R1mpo+DVGk014+vY1142/Yy1C6z41XK4OtVXpIrqx1H2NUYtLRlwfRJ+DDa/uOhKDfsZ50bfgZzbJF8l68EqjQyrf4JsV/wBIVFkUR2P8DRTQ5offViQNAmwbH0f6rnwiib4LbHwZ5N6JrTMVzZS2PNMqaM66cQbFbDbFbMq150MRksgQ5xAEgNXRohokCldIxGWNEdqAFRIaIFS5UgQG2SfKlIZCbJ2TYfDAxdk7J4fEbG2yCA4OH7mHcxSRosMpMZSZVslSGUixyEemK2CH1cnESiUyUV5LZzaKtd75H0/ritR3Pg0RqbRNdOn4N1VTa8E9rLXrGKNUtmlUvRsjR8D/AE/gc1WOvZy50vZVLHUvKOvKjfsJ/D/BpnaZ/RY4lvTqprmJz7+hVT39h6l4/wACSqa9jWadOP7LP/Xhb/TUW3qH/Ry7/TdsZfbDg+jyrl+CuVG1yi5uR1+f9+nzC3od0P6TDb062vyj6ldhKXsc+/o8LN7Rf/WO7z//ANCf+vmU6bICx7t8nv7vTtb/AKTDb6cil9seSp6R2+f/APoZeSA9HLoE0v2GS3pFkP6C56R14/uxXHA2TwZw8xMtkHDyi5uN5/TmlAE1oODWWNZZf0BonQaH1cGg0Gydi6pALySKCbF8GaIPgyRbRfCXBOmW2mLLEURkWxZHGHViY0ZcleyY+SUVqiy2LM0Wy6DEx00IbQkWWoVY6WV8GqpmWJfWKOX0rpUvwdGhnKpb4OlQ2a5rzfaOjB8CXeCK2Fr4NeuWT9cvJ9zm3e50cmXk5d0vJFeh4xln5K/cmcirv5MtR6OJ+NEWNsoUxlPYpD1hqrlybK2c6EtGmFjRbl3iupW+CLGZK72jRCXf5M9Vybw0Y8O6R0oQUYmGlxhzs1K5a1sw1XLrNaIsvgYo3RXuXQvj+TG6c+8OhWbKkcyvIX5NlWQvyPNcnpl0a/JpTMELl+TVXYpHVjcji3itCYMFrQsmdM11zWcRIpn4LGxJ60XIWb+udky1s42VZrZ1cySSZ5zNua2Rp05jDl2+TkXWcmjIubbMNnPJnct8wlkjHay2yTMtkmXnK1U2USkWSKJnTiJtJKZU5ksWSOjKformVSkNJaKZNm2S6WUhW2Rzsk2yikewJaIbNYmlZCGbEfngd/E8OmDIQMJQlDx8laLopGkialjwiJotgOotOkb8OO2jFFbZ2enUdzXBlrXE9d3peJ9SUXo+g9Fw+1R4PN9DxFpcHu+m1dsUed7b/SdCqHbFItRD4QJnHq9CQDQs9rwTAYCF4D3KMPg8z6q6hHG6dc+7X2s9HfNQqb2fFv1M9RSortpjPXDQ8k+LesOovM6lZ92+Ty5ozL5X5E5t+WZwoAAAgAAAAAAAAAAAAAAAAAAAAAAAAACU9PZ9M/TXqrpzVBy0fMjt+nOoSwc+Ek9cgH7G6HkK2iL35R3PJ869Gdajk4VX3LekfQaLO+CYUloEkAYAgFLYUIkjm5+MrK5HTaKrY7gxxea+X+oenacno+ddUx9Slwfaev4qlGXHsfMesYTUp8G2W8fP749s2LHlGzOocbJGaEdI3ydEeGaIrZUo8muqOzSITFtI0VLbFjUaaqjLVaSNFEN6OhVTv2KMarejs42PtLg591cVUY/Pg6VGPyuC/Hw2/Y6mPhPa4ObVV1npxuPBvpxPg3UYfHg3VYuvYztTaw1Yfjg3V4nHg214/wAF6rS9hIumKGKkXwo0aVBDqJNT9qY1aHVZZonwZUfap1iOo0BoXR1kdIfSNTiiO0OjrN9DgV1aNuloVxTH8dObYnDRVNNG917Kp07D5XPRzptoqbN1mO2jPKhomxvj0ZpMpmzROtozyiY12Y0pbFY7iI0Q2lK2RsGI2C/9NsNihsR/J9hsXYbA+JAjYbDpggkACCCSAMADIEEkkAIJACBUGAhEiTQQDZDApEh4RC8EspVJLksrr2RCG2bqavgGO9Jqr0jVXFJCqGkMuCK5NVctDpIpTHTF1nV3amHYhFIZSHNIDrRXKpMvROtmk0OsUqF+CuVHwdDsJVa/BX0qb45Msf4Knj/B23TF+xDx0/YJpc93AnR/6lP0NPmJ6J4ifsVWYO48IuVrn+lwXjxkv2ozXYEJL9qPQPBaKbMVr2NZp0Y/p5/leRyejxmnwcTK9Pp74PfWY/wYrqF/pLmnd5f22f7XzLJ6VKmekmY50Sr9mfQ8nAjNt9pysnpHdvSNs7/HseP9s48Y7JR9iVPZ28joslvgwWdOnX7Mr7deP64xtAkWyolHjTFUGvYf06M/0SjRGhu1/glRH1rPSUqLYpjxrLYw0PpasqIIuiiIpFkRMbEpDRXJCGiKoqxItiVJjxZLLUXRZYpFUSxIXGOo0VvaNNZlr4RqrYSOT0jfSvB0qV4ObQzo0y4Lked6tkeEVXS4YylwU3Phl8c+Z+ubky8nLul5Ohkvycq+XkOPS8Ms858lfcJZPkr7+CbHpZxyL/qDwmY3MeFguH8ujCRcpcGCFvBcrdhWWvNshPk1wt17nLjbob+I+TDdcnp5ussrXuN/FtnIha5PybqKnLRzarj3ONSyZNl9d8n+Ra8Rs11YjMufrk2eu2RrrvaK44zSG+n2mkjj3OtteS0zo4+Tv3ODvtL8e9prkqVhrHXp67dot3s5NGRwuTfXbtHT56cnp5rZGa6Wky6UuDNa+GdX1+MM45XKzZ8M81mz5Z6DOlwzzWZLlkWujMcu58szSfBfa+TNN8CaxRZ7mWZomzPI0ydVSRTOJpaKpxOjLO1jmtMRo0yr2K6zaJZJRKpQNkqyqUDSUmTsDsL3AHE2zSZnErkjU4FcoG0pMrGitlrrBR0O/pUmiGixoXQ8xNpUiyIRgWKBtE0JFsUQo6HSJ1U09S3I9R0fH7u3g4OJQ5TXB7foeJxHg5N6Tx6vomJqK4PWYtfYkcrpNCjBcHbgtI870/0jtAkSBkEN6Ii9hJbF/axA7ehZPcQfKFctLTGHP6rkfQwZyb1pH5f/AFK6q7+p2RUtrZ949c9ahh9LuXct6Pyv6iz3m9Qsm3vkr/A4ze3sgAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB6puuxSXsxAAPs36cdfl9SqmU/+z9CdLvVtEXv2Px/6N6i8TqVe5aWz9R+leoLIwq2nvgYexRJXCaaXI+xANEJaYxD8CoAkltEbexvYcVHG6pR3xfB4HrmCoqT0fS8qHcmeT67iN1vSNc1tmvjfVcXtlJ6ODOPae56ziNOW0eSyKNSZtmrY4bbNMG46GppXuaHUuNGn1+FxZVykb6K9tGbHq20dvCxe5rg5ta/VxbiYzbXB6HBw20uAwOnt64PT4XT+1LaMdaHWfEwfyjq04ST8GunGSS0jVCrRhql1RXipLwXxqS9i5JEMxuk2iMUiNchsnaF9FZ0aJFckK5om7KYp9oWUiqViK5XL8mV2uYX94d5ldy/IfVX5I+1zza+8nZkVq/I6uX5CbH/NocgTKVbF+46mjozv8RcVclsHFCxmie7ZX0zssK4IqnUn7Fr2Hkm/q86sc+2j4MNtLO5KEWUWURZFw6cergyraKZI7NmMueDnXUyUnwRrHHVn16xSRWXzg17FLi0RY6MaQDYEMnjoiNk7FJQqo2wII2T1NPsjZGyNlQ4bZGyCANOySAEEkkAhBJBIvuIGJF2TtCKwEE7I9xlwyBeSB4RbaGnVaaKtnQrr0inGr8G6MeBuL13+qnHQjRpcOCuUDOsLpUhhuwHEztLpe4ZSI7eSdE/RHjMsUyjaRKkg+g0KSJ5b4KVIPqNMuaTY0JMnlFcbGT3lTTK9PtjLkRSTLFwXNI7YlVbXgSeOn7FqkwbbLm1TdjDZix/Bz78WPPB3HDa5M9tUX5Lm2ufWvN24m3wjJbipeUelnTEzWYsZexc29Hy/psjy9uJGXsYremKf9J6ueEvwVSxNexc268f114y3ou1+0yy6M/8ASe3li8eCp4a/BpNuzH9tjwlnSZL+kzy6bOPse+ngxfsZp9Og/YqadWP73iFiTQPHkj2Eumw/BjuwEnwi5p0Y/tlea+lJAotHZswtexmnitew/pt/9MrEkOkXfQkvYFWw6f8A3lV6HQ3YyVFh0r6Sngi+KKoIuiDO6PE0VlETRWOMd/420vwbqnwYajbWXHne0aoy4K7nwyYlVz4LYYn65mTLycjIn5OplPycTJlrYPY/myx22clP1efIl1iTZl+qt+QepnEsb1PYfV0ZY3R/JE7N+CaqebWsnT8l0Mjb8nI72mW1Xaa2zPSd+ckdlW79yyDcmYarFJrTOpi19zRz7eb78jXi0uTR38TH4W0ZcLH8cHbop0lwc1eP7b4sqoWvBqhSvwNTXwaoQLzHmenp+s/0uCmdfwdHsK51cFfLOb65VkPtZTBuLOjdWlBnPlwyKufrXTfr3OnRdvXJwI2aZ0ca3wXjTLeXYc+DNdZpPklT3Ey5M9JnTNOa5/XMz7eGedyp7bOvnWJ7OFe9th1UjFY+SiRomimSRUNmmilo0yiVuJvlNVdosoGhIVxN8s6zdhDgX9odjZpKTJKsplUdB1P8COllyk5zqEdTOi6H+CHSaTROa6hHWdKVBTKl/g0myYHWK6za6mJKtmmddKsMo6IUTROp/gT6bTN5UCMSxRQRQ/ay+hW+C2ld0tFcos1YVMpWeDH00l3ulYXfKPB7/pGD2xjwee6FiNuO0fQOn4yjBcHDvYb8KrsibUJVDtRajk1e1NAbJYrT2QRvIslsn2ITYQBeDD1C9UVSk/wa3JrZ5P1d1OOJgTk5a4HA+M/qX6ldl91EZ+7Xk+NWzc7HJ+56H1d1F5nVrZKW13M82FAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGnBvePkRmn4Z+hP079SRsxa63PnwfnJcHt/Q/WJYvUK4OWlscD9cYVytrUtm6L2eT9PdSjfiw1Le0epqf27Cg8paDe0Q13E64ICCfYXXJI4amyOzk9SxvqQfB2pcma+tSi+C5Wua+X9d6f9suDwOdi9lj4PsvWMJTjLg+edY6e1KXBU20jx6jpmmqpyaHlitWa0zp4WE5NcFf9PxXE4eG5NcHqOndOb0+0np3TvHB63AwVGK4Rza3+mrwMPsS4O9TUklwRVQo+xqgtGd0VRCHaxyd8EN6MtVA0Q+CHNIqnaY6p8NKaRW5r8mey4zTvZndNMZbJXJe5RPJS9zDZezLOyT/ACZ3TaZjoTy1+SmWVv3OfJyf5Iipb9zO1czG95PyL/F69zG4yKZKXyT+tJI6Lzde5H8f8nJl3fJU3L5HOq+Y78M75NEM5fk80pyXux43yXuy5tncPUxzU/c0V5KfueVrymvc21ZnyXNsteT0f1k0SpbOPVmb9zZXkJ+5pnbG+VjcuSHESFiaLHLZtmxHLFUkZLaO570bHyS4rQa/VY3Y4tuP8GOylr2O/ZUn7GS3H+DK5dfn6OFOLRX7nTuxjHbV2kWO7HozshEtEGdjomumFYdwrZB8TsNib5JTKg4cNEIlAEgBAgknYuyRA2xWAoHIAIYCHDDIRMlMZcOaKPJnXJpoXKGx9K6lC4RtjHgyY68G+C4G8z11+l0VyRe0JJGdZys7QJFjRGjOxRGuCtlzQjiZU1LQIscCO0RBB7kpE6HDiUTsghldFytiy1T4MyZPfoqVncNSmOrUjD9Qh3a9ypTnm3SuWjJbd8med/yZp2t+5X0ueTapdwaTMtdnBdGey5VcsO4bElTstjIdNFTR/VjG6Pgrljo6D0I4lzSp62ObLGRXLF+Dp9gOv4Lm1z+iuNLF+DLZh7fg70qvgR0r8FTbbH9NjzdmF8GWeBv2PUTx0/YreMvwV9ujP9VeVn0/4KJ9Pa50etlir8FMsRPjRU26M/1PIyxJfgr/AIWS9j1ksFfgolgr8FTTfP8AU84qGvYb6T/B3nhL8CPC+Cvpc/pjixraLoRZuniafgI4zXsVNHfeWFqRuqRVClo11V6LmnJ6ekpkuCi7wbOzgy3wemXNM8anXHytcnCzPc7mXF6ZwcyLe+GHXq+HrI42TLl8mTuX5NORVJyfDMbpnvwxfT1PP3h1L5H+okvJXDHm/ZljxJ68MV01vvFU7iK7HKaQ6wLJPwzdg9KnK6O0zO1zev8ATONfT8eU2uGerwMF6W0L07pXYo8HpcbFUIrgx1OvG/p/phcXG7UuDp11ceBa4a9jdVXsyuXh+3t1FUNLwXxiMoaLIxNM5efr07SKISjwXKJE1wVYedObkR+1nJtWtnZyP2s5F/uYajs8/wDGTfJ0cT2OZv7jp4nhCyNuiv2mDMs1s2SlqJyc6fJ0Rzf+uVl2bbOZY9s2ZL5MUltlRTNMraNEoidpplNZ3ERwNLiK4G2UVn7SewvUCyNW/Y1lRYyKnZZGg1Kht+DRVit+xX0muf8AQ+A/h3+DuV4Lfsa6+mb9hzRPMfwsmtdoLAf4PXx6Vx4G/wDE/BU2TxzwHrwUTwH+D2//AIn4K59I48FzYeFlhNPwUW42n4PaW9J17HMyumuL8F49P1NeWlTr2M86/g9DbhNexhtxGn4OnPqnjkqHJdGva8Gr+H0/A6q17Gn/AEDGqNvwdbp2K3NcCU090lwej6Vg90lwYb2l3+iY2lHg9piV9sFwcjpWH2xjwehrh2o4t6HTpEgBihIAAqAVzl2lhVcuNjgZ8u6NVMpN+x8N/Uv1R/JsohPk+n+quqxw8Ge5JcM/LPq7q0szqNv3bXcyg85k3O66U2/LKQAkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADX0/JeLlQsT8MyAnpgH6K/Tz1IsiqEJS5Wvc+0YWQrKkfkX0N1l4ebCLlpbR+m/TnUY5OLW1L2HQ9SnofyVRkpJDpkANCtjvwVyA4VsSXKJYkhdaRgzMdTi+Dx/V+mqXd9p7uce5HHz8ZSi+BfTWPmVvTdW/t9zp4HT1tfadi3ATs8G/DwdNcE3TSLcPBUYLg7FFXYlwTRUoxSNShpGVpURQ/gXwTsXU0JiTloJPRROWzPVELO0plY2S1tgobMdLkUy2xHU2a1UOquCFd45zof4EeNv2Op9H4J+gL5ObctYq/A38KvwdP6JP0hfJzbkvF+CuWJv2Oy6kK6UOZVPRwpYfwI8L4O66UR9BFfCv+jzs8Rr2KJ47Xsejnjr8GazFX4MrlpnXXAcGg73H3OrZir8GO3H17E/43zJVMMlxfk205nPk5s62mTHcQmuHrzj0NOZ8m2rJUvc8tHIcfc2UZj2uS56uXfk9RCSkMzmY+XtLk3wn3LZ0eW/pybzcn7diTr4LYsZx2jaxOdVzbavgwZFPB2rIGS2nZnqOzz9Hn7KmjNJaOzfTpM5l0dMx1Hf576zNisZrkjRnx15/wAQSg0ACmTG2ITsCOAqZIgnZGwI2IJ2QRsAODYbIZAA2xkIMhji6C2zbRHwZKltnQoiNy+3+N1C1o3Q8GOpGuDB5Htf0zYjCT5F2TU5qGKyWxGzOxpE7J0V75G2RYtPaR2jJki4RO0jtLAaFYUvFWg0PolIR/SloST0i+UeDPbxEcVP1W5lM7NBKRktsG3xnqyVonfsxyt58hG0p0TH46Vb4Losy0S3A0RZpGWs/rRGQ6mUJjbGyuV0Z8j9yM3cHex9RctKaG2jKpsZTY+j4XS0I0itzZKnwH0fzwOIv0xu9DppjmjnYolWVOs2NIRxTZc0ubrHKv4K3Vv2N7rRH0kaTSv+tjn/AEPgSVHwdRVIh1IuaL/vXK/hd+xP8J8HTVSHVSKmlz+i8clYuvYsjRr2On9FEfRRcqb7dYFUVX0prwdN1FVlW14L+jz6vN5OLvfBy7und2+D1lmPv2KJYq/Addfn78ePn0fuf7Sr/wAJz+09k8aK9iP4aO/Arp1T+vjytfRF/pL/APwsdftPUQxl+C5YnHgnpa/trykOix7v2HRxukwg0+w7ccTnwaq8XS8B1zen9lrFRiqOtI3wp+C+vH+DTGlL2Djg9f6Os9dDNcK+1FlcEX9nA/lw731So7LFEeMNDuOhyMf/AFTrRTbLSL58GO+XDFW/nO1iyJ8M5V8t7NuTPyc2ctnPp6Pnn8Ur9x0sV6SOelybqHpCzBvLXZP7TkZs+ToWS4ORmS5N45LP1zr5bZnbLbfJWo7KhKpCMtlATsLiaRIbs2WQhs0Qq2aSlxnhS2/Brqxm/Yuqo2/B08fGTS4KlLjJRh78o304Pwb6MT8I6FGLr2H1lpgpwP8A1NteFr2OjXQkvBb2xQdSwxxEvYl4q/Bsc4xXIn16vyP6DL/DL8CyxU14NTyKvyL/ABFb9w+xyudZgp+xz8jpnd/SekU6pe5E64S8FTZcrxV/Sv8A1OTkdMab+0+g24sZexhu6epb4Nc+gsfO7cBxfgzSxWn4PdZHS1z9pzrOl/d+03m0VwMLDcprg9p0jA12vRmwOmruX2nrsDDVcVwRrSa14lChBcGzXAsUoonezm1UBEggEEgACoD4Riy8iNVUm34NknqJ5H1V1FYeDbLetRY4HzX9TvUShRKuEz4Bl3O6+U2/LPUesOtTz8yce5tJnkPI7QAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaun5MsbKhNPWmfob9PPUUb8eEJT51+T83p6ez2vovr08DMhFz0tgH67wrlZWmns26PH+lurRy8SuXdvaR66MlJbERhWiWK2BwrSK5rRY2JLkVaZVbM2RFSTLbJaZQ33GWq2y508dOezXj1KI7r5GitGNrRdFJD93BUpE7I6imchXJgKw6RbJvRXtsscdgoE0EUdssjAlQHUSbD6hRGUSUiQmStRokNhsfC6ADYIPk+o0Q4jaAODpO0hxH0RoY+qqcNlUqzZ2CuBncqm7HOnTszWYyfsdaVRVKkm4bZ9dOHdhxSMNtHb7Ho7qNxOfdjfBlrDox62uI6gScHwb54+vYzzq0Y6nHRLL/qynIlFo7WLlbik2edT7WaaMhxZXnqysvbEseqrsi15L1JHDx8raXJ0abe73OzPp1w68+NbSaKLIlqltFcuTacrPtjFbUpI5mRjI7cobRjvq2mTrMdXj6Xrz1tfayl+To5FOmzBOOmc+o9fy32EYvcySDNtEpsNgQCuJT5G7mVp8k7BNh+4NibJ2IoYkTZOwVwMXYzIGcgTHixAT0CdNtPlHUx47OTjvbR2cdcB1w+9bIR0i1PQkfBOxdeV6f6GyGw2QybSkRsUkgi1pEaBEvwCJUlDpCodDKjQ3bwCGXgOJI4oNaHFYuFVcjNbzE0T8GezwJr5sNvCZz7ps6F/hnMvfIO/wA8sze2NEr3yWQHHT8uhjy1E1QezBU9I11vguMNz9aUTsRMYbGxPsAPwCGmxKDYIGMcQ2GwIA+JTHUionYhyLu8lSKUw7ipU2L+4lSKNkdzKlTY1KSJ4ZlUxvqD+kXK/SJXBVGe0T3mk0XFqkN5KVIdSKmkXp+0SUdjKRLLmi7WadaKpVGxx2R9PZX0qb0wOjfsTHH4N30SVXoqVX/TTHGjXsXRrf4NCh8FkYIv8RfSs8an+C6EH+C+MEWKGg/Gd3SxgkWKCZCQ8R/jK2mjWixJIr2HcV2M71bwJORW7dFUrSLVZymyRhyJ8Mvss4MF8+GY607PLLDkS3s57fJrvl5MbfJjddd2VkFtmqC0jLV5Na/aVlO6rtnwcvKnuRuvno5l0tyNo5tKJQTK5faXMqmtmkZUibbHVW0RGPJpriO05FMatM1VV7HhUaqqiZpdybHp2zsY2OtLgz49R1seGkjfP6w1+NFFCSNEY9pFbUUWOS0VWFv6O9Jcma/IUU9MW6xo5103Jmeq0xlGRnySaTOY8+3b8mmdDn+SiWK/wY3VdGcRTLqNov8A5G0mWK/wVSxmvYi703nnlph1Wxe5sp6tN+WcOdbj7BCTQZ9Kr/lh6urO7/LNKthJeTyteQ4+5rrzWvc3z6MPXyk/x3JwjPwUvCUn4KMfL21tnTqujJextn1cO8UuNhRg9pHVrj2xSKKtGpeDT66ys4newSF8DIViKnehZya8EtbBraElKluIbYsVpkyekOGoysiNVbbZ8W/U31Iqqp1Qn5Wj6F6r6osLCsl3aaR+YvWfXZ9QzprubWyv8N5XLud18pN+WUA3tgSQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL8W90Xxkn4ZQAB+gf059SRnVXVKfK17n2zAy43VRae+D8c+lutTwMyH3NLZ+kfRnXFmYtb7t8DJ9E8oVoiqalBMaRFVFbK5y0iZy0Z7JcEWtcxXY9laCTDZjrTWQ2wSE2PFmVq06JSAlCRU6DRJGwIJE6RGyNiBg2KAgfZApIQVIEAMkkoUNgD7AXYbAGAjZOwBk+A2hCQ4SWkK4jAFipVMobM86U14NjIcdoi5aZ3xyrMf4MF1Hwd6daMttG98GOsOnHo85ZU0xEtHVvx/PBz7a3FmOpxtNfRqbtNcnVxsjxycFbTNdFrWisaRrD0tdu0WexycfI8cnRhYpRR1Z25d4W62V2V7TLEyWto171GbyuPk073wcq6nlnpbqto5t9Hngm4d/l68cCcdMRmy+rUmZJx0c+p+vT89dhdkNkMgTeROydkIkkrEbDZAAnhkw2KGwUsTJK9kpgDislEtcCZ6asXyjt4/g42IuUdmjwDg9mtPgHIr7tEdwrXn7izuIchNhsmlIbYbE2TsirkMCF2Tsk+LExkVJjpjhVYmPvgq2MmNFOKyNkNiSrm+DNZLgtsZktlpCdPlGe+XDOXkPk23T2mc657YR6XnlSnyXVlC8l1ZUb8/Gus1VmSs11lOXf+tCHQkR0xsaZrgVDb4IRSUoglEewAexGiSByGNEaGQD4XS6JQ2iHwBBitg2I2IcTsO4TZGw6Plap6J+oUNiuQ5ofDSrB1aY+8O8r6TcN8bSz6pzVZyP9YqaT/zdFWIZTRzlcOr/AJH9H/zdFSQ60znK/wCS6GSkvJU2jXnxt7RkY/4lB/Er8lf9GXy3pjdxgWQiXkcD/wCibitymifqI5qyPkZXj/6J/wCboOwV2GL63yK7Q/6F/wA2mdnJW5md2bYdwrtrnzNOZivmXWT4MN8/JldOvzyz2yKPI05chBbZMrfiytF8nqIsI6QlstI1yx3WPJn5MDe2aMiW2zKbRz6qWxdbBkxWy5UcNCPJphESuJojEVrTMPBGymJmibKCZV2fjfRHwdGpaRjx0uDfBcHRiuX0WxTZL2kQpaQkplWsOK7Fszuvk072DjtGdaZURhHXgiVKfsWOLRJnY1mmZ46fsJLETXg2JDaJ+V/9HGuw/PBgtx+x+D0kq0zNbiqXsK5Xj1edlFxE+o0zq5GG9cI51uPJMjtjTVlWU3tNcnSx8pqS5OKoyiX12uLLm2V8+vXY2SmlydKu1NHkcbKa1ydrGytpcnRj0c3r4uyuQ8FFNncaDol64PSWD2CPkEhkhVOUSaitmPJvUIt7NNskos8Z6t65Dp2FOXdpocU+e/qd6jVcbKIy5a/J8AybnddKTflnpPV/XJ9T6hN921s8qOgAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHqsddikvY+wfp76mVTrplPnwfHDq9E6jPCzISUmtMcD9m9IzlkURae9o68n9p8p9C+ollYdac9vR9OxrvrU7YrFQtstMzykvcsvjtmW18HPut8wSe/AJiRY5ha1kTwShB4kGsT4JTFJQ0U2yCSAIAQyExA4bF2GxA2yNigEB9hsQBkfZGxQAG2TsQlAD7J2KSAMiRdk7KhUyAglDSWSJXgkgLDlLKOyuUOC9ESIuVzTnX1bRyr6OXwd2cdmK6vzwc3rl1eO3DnVp+BN6Zuvr+DFKDTMJOOrvV9NjTOrjXb0jjV8G3GnqRrnTD0y7UXsujyZKZ7NcWdGNOTU4Jx2jHdX5N7fBmtjtM6Z/h43yuBk1PvfBzrYNHdyIcs5eRHWzm3P16/hv8AHNkiCyxclTMq9DN7E7RIhOyargYAAk8AbID3GfASnyDFXkQq6I+tiwL4LkVYbrRix1o6tT0jBQjZHwT1xeq/u2CZWhvYnrj1DbDYmyUxWiRJJCYEVXDbAVeRiejhkOmImMmPqKdMZFex0NFNyLJ6QxXYwGYotkjFfL7TRazJdLUROzyyw2y0uTDZLbNN8jE3tlR6WMheS+BVFGiuJUXV9aZprZTBcF0SnJv/AFfFjplcSxDZU2yUxQGg6YCpkoYBAxDKhUIlEAMjbBtNCgxHwrFaJZBKpC6AYRi4chZeRGMxGJpMoZHIENh0/gbDuEbF2Po+FncT3sr2Gw6PhcrGT9VlOw2H0nWOr1ax42mZMZMPpn/ya42D/UMsWOmP6L/mvUh4yM6ZZGQ/ov8Amv7g2VqQbH9J+IfZPdwVN8g5cB9HMoslwYLpGm2XBhtlyLrbMUvbkX1LkqjzI01oeVVoSWjHkPWzS3pGLIlwzoy5d1htlyU+fBNvkWHg1YIa5HguQGiHTkaKy9eDPAvT4I1p0YyZPk1US5MsY7ZrohyTKvWfx1cd+Do1vg5uPxo3wlwdXnXD6rnyI0id8EMu1gXwSmKyUQqJ8ojSJAQ6NBoCRyJukpESiSBXz0pviidKl7GS3ET9jqa4Kpx2Zaw2z6uDdia8IxWUuL8Ho7Ktrwc7Ip4fBhZx141K51U3FnTxsjWts5va4yY8JNMM6403iWPV4l6aXJ1ISTR5TDye1rk7uPkKUfJ049Xme/i6G+OBYye3sWE9hbNQg2dGb1x2cc/qmdHGplJvWkfn79SPVX1pWUwn7n0T1/6gWHjSSnp8n5r651Gebmzm5N7Zp/hOZbY7JuT9ysAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAExk4yTRAAH0n0D6jeJkQqnPjZ+i+i9UhkUQ7Zb2j8a4OXLFyIzi9aZ94/Tz1N/ERhXOfPHuNWa+2TalHZhufJNOR9SpNP2K7HtnL6OrCExkyvY0TnrXixDJipDICq1eCRYvgbYM6CGwZABDZGwZAgbYbIAQDZKYpIQG2GyNhsZJ2QGwAAkgAB9hsXYbAG2SmJslC6OLExkVpjJlSosOQ2RsktI2BAJiVEOOzPZXs1oSUSNZ60zrjkX0+eDn216fg7tteznX1eTDeOOvz31y3wWU2akRdHRVW/vMP8bWdjtY096OjCXBx8aXg6MJ8Gvnpy7y1KRElsSLHb4OzN/GHP1hvr5ZysmvydyxbObk1+SNR3eO3Btjpmdm/IhrZhktMx09Xy10oAyNmbpSRsNkBC4knfAuwb4GZtkorUuSxMSdLIGupbZjg+TdR5Irm3WylaNK8FEFos2TXHtamTsriyXLgjrCxOxkyruJTEOLdk7K0ydk0+HTG2V7GTIKw6GTK0xkxosWJjxZVseL4KiOHbK5sJSKpyBecqLWYL5faarpHPvnwwd3lliukZk9llstsriVHfn/F0EaazPEvgXE6rTDwWxKoeC6KKculsR0JHwOhs6kCCRoSTsUnYwbZDZGwGOJ2GyAAuDYbDZDYHxDIBsjYGnYsid8CNhxUQyuQzZXJkWNMobFbBsVi40kDYuyGyA4rh9hsUkQ4bZGyABPDJjplaGQFxamOmVodD4mnTHiytFkRovDpjbEQbGzDfJDlwDZXNiVFVszLJ7ZZZIqXLHFxMF9xqS0iqES58I0yjVJZLSMF8/Jouno510+TbLl2SXLIXAvdsnZow/8ATDRFRZFE9bYWRLUyuKHSZlquvEXVPk6NC8HPqhpnRo4JzV7n43VI21oxVM2Vy0jt86832i7wKyW9is0rmQwRBKIqjEAAujiQIJKlTYklCjIuVNydEaJ2Gw1elywkobRkup2nwdDW0VTjsw1lv5+nHBux+3fBjlFpneyaU14OVbVpsxuXZn06orm4vydjCyfHJx3HTLqbHB+RTsGsyx6qq7ejn9c6rDExpOUtcCY+SlS5N+EfMP1F9TfQhKuMvb8no+P+PK9pzXHhP1D9R/xl064T9/yfMZScpNs2dRzJ5WROUnvbMRrWAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAep9J9bl0/Mh9zS2eWHqsdc1JMBH6y9NderzcWH3bej0ympraPz56A9RON0arLNe3LPuPT8pW1KSfDMvTP/rq89uiNHyLH7mNyp69jjv+t5V0USStduyuEm29lQLExkxBkSzpiA3ojYANEEsgRJANhsXAgAAYAAAAAAAABOg0AQBOg0ASiRdhsjgOGxdgVE2H2MivZKei+lxaJsO4gOjh0yXyKhkVmwqrlDaMV9fDOjLwZrY7I3OtvLXHCyIeTHrtkdm+lM5t1SicesO3OuxZRPwdGqezlUvTOhS/As/idR0a+R34KYSaRZ3NnViubU5Sy8GO+O0zbLwZrI7RpV+d5XDyo8s5ti5O7k0rTONfDTZjrL1PDbMxRmhGZWPQzewARsBL4Ak+AFb3wPpREXyXLwVKOh1IlG1kHydHG8owVR2zo48dMmuT0rauEDZCfBDZna5rDxYSZUp6J7tk9Z/J0xkyvehkxdHytTG2VbGUmTRw6YyYiZJPE2HTGTK0xtjRYsGT4K+4nu4GnglIqlImTKLJaG1xnqi+Rzb5cM13z8nOvltBI7/LDLZPbCt8kOOxorRcdXONUFtF8EZq5GqtlxltfBcF0SqPgdMpzVcvAyK1IZMaKcBdhsE8MAuydj6OJAgNgEgRsNiCQbI2AzQyNksUrp8SJIGxWw6OFbK2x2K4ktMk2QxmhWJrCMBmhQVASQShCpIJASaBkQh0gTYZFiQsUMhs6dIZCdzGTH1nTbFbGEkCOUb4KrGS56KLLA62zm8VWS5Fh5B/cx4RWyoL+L4eAm+CY8IpunpGmYy1pnvZzrZcl9972zJJ9zNplz6vUKQ6ZX4GiyvllJ+r4F8EUVmqCRFb4h0h4rkEG9GOq7fOL4tI01SMSkaKXyTlXpPx1aeTXBMx478G+C2js868v2PEGT4IZr1ylBBoCbVwxBGw2JXDAQShwqklEAOl2H2ShEx4hOo1ZV0Y8CziNGXA37kVxnGSUO7ZgyKNc6OtKDj4KMivcPBNy6Mb48/OH3aBQ0tl7hL67TXBVnWwx6pS3wkR/wA/10f9JxzOrdVjgYNrctNI/PnrDrk+oZk0p7Wz2Hrz1O++dNU+HwfJb7XbY5N+WduJzLzPbXdKm9vYAA2QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6PSeoTwsmE4vWmfevRvqeOZjV1ymt6Pzonp7PW+ketyws6tOWltBf2cVm8r9TY1m4KRrX3LZ5z0/1OGfgQlGSbaPQVPWkcPpjldmNdWp64Ja0RKPKLI8omXjToSHXggb2EikZGyZCAkwEIkAAAAIAAAAAAIAEAIAkAAAAAACAAACSSCQAJIACMMhBgIwJkAvIypn4KZrZcytoDzWO6PBzciB2LI8HPyIcGO3X51zo8M2US5RllHRZTLTRi2tdevlFpnpnwaNm+HLtL8FM0W74K5+DcZYMlcM4uTHlndvXDORlR8mend4uZNFTLbPJWzKvW8v8ACAgZBNbJI9yGw2SUMSvIuyY+RVG41UnQofJgpRuqemZ1x7jVsiTF7hZMisOJ2NFlOx4sg+H3yOipPkdMSeLNjJlexkwTVqZOxEydgiw4yZWmMmCacHIXYrYJsEpGa2RZORltmU38ozXyMFstmi+fkxTlyOPR85+IQ6QkS2KKjWrK0aoeCiCNEBufa+PgdCR8DouOenQyETGTGRyCNgCUkkAAMBAAVSBADCQIADQQyRWBwrFYzFYLKyGyWKxKhWQyWKwVEMUZisSwCAEIjIPcESBJQyISGQFaeIwqGXkGVNolACY0G2VyYzZTNj4JCTkZrJltjMdkuSf/AF0Zn4sjLbNEDJXyzXDwXlltY3qJjvnwy+2Wos59tnk6MubbLdPllHeTbLko7uTbLCre4aMihSHTLpRrrka65HPrZqrkY7dGGtSDuK0xtnNp2eZ1I00z5MWy6qXIZXufjt48/B0qpbRxsaXg6tMuDozXme2Wtcohkwe0EjaOKzlVtkbJYo+KiQ2QGw4rphkImMmNNNsPJGyUCOJSGQoyDpWLIssi+SlDphKlpSUkV2QTRFcmWPlGk/S/xys2hRrcj5n6z9QRwsSytTXce99SdVrwcScpSXg/NHrbr8s3qFijP7dmkyL6fjznV+oTzcmUm98nLJbbe2QW56AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACym2VVilF6aKwAPrvoD1ZKqddNk+N/k+5dPy4ZVcZxa5R+QOl508PJjOMmtM+8ehfVcMimFc7OeERvPY189cfW4ra2CeinHvVlSafkt8eTi1OOqa6fY2+CtDoQQxdDMXuQEkCWQBAAAAAAAIAACMAgAAkAAAAAACAAACSSCQAACASZEoUnYAxKRA0WCaloXQ7YoylVTXBivjtG+Zltjsz26fOuXbAqjwzZbExy4Zh/66G2iw2Rls5dUuToVbaNcstRoQskNEJeDon+M5/rHdE5WXHhnZsjtHLzI8Mz07PGuHb+5lTL7l9zKGZV63jfwjIZLFZFdKGw3wQw9hCDfJbXyUc7L6vYmp220o1x4M1JpXgiuPZtkNkbIZnWPE7GiytbHRCuH3yOmVodAzsPslMTYyYJsWp8E7EUidoE2HTG2JslMEWH2LJ8BtEN8DhfKmxmK2RrtkjFcynV5ZYr5GNvk0XyMm9yHHfifi6BpgjNWaoFRWl0EXxRVAtiNy6XR8DCxGKjGpQwpIy4bZIpIFxJJAASQAAKgAAZAAAFBislsVsDhWKyWxWwUhislshsSoVisZisFxBBJAlAEACBkMhUPEE1KQyFGQ2dMhkQiRoqdhsjZKHwgyqRayqQ+HIzWsxT8m24xSX3EcdE/xdQts161Ez0I0zaUS8xjtlvnqLOZZZ5NmTNaZy5y8nRmOTauyZQ58jWMob5Nsxz6XKRbFmWMi6EjTgz/rVBmqDMUGaYSMtx0YrXFlhRCRbvg5dR2+YbHrlyVSeghLkiN7Ox18afg61M+Dg489aOrRZwa5ri9cOtXLgfezNVNaL4vZ1Yv48zeeUNCtFuhJFoV7DYMgB0xKFJRJm2MmKgCHIfYyEGXAUrFkR0tiR5LUiWVPWkvJj6lnww6JSk0uCcrKVEG98I+X+vPV9dONKuFn3a/J0ecZaryv6hesHap01Wfn3PjeRfK+1zk9tmvq3ULM3KnKUm02c42Z2gAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeD0XpvrVnT8uH3tLZ50mMnGSaAP1V6W9SVZmLWvqJy0ezosWQj8sekPU1uDkwhKb1v8n6E9P9Yhl4tc1JNtGHpj/1vjb1Wu0juYtdqmi6MU0c1jfqvu2tC9nOxrI9siYvYjD8aIJa5I0BAA0GgIEkAASBACNJDAAAAAAAAAAgAAAkkgkCSgIRIAEojYAkyGFJFU2GIYJgxxMIyqfguZVPwTpv5sF74ZzbJfcdHJ8M5Vr+4wrszPxfTPk6dE+EcWl8nVofCLyWstqY2yqLLDpn+Oa/lJNcHNy1wdOfg52WuDPTp8r+uBkrlmY2ZK5ZjZlXreNKxGNIUiuyFYewA/AqaC6pGf3NdC2RWe611I0exXWtIsIrk1QAAZ1mlAQBKodDJibJ2CLFiYbETJ2CbFiYyKk+S1Aiw6GEROwTYlsWT+0Gyuchw8xTY+TJc9I0WMxXzKdfnlivfLM8f3FlktsRL3KjszGiBpgZK2aqyhtoiXRKYF0RuPa2PgZCx8E7KZn2ShCUwLhwF2TsCNskUAIxIqJAkgQAySQ/BGwbAykMGyGwWhiksVgaH5FYN8kCVA2KyWKwXAQDYbEpKJQqGQipkShSQTTIeJWh0NFh0N5FQy8lRnUpDJABchFkyqTLWVyQ+HKzWrZllHk2ziJ9MnjT6/CVLQ1z1EdR7TNkT0mXnLHenPyZ+TBKRfkT5ZhlI6Mxy7qJyKmwnIrcjfOWNqzuLIMz7La2Xwo2QZogzJWzTBme8ts1rgXrwZ62aF4OXeXb5Uk2JGXI84iKPJjY7Z+xrqno6NFutcnIi9GqqzQRlvHXoaLNo21yONiW7R06pnRjX48z1x+tmyuT5BS2hWayua5Gw2QBbOpJQo6RFOJQPyMiGuRRcS1pBD73on9yCP2PZfOpq9VqMdlVuSoLnwE712nl/UnW68DEnJyW0vyXnDDVcr1p6nh0/HnGNi3o/PPqHrlvUMme5trf5Op6w9TWdRyppTet/k8VKTk22bycc9qG9vYAAyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWU2yqsUovWmfVvQnq/wCjOFNs+F+WfJTVhZc8W6M4ya0FOXj9hdLz4ZlEZQkntHWjNr3Ph/oP1gtV022f5PseJmV5NCnF72jj9M8rqxrro771sT9pND3Ei393Bk0NvYaBJpEgEBokAJGiBhH5AJ2GyAEE7AgEASAAAAAABAAABJJBIAAAAQ2ShSQIxJAIVLh0SKhhxJGV2eC1lNngWmvm52VLhnGul9x1srwzi3/uMK7sf4tonydWiXCONR5OxjrhFZXqfjfDlFola4LPY6J/jz9f6rl4Ofl+DoT8HOy/DI06PJxMjyzJJGu/9zMsjKvW8FMhGPLyVsiu6An2FHRNFIl9xsoWiiMeTVWtEVlutcfBPuJF8DLyRXLowAQRWadkbIAhcMiSESMqlDCoYE1K8lqKo+SxAinTJ2KgYJDZTYyxlNj4HFY/1mtmYb57L75aZislst2+cZ5PkeK2hH5HgOOqf4sgjVWimCNEEWz3V0fYtiVxLIjce1qfBIqJQ0wyZIpKAG2GyCALh0xhEMgKmJFJ9hpoIbJFYENhshkbBUDYrJFYGhshsGQCitkAyGJUQ2QDIBcGwIASjEoVDIRVJJAARxkIh0VEU6GQiGRUZU6Y6EiuS2MS5EFcRHEua0imb0WXVUlySohvbLEuBcL6Z7eEcrKs8nTyXpHEyp8s0zGWtMF8zE5l9z4Zic+TfMYap5SE2I5B3G+YzPsshIz9xZBl8HWyuRrrZhrZsqZOovNba2aYvgyVvwao+Dk3Hb5U0mItBJio59R6GKfY0Z6K5eBU3szVqOviXaXk6lFuzztNnbpHUxrfBU04fXDtwntFmzHVZtF8ZG+dOHeeLg0LF7ZZo1jn1C6GQaAKUMifYXYyYostb5Y1j4JUdcmHqWbDFplJvWkbYiNVk6x1SvBxZSlJJpHwT1x6vnlXWVVz43+Tq+u/WDlOdNdnxwz5FlZM8i5zk97Z0T8jl3oltsrZuUnvZWAAyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHR6X1O3ByIyjJrTPvPoT1dXlY0arbF3eOWfnU7XROtXdOyYOM2kmTcyqzrj9g4mRCcV2vezb2xa22fLvRXq2GbVFWWLu1+T6LXkK+MXFnNvHHRnXWlTbevYiUtDeIoTW2c9axMW2S3olLSFkOUDuIIROh0gAaAQAACAJAAAAAAAjQaJAC6A2AAE7IAACdE6IJQEnQAA5FROydikhfxltDeiqctoskZ7XwRa08u1z8yWkzi2y3M6mW/JyJr7zPj0sT8aMdbaOxRwkcvFjyjr0R4Q4j01+NcHwWrlFUfBanpG8/xw/wC1XZwjlZcvJ0rnwcnKfkjTs8M9cq/y2ZZM03vlmSTMa9byhJCNDMGRXTKrfA0WQ0CXIqa+tGqETPUjVBGdY+lWJaGTISJM7XNU7I2AECQAAAaUyUyEShAyGQqGQIpkNsVEjRTKRIqJ2NPENme2XBbJma2XBUjXzn6wZEuTFKb2ash8mJ+SndmHS2PFciRLIlRqtizRBmeJogVGW18SxCQLENzahkSiEA08MShUSgIwaAkSUolEEoZGAAAgQBGwHAQ0SQBoYrZLFYKhWxdjMVgriCGSKxKkQyABgqIAABSUMkKvI6EmpSDQEglKGSFGQ4mmSGRCJXkuMdHiXRZWkWxRrIyqZLgzWLTNMnwZbPJchdJHyW70ilEylpBxNrNly4ZwcufLOvlT4Zwsp7bLzGWqw22Npoy62XWIq8G2YxtQ4pFbZZJlT5OjMR1K5LoJoqgjRA04jVWVto2VSZmho0QZNivPTbUzVF7MVcjTW9sw3l3+euLnEjWizXAricm8u3GyNiN6GktFUjm068fqyE+ToY9utHLi9FsLu1kyjfnOPRU38I2QsbOFi37aOvTPaNsaeb7ebdXLlbNHctcGKL29F8X2+TozXBrK4OBVLY8YN8lI5wIZaQNaRlyL41RcnLWisZ7RatvyoU1yc5JaR8l9e+sY0xnVTZz8M2etvWEcSudddi3r2Z8H6z1e3qGTOUpN7Z1TMjl9Ns3Us+zNyZTlJvbMIANzgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE9PYAAeh6B6gu6bkRak9b/J959G+sIdQrhCUlvX5PzMm09o9L6a6/Z03Ji+963+SdZ6rOuP1zjXxuXD2XS4Pn3pP1VVm0Vpy+7X5Pe1Wq6CaZybxx1Z103dyNrYji0x4sx/xaGtASyUg6CgTogCQCAEASAAAAAAAAADIAAAAAAASBAADbDZGyBmZE7F2Q2TaizqJyM1s+BrJ6Md9nBFdPlhmypJ7Oa1uRpum2Uwi3JCds/I1Y0TqVLSRix4eDo1x0kOOb1q+K4GfghcIWUjaf45ZP1Vc+GcjKfk6V0uGcnKl5I09DwjnXsySNNr2zNIxr1fOEJIZDZFbyBkxXIjZZAVF/GipGuCM9SNcFwZ1zelTogZoUyrAAAEqgAAAqlEoglCMyGQqGQIqUNsUkaEkNgRJjPiuUjNbLgtmzJdIqNvKfrHe+TL7l1z5KF5Ldki2JbErgWx8ji1kfJfApiXQKjLbREdFcR0U5tHRIqJAjJkioYCSiRUMCakYVEgkxAENgSdkNkBsDTsggNgYFJbFbBUQxWDYrYKiRGTshiVEAQAKSAAASiSESCaYlCjLwCUoZCoZDhU6JXkhEryXGOlsWWplMS1eDWMqllM47LWxS4hT26RTa9I0WPSMGRZpMfE1iyp+TkX8tmzIt8nOsntmmYy0osjwZ2jTJ8FEkdGcsNVRITXJa0Cib5jO1EEWohR0OkXxNqytM0wRVBF8EybDzeNVUNm2qopxq22jrUY7a8GOo6M+nFKrJdR0Y4j/BMsVpeDk3HV5erjzgZ5ROnfTr2MNkNM5dZen5bZZcCc7LLFyR2mNdN/Y0Y1na/J2ca/hcnn4y0zZj36a5Ca45/Ty69HXYuGaoz7/Bxqb98bOljTWjfGnn+vnxurjrll/ctaMjt44Lo2QhDukzrxOuDf4a22NcG2z5t609Wwwa7K4SW9fk2+sPVdWDVOEJ8/3PgHqPr9vUcqbc203+Tpxnjl36M3XOt3dRyJSlNtNnDb29kttvbILYW9AAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJjJxe0QAB6/0t6ks6fkwUptRTPv3pT1RTn0wX1E3/c/KcZOL2mex9KeqLem5ME5tR2TrPV51x+sYTVkdpk6aPGemfVNPUKI/zE5HsqbVbDZybxx050ZDIVcsju0zHnFmZDBzE7uQBmRsbyiHHQAAQABIEBsAkCAGSQAAAAGQASBAAEhsggKRhJMHIpnMmrzFdrMdvKLrJmef3EurE4zShsaurlcFsYcmiqA5Gt1+LKK9I1x4QkIj6Kkcfpem2Vzb0T3aK7LNIssZ/Wa+Wkzk5MvJtybfJyrp8sz09HxyzzfJVIsk9sqkZV6XnCNoXewkhUiK2DL64vRWjRWTUbq+qJriuDPWXp8EVy7pmITsjZlWQACUStGg0MSCaUlEkoRhDIABFqdghWNFcDSnwJJoaZTJjXmdVTZjukapswXy5Ky6fLLNa9sqXkaT5JijR1SHiWxXIkYl0VwOQqaKL4FcS2JTLS2I5WixeBsKlDIVEoCMSiCUCUk7FfgEBU6ZKYqJBJtkMgn2AIYAwQBDBksVgcQxWMxWCiMUdisFI2QyGAlQAAApIEIkCSSQSCalEoglBEmQyFRKKhaWIZLkWJZHyaRhpZFFmuBYDt8GsjKqpPRCfJE2KmXIlFvhnJy5pb5OnfPUWcDNnyypGdrFfLbZkl5LZy5K3I2zGOqrkuChs0P7loplDR0ZjDVJrZKiCeiyPJrGVpNFtcNjfT2XVVj6XTV17NtOO5PwTj47k1wdvDwnxwTaOkwsJ7W0d/Gw1pcD4uLpLg6VVOtcGWh9M8cRa8CW46SOqocFF0Now1G3n6frzeVR5OTdVp+D09+PvfBy78Xl8HNrD1PH2cC2t78FMl2+To3wcJa0Zrqu5HNrL1PPcrHvb4LIS7WV9vZIZ8mfy6eSt1N+mjpY+V4WzgRl2l9WUoR7pPWjXzzXF/RmSPVwugobkzynqf1ZV0+iUY2La37nG656wrwqZRjYt6Pj3qH1Hb1C6X3vTZ6flnkfPf0bkv4f1L6kt6jkT+9tN/k8pKTk9smUnJ7Yps4LegAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0JOD2mKAB7P0p6os6bkQUpvW/c+/wDpv1Zj9TqgvqR3pcH5PjNwe0z0vpz1Nf03Jg/qPW/yTc9VnXH66jYrIpxY/hHgfSnrTHz8euE5ru17s9vVkRvinFpo5fTHHTjXV65GceCnTTHjMxajwSnsnhhrQgjRAzFYBBDZJDAJT4JFXgkZJJIAAkADYAEbDZGwCSH4I2K5gOFkzPNlspFTexcaZiiSbFUHs0doygHGn1xVGsvrgCiXQRUidbPGOkS0HhCSkXMs/wDarmZLpaTNE58GDIs8hXT55Y8iezn2eTVdMyy8mOnf5ZUtEMeRWzKu7JWhdDsjtIqrS6NVUeClRNdUdRJrLdW1xLdCwLCK5dUnaCQ2wMqmI0QM0QS0BJCJBnQSiBkJSQAAZ1A68CDb4GURMoky2TKZsbfDNbLRgue2ar2YpsvLr8oqfksgiv3LoeDRvxZFF0fBSiyLHEaWIsiVryWxKZaWIsK0WIbCpRIpIiMiRRgKpfggH4IQEdDCokEpJXgUlPgCAENgmBpYrJbFA4GKyRWCoVisligaGAAJUAAAKBJBIElEkIlAmpGRBKHEpHihUPFFxNPFDxXJEUWJGkYaMiZPgEDRpGVUTE3osmiiT0aRCrInwzh5b22dLKt1tHJvntmmY596/WOS5K5ItYjNsxjrSprQsuS1x2gjWbRlaz/TbLq62XfTLqqtyHaksKm/Y24+K5NcG3Dwe9Lg7uL0zhfaRdCseDg71wehxcNJLgsxcJQ9jpV1KK8C+iVV0qPsaIwRKQyQrRUa4Kpx2ae3YrgTYmXjDKnfsY7sZc8HZ+mUW079jO5dHn68rzGVh7TejiZEHFtaPZZFG01o4mViabbRzax+vU8P6HmbINckQ5OhkY+9pIx3L+Hg5S9iZ59enn3nGXJmqvub4R5Hr/qWGNCUISW9EepvUcKa5wjLn+58r6l1OzKtk3Js6vPy5+vJ/t/s/wDIv6r1m3MtluT0cWUnJ7YN7ZB0vE1q6vaAAASAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlNp7RAAHe6J1+/p+RFqxpJ/k+4ekPWsMiqELLOfln5x8HW6X1m/Bti4zaSf5I3n6i864/YmLm1ZVSlFp7LJPT4Pjvoz1tGyMK7bef7n1XDz6MqClGaZza8bHTncrpQZLZWpfjwNvZhfxonYBx+SG/wL6PiQ0Qn+QbKg4gkXYbF1JiRNk9wdBmRshsXYz4lshshsXYdHDbFaDZKYQ5FTiR2l2g7R8V9EjEbtHS0A5lN0VRLYoVDb0i5EftD8FE2WTsM87EV1pmKrZHOvk+TVbZyYrW2RXbhknyylovlEj6ezPUdeNSMrQrRrlStCfRTMbl0z0jLoeMdlkqtERTTIsO7h41l0I6QVx2XxgTWWtIiidDqJOjOsaqJSGcQ8GdhRDQrHZGieK6QdEdpOg4mo9xkRrkkk0gAaBnUBsnQa4GcVyZVMsm9FE5cFSN8RjyPc59kuTbky8nPnyy8x2eUEZcmmHgzRiXwZpI3sWosiVxZbHyPjLSxFsSuKLYorjHR0OhUhkNjUkgkTomkCUQSgJL8EInWw0BJRJCJBKSNk6FbABsEyCABmxdhsgFRLYrJYrYKkQxWS2QCuIAGRsRpAjYIOGkABICSh0KkOgTUolCjLkcSlFkREWwRrIjVPFFqQiWids0zlhqrENrgK47HklFGsyxumayJitemzVdZo5193kuRF0wZkn3HNse2a8mxykZHyzXMcu7+q9CuJdrgXTb8GsZUigWwqLqqHL2N+NhOTW0X9IZKsVz9jqYnTG2vtOph9MXHB2sfCUNcE3QY8LA7UuDs0Y6ivA9dWl4NEY6Rnf0qWMVEsI0SkEhDRPglEpbK6VqYvY+itrt8DxewZ0IiUNoZ/ALxyHBKyW0ppnJzMfh6R2rpqJxOp9Roxq5Oc0tIzvlbXR5+ty89nuOOnKXB819VeqoUQnXCfJo9a+tYQ766bN/2PjPU+p2Zt0pSk3suefHRr+uych+qdUszLpScm0zlt7ZG9gaODWrq9oAABIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA3YHUrsO1ShJrR9V9G+tpyshXdZr25Z8cNOLl2YtqnCTWgv6rOuP2J07qVWRRGUZp7X5N8bF52fnr0j69njuFV09rxyz7L0brtPUKYyjJc/Jyenk6sblei05c7HX2ozRvilwyyM+/wc9xxt/q1z2QiO1olBDSKyWxdi4ngI2BOhyDhWyNjOIdpXCQToNE6H8n1Gg9xg0Hzwd6hDJAkNoqFYXROidEN6KhcGtCTloidiRltvSGvOU226Mk7iq7IX5MVmRz5IbZy2Oe2I1syq/gZXoG+VrrF7NEq1MdSTJrXNUuIrRfJcFLiyK1mlbjsI17LFEsjEzsV9FhDRfGPAutFsfBGojWkdpDQ5DRlYnqtoXRY0K0TYfSANojRFCAJ0ToQQkToleCSbAXQEkC4kbIb4AWQ5FZiqbKJsumzLZI0jpxGTI52Y2uTVa9md+S47POcQkWxQkSyJTXSyKLI+RIlkfI2OlsS2JVEtiNhpYiSESNlTLwSRHwAkpJFJAGJIACSSQAEkhkisRAgkgBEAAAqIYrJYrYLiGQQ2GwVAyCSAMEkEjCSUQiQJKHQmyUxJphl4FHQ8/6mpiX1lKXJfWjfMZaXJcEqA0UMbZc26hS7UU3X8E2y0jm32+eTSMNVN12znX2eRrLd+5mse2UztZ7JbZTotlFuRfVjOXsaRjq/rPGDZroxHJrg3UYDeuDr4vT9a4H1DDi9O3rg6+PgKOuDfRiJJcG2FCXsHUqsfGUUuDbGtJBCGizQJqUkSLpjIJU0aDROidAXQkMg0SIqPBKF8B3pFSJTrkWyyMYvkz5GTGqLbkkeE9TetKenVzXetr5LkJ2+veoKen485SsjtL8nwn1d+oVmRZOuqXHjg4fq31tkdSyZquxqL/DPCXXzuk3Jt7K7xXWjO6hbl2ylOTezF5ACUgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACyq6dU1KL0e19N+sr8CyEZWPtXyeGJjJxe0By8fqT0v6qx+pVwU5ruPaK2vt3Fn5H6J6lyemXRcbGkn+T6/6a/UCvKhGu+1b+WZb8+unz9P/wCvrldql7jTkorg42H1Cq+tSqkns2q1z8nJrNjqnK092w7itPgjuIafK5SGUjP3kqY4Xw0dyI7invDvKlK4XbDZUpDKS/JpKzuTjITvX5DvX5CiRZsO4q+ovyQ57FFcWOZXZZpCORXN7QykUXXtJ8nLyMprfJryd6Zw8uTTYmmYi3Mf5M0srfuY7bOShzZPW8jqLJ48jLJ+TlK0ZWB03YhlfJphlL8nCjYy6FrFVSu9C9S9y5NM4dV7TN1WRzyyarrpKKG7Smu6L9zRHUhcF0TtY6i0XRgmS4EaibpTonRZ2kNEXJfStoVosaFM7lUpNBofQaIuVyk0GhtBoj5PpdEaH0ToPkrVeg7S3tDQvkuqXEqmaXoosQ5GmKzT8GK6WjbPwzBkJlyOvzZJy2xAlvZKKkdefxKRZFCpFiQ+HaaI8fJCQ8UDLVWRLY+CuJYvA2OjoYhADOmXgkhPgASklCkoCMSKSBJJIAAkgnZAECCSAOIIfgnZDYKhWIxmIwXIgCABSQI2TsQBJBIBKJIRI0oJRBKQJqxDxEii2CLzGdp4ovgiqCL4m2Yy1Tp6Qs7O1BJ6Rmvn9jNsxzbqnIyfPJy7rm2+S23cm9FH0Jyfg0jl1WeUpNjQhKRrhgzk/wBp0sXpz43EbO1z8fBlNp6Ovi9O8fadPFwIxS4OlVjxih9Z2udThJa4OhVjqKXBcq0vBbFcD6ksYJFi0QT2gXTJjCLQ8UmCbRslA4gkCbTIdIWLQ6Gjo0Q3onaKbbFFcsuQHc0/cwZubXjVSlKSWkcvq3Xsfp1U3OxJpHxz1f8AqTNqdVFm/bhlyB6H1j+oFWLGddVnKPh/XfU2R1K6Tdjab/Jzep9Wuz75Tsk3t/k5jewtBpTc3tsUAEQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA14edbi2KUJNaMgAH1X0v68so7a7Z8fJ9W6V6jozq4tWR21+T8r12yrluLaPUdD9UXYVsdzel8mesSujz9bP8AX6drzVLhPgtdya4Z806H6yqy6YQc13f3PY4eT9VKantHNrzsel57zY7MZvY7t0jIsqGte5KTlzvgyubGvJV0L3KemW9/yZZSUVx5FU2IfLb9TRDtZlUmOuSpUXK36zG+pwVJEtcF9Z3PEux7LYT2Z+17L64Maau8oTtLowJcASw317izgZ2O23werlX3Lwc/JxO7fArV5rxN1Ek3wZ3Br2PVXdO3vgw29NfPBna2mnB+mw1o3W4zhLWjLZW0H0OkU9FkbjO0yUHTlbI3lsb+fJh3wTFsOm7NGRrXJ1cfIT1yeYrm17nRx72muQKvTVzTXku3wcmi/hcm+Fm4iqVjI0SnsdR2TwdVNFbNEoiKHJNipVOiS7sRHaRcqlVaDRZpE6Qvg/pWuESS48hoPgvoJESQ6QNE/BfTPJaKpmma4KJR4D5bY0x2mG5nQvjrZzbk9lTLt89MlnLJhHaH7NsthDSK+XR9EURkixRDtD5TdCKLYiKJZFBxF0dIZIhDIXEWmJIJ2HE9AAiQIEkaJAgvIxCJAgAAABKIARJbFZOxWxHEMVslsUFxDFJbF2CoBWyWxWwVBsnYmwTEFiGRWmMmAsORsgnRSaZMeLK0iyKGztWJlsHwVJF1ceC8T9Y7p4l0URCs0QrN5HPrTPKLM9lbktHT+jtCrH+7wayObdcmGG9+DVVifB04Y6/BohQl7FxhqsNOMl/Sb6qUvYsjUl7F0Y6BnURgkWJBoZISEpDJEpDJDLpfHJMX3Da2Hb2lJtH0tjRXaEZbG7dj4lDk2iY+NDJIlpFSJpVDXJHf7MWVirXLON1brVOHU5Smlr5KmUt+XnV40HKUkkjw3qL1zj4NU+22PcvbZ4v1h+o8IxnVVPn4Z8b6t6gyM+6UnN6b/Jf+B6z1T69yOpTnGM3r4Z8+yMqy+blKTeyqU3J7bFFaAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlNp8EAAdHB6pdiWxlGbWvk+k+m/XCjGNdsv+z5KW1XzqknFtCs60x6XL9NdN6zVmJOMkd2u7ceGfnDonqrIw7IqVj1/c+q9C9Y42TXFTsXdr8mWvN3+X9Ev+vfVqTluXgu0jkY3Vqrku2SZ0K7u/wc2sOqblaNEpMiC2aa60yeC6VJMujDa5Lo0oZV6KkZ3UVxr+C+FevYmMdFiRTO1CjoNbZZ2go6YM7S9vBVOCZp1wVuOyKcrJKiL9jPZjRfsdLsKrIEVpNOFf06MtvtOZk9P1vUT1cobiZLcdS9jPq5XjLcJr2Mk8ecT2dmCpexkt6avwHVyvJOEk+SU9HdyOnLXCOdbhyivBXVsymkaKrkmZZ1yi/BEdpldDt05KWuToVZS15PNRskjRXlNcbBNeoryE/c1QvX5PM1Zb/JqhmP8AIku/9WLDvRxY5r/JdDL2/IcDp9weTJHIT9y+FiYcHT6YaY6aJ4HwdQo8ENDb4Fb5D5FoIZINE3KeqpCNcFrRXJcC+WudMd63s59sOTqWR2Zp1bHMuvz0wqsnt5NP09ewKsrjpmlCiw7TT9P4IcBcL6VRiP28DqI3bsXC+lSQyTLOwlRFxPVeidFnaDiLhdIkSD4IJNIASgAJABEAAAAACGAQxWyRWJUDYoMhgqIbEbGYgLidiskVgpBKIJRJGRKIQyAVKJ2QMkXEUyLIiRiWRQ2Wjo01LgoUTTTHg0xP1z+t/GitGqESmuJpijokcd0ZRQ6gvwRFFsUaRjqojEtigUR1wUyo0SkCHQJqNDINDJCZ0yGISG0VIkIbXcCQ8VoqRNqIwSG2hZy0Uu5Q5kyuJWybXuYcnqEMeD7pJHO6r6ixsOuXdYlo+R+r/wBQYR74U28+2mXIT3vXvW2LgVz3Yt6/J8S9Xev7c6coU2NL4Z4/q3qTLz7JOdsmn8nDnNze2x9C/JzbcmblObezMAEkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACU2nwbcXqd+LJOEmjCAHLx7ro3rXIpsjGyb0fVfTvqnHzYxU7Ft/J+cVJxe0zqdO63fgzTjN8fIuStM+uo/WePfRZFOM0zdUk/B8F9N+vp98IXT1/yfYeh9exsumLVsW2vyZa846M+3Xo4x0hlASNkLYpxkjTBprtM/k76K1FD9v4H/AIbfOyez6fyFyn76q017E+R1NP2Ga2iLB9K9ENFnaQ0RVdVsrlHZa0IyKqVS17COBf2kOJnY0mmZw0UzrTNkolUohxU0wWY6a8GK7BUk+Ds9hEqk/YFzTyt/TF+DDZguPhHsp4yfsZ54KfsHar6eOljzX9LKXTJPemeyl06P+kw3dO+7wHTlecUpR9mWRul8nUs6fr2M08Nr2YdP8VRuZbHI0/JROiS/JU4yX5H0+R1K8nnyba8rXucCM5Itje0HVfMeihmfJbHK2eehks1V5I/ofMdtX7RKs2c+u3ujvZfCfPkuVnY3R5LFHZRU0/c1RW15H+MrFco6RVJM19q/IsooqSCWsMoFMoG2aRTJIqSN86rJKAKBocUSoIORr91n7CHWa1WiHWLh/wDSsirHVRf2B2k3I+6q+mQ46LXEhwJuVfdVaI0W9pHaL5H0pcRe0vcRXEXzGk0q0Gh+0jtF8n9FAbQaF8jpQG0RoXB1BDJFfkOHKBGMQw4qK2RsZoVoXFxDQrGYrQuLhWxGx2hdC4oLwGw0QTxNqyPI/sLBFqRUhWkXktiL2lkUXIz1oyRZFBGJbCBcy59aPCGzXVVpCVQNdcODXGXN66/EwjovjEWMS6MTfkclqEiyL5JURlHkbO0yG1shIlAztSoDJaBD9oIuguUSt78BGD3stclH2DiLRGPBOiO/uJclFcsuRPTcLyyud0YLyY8rOhWmnJI8h171ZT02qT+rFtfJpIT1GZ1amiLc5paPCepfXuNh1SVV0XL4Z8w9TfqPdkSlCqXHjg+b5/WMjNscp2N7+Rl1671F67ys22ahY9M8Rk5tuTNynJtszuTk9tkB0gAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsqunVJOLaPSdJ9XZeA4r6stL5PLgBy8fcfTn6lpyhC6X+WfVOj+oaM+qM4zXPyfj+q+ymScZNHruhetMrp7jF2y0vkXJVzb9aVZCmuJF8WpeT4r0D9SqZxjG6x7/ufSOlepcXOrThYtv5C4V9R6Xsj7IXsaKqchT1po0dyZlrCpSaFaLCGjHWVSqJIRovaEcTKxcqkhjuPIjQuLlK+RXEcNC4qVV2EOJcxWieKlUuIriXNCtCXKpcSqdSfsae0O0VV1gljJ+xTPCT9jqdodiEf04VnT9+xlt6dx+09K60VSpTA5p5eWA/wUzwpL2PUyxo/gqliRfsHVfTyrxpRDtlE9FZhL8GWeF8B0/pz673GOmy2GXr3LJYT/BW8SS9h/RtVWcl7mqPUYr3OV/DTXsH0bPwOaRY7C6jFvyEs9fk4307E/BElYVNlI6U85fkqecvycyUbCtqwc20jr/xi/JbHMj+Th/zB4ysKml13o5SZYrkziVzmjVXZL3K+kddRS2PGOzJVYa65ofR0/wBMPpjqSHWmBfTO6iPpmrtIcA4PtjdYrgbHARwJsXNsbgR2GpwF7A4ubZ+wjsNPYK4E8OaZ3EVxNDiI4hxU0o0I0XuIriLi5VOiGi3tIcRcX1S0K0WNCtC4qVXojQ+mRoXFyk0GhtBoXD6rceSVAtUdjqAuJulUVosQ/YSoFSM7ouh4RGjWX11fBcyx1sQgXwhyPCsuhXyaSObWzVwNEYkVxLlEuTjn3oRRdFCxiXRiXKwtQkOlySojKPJURaFElRHSHUSpGdpFEsUSdA5JDmUWo70nol61tme6+uEXJtcHm+req8bAjLvmuPk0mUdelsyK60+UjzHXfU1PT6pSdi/yfNvUX6oUxUo0WPf9z5T1v1jndRslu6Xa/kfODr6P6j/U5ds66pc/lM+XdV9UZfUJy7rZafycK26dsm5NtlYdSedkrHuT2IACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAN6AAC+nLtpknGTR6ronrTL6fOK+o9L5PHBvQ+n1+g+gfqbXYoRuuPonSvVGLnRTham2fj6rJsqluMmj0/Q/WGV062L720vkP9VNP15VkxsW0y9STPh3Qv1OhNRjbYl/c97031hiZaWr4b/uZ6wv6e01vwK4mPD6hXdFOMkzodymjK+avpS47EcC+S0iv6mnrRlcqmmeUWhdmtxU1+CiWP2veyLlU0RLYNIbu1xoRrbIsXKhpMhxLFD5FmtEVc0r0T28EoYUP6VNBosaIaHwfStitFjQvaLh/SpoXRd2kOIlzSlx2Uzq2a3EXtEf0xOr4FdG/Y3OHwCh8EK+2BYy/A38JF+xu7SdB0rpgeFF+xXLAj+DqaRHaPpfTjzwI/gplgL8Hd+mvwQ6l+B9ObeeeB8ErBSXg77oX4K5Urfgf0r764n8Jr2I+i17HadK/AjoX4HNj6cuKkvY0Qk0aXR8EfR17FTZfRIzZohMqVTLY1suaT9L4vYwkYMtUSvovovbsVxLe0HEqCbZ3EVxNDiL2jXNqO0VxNHaQ4hxc2zOJW4mpxIcA4ubY3EVxNbrK3AVi5tmcRJI0uAvYTxf2ySixO17Nrr+BHD4DhzbP2EdiNHaR2h8q/6M7gR2Gnt+A7PgPk/+iiMdFsUOq9jRrYvlF9C9g8ay6NZdGv4KmWWvRRGovhXosjDT8FiW/Y0mXPr0EYIsjAauvZpjSXMufW1cI6LVHYyqHjHT0P5Za0iMS2MSyMOAf2+w5lndBRJ0NGW/YiySgu7Zcyi6C2N3JHNyOrUUxbnOMdfk8z1T1vhYkZavg2vk0mU2vZX5cKk25aPOdU9VYeGn33JaPlfqD9U3qUKZp/2PmHWPV+V1CyTdkkn8lc4m19Y9SfqcqnOGPdv/AJPlXW/Wmb1Gct2PT+TzF2TZdJuUmykOpW25E7ZNybZUAEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABZC+yt7jJo6/TvUOXhzTVsuPk4gAH2X01+pzxu2F3P8Adn0zpnr/ABM2Mf5kYt/J+UI2Sg+GbaOrZWO12WyX/I/xXX7Gxev41yX82L/5OnDMpsW46Z+R+l+s8zGnHuuk0vk+oemv1Hx3GMb58/LJuJVTT7X3d/7RlXL3Z5rpvq3AyoR7Jrn5O9T1Cq5JxkiL5Kmlkq+7heSt48l7l31Iv9rDbZjfJcrO4SXuI4vZr0n5J7EzK+S/pmil7gy2UNeCvtZPxxUpdEaH0RoXD6XtIcR9BomxUqvtIcR9ENE2KlV6I0WNENC4fS6I7Sfckn5BdB2j6DtD5JXoNFvaT2oOEp0Tot7URpBwuk0R2/BZpB2isOaVdi/BHYvwXdpHaL5P6Uutfgj6SfsX9odpUg+lCq+BlX8F2g0VIOq1AZRJAqF0dpHaMBrC6TtI7C3Qdoz6qcBHA0doOI1TTL2fBPZ8F3aHaNX2ocCqVZqaEcdhVTbI6yPpmlwDsFxX2zOv4K3UbXAX6Y+D/ox/R+Cfo/Br7CewfD/6Mf0fgPo/Bt+mT9ND4f8A0ZI0/A6p+DUqxlWLiL6M8avgtjWXqsdVlSMteij6fwWQr+C6NfJohUjSZYa2ojXosUGy51kxjouZZ3Sv6UvyWwq0uSJ2xguWYcnqUKk25pJfJcyi6dF6XuVyvrgvuaPHdT9Z4uGpd1i2vk+fde/U6C7o02f9lfPEWvr+b6gxMRNuyH+TyHWv1DxcWEmpRevk+DdW9b5mXOXbdLT+TzOT1bKyG++2T38h+RPX0r1J+pM8xzjS+1fDPnmb1zKyptu2XPycuU5S8sUXSWTusm/uk2VgAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALqsmyl7jJopAA7+F6ozsSS7bZaXye26F+peTTKMbrnr+58qJUnF8MfT6/T/R/1EwciEe+9dx6zF9UYF6Wrkz8f0dQuoacJyX/ACdjE9XZ2M1qyXHyP8q5t+vKupY9qTjNM1QvjLwz8vdO/UrNpcVKx6PoHQP1Lhd2q61L+7J+JVTb7J5Qrjs85geq8LJhFu+HPydivquLZHasi/8Akz35Lm2pwI7StZtMvE0Wwtrn4kjG+VVNl0Q4l2ovwyO0i+dV9xToXtNHYR2L8k3zp/cZ9EaNDgitx0T/AM6f3FLjyHaXKIOJPyr6VaJ0PoNB8j6I/BHI7TBIVg+oTlhplmiRcL6irtYyRatCvyEyVpGgG1sOwr5LpCB+wOwPk+kJ0N2hofD6XQdowyQ+DqvQaLO1EqK/I+F0iRKiM1ojY+DoaEY+2yO0fB0mg0Wdga0Pg6qcCO0t0T28D4Os7gHYWuIJP8Bw/pU4EdnJpUU/IOCS4ZXB9s30yfplyTfsWKvY5C+2ZVk/TNSqG+kivkf9GVVjxgaPpx15ISivcf8Azqb6EjWWKtEO2qC25Iot6pi1L7rYr/kuedZ30aXFRQv1lBcs891H1ZhYsJP68ePk+fdd/U2NLlGmxP8AsyphndPrWR1WmlfdNI4ub6uwsdPdy4Pz/wBS/UrNvlJRsejzWZ6tzcnfdZLn5KT9PufWP1KxalJQv5Pm3W/1JzLrJRpufb/c+dX51t7blNv/AJMzk35DqbXczfU2blyffY3v5ORbkTte5PZSAdIb2AAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJTa8F1OXbS04zaKAAO/i+qM3G123S4+TvYn6i51MVF2S/yeCAfT6+rYf6n5Kku6b/AMnsej/qTG1xU5r/ACfnlSa8MvpzLqnuM2v+QP6frjp3q3HyYr+ZH/J3Kur0TSasj/k/ImF6nzMXWrZf5O/ifqFl1a7rG/8AkORU0/Usc2qfia/yN3wl4mj85Yv6oWwa7pP/ACd/B/VOMmlOX/ZPxD+n29f7h1o+cdO9f42SluX/AGekxfUdF6Wprn5JvmqV6PQOJgqzY2Lamtf3NMbov+pGd8lfSzQcIFZB/wBSBzh+UL/kPocEA5w9mRtf6if+R/Q8kdjJTX5LUl+Sf+Q6p7WTvRa0SqtoX/MdU9wdxc6RXUP4P6V72GuSzs0HaHwfVbRDRb2h2B8DqrRKRZ2B2h8jqlxeyUmXdmyHWx/JdV6J0Oq2N9KQ/kvpXwG0Oq2vINJD+T6TuQdyDugvdB31/lD+R2I7l+CHL4Gc6/ygVlevKKmCuoTuX4HWn7Cudf5QjvhH+pD/AOY+lrr7lwL9Fp7bM88+uC5kv8mS/ruPTFuUl/kqYK11O5RJWRBfg8dm+t8GhPclx8nl+ofqfiVbUH/2VMJtfWv4qrXMkim3Poiv/siv+T4Lnfqp3bUJNf8AJ5zM/UbLt322tf8AJXzE/T9B5/qXGxU92w4+TyfUf1IoxtqM4v8A5Pgud6qzspvd0ufk493UMi1/dZJ/8jTdPsfU/wBWLHtQl/2eUzv1IzMjaVkl/wAnz2VkpPlsXYup69Bmeqc3K2pWy0/k49uXba9ym2ZwDpJbb8sgAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATtr3HjfOL4kwAA24/V8mhrtsa/wCTrY3q/Pp1q6X+QAfT67WL+o/UKYpO5/5OnT+qOZHW7H/kAA+uhT+qty/dP/s2Q/VZ+8/+wAB1dH9Vo/6v+y6v9VYN8z/7AAPtbaf1Qpfma/ydLH/UnGm1u1f5ACeDtdrF9c4d2v5q/wAnWo9TU2v7ZrQAKyLldCrq8LP6jVDMjL3ABcNbG6Mvcbvj+QAOQ+p74fknvh+UAC5B0d8PyK5w/IAPkHSvJrguZGezqFUf6gAXAzy6zTD+pGe71LRWv3IADhOVk+tMenbc0cDN/UnGr2lNf5ACpCtcS/8AVKtN6kv8mOf6qL2l/wBgA+J+qol+qr/1/wDZRP8AVWzfE/8AsAGXWaz9VL9cWP8AyYrv1QzJeLX/AJABjrnX/qP1Czern/k5mT636jdFp3S/yAD6PquRf17Mu33Wy/yc+zLtsf3SbABdTapc2/cjbABEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//Z" alt="Gifts" style="width:28px;height:28px;object-fit:contain;border-radius:50%;">
                            <span>Gifts</span>
                        </div>
                        <div class="menu-row-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </div>

                    <div class="menu-row">
                        <div class="menu-row-left">
                            <i class="fa-solid fa-ticket"></i>
                            <span>My Top-Up Coupons</span>
                        </div>
                        <div class="menu-row-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </div>

                    <div class="menu-row">
                        <div class="menu-row-left">
                            <i class="fa-solid fa-chart-simple"></i>
                            <span>Game statistics</span>
                        </div>
                        <div class="menu-row-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </div>

                    <div class="menu-row">
                        <div class="menu-row-left">
                            <i class="fa-solid fa-globe"></i>
                            <span>Language</span>
                        </div>
                        <div class="menu-row-right">
                            <span>English</span>
                            <i class="fa-solid fa-chevron-right"></i>
                        </div>
                    </div>
                </div>

                <!-- 5. Service Center -->
                <div class="service-section">
                    <div class="service-title">Service center</div>
                    <div class="service-grid">
                        <div class="service-item">
                            <i class="fa-solid fa-gear service-icon"></i>
                            <span class="service-label">Settings</span>
                        </div>
                        <div class="service-item">
                            <i class="fa-solid fa-clipboard-list service-icon"></i>
                            <span class="service-label">Feedback</span>
                        </div>
                        <div class="service-item">
                            <i class="fa-solid fa-bullhorn service-icon"></i>
                            <span class="service-label">Announcement</span>
                        </div>
                        <a href="{{ support_url }}" target="_blank" rel="noopener" class="service-item">
                            <i class="fa-solid fa-headset service-icon"></i>
                            <span class="service-label">Customer Service</span>
                        </a>
                        <div class="service-item">
                            <i class="fa-solid fa-book-open service-icon"></i>
                            <span class="service-label">Beginner's Guide</span>
                        </div>
                        <div class="service-item">
                            <i class="fa-solid fa-cube service-icon"></i>
                            <span class="service-label">About us</span>
                        </div>
                    </div>
                </div>

                <!-- 6. Logout Button -->
                <button class="btn-logout" onclick="location.href='/logout'">
                    <i class="fa-solid fa-power-off"></i> Log out
                </button>
            </div>
        </div>
        <div class="sub-fab-right" onclick="window.open('{{ support_url }}','_blank')" style="cursor:pointer" title="Customer Service"><i class="fa-solid fa-headset"></i></div>
<div class="gift-modal-backdrop" id="gift-modal" onclick="closeGiftRedeemModal(event)"><div class="gift-popup-card" onclick="event.stopPropagation()"><i class="fa-solid fa-gift"></i><h3 style="color:white;margin-bottom:6px;">Gift Code</h3><p style="color:#a7a0d8;font-size:.8rem;">Enter a code to test the gift UI.</p><input type="text" id="gift-code-input" class="gift-input" placeholder="ENTER CODE HERE"><div style="display:flex;gap:10px;"><button class="btn-claim-gift" style="background:#38306e;" onclick="closeGiftRedeemModal()">Cancel</button><button class="btn-claim-gift" onclick="claimGiftCode()">Test Code</button></div></div></div>

<script>
function openGiftRedeemModal(){location.href="/gift";}
function closeGiftRedeemModal(e){if(!e||e.target===e.currentTarget){const m=document.getElementById("gift-modal");if(m)m.style.display="none";}}
function claimGiftCode(){location.href="/gift";}
function copyUID(){
 const text={{ uid|tojson }};
 if(navigator.clipboard){navigator.clipboard.writeText(String(text)).catch(()=>{});}
}
function refreshMasterBalance(){document.querySelectorAll('[data-balance]').forEach(e=>e.innerText='₹{{ balance }
 location.reload();
}
</script>
<div class="account-logout-fixed"><button class="btn-logout" onclick="location.href='/logout'"><i class="fa-solid fa-power-off"></i> Log out</button></div>
<!-- Bottom Navigation - New Design -->
<nav class="bottom-navbar">
    <a href="/home" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      <span>Home</span>
    </a>
    <a href="/activity" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2zm-7 10.25l-2.61 1.56.69-2.97-2.3-2 3.03-.26L12 7l1.19 2.58 3.03.26-2.3 2 .69 2.97L12 13.25z"/></svg>
      <span>Activity</span>
    </a>
    <a href="/spinwheel" class="wheel-item">
      <div class="wheel-wrapper">
        <svg viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="46" fill="#7522c7" stroke="#9d3efa" stroke-width="2"/>
          <circle cx="50" cy="8" r="2" fill="#ffd700"/>
          <circle cx="80" cy="20" r="2" fill="#ffd700"/>
          <circle cx="92" cy="50" r="2" fill="#ffd700"/>
          <circle cx="80" cy="80" r="2" fill="#ffd700"/>
          <circle cx="20" cy="80" r="2" fill="#ffd700"/>
          <circle cx="8" cy="50" r="2" fill="#ffd700"/>
          <circle cx="20" cy="20" r="2" fill="#ffd700"/>
          <circle cx="50" cy="50" r="40" fill="#b066fe" stroke="#d5a5ff" stroke-width="2"/>
          <path d="M50 50 L50 14 A36 36 0 0 1 81 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L81 32 A36 36 0 0 1 81 68 Z" fill="#c026d3"/>
          <path d="M50 50 L81 68 A36 36 0 0 1 50 86 Z" fill="#00e5ff"/>
          <path d="M50 50 L50 86 A36 36 0 0 1 19 68 Z" fill="#c026d3"/>
          <path d="M50 50 L19 68 A36 36 0 0 1 19 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L19 32 A36 36 0 0 1 50 14 Z" fill="#c026d3"/>
          <circle cx="50" cy="50" r="13" fill="#00b4d8" stroke="#ffffff" stroke-width="1.5"/>
          <text x="50" y="53" fill="#ffffff" font-size="7" font-weight="900" text-anchor="middle" font-family="'Poppins', sans-serif">SPIN</text>
          <polygon points="50,6 45,13 55,13" fill="#60a5fa" stroke="#ffffff" stroke-width="0.8"/>
        </svg>
      </div>
      <span class="wheel-label">Get ₹500</span>
    </a>
    <a href="/promotion" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
      <span>Promotion</span>
    </a>
    <a href="/account" class="nav-item active">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
      <span>Account</span>
    </a>
</nav>
</body>
</html>
"""

support_html = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Self Service Center</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; -webkit-tap-highlight-color: transparent; }
    body { background-color: #f0f2f5; display: flex; justify-content: center; min-height: 100vh; }
    .mobile-container { width: 100%; max-width: 480px; background-color: #ffffff; min-height: 100vh; display: flex; flex-direction: column; box-shadow: 0 0 15px rgba(0,0,0,0.05); position: relative; }
    .header { display: flex; align-items: center; justify-content: space-between; padding: 14px 18px; background-color: #ffffff; border-bottom: 1px solid #f0f0f0; }
    .header-left a { font-size: 22px; color: #333333; text-decoration: none; }
    .header-title { font-size: 17px; font-weight: 600; color: #222222; }
    .header-right { display: flex; align-items: center; gap: 6px; font-size: 14px; font-weight: 600; color: #333; }
    .flag-icon { width: 22px; height: 15px; border-radius: 2px; object-fit: cover; }
    .banner-container { background: linear-gradient(135deg, #120038, #3b007a, #001057); padding: 20px 16px; color: #ffffff; position: relative; overflow: hidden; }
    .banner-title { font-size: 18px; font-weight: 700; color: #ffeb3b; line-height: 1.3; margin-bottom: 6px; }
    .banner-badge { display: inline-block; background: rgba(255, 255, 255, 0.15); border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 20px; padding: 3px 10px; font-size: 11px; margin-bottom: 10px; }
    .banner-features { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; }
    .feature-chip { background: #0044ff; border-radius: 12px; padding: 3px 8px; font-size: 9px; display: flex; align-items: center; gap: 4px; font-weight: 500; }
    .content { padding: 16px 18px; flex: 1; }
    .section-heading { font-size: 16px; font-weight: 700; color: #222222; margin-bottom: 12px; }
    .service-list { display: flex; flex-direction: column; }
    .service-item { display: flex; align-items: center; justify-content: space-between; padding: 14px 4px; border-bottom: 1px solid #f2f2f2; text-decoration: none; cursor: pointer; }
    .service-item:active { background-color: #f8f8f8; }
    .item-left { display: flex; align-items: center; gap: 14px; }
    .icon-circle { width: 42px; height: 42px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 18px; color: #ffffff; flex-shrink: 0; }
    .icon-orange { background: linear-gradient(135deg, #ffb300, #f57c00); }
    .icon-purple { background: linear-gradient(135deg, #a01077, #72095b); }
    .item-label { font-size: 14px; font-weight: 600; color: #333333; }
    .chevron { color: #b0b0b0; font-size: 14px; }
    .tips-box { margin-top: 24px; padding-top: 10px; }
    .tips-title { font-size: 14px; font-weight: 700; color: #333333; margin-bottom: 8px; }
    .tips-text { font-size: 12px; color: #777777; line-height: 1.5; margin-bottom: 8px; }
    .action-container { padding: 16px 18px 25px; }
    .btn-progress { width: 100%; background: linear-gradient(180deg, #ffbb00, #f59e0b); color: #ffffff; border: none; padding: 14px 0; font-size: 16px; font-weight: 600; border-radius: 30px; cursor: pointer; box-shadow: 0 4px 10px rgba(245, 158, 11, 0.3); }
    .floating-chat-btn { position: fixed; bottom: 85px; right: max(20px, calc(50% - 220px)); width: 55px; height: 55px; border-radius: 50%; background: linear-gradient(135deg, #ff9800, #f57c00); color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 24px; box-shadow: 0 6px 18px rgba(245, 124, 0, 0.45); cursor: pointer; z-index: 999; }
    .chat-modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.6); display: none; justify-content: center; align-items: flex-end; z-index: 10000; }
    .chat-container { width: 100%; max-width: 480px; height: 85vh; background: #ffffff; border-radius: 20px 20px 0 0; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 -5px 25px rgba(0, 0, 0, 0.2); animation: slideUp 0.3s ease-out; }
    @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
    .chat-header { background: linear-gradient(135deg, #3b007a, #120038); color: #ffffff; padding: 15px 18px; display: flex; justify-content: space-between; align-items: center; }
    .chat-header-info h3 { font-size: 15px; font-weight: 600; }
    .chat-header-info small { font-size: 11px; color: #ffd54f; }
    .close-chat-btn { font-size: 20px; cursor: pointer; color: #ffffff; opacity: 0.85; }
    .uid-section { background: #f8fafc; padding: 10px 15px; border-bottom: 1px solid #e2e8f0; }
    .uid-badge { padding: 8px 12px; background: #ede9fe; border-radius: 8px; font-size: 13px; font-weight: 600; color: #5b21b6; }
    .chat-body { flex: 1; padding: 15px; overflow-y: auto; background: #f4f6f9; display: flex; flex-direction: column; gap: 12px; }
    .chat-bubble { max-width: 80%; padding: 10px 14px; border-radius: 14px; font-size: 13px; line-height: 1.4; word-break: break-word; }
    .bubble-user { align-self: flex-end; background: linear-gradient(135deg, #a01077, #72095b); color: #ffffff; border-bottom-right-radius: 2px; }
    .bubble-agent { align-self: flex-start; background: #ffffff; color: #1f2937; border: 1px solid #e5e7eb; border-bottom-left-radius: 2px; }
    .bubble-time { font-size: 10px; opacity: 0.65; margin-top: 4px; text-align: right; }
    .chat-footer { padding: 12px 15px; background: #ffffff; border-top: 1px solid #eee; display: flex; gap: 10px; align-items: center; }
    .chat-footer input { flex: 1; padding: 11px 16px; border: 1px solid #ddd; border-radius: 25px; outline: none; font-size: 14px; }
    .chat-footer button { width: 44px; height: 44px; border-radius: 50%; background: linear-gradient(180deg, #ffbb00, #f59e0b); border: none; color: #ffffff; font-size: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center; }
  </style>
</head>
<body>
  <div class="mobile-container">
    <header class="header">
      <div class="header-left"><a href="/account"><i class="fa-solid fa-arrow-left"></i></a></div>
      <div class="header-title">Self Service Center</div>
      <div class="header-right">
        <img src="https://flagcdn.com/w40/us.png" alt="US" class="flag-icon" />
        <span>EN</span>
      </div>
    </header>

    <div class="banner-container">
      <h1 class="banner-title">Welcome to Our<br />Self Service Center!</h1>
      <div class="banner-badge"><i class="fa-solid fa-headset"></i> 24/7 Support • Fast, Secure &amp; Easy Service</div>
      <div class="banner-features">
        <div class="feature-chip"><i class="fa-regular fa-comment-dots"></i> Quick Response</div>
        <div class="feature-chip"><i class="fa-solid fa-shield-halved"></i> Secure Service</div>
        <div class="feature-chip"><i class="fa-solid fa-headphones"></i> Easy Support</div>
      </div>
    </div>

    <main class="content">
      <h2 class="section-heading">Self Service</h2>
      <div class="service-list">
        <div class="service-item" onclick="openChatWithTopic('FAQ')">
          <div class="item-left"><div class="icon-circle icon-orange"><i class="fa-solid fa-comments"></i></div><span class="item-label">FAQ</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Deposit Not Receive')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-solid fa-wallet"></i></div><span class="item-label">Deposit Not Receive</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Withdrawal Problem')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-regular fa-credit-card"></i></div><span class="item-label">Withdrawal Problem</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('IFSC Modification')">
          <div class="item-left"><div class="icon-circle icon-purple" style="font-size:11px;font-weight:800;">IFSC</div><span class="item-label">IFSC Modification</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Delete Withdraw Bank Account')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-solid fa-money-check"></i></div><span class="item-label">Delete Withdraw Bank Account and Rebind</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Delete UPI and Rebind')">
          <div class="item-left"><div class="icon-circle icon-purple" style="font-size:11px;font-weight:800;">UPI</div><span class="item-label">Delete UPI and Rebind</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Change ID Login Password')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-solid fa-lock-open"></i></div><span class="item-label">Change ID Login Password</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Change Bank Name')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-solid fa-building-columns"></i></div><span class="item-label">Change Bank Name</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Delete Old USDT Address')">
          <div class="item-left"><div class="icon-circle icon-purple" style="font-size:14px;font-weight:800;">®</div><span class="item-label">Delete Old USDT Address and Rebind</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
        <div class="service-item" onclick="openChatWithTopic('Game Problems')">
          <div class="item-left"><div class="icon-circle icon-purple"><i class="fa-solid fa-headset"></i></div><span class="item-label">Game Problems</span></div>
          <i class="fa-solid fa-chevron-right chevron"></i>
        </div>
      </div>
      <div class="tips-box">
        <h4 class="tips-title">Kind tips</h4>
        <p class="tips-text">1. Please select the relevant query and submit it for review. After successful submission, the customer service specialist will handle it for you immediately.</p>
        <p class="tips-text">2. After submitting for review, you can use [Question in progress] to view the review results of the work order you submitted.</p>
      </div>
    </main>

    <div class="action-container">
      <button class="btn-progress" onclick="openTicketChat()">Progress Query</button>
    </div>
    <div class="floating-chat-btn" onclick="openChat()" title="Open Live Support">
      <i class="fa-solid fa-headset"></i>
    </div>
  </div>

  <div class="chat-modal-overlay" id="chatModal">
    <div class="chat-container">
      <div class="chat-header">
        <div class="chat-header-info">
          <h3>24/7 Live Customer Service</h3>
          <small>UID: {{ uid }}</small>
        </div>
        <i class="fa-solid fa-xmark close-chat-btn" onclick="closeChat()"></i>
      </div>
      <div class="uid-section">
        <div class="uid-badge"><i class="fa-solid fa-user"></i> Your UID: <b>{{ uid }}</b></div>
      </div>
      <div class="chat-body" id="chatBody">
        <div class="chat-bubble bubble-agent">
          Welcome to ShreeWin Support! For fastest help chat on Telegram @Shreewinofficial01_bot
          <div class="bubble-time">System</div>
        </div>
        {% for m in my_msgs %}
        <div class="chat-bubble bubble-user">
          {{ m.message }}
          <div class="bubble-time">{{ m.time }}</div>
        </div>
        {% if m.reply %}
        <div class="chat-bubble bubble-agent">
          <small style="color:#e11d48;font-weight:700;">Support Agent</small><br>
          {{ m.reply }}
          <div class="bubble-time">Replied</div>
        </div>
        {% endif %}
        {% endfor %}
      </div>
      <div class="chat-footer">
        <input type="text" id="chatInput" placeholder="Type your message here..." onkeypress="if(event.key==='Enter') sendMessage()" />
        <button type="button" onclick="sendMessage()"><i class="fa-solid fa-paper-plane"></i></button>
      </div>
    </div>
  </div>

  <script>
    function openChat() {
      // Live support via official Telegram bot
      window.open('{{ support_url }}', '_blank');
    }
    function openTicketChat() {
      document.getElementById('chatModal').style.display = 'flex';
      var body = document.getElementById('chatBody');
      body.scrollTop = body.scrollHeight;
    }
    function closeChat() {
      document.getElementById('chatModal').style.display = 'none';
    }
    function openChatWithTopic(topic) {
      openChat();
      var input = document.getElementById('chatInput');
      input.value = 'I have a query regarding: [' + topic + '] - ';
      input.focus();
    }
    async function sendMessage() {
      var input = document.getElementById('chatInput');
      var text = input.value.trim();
      if (!text) return;
      var form = new FormData();
      form.append('message', text);
      try {
        await fetch('/support', { method: 'POST', body: form, redirect: 'follow' });
        window.location.href = '/support?sent=1&open=1';
      } catch (e) {
        alert('Network error. Please try again.');
      }
    }
    if (location.search.indexOf('open=1') !== -1 || location.search.indexOf('sent=1') !== -1) {
      openChat();
    }
  </script>
</body>
</html>
"""

deposit_html = """


<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>Shree.Win - Deposit</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"><link href="https://fonts.googleapis.com/css2?family=Delius&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet"><style>
        :root {
            --bg-dark: #161239;
            --bg-card: #241d4c;
            --bg-card-alt: #1c1740;
            --bg-card-inner: #1f1b40;
            --primary-purple: #8d7ff7;
            --primary-gradient: linear-gradient(135deg, #a78bfa 0%, #7c66f6 100%);
            --btn-purple: #9b8df8;
            --btn-amount-bg: #2d275e;
            --btn-amount-active: #8d80f8;
            --text-white: #ffffff;
            --text-light: #b0a9d8;
            --color-green: #00e676;
            --color-orange: #ff9800;
            --color-red: #ff4d4f;
            --color-gold: #ffb800;
            --pay-card-bg: #2b245e;
            --input-dark: #272153;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Delius', 'Nunito', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #000;
            display: flex;
            justify-content: center;
            min-height: 100vh;
            overflow-x: hidden; overflow-y: auto;
        }

        /* Mobile Container Frame */
        .app-container {
            width: 100%;
            max-width: 400px;
            min-height: 100vh; height: auto;
            background-color: var(--bg-dark);
            display: flex;
            flex-direction: column;
            position: relative;
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 0 20px rgba(255,255,255,0.1);
        }

        /* Smooth Screen Transition Styles */
        .app-screen {
            display: none;
            flex-direction: column;
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            background-color: var(--bg-dark);
            opacity: 0;
            transition: opacity 0.25s ease-in-out;
            z-index: 1;
        }

        .app-screen.active {
            display: flex;
            opacity: 1;
            z-index: 5;
        }

        /* Shared Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 16px;
            color: var(--text-white);
            background-color: var(--bg-dark);
            z-index: 10;
        }
        .header .back-btn {
            font-size: 1.1rem;
            cursor: pointer;
            padding: 5px;
        }
        .header .title {
            font-size: 1.25rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .header .history-link {
            font-size: 0.9rem;
            color: #d8d4fd;
            text-decoration: none;
            cursor: pointer;
        }

        /* Scrollable Area */
        .scrollable-content {
            flex: 1;
            overflow-y: auto; -webkit-overflow-scrolling: touch; flex: 1; min-height: 0;
            scrollbar-width: none;
        }
        .scrollable-content::-webkit-scrollbar {
            display: none;
        }

        /* Floating Support */
        .sub-fab-right {
            position: absolute;
            bottom: 25px;
            right: 15px;
            width: 52px;
            height: 52px;
            border-radius: 50%;
            background: radial-gradient(circle, #00f5a0 0%, #00d9e9 100%);
            box-shadow: 0 0 15px rgba(0, 245, 160, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: 3px solid rgba(255, 255, 255, 0.4);
            z-index: 15;
        }
        .sub-fab-right i { color: #1e1b4b; font-size: 1.5rem; }

        /* ================= 1. ACCOUNT VIEW STYLES ================= */
        .profile-header {
            background: linear-gradient(180deg, #9b89ff 0%, #6e55f8 50%, var(--bg-dark) 100%);
            padding: 24px 16px 15px 16px;
            position: relative;
        }
        .profile-row {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .avatar-wrap {
            position: relative;
            width: 72px;
            height: 72px;
            border-radius: 50%;
            border: 2px solid rgba(255, 255, 255, 0.6);
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            flex-shrink: 0;
            background: #25204d;
        }
        .avatar-wrap img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .user-details {
            display: flex;
            flex-direction: column;
            gap: 4px;
            flex: 1;
        }
        .username-row {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .username {
            color: #ffffff;
            font-size: 1.15rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .vip-badge {
            background: linear-gradient(135deg, #e2e8f0 0%, #94a3b8 100%);
            color: #1e1b4b;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 800;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        .uid-pill {
            background: rgba(255, 152, 0, 0.9);
            color: #ffffff;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            width: fit-content;
            cursor: pointer;
            margin-top: 2px;
        }
        .last-login {
            color: #d1ccff;
            font-size: 0.72rem;
            margin-top: 2px;
        }

        .main-padding { padding: 0 14px; }

        .wallet-card {
            background-color: var(--bg-card);
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 14px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.25);
        }
        .wallet-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .wallet-left {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .wallet-title {
            color: #a7a0d8;
            font-size: 0.9rem;
        }
        .balance-value-row {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #ffffff;
            font-size: 1.8rem;
            font-weight: bold;
        }
        .balance-value-row i {
            font-size: 1.1rem;
            color: #a7a0d8;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .btn-enter-wallet {
            background-color: #beb4ff;
            color: #2b2361;
            border: none;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
            cursor: pointer;
        }

        .wallet-actions-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            text-align: center;
        }
        .w-action-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            cursor: pointer;
            text-decoration: none;
        }
        .w-action-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
        }
        .w-action-icon.arwallet { background: rgba(255, 77, 79, 0.15); color: #ff4d4f; }
        .w-action-icon.deposit { background: rgba(255, 152, 0, 0.15); color: #ff9800; }
        .w-action-icon.withdraw { background: rgba(0, 186, 242, 0.15); color: #00baf2; }
        .w-action-icon.vip { background: rgba(0, 230, 118, 0.15); color: #00e676; }
        .w-action-label {
            color: #ffffff;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .history-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 14px;
        }
        .history-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            text-decoration: none;
        }
        .hist-icon-wrap {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }
        .hist-icon-wrap.game { background: #1a73e8; color: white; }
        .hist-icon-wrap.trans { background: #00c853; color: white; }
        .hist-icon-wrap.dep { background: #e53935; color: white; }
        .hist-icon-wrap.with { background: #fb8c00; color: white; }
        .hist-text { display: flex; flex-direction: column; overflow-x: hidden; overflow-y: auto; }
        .hist-title { color: #ffffff; font-size: 0.95rem; font-weight: bold; line-height: 1.1; }
        .hist-sub { color: #8f88c2; font-size: 0.72rem; margin-top: 2px; white-space: nowrap; }

        .menu-card {
            background-color: var(--bg-card);
            border-radius: 14px;
            overflow-x: hidden; overflow-y: auto;
            margin-bottom: 14px;
        }
        .menu-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            cursor: pointer;
            text-decoration: none;
            color: #ffffff;
        }
        .menu-row:last-child { border-bottom: none; }
        .menu-row-left { display: flex; align-items: center; gap: 14px; font-size: 0.95rem; font-weight: 600; }
        .menu-row-left i { font-size: 1.2rem; color: #9b8df8; width: 22px; text-align: center; }
        .menu-row-right { display: flex; align-items: center; gap: 8px; color: #7b74ba; font-size: 0.85rem; }

        .service-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 18px;
        }
        .service-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 16px; }
        .service-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            row-gap: 20px;
            column-gap: 8px;
            text-align: center;
        }
        .service-item { display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; text-decoration: none; }
        .service-icon { font-size: 1.6rem; color: #8d7ff7; }
        .service-label { color: #ffffff; font-size: 0.82rem; font-weight: 600; line-height: 1.2; }

        .btn-logout {
            width: 100%;
            background-color: transparent;
            border: 1px solid #4a3e8e;
            color: #ffffff;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 30px;
        }

        /* ================= 2. DEPOSIT VIEW STYLES ================= */
        .deposit-pad { padding: 10px 14px 155px 14px; }
        .balance-card {
            background: var(--primary-gradient);
            border-radius: 16px;
            padding: 20px 18px;
            color: white;
            position: relative;
            overflow-x: hidden; overflow-y: auto;
            margin-bottom: 15px;
            box-shadow: 0 4px 15px rgba(124, 102, 246, 0.25);
        }
        .balance-label {
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 8px;
            opacity: 0.95;
        }
        .balance-amount {
            font-size: 2rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .balance-amount i { font-size: 1.2rem; cursor: pointer; transition: transform 0.4s ease; }
        .balance-card .dots-bg {
            position: absolute;
            bottom: 8px;
            right: 15px;
            color: rgba(255, 255, 255, 0.3);
            font-size: 1.1rem;
            letter-spacing: 2px;
            font-weight: bold;
        }

        .channels-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 15px;
        }
        .channel-card {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 4px 10px 4px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            position: relative;
            border: 1px solid transparent;
            min-height: 86px;
        }
        .channel-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .channel-icon-wrap {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 6px;
        }
        .channel-name { color: white; font-size: 0.72rem; font-weight: 600; line-height: 1.1; }
        .channel-badge {
            position: absolute;
            top: -4px;
            right: -2px;
            background-color: var(--color-red);
            color: white;
            font-size: 0.65rem;
            font-weight: bold;
            padding: 2px 5px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 2px;
        }

        .amount-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .section-title {
            color: white;
            font-size: 1.05rem;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 14px;
            font-weight: bold;
        }
        .section-title i { color: #b0a5fa; }

        .amount-grid-deposit {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 15px;
        }
        .amount-btn {
            background-color: var(--btn-amount-bg);
            border: 1px solid rgba(255, 255, 255, 0.05);
            color: #bcb6ea;
            padding: 12px 5px;
            border-radius: 8px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
            transition: all 0.2s ease;
        }
        .amount-btn:hover, .amount-btn:active, .amount-btn.active {
            background-color: var(--btn-amount-active);
            color: white;
            box-shadow: 0 2px 8px rgba(141, 128, 248, 0.4);
        }

        .amount-input-box {
            background-color: var(--bg-card-inner);
            border-radius: 25px;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .amount-input-box .currency-sym {
            color: #958df1;
            font-size: 1.1rem;
            font-weight: bold;
            padding-right: 10px;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
            margin-right: 10px;
        }
        .amount-input-box input {
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: #ffffff;
            font-size: 0.95rem;
        }
        .amount-input-box input::placeholder { color: #7b74ba; }
        .amount-input-box .clear-btn { color: #7b74ba; font-size: 1rem; cursor: pointer; padding: 2px 5px; }

        .instruction-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .instruction-inner {
            background-color: var(--bg-card-inner);
            border-radius: 10px;
            padding: 14px;
        }
        .instruction-list { list-style: none; }
        .instruction-list li {
            position: relative;
            padding-left: 18px;
            color: #9e97d8;
            font-size: 0.82rem;
            line-height: 1.45;
            margin-bottom: 14px;
        }
        .instruction-list li:last-child { margin-bottom: 0; }
        .instruction-list li::before {
            content: '◆';
            position: absolute;
            left: 0;
            top: 0;
            color: #8d80f8;
            font-size: 0.75rem;
        }

        .sub-no-data-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px 0 10px 0;
        }
        .sub-no-data-icon { width: 170px; height: 120px; opacity: 0.85; margin-bottom: 10px; }
        .sub-no-data-text { color: #ffffff; font-size: 1.15rem; font-weight: 500; }

        .history-card-item {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-left: 4px solid var(--color-green);
        }
        .history-card-item.pending { border-left-color: var(--color-orange); }
        .history-card-item.rejected { border-left-color: var(--color-red); }
        .history-card-left .hist-amount { font-size: 1.1rem; font-weight: bold; color: white; margin-bottom: 2px;}
        .history-card-left .hist-utr { font-size: 0.75rem; color: var(--text-light); }
        .history-card-right { text-align: right; }
        .history-card-right .hist-status { font-size: 0.8rem; font-weight: bold; text-transform: capitalize; }
        .history-card-right .hist-time { font-size: 0.7rem; color: var(--text-light); margin-top: 2px; }

        .status-approved { color: var(--color-green); }
        .status-pending { color: var(--color-orange); }
        .status-rejected { color: var(--color-red); }

        .deposit-bottom-bar {
            position: fixed;
            bottom: 64px;
            left: 0;
            right: 0;
            background-color: #171337;
            padding: 12px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 150;
            max-width: 400px;
            margin: 0 auto;
            box-shadow: 0 -4px 16px rgba(0,0,0,.22);
        }
        .recharge-method-info { display: flex; flex-direction: column; }
        .recharge-method-info .label { font-size: 0.78rem; color: #ffffff; margin-bottom: 2px; }
        .recharge-method-info .method-name { font-size: 0.95rem; color: #ffffff; font-weight: bold; }
        .deposit-btn {
            background-color: var(--primary-purple);
            color: white;
            border: none;
            padding: 10px 28px;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }

        /* Gateway Screen (ArUpiPay) */
        .cs-pill-btn {
            background: linear-gradient(90deg, #7c67ff 0%, #6852ee 100%);
            color: white;
            font-size: 0.8rem;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            cursor: pointer;
            font-weight: 600;
        }
        .pay-amount-bar {
            background-color: var(--pay-card-bg);
            border-radius: 12px;
            padding: 16px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .pay-amount-left { display: flex; align-items: center; gap: 12px; color: #ffffff; font-size: 1.7rem; font-weight: bold; }
        .pay-amount-left i { font-size: 1.25rem; color: #d1ccff; cursor: pointer; }
        .pay-timer { color: var(--color-red); font-size: 1.15rem; font-weight: bold; letter-spacing: 0.5px; }

        .pay-bullet-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
        .pay-bullet-title::before { content: '•'; color: #ffffff; font-size: 1.3rem; line-height: 0; }

        .pay-methods-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
        .pay-method-card { border-radius: 12px; padding: 12px 10px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; cursor: pointer; transition: transform 0.15s ease; }
        .pay-method-card:active { transform: scale(0.97); }
        .pay-method-card.paytm { background: linear-gradient(135deg, #d4f8ff 0%, #a4e6f9 100%); color: #042e6f; }
        .pay-method-card.phonepe { background: linear-gradient(135deg, #fce8ff 0%, #ebd0fc 100%); color: #5f259f; }
        .pay-logo-wrap { display: flex; align-items: center; gap: 6px; font-size: 1.05rem; font-weight: bold; margin-bottom: 4px; }
        .pay-logo-img { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.85rem; font-weight: bold; }
        .paytm .pay-logo-img { background-color: #002e6e; font-size: 0.6rem; }
        .phonepe .pay-logo-img { background-color: #5f259f; font-size: 1rem; }
        .wake-text { font-size: 0.75rem; color: #8b80cf; font-weight: 600; }

        .qr-card {
            background-color: #372f78;
            border-radius: 14px;
            padding: 22px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            margin-bottom: 22px;
        }
        .qr-image-wrapper {
            background-color: #ffffff;
            padding: 12px;
            border-radius: 14px;
            display: inline-block;
            margin-bottom: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        .qr-image-wrapper img { width: 180px; height: 180px; display: block; margin: 0 auto; }
        .qr-upi-info { color: #332d5e; font-size: 0.82rem; font-weight: bold; margin-top: 8px; font-family: 'Nunito', sans-serif; }
        .qr-desc { color: #ffffff; font-size: 0.88rem; line-height: 1.45; text-align: left; width: 100%; margin-top: 6px; }
        .qr-desc p { margin-bottom: 8px; }

        .utr-warning-text { color: var(--color-red); font-size: 0.95rem; line-height: 1.35; font-weight: bold; margin-bottom: 12px; }
        .utr-input-box {
            background-color: #272153;
            border-radius: 30px;
            padding: 6px 6px 6px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 22px;
            box-shadow: 0 0 10px rgba(186, 104, 200, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .utr-input-box input { background: transparent; border: none; outline: none; color: #b7b0ee; font-size: 0.95rem; width: 70%; }
        .utr-paste-btn { background-color: #8d80f8; color: #ffffff; border: none; padding: 8px 18px; border-radius: 20px; font-size: 0.9rem; font-weight: bold; cursor: pointer; }
        .reminder-list { color: #ffffff; font-size: 0.9rem; line-height: 1.6; margin-bottom: 25px; }

        .pay-bottom-bar {
            position: fixed !important;
            bottom: 0 !important;
            left: 0;
            right: 0;
            max-width: 400px;
            margin: 0 auto;
            background-color: #1a1540;
            padding: 12px 16px calc(12px + env(safe-area-inset-bottom, 0px));
            display: flex !important;
            gap: 12px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 2000 !important;
            box-sizing: border-box;
        }
        .btn-cancel { flex: 0.35; background-color: #38306e; color: #ffffff; border: none; padding: 12px 0; border-radius: 8px; font-size: 0.95rem; font-weight: bold; cursor: pointer; }
        .btn-submit-utr { flex: 0.65; background: linear-gradient(90deg,#8b5cf6,#7c3aed); color: #fff; border: none; padding: 14px 0; border-radius: 12px; font-size: 1rem; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(124,58,237,0.4); }
        .btn-submit-utr.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 12px rgba(141, 128, 248, 0.4); }

        /* ================= 3. WITHDRAW VIEW STYLES ================= */
        .withdraw-pad { padding: 10px 14px 40px 14px; }
        .arpay-banner {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 14px;
        }
        .arpay-logo { font-size: 2rem; color: #ffb800; font-weight: 900; line-height: 1; }
        .arpay-text h4 { color: white; font-size: 1.05rem; font-weight: bold; margin-bottom: 2px; }
        .arpay-text p { color: #9e97d8; font-size: 0.8rem; }

        .methods-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 14px;
        }
        .method-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            min-height: 90px;
            transition: all 0.2s;
        }
        .method-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .method-icon { font-size: 1.8rem; margin-bottom: 6px; height: 36px; display: flex; align-items: center; justify-content: center; }
        .method-name { color: white; font-size: 0.8rem; font-weight: 700; letter-spacing: 0.5px; }

        .account-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
            cursor: pointer;
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: 0.2s;
        }
        .account-card:active { transform: scale(0.98); }
        .account-left { display: flex; flex-direction: column; gap: 4px; }
        .account-name-row { display: flex; align-items: center; gap: 8px; color: white; font-size: 1rem; font-weight: bold; }
        .account-vpa { color: #9e97d8; font-size: 0.9rem; font-weight: 600; }
        .account-card i.fa-chevron-right { color: #7b74ba; font-size: 0.95rem; }

        .add-bank-box {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 24px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            margin-bottom: 6px;
        }
        .dashed-plus-icon {
            width: 46px;
            height: 46px;
            border: 2px dashed #7a70bb;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7a70bb;
            font-size: 1.5rem;
            margin-bottom: 12px;
        }
        .add-bank-text { color: #8c82cb; font-size: 1rem; font-weight: bold; }
        .add-bank-warning { color: var(--color-red); font-size: 0.8rem; text-align: center; margin-bottom: 14px; line-height: 1.3; }

        .amount-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 14px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.88rem;
            margin-bottom: 8px;
            color: #bcb6ea;
        }
        .btn-all-pill {
            background-color: #38306e;
            color: white;
            border: none;
            padding: 3px 18px;
            border-radius: 14px;
            font-size: 0.8rem;
            font-weight: bold;
            cursor: pointer;
        }
        .received-val { color: #ff9800; font-weight: bold; font-size: 1.1rem; }

        .withdraw-action-btn {
            width: 100%;
            background-color: #d1cbff;
            color: #7a6fc7;
            border: none;
            padding: 14px;
            border-radius: 25px;
            font-size: 1.05rem;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 20px;
            transition: 0.2s;
        }
        .withdraw-action-btn.ready {
            background: var(--primary-purple);
            color: white;
            box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4);
        }
        .val-red { color: var(--color-red); font-weight: bold; }

        .btn-all-history {
            width: 100%;
            background-color: transparent;
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #bcb6ea;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
        }

        /* Payment Method Screen (UPI Sub-Screen) */
        .pm-account-card {
            background-color: #262153;
            border-radius: 14px;
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            margin-bottom: 15px;
        }
        .pm-card-header-stripe { height: 38px; background: linear-gradient(90deg, #0066ff 0%, #0088ff 100%); width: 100%; }
        .pm-card-body { padding: 18px 16px; color: #ffffff; }
        .pm-info-row { font-size: 1rem; color: #d1ccff; margin-bottom: 12px; letter-spacing: 0.3px; }
        .pm-info-row .bold-text { color: #ffffff; font-weight: bold; }
        .pm-current-tag { display: flex; align-items: center; gap: 8px; color: #a49fc7; font-size: 0.92rem; margin-top: 14px; }
        .pm-check-circle { width: 20px; height: 20px; background-color: var(--color-red); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.75rem; }
        .pm-bottom-bar { position: fixed !important; bottom: 0 !important; left: 0; right: 0; padding: 16px; background-color: #1a1540; z-index: 99999 !important; max-width: 400px; margin: 0 auto; box-shadow: 0 -4px 20px rgba(0,0,0,0.5); }
        .btn-add-method { width: 100%; background: linear-gradient(90deg,#8b5cf6,#7c3aed) !important; color: #fff !important; border: none; padding: 16px; border-radius: 30px; font-size: 1.1rem; font-weight: 800; cursor: pointer; box-shadow: 0 4px 15px rgba(139,92,246,0.5); }

        /* Add Bank Sub-Screen */
        .ab-notice-pill { background-color: #272153; border-radius: 20px; padding: 10px 14px; display: flex; align-items: center; gap: 10px; margin-bottom: 18px; color: var(--color-red); font-size: 0.8rem; line-height: 1.35; }
        .ab-form-group { margin-bottom: 16px; }
        .ab-label { color: #ffffff; font-size: 0.95rem; font-weight: bold; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .ab-label i { color: #8d7ff7; font-size: 1rem; }
        .ab-select-box { background: linear-gradient(90deg, #6b55fb 0%, #503ef0 100%); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; color: #ffffff; cursor: pointer; font-size: 0.95rem; font-weight: bold; }
        .ab-input-box { background-color: var(--input-dark); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; }
        .ab-input { width: 100%; background: transparent; border: none; outline: none; color: #ffffff; font-size: 0.95rem; font-family: 'Delius', sans-serif; }
        .ab-input::placeholder { color: #766eb5; }
        .ab-bottom-bar { padding: 14px 16px; background-color: var(--bg-dark); }
        .btn-save-bank { width: 100%; background-color: #d1cbff; color: #7a6fc7; border: none; padding: 15px; border-radius: 25px; font-size: 1.1rem; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .btn-save-bank.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4); }

        /* Bank Selector Modal */
        .bank-modal {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 50;
            display: none;
            flex-direction: column;
            justify-content: flex-end;
        }
        .bank-modal-content {
            background: var(--bg-card);
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            padding: 20px;
            max-height: 70vh;
            display: flex;
            flex-direction: column;
        }
        .bank-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 14px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .bank-list { overflow-y: auto; flex: 1; }
        .bank-item {
            padding: 14px 12px;
            color: #d1ccff;
            font-size: 0.95rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .bank-item:hover, .bank-item:active { background: rgba(255,255,255,0.08); color: white; }

        /* Gift Claim Popup Modal */
        .gift-modal-backdrop {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 100;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .gift-popup-card {
            background: var(--bg-card);
            border-radius: 18px;
            width: 100%;
            max-width: 320px;
            padding: 24px 20px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.6);
            border: 1px solid rgba(255,255,255,0.1);
        }
        .gift-popup-card i.fa-gift { font-size: 3rem; color: #ffb800; margin-bottom: 12px; }
        .gift-input {
            width: 100%;
            background: var(--bg-card-alt);
            border: 1px solid rgba(255,255,255,0.1);
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-size: 1rem;
            text-transform: uppercase;
            text-align: center;
            margin: 14px 0;
            outline: none;
            font-family: 'Nunito', sans-serif;
            font-weight: bold;
        }
        .btn-claim-gift {
            width: 100%;
            background: var(--primary-purple);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }
    .bnav{position:absolute;bottom:0;left:0;right:0;background:#16122e;z-index:100;border-top:1px solid #2a1f55}.bnav img{width:100%;display:block}.bnav-links{position:absolute;inset:0;display:flex}.bnav-links a{flex:1;height:100%;display:block}

/* Bottom Navigation Fix */.bottom-navbar{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:400px;height:65px;background:#141332;border-top:1px solid #26244f;display:flex;justify-content:space-around;align-items:center;z-index:1000;padding-bottom:5px;box-sizing:border-box}.bottom-navbar .nav-item{display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:#5d5c88;font-size:11px;font-weight:600;flex:1}.bottom-navbar .nav-item svg{width:26px;height:26px;fill:#5d5c88;margin-bottom:2px}.bottom-navbar .nav-item.active{color:#6965e8}.bottom-navbar .nav-item.active svg{fill:#6965e8}.bottom-navbar .wheel-item{position:relative;top:-16px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;flex:1.2;text-decoration:none}.bottom-navbar .wheel-wrapper{width:72px;height:72px;position:relative;display:flex;justify-content:center;align-items:center}.bottom-navbar .wheel-wrapper svg{width:100%;height:100%}.bottom-navbar .wheel-label{position:absolute;bottom:-6px;white-space:nowrap;font-size:13px;font-weight:900;color:#ffe600;text-shadow:-1.5px -1.5px 0 #b30000,1.5px -1.5px 0 #b30000,-1.5px 1.5px 0 #b30000,1.5px 1.5px 0 #b30000}.scrollable-content{padding-bottom:90px !important}.screen-payment-gateway .scrollable-content, #screen-payment-gateway {
            padding-bottom: 90px !important;
        }
        #screen-payment-gateway .pay-bottom-bar {
            z-index: 2000 !important;
        }
        .bottom-navbar.hidden-for-pay, .bnav.hidden-for-pay {
            display: none !important;
        }
</style>
<style>
/* smooth deposit polish */
.app-container, .app-screen, .scrollable-content {
  -webkit-overflow-scrolling: touch;
  scroll-behavior: smooth;
}
.amount-btn, .channel-card, .deposit-btn {
  transition: transform .15s ease, background .2s ease, box-shadow .2s ease;
}
.amount-btn:active, .channel-card:active, .deposit-btn:active {
  transform: scale(0.96);
}
.amount-btn.active {
  box-shadow: 0 4px 14px rgba(141,128,248,.45);
}
.channel-card.active {
  box-shadow: 0 4px 14px rgba(104,82,238,.4);
}
.deposit-bottom-bar {
  backdrop-filter: blur(8px);
  box-shadow: 0 -8px 24px rgba(0,0,0,.25);
}
#screen-payment-gateway {
  animation: fadeIn .25s ease;
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: none; }
}
</style>
</head><body><div class="app-container"><style>#screen-deposit.app-screen.active{display:flex!important;opacity:1!important;position:relative!important;z-index:1!important;height:auto!important;min-height:100vh!important}#screen-payment-gateway{display:none}#screen-payment-gateway.active{display:flex!important}</style><div class="app-screen active" id="screen-deposit" class="app-screen active">
<div class="header">
<div class="back-btn" onclick="window.location.href='/account'"><i class="fa-solid fa-chevron-left"></i></div>
<div class="title">Deposit</div>
<a class="history-link" href="/deposit-history">Deposit history</a>
</div>
<div class="scrollable-content deposit-pad" id="deposit-scroll-area">
<!-- Balance Card -->
<div class="balance-card">
<div class="balance-label">
<i class="fa-solid fa-wallet"></i> Balance
                </div>
<div class="balance-amount">
<span id="deposit-balance-val">₹{{ balance }}</span>
<i class="fa-solid fa-arrows-rotate" id="refresh-deposit-btn" onclick="refreshMasterBalance()"></i>
</div>
<div class="dots-bg">**** ****</div>
</div>
<!-- Channels Selector -->
<div class="channels-grid">
<div class="channel-card active" data-channel="UPI-QR" onclick="selectDepositChannel(this)">
<div class="channel-icon-wrap"><i class="fa-solid fa-qrcode" style="font-size: 1.8rem; color: #00e676;"></i></div>
<div class="channel-name">UPI-QR</div>
</div>
<div class="channel-card" data-channel="Innate UPI-QR" onclick="selectDepositChannel(this)">
<div class="channel-icon-wrap"><i class="fa-solid fa-qrcode" style="font-size: 1.8rem; color: #38ef7d;"></i></div>
<div class="channel-name">Innate UPI-QR</div>
</div>
<div class="channel-card" data-channel="PAYTM" onclick="selectDepositChannel(this)">
<div class="channel-icon-wrap"><i class="fa-solid fa-mobile-screen-button" style="font-size: 1.8rem; color: #00baf2;"></i></div>
<div class="channel-name">PAYTM</div>
</div>
<div class="channel-card" data-channel="ARPay" onclick="selectDepositChannel(this)">
<div class="channel-badge"><i class="fa-solid fa-gift"></i>+2%</div>
<div class="channel-icon-wrap"><i class="fa-solid fa-shapes" style="font-size: 1.8rem; color: #ffbc00;"></i></div>
<div class="channel-name">ARPay</div>
</div>
<div class="channel-card" data-channel="Expert UPI-QR" onclick="selectDepositChannel(this)">
<div class="channel-icon-wrap"><i class="fa-solid fa-qrcode" style="font-size: 1.8rem; color: #ff5722;"></i></div>
<div class="channel-name">Expert UPI-QR</div>
</div>
</div>
<!-- Amount Section -->
<div class="amount-section">
<div class="section-title"><i class="fa-solid fa-money-bill-wave"></i> Deposit amount</div>
<div class="amount-grid-deposit">
<div class="amount-btn active" onclick="onDepositAmountClick(100)">₹ 100</div>
<div class="amount-btn" onclick="onDepositAmountClick(300)">₹ 300</div>
<div class="amount-btn" onclick="onDepositAmountClick(500)">₹ 500</div>
<div class="amount-btn" onclick="onDepositAmountClick(1000)">₹ 1K</div>
<div class="amount-btn" onclick="onDepositAmountClick(2000)">₹ 2K</div>
<div class="amount-btn" onclick="onDepositAmountClick(3000)">₹ 3K</div>
<div class="amount-btn" onclick="onDepositAmountClick(5000)">₹ 5K</div>
<div class="amount-btn" onclick="onDepositAmountClick(10000)">₹ 10K</div>
<div class="amount-btn" onclick="onDepositAmountClick(20000)">₹ 20K</div>
<div class="amount-btn" onclick="onDepositAmountClick(30000)">₹ 30K</div>
<div class="amount-btn" onclick="onDepositAmountClick(40000)">₹ 40K</div>
<div class="amount-btn" onclick="onDepositAmountClick(50000)">₹ 50K</div>
</div>
<div class="amount-input-box">
<div class="currency-sym">₹</div>
<input id="deposit-input" placeholder="₹100.00 - ₹50,000.00" type="number" value="100" oninput="window.selectedDepositAmount=parseFloat(this.value)||0"/>
<div class="clear-btn" onclick="document.getElementById('deposit-input').value=''"><i class="fa-regular fa-circle-xmark"></i></div>
</div>
</div>
<!-- Recharge Instructions -->
<div class="instruction-section">
<div class="section-title"><i class="fa-solid fa-book-open"></i> Recharge instructions</div>
<div class="instruction-inner">
<ul class="instruction-list">
<li>If the transfer time is up, please fill out the deposit form again.</li>
<li>The transfer amount must match the order you created, otherwise the money cannot be credited successfully.</li>
<li>If you transfer the wrong amount, our company will not be responsible for the lost amount!</li>
<li>Note: do not cancel the deposit order after the money has been transferred.</li>
</ul>
</div>
</div>
<!-- Deposit History -->
<div class="history-section" id="deposit-history-anchor">
<div class="section-title"><i class="fa-solid fa-file-invoice"></i> Deposit history</div>
<div id="deposit-history-container">
<div class="sub-no-data-area" id="no-deposit-history-view" style="display:none;">
<svg class="sub-no-data-icon" fill="none" viewbox="0 0 200 150" xmlns="http://www.w3.org/2000/svg">
<path d="M20 100 Q 60 70 100 95 Q 150 75 180 105 L 180 140 L 20 140 Z" fill="#2a245c"></path>
<path d="M50 110 Q 90 85 130 110 Q 165 95 190 120 L 190 140 L 50 140 Z" fill="#363073"></path>
<path d="M35 125 C 28 115 28 100 35 90 C 42 100 42 115 35 125 Z" fill="#6d65b5"></path>
<rect fill="#4d478a" height="10" width="2" x="34" y="125"></rect>
<path d="M165 130 C 160 122 160 112 165 105 C 170 112 170 122 165 130 Z" fill="#6d65b5"></path>
<rect fill="#4d478a" height="8" width="1" x="164.5" y="130"></rect>
<rect fill="#756bbd" height="75" rx="4" width="50" x="90" y="45"></rect>
<rect fill="#8d84d6" height="12" rx="3" width="45" x="95" y="40"></rect>
<rect fill="#8d84d6" height="12" rx="4" width="55" x="80" y="120"></rect>
<rect fill="#857ccf" height="65" opacity="0.9" width="55" x="90" y="55"></rect>
<rect fill="#645ca3" height="20" rx="3" width="20" x="140" y="105"></rect>
</svg>
<div class="sub-no-data-text">No data</div>
</div>
<div id="deposit-history-list-view">
<div class="history-card-item approved">
  <div class="history-card-left">
    <div class="hist-amount">₹500.00</div>
    <div class="hist-utr">UTR: 123456789012</div>
  </div>
  <div class="history-card-right">
    <div class="hist-status status-approved">Approved</div>
    <div class="hist-time">2025-09-18 14:32</div>
  </div>
</div>
<div class="history-card-item pending">
  <div class="history-card-left">
    <div class="hist-amount">₹1,000.00</div>
    <div class="hist-utr">UTR: 987654321098</div>
  </div>
  <div class="history-card-right">
    <div class="hist-status status-pending">Processing</div>
    <div class="hist-time">2025-09-19 09:15</div>
  </div>
</div>
</div>
</div>
</div>
</div>
<!-- Fixed Bottom Deposit Bar -->
<div class="deposit-bottom-bar">
<div class="recharge-method-info">
<span class="label">Recharge Method:</span>
<span class="method-name" id="selected-method-text">UPI-QR</span>
</div>
<button class="deposit-btn" onclick="event.preventDefault();openPaymentGateway();return false;">Deposit</button>
</div>
<div class="sub-fab-right" style="bottom: 75px;cursor:pointer" onclick="window.open('{{ support_url }}','_blank')" title="Customer Service"><i class="fa-solid fa-headset"></i></div>
</div><div class="app-screen" id="screen-payment-gateway">
<div class="header">
<div class="back-btn" onclick="closePaymentGateway()"><i class="fa-solid fa-chevron-left"></i></div>
<div class="title">ArUpiPay</div>
<button class="cs-pill-btn" type="button" onclick="window.open('{{ support_url }}','_blank')">Customer Service</button>
</div>
<div class="scrollable-content" style="padding: 14px 14px 130px 14px;">
<div class="pay-amount-bar">
<div class="pay-amount-left">
<span id="gateway-amount-display">₹0.00</span>
<i class="fa-regular fa-copy" onclick="copyAmount()" title="Copy Amount"></i>
</div>
<div class="pay-timer" id="pay-countdown">15:00</div>
</div>
<div class="pay-bullet-title">Choose a payment method to pay</div>
<div class="pay-methods-row">
<div class="pay-method-card paytm" onclick="openAppPay('paytm')">
<div class="pay-logo-wrap">
<div class="pay-logo-img">paytm</div>
<span>Paytm</span>
</div>
<span class="wake-text">Wake up support</span>
</div>
<div class="pay-method-card phonepe" onclick="openAppPay('phonepe')">
<div class="pay-logo-wrap">
<div class="pay-logo-img">पे</div>
<span>PhonePe</span>
</div>
<span class="wake-text">Open app</span>
</div>
<div class="pay-method-card" onclick="openAppPay('gpay')" style="background:linear-gradient(135deg,#1a73e8,#0d47a1);">
<div class="pay-logo-wrap">
<div class="pay-logo-img" style="background:#fff;color:#1a73e8;font-weight:800;font-size:0.75rem;">G</div>
<span>GPay</span>
</div>
<span class="wake-text">Open app</span>
</div>
<div class="pay-method-card" onclick="openAppPay('upi')" style="background:linear-gradient(135deg,#6a1b9a,#4a148c);">
<div class="pay-logo-wrap">
<div class="pay-logo-img" style="background:#fff;color:#6a1b9a;font-size:0.7rem;">UPI</div>
<span>Any UPI</span>
</div>
<span class="wake-text">Open app</span>
</div>
</div>
<div class="pay-bullet-title">Use Mobile Scan code to pay</div>
<div class="qr-card">
<div class="qr-image-wrapper">
<img alt="UPI QR" id="dynamic-qr-img" src=""/>
<div class="qr-upi-info" id="qr-upi-text">UPI ID: {{ upi_vpa }}</div>
</div>
<div class="qr-desc">
<p>1. Please use another device to scan the QR code with your payment app</p>
<p>2. If you scan the QR code from this device's gallery, the payment amount may be limited (≤2000).</p>
</div>
</div>
<div class="pay-bullet-title">Input UTR/ Paste UTR</div>
<div class="utr-warning-text">
                If you do not back fill UTR/ paste UTR, 100% will fail.
            </div>
<div class="utr-input-box">
<input id="utr-input" maxlength="12" oninput="validateUTR(this.value)" placeholder="Input 12 digits here" type="text"/>
<button class="utr-paste-btn" onclick="pasteUTR()">Paste</button>
</div>
<div class="pay-bullet-title">Important reminder:</div>
<div class="reminder-list">
<p>1. Do not pay for the same link repeatedly!</p>
<p>2. Paytm is wake up support!</p>
</div>
</div>
<div class="pay-bottom-bar" id="utr-action-bar" style="display:flex!important;z-index:2000!important;position:fixed!important;bottom:0!important;left:0;right:0;">
<button class="btn-cancel" onclick="closePaymentGateway()" style="flex:0.35;background:#38306e;color:#fff;border:none;padding:14px 0;border-radius:12px;font-size:15px;font-weight:600;">Cancel</button>
<button class="btn-submit-utr" id="submit-utr-btn" onclick="submitUTR()" style="flex:0.65;background:linear-gradient(90deg,#8b5cf6,#7c3aed);color:#fff!important;border:none;border-radius:12px;font-weight:700;font-size:16px;padding:14px 0;">SUBMIT UTR</button>
</div>
</div></div><script>
function showAppScreen(screenId,anchorId=null){const t=document.getElementById(screenId);if(!t){if(screenId==="screen-account"){window.location.href="/account";}else if(screenId==="screen-deposit"){window.location.href="/deposit";}else if(screenId==="screen-withdraw"){window.location.href="/withdraw";}return;}document.querySelectorAll(".app-screen").forEach(s=>s.classList.remove("active"));t.classList.add("active");const hideNav=["screen-payment-gateway","screen-payment-method","screen-add-bank","screen-payment"].includes(screenId);document.querySelectorAll(".bnav,.bottom-navbar,.bottom-nav").forEach(function(nav){nav.style.display=hideNav?"none":"";});if(anchorId)setTimeout(()=>{const e=document.getElementById(anchorId);if(e)e.scrollIntoView({behavior:"smooth"});},100);}function scrollToAnchor(areaId,anchorId){const e=document.getElementById(anchorId);if(e)e.scrollIntoView({behavior:'smooth'});}
function refreshMasterBalance(){document.querySelectorAll('[data-balance]').forEach(e=>e.innerText='₹{{ balance }}');document.querySelectorAll('#deposit-balance-val,#withdraw-balance-val,#withdrawable-val').forEach(e=>e.innerText='₹{{ balance }}');}
function selectDepositChannel(el){document.querySelectorAll('.channel-card').forEach(c=>c.classList.remove('active'));el.classList.add('active');const o=document.getElementById('selected-method-text');if(o)o.innerText=el.getAttribute('data-channel')||'UPI-QR';}
function onDepositAmountClick(amt){window.selectedDepositAmount=Number(amt)||0;const i=document.getElementById('deposit-input');if(i)i.value=amt;document.querySelectorAll('.amount-grid-deposit .amount-btn').forEach(b=>b.classList.remove('active'));if(typeof event!=='undefined'&&event&&event.currentTarget)event.currentTarget.classList.add('active');}
function getUpiConfig(){var vpa='{{ upi_vpa }}';if(!vpa||vpa.indexOf('{{')===0)vpa='merchant@upi';var name='{{ upi_name }}';if(!name||name.indexOf('{{')===0)name='ShreeWin';var min=parseFloat('{{ min_deposit }}');if(!(min>0))min=100;var max=parseFloat('{{ max_deposit }}');if(!(max>0))max=50000;return{vpa:vpa,name:name,min:min,max:max};}
function buildUpiLink(amt,orderId){var cfg=getUpiConfig();var tn='DEP'+String(orderId||Date.now()).slice(-10);return 'upi://pay?pa='+encodeURIComponent(cfg.vpa)+'&pn='+encodeURIComponent(cfg.name)+'&am='+Number(amt).toFixed(2)+'&cu=INR&tn='+encodeURIComponent(tn);}
function makeOrderId(){return 'SW'+Date.now().toString().slice(-10)+(Math.floor(Math.random()*90)+10);}
function openPaymentGateway(){
  try{
    var cfg=getUpiConfig();
    var inp=document.getElementById('deposit-input');
    var amt=(window.selectedDepositAmount!=null&&window.selectedDepositAmount>0)?Number(window.selectedDepositAmount):((inp&&parseFloat(inp.value))||cfg.min);
    if(!amt||isNaN(amt)||amt<cfg.min){alert('Minimum deposit is Rs.'+cfg.min);return;}
    if(amt>cfg.max){alert('Maximum deposit is Rs.'+cfg.max);return;}
    window.selectedDepositAmount=amt;
    window.depositOrderId=makeOrderId();
    var el=document.getElementById('gateway-amount-display');
    if(el)el.innerText='Rs.'+Number(amt).toFixed(2);
    var upiLink=buildUpiLink(amt,window.depositOrderId);
    window.currentUpiLink=upiLink;
    var qr=document.getElementById('dynamic-qr-img');
    if(qr)qr.src='https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data='+encodeURIComponent(upiLink);
    var ut=document.getElementById('qr-upi-text');
    if(ut)ut.innerHTML='UPI ID: '+cfg.vpa;
    document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav').forEach(function(n){n.style.display='none';});
    if(typeof startPayCountdown==='function')startPayCountdown(15*60);
    var gw=document.getElementById('screen-payment-gateway');
    if(gw){
      document.querySelectorAll('.app-screen').forEach(function(s){s.classList.remove('active');s.style.display='none';});
      gw.classList.add('active');
      gw.style.display='flex';
      gw.style.opacity='1';
      gw.style.zIndex='50';
    } else if(typeof showAppScreen==='function'){
      showAppScreen('screen-payment-gateway');
    } else {
      alert('Payment screen missing. Please refresh.');
    }
  }catch(err){
    console.error(err);
    alert('Deposit error: '+(err&&err.message?err.message:err));
  }
}
function copyUpiId(){var cfg=getUpiConfig();try{navigator.clipboard.writeText(cfg.vpa);}catch(e){}alert('UPI ID copied: '+cfg.vpa);}
function openAppPay(app){var amt=window.selectedDepositAmount||100;var link=window.currentUpiLink||buildUpiLink(amt,window.depositOrderId||makeOrderId());var q=link.split('?')[1]||'';var url=link;if(app==='phonepe')url='phonepe://pay?'+q;else if(app==='gpay')url='tez://upi/pay?'+q;else if(app==='paytm')url='paytmmp://cash_wallet?'+q;try{window.location.href=url;}catch(e){}setTimeout(function(){window.location.href=link;},700);}
function startPayCountdown(sec){var el=document.getElementById('pay-countdown');if(!el)return;if(window._payTimer)clearInterval(window._payTimer);var left=sec|0;function tick(){var m=('0'+Math.floor(left/60)).slice(-2);var s=('0'+(left%60)).slice(-2);el.innerText=m+':'+s;if(left<=0){clearInterval(window._payTimer);return;}left--;}tick();window._payTimer=setInterval(tick,1000);}
function closePaymentGateway(){
  var gw=document.getElementById('screen-payment-gateway');
  var dep=document.getElementById('screen-deposit');
  if(gw){gw.classList.remove('active');gw.style.display='none';}
  if(dep){dep.classList.add('active');dep.style.display='flex';dep.style.opacity='1';}
  document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav').forEach(function(n){n.style.display='';});
}
window.openPaymentGateway=openPaymentGateway;
window.closePaymentGateway=closePaymentGateway;
window.openAppPay=openAppPay;
document.addEventListener('DOMContentLoaded',function(){
  if(typeof refreshMasterBalance==='function')refreshMasterBalance();
  var depBtn=document.querySelector('.deposit-btn');
  if(depBtn){
    depBtn.onclick=function(e){e.preventDefault();openPaymentGateway();return false;};
  }
});

</script>
<!-- Bottom Navigation - New Design -->
<nav class="bottom-navbar">
    <a href="/home" class="nav-item active">
      <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      <span>Home</span>
    </a>
    <a href="/activity" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2zm-7 10.25l-2.61 1.56.69-2.97-2.3-2 3.03-.26L12 7l1.19 2.58 3.03.26-2.3 2 .69 2.97L12 13.25z"/></svg>
      <span>Activity</span>
    </a>
    <a href="/spinwheel" class="wheel-item">
      <div class="wheel-wrapper">
        <svg viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="46" fill="#7522c7" stroke="#9d3efa" stroke-width="2"/>
          <circle cx="50" cy="8" r="2" fill="#ffd700"/>
          <circle cx="80" cy="20" r="2" fill="#ffd700"/>
          <circle cx="92" cy="50" r="2" fill="#ffd700"/>
          <circle cx="80" cy="80" r="2" fill="#ffd700"/>
          <circle cx="20" cy="80" r="2" fill="#ffd700"/>
          <circle cx="8" cy="50" r="2" fill="#ffd700"/>
          <circle cx="20" cy="20" r="2" fill="#ffd700"/>
          <circle cx="50" cy="50" r="40" fill="#b066fe" stroke="#d5a5ff" stroke-width="2"/>
          <path d="M50 50 L50 14 A36 36 0 0 1 81 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L81 32 A36 36 0 0 1 81 68 Z" fill="#c026d3"/>
          <path d="M50 50 L81 68 A36 36 0 0 1 50 86 Z" fill="#00e5ff"/>
          <path d="M50 50 L50 86 A36 36 0 0 1 19 68 Z" fill="#c026d3"/>
          <path d="M50 50 L19 68 A36 36 0 0 1 19 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L19 32 A36 36 0 0 1 50 14 Z" fill="#c026d3"/>
          <circle cx="50" cy="50" r="13" fill="#00b4d8" stroke="#ffffff" stroke-width="1.5"/>
          <text x="50" y="53" fill="#ffffff" font-size="7" font-weight="900" text-anchor="middle" font-family="'Poppins', sans-serif">SPIN</text>
          <polygon points="50,6 45,13 55,13" fill="#60a5fa" stroke="#ffffff" stroke-width="0.8"/>
        </svg>
      </div>
      <span class="wheel-label">Get ₹500</span>
    </a>
    <a href="/promotion" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
      <span>Promotion</span>
    </a>
    <a href="/account" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
      <span>Account</span>
    </a>
</nav>

<script>
function refreshMasterBalance(){
  var bal='₹'+'{{ balance }}';
  document.querySelectorAll('[data-balance]').forEach(function(e){e.innerText=bal;});
  document.querySelectorAll('#deposit-balance-val,#withdraw-balance-val,#withdrawable-val').forEach(function(e){e.innerText=bal;});
}
</script>


<script>
(function(){
  window.selectedDepositAmount = window.selectedDepositAmount || 100;

  window.onDepositAmountClick = function(amt){
    window.selectedDepositAmount = Number(amt) || 0;
    var i = document.getElementById('deposit-input');
    if(i) i.value = amt;
    document.querySelectorAll('.amount-grid-deposit .amount-btn, .amount-btn').forEach(function(b){
      b.classList.remove('active');
    });
    if(typeof event !== 'undefined' && event && event.currentTarget){
      event.currentTarget.classList.add('active');
    }
  };

  window.openPaymentGateway = function(){ if(typeof openPaymentGateway==='function') openPaymentGateway(); };

  window.closePaymentGateway = function(){
    document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav').forEach(function(n){ n.style.display=''; });
    if(typeof showAppScreen === 'function') showAppScreen('screen-deposit');
    else {
      var gw = document.getElementById('screen-payment-gateway');
      var dep = document.getElementById('screen-deposit');
      if(gw){ gw.classList.remove('active'); gw.style.display='none'; }
      if(dep){ dep.classList.add('active'); dep.style.display='flex'; }
    }
  };

  window.submitUTR = function(){
    var el = document.getElementById('utr-input');
    var utr = el ? el.value.replace(/[^0-9]/g,'').trim() : '';
    if(el) el.value = utr;
    if(utr.length !== 12){ alert('Please enter a valid 12-digit UTR number'); return; }
    var inp = document.getElementById('deposit-input');
    var amt = (window.selectedDepositAmount != null && window.selectedDepositAmount > 0)
      ? window.selectedDepositAmount
      : ((inp && parseFloat(inp.value)) || 0);
    if(!amt || amt < 1){ alert('Invalid amount'); return; }
    window.location = '/submit_utr?amount=' + encodeURIComponent(amt) + '&utr=' + encodeURIComponent(utr);
  };

  // Wire amount buttons with direct listeners (more reliable than only onclick)
  document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.amount-grid-deposit .amount-btn, .amount-section .amount-btn').forEach(function(btn){
      btn.style.cursor = 'pointer';
      btn.style.pointerEvents = 'auto';
      btn.addEventListener('click', function(e){
        e.preventDefault();
        e.stopPropagation();
        var t = (btn.textContent || '').replace(/[^0-9]/g,'');
        // handle 1K 2K etc
        var label = (btn.textContent || '').toUpperCase();
        var amt = 0;
        if(label.indexOf('K') >= 0){
          amt = parseFloat(label.replace(/[^0-9.]/g,'')) * 1000;
        } else {
          amt = parseFloat(t) || 0;
        }
        if(amt > 0) window.onDepositAmountClick(amt);
        document.querySelectorAll('.amount-grid-deposit .amount-btn, .amount-section .amount-btn').forEach(function(b){ b.classList.remove('active'); });
        btn.classList.add('active');
      });
    });
    var depBtn = document.querySelector('.deposit-btn, button.deposit-btn, .deposit-bottom-bar button');
    if(depBtn){
      depBtn.style.pointerEvents = 'auto';
      depBtn.addEventListener('click', function(e){
        e.preventDefault();
        window.openPaymentGateway();
      });
    }
  });
})();
</script>


<script>
/* === DEPOSIT BOOTSTRAP (runs last, fixes dead button) === */
(function(){
  function cfg(){
    var vpa = '{{ upi_vpa }}';
    if(!vpa || vpa.indexOf('{{') === 0) vpa = 'merchant@upi';
    var name = '{{ upi_name }}';
    if(!name || name.indexOf('{{') === 0) name = 'ShreeWin';
    var min = parseFloat('{{ min_deposit }}'); if(!(min>0)) min = 100;
    var max = parseFloat('{{ max_deposit }}'); if(!(max>0)) max = 50000;
    return {vpa:vpa, name:name, min:min, max:max};
  }
  function orderId(){ return 'SW' + Date.now().toString().slice(-10) + Math.floor(Math.random()*90+10); }
  function upiLink(amt, oid){
    var c = cfg();
    return 'upi://pay?pa=' + encodeURIComponent(c.vpa)
      + '&pn=' + encodeURIComponent(c.name)
      + '&am=' + Number(amt).toFixed(2)
      + '&cu=INR&tn=' + encodeURIComponent('DEP' + String(oid).slice(-10));
  }
  function showPayScreen(){
    var gw = document.getElementById('screen-payment-gateway');
    var dep = document.getElementById('screen-deposit');
    if(!gw){ alert('Payment screen not found. Hard refresh page.'); return false; }
    document.querySelectorAll('.app-screen').forEach(function(s){
      s.classList.remove('active');
      s.style.display = 'none';
    });
    gw.classList.add('active');
    gw.style.cssText = 'display:flex!important;opacity:1!important;z-index:9999!important;position:absolute;top:0;left:0;width:100%;height:100%;flex-direction:column;';
    document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav,.deposit-bottom-bar').forEach(function(n){
      n.style.display = 'none';
    });
    return true;
  }
  window.openPaymentGateway = function(){
    try{
      var c = cfg();
      var inp = document.getElementById('deposit-input');
      var amt = (window.selectedDepositAmount > 0) ? Number(window.selectedDepositAmount)
              : (inp && parseFloat(inp.value)) || c.min;
      if(!amt || isNaN(amt) || amt < c.min){ alert('Minimum deposit is Rs.' + c.min); return; }
      if(amt > c.max){ alert('Maximum deposit is Rs.' + c.max); return; }
      window.selectedDepositAmount = amt;
      window.depositOrderId = orderId();
      var link = upiLink(amt, window.depositOrderId);
      window.currentUpiLink = link;
      var el = document.getElementById('gateway-amount-display');
      if(el) el.innerText = 'Rs.' + Number(amt).toFixed(2);
      var qr = document.getElementById('dynamic-qr-img');
      if(qr) qr.src = 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data=' + encodeURIComponent(link);
      var ut = document.getElementById('qr-upi-text');
      if(ut) ut.textContent = 'UPI ID: ' + c.vpa;
      if(!showPayScreen()) return;
      // countdown
      var cd = document.getElementById('pay-countdown');
      if(cd){
        var left = 15*60;
        if(window._payTimer) clearInterval(window._payTimer);
        window._payTimer = setInterval(function(){
          var m = ('0'+Math.floor(left/60)).slice(-2);
          var s = ('0'+(left%60)).slice(-2);
          cd.innerText = m+':'+s;
          if(left-- <= 0) clearInterval(window._payTimer);
        }, 1000);
      }
    }catch(err){
      alert('Deposit error: ' + (err && err.message ? err.message : err));
      console.error(err);
    }
  };
  window.closePaymentGateway = function(){
    var gw = document.getElementById('screen-payment-gateway');
    var dep = document.getElementById('screen-deposit');
    if(gw){ gw.classList.remove('active'); gw.style.display = 'none'; }
    if(dep){ dep.classList.add('active'); dep.style.cssText = 'display:flex!important;opacity:1;'; }
    document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav,.deposit-bottom-bar').forEach(function(n){
      n.style.display = '';
    });
  };
  function bindDepositButtons(){
    document.querySelectorAll('.deposit-btn, .deposit-bottom-bar button, button.deposit-btn').forEach(function(btn){
      btn.style.pointerEvents = 'auto';
      btn.style.cursor = 'pointer';
      btn.onclick = function(e){
        if(e){ e.preventDefault(); e.stopPropagation(); }
        window.openPaymentGateway();
        return false;
      };
    });
    // amount chips
    document.querySelectorAll('.amount-grid-deposit .amount-btn').forEach(function(btn){
      btn.addEventListener('click', function(){
        var label = (btn.textContent || '').toUpperCase();
        var amt = 0;
        if(label.indexOf('K') >= 0) amt = parseFloat(label.replace(/[^0-9.]/g,'')) * 1000;
        else amt = parseFloat(label.replace(/[^0-9.]/g,'')) || 0;
        if(amt > 0){
          window.selectedDepositAmount = amt;
          var inp = document.getElementById('deposit-input');
          if(inp) inp.value = amt;
          document.querySelectorAll('.amount-grid-deposit .amount-btn').forEach(function(b){ b.classList.remove('active'); });
          btn.classList.add('active');
        }
      }, true);
    });
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', bindDepositButtons);
  } else {
    bindDepositButtons();
  }
  // also bind after short delay (in case late DOM)
  setTimeout(bindDepositButtons, 500);
})();
</script>
</body></html>


"""

withdraw_html = """


<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"><title>Shree.Win - Withdraw</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"><link href="https://fonts.googleapis.com/css2?family=Delius&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet"><style>
        :root {
            --bg-dark: #161239;
            --bg-card: #241d4c;
            --bg-card-alt: #1c1740;
            --bg-card-inner: #1f1b40;
            --primary-purple: #8d7ff7;
            --primary-gradient: linear-gradient(135deg, #a78bfa 0%, #7c66f6 100%);
            --btn-purple: #9b8df8;
            --btn-amount-bg: #2d275e;
            --btn-amount-active: #8d80f8;
            --text-white: #ffffff;
            --text-light: #b0a9d8;
            --color-green: #00e676;
            --color-orange: #ff9800;
            --color-red: #ff4d4f;
            --color-gold: #ffb800;
            --pay-card-bg: #2b245e;
            --input-dark: #272153;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Delius', 'Nunito', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: #000;
            display: flex;
            justify-content: center;
            min-height: 100vh;
            overflow-x: hidden; overflow-y: auto;
        }

        /* Mobile Container Frame */
        .app-container {
            width: 100%;
            max-width: 400px;
            min-height: 100vh; height: auto;
            background-color: var(--bg-dark);
            display: flex;
            flex-direction: column;
            position: relative;
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 0 20px rgba(255,255,255,0.1);
        }

        /* Smooth Screen Transition Styles */
        .app-screen {
            display: none;
            flex-direction: column;
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            background-color: var(--bg-dark);
            opacity: 0;
            transition: opacity 0.25s ease-in-out;
            z-index: 1;
        }

        .app-screen.active {
            display: flex;
            opacity: 1;
            z-index: 5;
        }

        /* Shared Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 16px;
            color: var(--text-white);
            background-color: var(--bg-dark);
            z-index: 10;
        }
        .header .back-btn {
            font-size: 1.1rem;
            cursor: pointer;
            padding: 5px;
        }
        .header .title {
            font-size: 1.25rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .header .history-link {
            font-size: 0.9rem;
            color: #d8d4fd;
            text-decoration: none;
            cursor: pointer;
        }

        /* Scrollable Area */
        .scrollable-content {
            flex: 1;
            overflow-y: auto; -webkit-overflow-scrolling: touch; flex: 1; min-height: 0;
            scrollbar-width: none;
        }
        .scrollable-content::-webkit-scrollbar {
            display: none;
        }

        /* Floating Support */
        .sub-fab-right {
            position: absolute;
            bottom: 25px;
            right: 15px;
            width: 52px;
            height: 52px;
            border-radius: 50%;
            background: radial-gradient(circle, #00f5a0 0%, #00d9e9 100%);
            box-shadow: 0 0 15px rgba(0, 245, 160, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: 3px solid rgba(255, 255, 255, 0.4);
            z-index: 15;
        }
        .sub-fab-right i { color: #1e1b4b; font-size: 1.5rem; }

        /* ================= 1. ACCOUNT VIEW STYLES ================= */
        .profile-header {
            background: linear-gradient(180deg, #9b89ff 0%, #6e55f8 50%, var(--bg-dark) 100%);
            padding: 24px 16px 15px 16px;
            position: relative;
        }
        .profile-row {
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .avatar-wrap {
            position: relative;
            width: 72px;
            height: 72px;
            border-radius: 50%;
            border: 2px solid rgba(255, 255, 255, 0.6);
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            flex-shrink: 0;
            background: #25204d;
        }
        .avatar-wrap img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .user-details {
            display: flex;
            flex-direction: column;
            gap: 4px;
            flex: 1;
        }
        .username-row {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .username {
            color: #ffffff;
            font-size: 1.15rem;
            font-weight: bold;
            letter-spacing: 0.5px;
        }
        .vip-badge {
            background: linear-gradient(135deg, #e2e8f0 0%, #94a3b8 100%);
            color: #1e1b4b;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 800;
            display: inline-flex;
            align-items: center;
            gap: 3px;
        }
        .uid-pill {
            background: rgba(255, 152, 0, 0.9);
            color: #ffffff;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            width: fit-content;
            cursor: pointer;
            margin-top: 2px;
        }
        .last-login {
            color: #d1ccff;
            font-size: 0.72rem;
            margin-top: 2px;
        }

        .main-padding { padding: 0 14px; }

        .wallet-card {
            background-color: var(--bg-card);
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 14px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.25);
        }
        .wallet-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .wallet-left {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .wallet-title {
            color: #a7a0d8;
            font-size: 0.9rem;
        }
        .balance-value-row {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #ffffff;
            font-size: 1.8rem;
            font-weight: bold;
        }
        .balance-value-row i {
            font-size: 1.1rem;
            color: #a7a0d8;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .btn-enter-wallet {
            background-color: #beb4ff;
            color: #2b2361;
            border: none;
            padding: 8px 18px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
            cursor: pointer;
        }

        .wallet-actions-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            text-align: center;
        }
        .w-action-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            cursor: pointer;
            text-decoration: none;
        }
        .w-action-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
        }
        .w-action-icon.arwallet { background: rgba(255, 77, 79, 0.15); color: #ff4d4f; }
        .w-action-icon.deposit { background: rgba(255, 152, 0, 0.15); color: #ff9800; }
        .w-action-icon.withdraw { background: rgba(0, 186, 242, 0.15); color: #00baf2; }
        .w-action-icon.vip { background: rgba(0, 230, 118, 0.15); color: #00e676; }
        .w-action-label {
            color: #ffffff;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .history-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 14px;
        }
        .history-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 12px;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            text-decoration: none;
        }
        .hist-icon-wrap {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }
        .hist-icon-wrap.game { background: #1a73e8; color: white; }
        .hist-icon-wrap.trans { background: #00c853; color: white; }
        .hist-icon-wrap.dep { background: #e53935; color: white; }
        .hist-icon-wrap.with { background: #fb8c00; color: white; }
        .hist-text { display: flex; flex-direction: column; overflow-x: hidden; overflow-y: auto; }
        .hist-title { color: #ffffff; font-size: 0.95rem; font-weight: bold; line-height: 1.1; }
        .hist-sub { color: #8f88c2; font-size: 0.72rem; margin-top: 2px; white-space: nowrap; }

        .menu-card {
            background-color: var(--bg-card);
            border-radius: 14px;
            overflow-x: hidden; overflow-y: auto;
            margin-bottom: 14px;
        }
        .menu-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            cursor: pointer;
            text-decoration: none;
            color: #ffffff;
        }
        .menu-row:last-child { border-bottom: none; }
        .menu-row-left { display: flex; align-items: center; gap: 14px; font-size: 0.95rem; font-weight: 600; }
        .menu-row-left i { font-size: 1.2rem; color: #9b8df8; width: 22px; text-align: center; }
        .menu-row-right { display: flex; align-items: center; gap: 8px; color: #7b74ba; font-size: 0.85rem; }

        .service-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px;
            margin-bottom: 18px;
        }
        .service-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 16px; }
        .service-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            row-gap: 20px;
            column-gap: 8px;
            text-align: center;
        }
        .service-item { display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; text-decoration: none; }
        .service-icon { font-size: 1.6rem; color: #8d7ff7; }
        .service-label { color: #ffffff; font-size: 0.82rem; font-weight: 600; line-height: 1.2; }

        .btn-logout {
            width: 100%;
            background-color: transparent;
            border: 1px solid #4a3e8e;
            color: #ffffff;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 30px;
        }

        /* ================= 2. DEPOSIT VIEW STYLES ================= */
        .deposit-pad { padding: 10px 14px 90px 14px; }
        .balance-card {
            background: var(--primary-gradient);
            border-radius: 16px;
            padding: 20px 18px;
            color: white;
            position: relative;
            overflow-x: hidden; overflow-y: auto;
            margin-bottom: 15px;
            box-shadow: 0 4px 15px rgba(124, 102, 246, 0.25);
        }
        .balance-label {
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 8px;
            opacity: 0.95;
        }
        .balance-amount {
            font-size: 2rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .balance-amount i { font-size: 1.2rem; cursor: pointer; transition: transform 0.4s ease; }
        .balance-card .dots-bg {
            position: absolute;
            bottom: 8px;
            right: 15px;
            color: rgba(255, 255, 255, 0.3);
            font-size: 1.1rem;
            letter-spacing: 2px;
            font-weight: bold;
        }

        .channels-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 15px;
        }
        .channel-card {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 4px 10px 4px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            position: relative;
            border: 1px solid transparent;
            min-height: 86px;
        }
        .channel-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .channel-icon-wrap {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 6px;
        }
        .channel-name { color: white; font-size: 0.72rem; font-weight: 600; line-height: 1.1; }
        .channel-badge {
            position: absolute;
            top: -4px;
            right: -2px;
            background-color: var(--color-red);
            color: white;
            font-size: 0.65rem;
            font-weight: bold;
            padding: 2px 5px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 2px;
        }

        .amount-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .section-title {
            color: white;
            font-size: 1.05rem;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 14px;
            font-weight: bold;
        }
        .section-title i { color: #b0a5fa; }

        .amount-grid-deposit {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 15px;
        }
        .amount-btn {
            background-color: var(--btn-amount-bg);
            border: 1px solid rgba(255, 255, 255, 0.05);
            color: #bcb6ea;
            padding: 12px 5px;
            border-radius: 8px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
            transition: all 0.2s ease;
        }
        .amount-btn:hover, .amount-btn:active, .amount-btn.active {
            background-color: var(--btn-amount-active);
            color: white;
            box-shadow: 0 2px 8px rgba(141, 128, 248, 0.4);
        }

        .amount-input-box {
            background-color: var(--bg-card-inner);
            border-radius: 25px;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .amount-input-box .currency-sym {
            color: #958df1;
            font-size: 1.1rem;
            font-weight: bold;
            padding-right: 10px;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
            margin-right: 10px;
        }
        .amount-input-box input {
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: #ffffff;
            font-size: 0.95rem;
        }
        .amount-input-box input::placeholder { color: #7b74ba; }
        .amount-input-box .clear-btn { color: #7b74ba; font-size: 1rem; cursor: pointer; padding: 2px 5px; }

        .instruction-section {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 16px 14px;
            margin-bottom: 15px;
        }
        .instruction-inner {
            background-color: var(--bg-card-inner);
            border-radius: 10px;
            padding: 14px;
        }
        .instruction-list { list-style: none; }
        .instruction-list li {
            position: relative;
            padding-left: 18px;
            color: #9e97d8;
            font-size: 0.82rem;
            line-height: 1.45;
            margin-bottom: 14px;
        }
        .instruction-list li:last-child { margin-bottom: 0; }
        .instruction-list li::before {
            content: '◆';
            position: absolute;
            left: 0;
            top: 0;
            color: #8d80f8;
            font-size: 0.75rem;
        }

        .sub-no-data-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px 0 10px 0;
        }
        .sub-no-data-icon { width: 170px; height: 120px; opacity: 0.85; margin-bottom: 10px; }
        .sub-no-data-text { color: #ffffff; font-size: 1.15rem; font-weight: 500; }

        .history-card-item {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-left: 4px solid var(--color-green);
        }
        .history-card-item.pending { border-left-color: var(--color-orange); }
        .history-card-item.rejected { border-left-color: var(--color-red); }
        .history-card-left .hist-amount { font-size: 1.1rem; font-weight: bold; color: white; margin-bottom: 2px;}
        .history-card-left .hist-utr { font-size: 0.75rem; color: var(--text-light); }
        .history-card-right { text-align: right; }
        .history-card-right .hist-status { font-size: 0.8rem; font-weight: bold; text-transform: capitalize; }
        .history-card-right .hist-time { font-size: 0.7rem; color: var(--text-light); margin-top: 2px; }

        .status-approved { color: var(--color-green); }
        .status-pending { color: var(--color-orange); }
        .status-rejected { color: var(--color-red); }

        .deposit-bottom-bar {
            position: fixed !important;
            bottom: 0 !important;
            left: 0;
            right: 0;
            background-color: #1a1540;
            padding: 12px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 20;
        }
        .recharge-method-info { display: flex; flex-direction: column; }
        .recharge-method-info .label { font-size: 0.78rem; color: #ffffff; margin-bottom: 2px; }
        .recharge-method-info .method-name { font-size: 0.95rem; color: #ffffff; font-weight: bold; }
        .deposit-btn {
            background-color: var(--primary-purple);
            color: white;
            border: none;
            padding: 10px 28px;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }

        /* Gateway Screen (ArUpiPay) */
        .cs-pill-btn {
            background: linear-gradient(90deg, #7c67ff 0%, #6852ee 100%);
            color: white;
            font-size: 0.8rem;
            padding: 6px 14px;
            border-radius: 20px;
            border: none;
            cursor: pointer;
            font-weight: 600;
        }
        .pay-amount-bar {
            background-color: var(--pay-card-bg);
            border-radius: 12px;
            padding: 16px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
        }
        .pay-amount-left { display: flex; align-items: center; gap: 12px; color: #ffffff; font-size: 1.7rem; font-weight: bold; }
        .pay-amount-left i { font-size: 1.25rem; color: #d1ccff; cursor: pointer; }
        .pay-timer { color: var(--color-red); font-size: 1.15rem; font-weight: bold; letter-spacing: 0.5px; }

        .pay-bullet-title { color: #ffffff; font-size: 1.05rem; font-weight: bold; margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
        .pay-bullet-title::before { content: 'â¢'; color: #ffffff; font-size: 1.3rem; line-height: 0; }

        .pay-methods-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
        .pay-method-card { border-radius: 12px; padding: 12px 10px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; cursor: pointer; transition: transform 0.15s ease; }
        .pay-method-card:active { transform: scale(0.97); }
        .pay-method-card.paytm { background: linear-gradient(135deg, #d4f8ff 0%, #a4e6f9 100%); color: #042e6f; }
        .pay-method-card.phonepe { background: linear-gradient(135deg, #fce8ff 0%, #ebd0fc 100%); color: #5f259f; }
        .pay-logo-wrap { display: flex; align-items: center; gap: 6px; font-size: 1.05rem; font-weight: bold; margin-bottom: 4px; }
        .pay-logo-img { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.85rem; font-weight: bold; }
        .paytm .pay-logo-img { background-color: #002e6e; font-size: 0.6rem; }
        .phonepe .pay-logo-img { background-color: #5f259f; font-size: 1rem; }
        .wake-text { font-size: 0.75rem; color: #8b80cf; font-weight: 600; }

        .qr-card {
            background-color: #372f78;
            border-radius: 14px;
            padding: 22px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            margin-bottom: 22px;
        }
        .qr-image-wrapper {
            background-color: #ffffff;
            padding: 12px;
            border-radius: 14px;
            display: inline-block;
            margin-bottom: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        .qr-image-wrapper img { width: 180px; height: 180px; display: block; margin: 0 auto; }
        .qr-upi-info { color: #332d5e; font-size: 0.82rem; font-weight: bold; margin-top: 8px; font-family: 'Nunito', sans-serif; }
        .qr-desc { color: #ffffff; font-size: 0.88rem; line-height: 1.45; text-align: left; width: 100%; margin-top: 6px; }
        .qr-desc p { margin-bottom: 8px; }

        .utr-warning-text { color: var(--color-red); font-size: 0.95rem; line-height: 1.35; font-weight: bold; margin-bottom: 12px; }
        .utr-input-box {
            background-color: #272153;
            border-radius: 30px;
            padding: 6px 6px 6px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 22px;
            box-shadow: 0 0 10px rgba(186, 104, 200, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .utr-input-box input { background: transparent; border: none; outline: none; color: #b7b0ee; font-size: 0.95rem; width: 70%; }
        .utr-paste-btn { background-color: #8d80f8; color: #ffffff; border: none; padding: 8px 18px; border-radius: 20px; font-size: 0.9rem; font-weight: bold; cursor: pointer; }
        .reminder-list { color: #ffffff; font-size: 0.9rem; line-height: 1.6; margin-bottom: 25px; }

        .pay-bottom-bar {
            position: fixed !important;
            bottom: 0 !important;
            left: 0;
            right: 0;
            background-color: #1a1540;
            padding: 12px 16px;
            display: flex;
            gap: 12px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            z-index: 20;
        }
        .btn-cancel { flex: 0.35; background-color: #38306e; color: #ffffff; border: none; padding: 12px 0; border-radius: 8px; font-size: 0.95rem; font-weight: bold; cursor: pointer; }
        .btn-submit-utr { flex: 0.65; background: linear-gradient(90deg,#8b5cf6,#7c3aed); color: #fff; border: none; padding: 14px 0; border-radius: 12px; font-size: 1rem; font-weight: 700; cursor: pointer; box-shadow: 0 4px 12px rgba(124,58,237,0.4); }
        .btn-submit-utr.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 12px rgba(141, 128, 248, 0.4); }

        /* ================= 3. WITHDRAW VIEW STYLES ================= */
        .withdraw-pad { padding: 10px 14px 90px 14px; }
        .arpay-banner {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 14px;
        }
        .arpay-logo { font-size: 2rem; color: #ffb800; font-weight: 900; line-height: 1; }
        .arpay-text h4 { color: white; font-size: 1.05rem; font-weight: bold; margin-bottom: 2px; }
        .arpay-text p { color: #9e97d8; font-size: 0.8rem; }

        .methods-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 14px;
        }
        .method-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 14px 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            min-height: 90px;
            transition: all 0.2s;
        }
        .method-card.active {
            background: linear-gradient(180deg, #8777fa 0%, #6852ee 100%);
            box-shadow: 0 4px 12px rgba(104, 82, 238, 0.4);
        }
        .method-icon { font-size: 1.8rem; margin-bottom: 6px; height: 36px; display: flex; align-items: center; justify-content: center; }
        .method-name { color: white; font-size: 0.8rem; font-weight: 700; letter-spacing: 0.5px; }

        .account-card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
            cursor: pointer;
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: 0.2s;
        }
        .account-card:active { transform: scale(0.98); }
        .account-left { display: flex; flex-direction: column; gap: 4px; }
        .account-name-row { display: flex; align-items: center; gap: 8px; color: white; font-size: 1rem; font-weight: bold; }
        .account-vpa { color: #9e97d8; font-size: 0.9rem; font-weight: 600; }
        .account-card i.fa-chevron-right { color: #7b74ba; font-size: 0.95rem; }

        .add-upi-box {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 24px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            margin-bottom: 14px;
            border: 1px solid rgba(255,255,255,0.05);
        }
        .add-upi-box:active { transform: scale(0.98); }
        .add-upi-icon { width: 46px; height: 46px; border: 2px dashed #7a70bb; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #7a70bb; font-size: 1.45rem; margin-bottom: 12px; }
        .add-upi-text { color: #8c82cb; font-size: 1rem; font-weight: bold; }

        .add-bank-box {
            background-color: var(--bg-card);
            border-radius: 14px;
            padding: 24px 16px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            margin-bottom: 6px;
        }
        .dashed-plus-icon {
            width: 46px;
            height: 46px;
            border: 2px dashed #7a70bb;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #7a70bb;
            font-size: 1.5rem;
            margin-bottom: 12px;
        }
        .add-bank-text { color: #8c82cb; font-size: 1rem; font-weight: bold; }
        .add-bank-warning { color: var(--color-red); font-size: 0.8rem; text-align: center; margin-bottom: 14px; line-height: 1.3; }

        .amount-grid-withdraw {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 14px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.88rem;
            margin-bottom: 8px;
            color: #bcb6ea;
        }
        .btn-all-pill {
            background-color: #38306e;
            color: white;
            border: none;
            padding: 3px 18px;
            border-radius: 14px;
            font-size: 0.8rem;
            font-weight: bold;
            cursor: pointer;
        }
        .received-val { color: #ff9800; font-weight: bold; font-size: 1.1rem; }

        .withdraw-action-btn {
            width: 100%;
            background-color: #d1cbff;
            color: #7a6fc7;
            border: none;
            padding: 14px;
            border-radius: 25px;
            font-size: 1.05rem;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 20px;
            transition: 0.2s;
        }
        .withdraw-action-btn.ready {
            background: var(--primary-purple);
            color: white;
            box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4);
        }
        .val-red { color: var(--color-red); font-weight: bold; }

        .btn-all-history {
            width: 100%;
            background-color: transparent;
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #bcb6ea;
            padding: 12px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: bold;
            cursor: pointer;
            text-align: center;
        }

        /* Payment Method Screen (UPI Sub-Screen) */
        .pm-account-card {
            background-color: #262153;
            border-radius: 14px;
            overflow-x: hidden; overflow-y: auto;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            margin-bottom: 15px;
        }
        .pm-card-header-stripe { height: 38px; background: linear-gradient(90deg, #0066ff 0%, #0088ff 100%); width: 100%; }
        .pm-card-body { padding: 18px 16px; color: #ffffff; }
        .pm-info-row { font-size: 1rem; color: #d1ccff; margin-bottom: 12px; letter-spacing: 0.3px; }
        .pm-info-row .bold-text { color: #ffffff; font-weight: bold; }
        .pm-current-tag { display: flex; align-items: center; gap: 8px; color: #a49fc7; font-size: 0.92rem; margin-top: 14px; }
        .pm-check-circle { width: 20px; height: 20px; background-color: var(--color-red); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.75rem; }
        .pm-bottom-bar { position: fixed !important; bottom: 0 !important; left: 0; right: 0; padding: 16px; background-color: #1a1540; z-index: 99999 !important; max-width: 400px; margin: 0 auto; box-shadow: 0 -4px 20px rgba(0,0,0,0.5); }
        .btn-add-method { width: 100%; background: linear-gradient(90deg,#8b5cf6,#7c3aed) !important; color: #fff !important; border: none; padding: 16px; border-radius: 30px; font-size: 1.1rem; font-weight: 800; cursor: pointer; box-shadow: 0 4px 15px rgba(139,92,246,0.5); }

        /* Add Bank Sub-Screen */
        .ab-notice-pill { background-color: #272153; border-radius: 20px; padding: 10px 14px; display: flex; align-items: center; gap: 10px; margin-bottom: 18px; color: var(--color-red); font-size: 0.8rem; line-height: 1.35; }
        .ab-form-group { margin-bottom: 16px; }
        .ab-label { color: #ffffff; font-size: 0.95rem; font-weight: bold; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .ab-label i { color: #8d7ff7; font-size: 1rem; }
        .ab-select-box { background: linear-gradient(90deg, #6b55fb 0%, #503ef0 100%); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; color: #ffffff; cursor: pointer; font-size: 0.95rem; font-weight: bold; }
        .ab-input-box { background-color: var(--input-dark); border-radius: 8px; padding: 14px 16px; display: flex; align-items: center; }
        .ab-input { width: 100%; background: transparent; border: none; outline: none; color: #ffffff; font-size: 0.95rem; font-family: 'Delius', sans-serif; }
        .ab-input::placeholder { color: #766eb5; }
        .ab-bottom-bar { padding: 14px 16px; background-color: var(--bg-dark); }
        .btn-save-bank { width: 100%; background-color: #d1cbff; color: #7a6fc7; border: none; padding: 15px; border-radius: 25px; font-size: 1.1rem; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .btn-save-bank.active { background-color: var(--primary-purple); color: white; box-shadow: 0 4px 15px rgba(141, 127, 247, 0.4); }

        /* Bank Selector Modal */
        .bank-modal {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 50;
            display: none;
            flex-direction: column;
            justify-content: flex-end;
        }
        .bank-modal-content {
            background: var(--bg-card);
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            padding: 20px;
            max-height: 70vh;
            display: flex;
            flex-direction: column;
        }
        .bank-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 14px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .bank-list { overflow-y: auto; flex: 1; }
        .bank-item {
            padding: 14px 12px;
            color: #d1ccff;
            font-size: 0.95rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .bank-item:hover, .bank-item:active { background: rgba(255,255,255,0.08); color: white; }

        /* Gift Claim Popup Modal */
        .gift-modal-backdrop {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            z-index: 100;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .gift-popup-card {
            background: var(--bg-card);
            border-radius: 18px;
            width: 100%;
            max-width: 320px;
            padding: 24px 20px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.6);
            border: 1px solid rgba(255,255,255,0.1);
        }
        .gift-popup-card i.fa-gift { font-size: 3rem; color: #ffb800; margin-bottom: 12px; }
        .gift-input {
            width: 100%;
            background: var(--bg-card-alt);
            border: 1px solid rgba(255,255,255,0.1);
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-size: 1rem;
            text-transform: uppercase;
            text-align: center;
            margin: 14px 0;
            outline: none;
            font-family: 'Nunito', sans-serif;
            font-weight: bold;
        }
        .btn-claim-gift {
            width: 100%;
            background: var(--primary-purple);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
        }
    .bnav{position:absolute;bottom:0;left:0;right:0;background:#16122e;z-index:100;border-top:1px solid #2a1f55}.bnav img{width:100%;display:block}.bnav-links{position:absolute;inset:0;display:flex}.bnav-links a{flex:1;height:100%;display:block}

/* Bottom Navigation Fix */.bottom-navbar{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:400px;height:65px;background:#141332;border-top:1px solid #26244f;display:flex;justify-content:space-around;align-items:center;z-index:1000;padding-bottom:5px;box-sizing:border-box}.bottom-navbar .nav-item{display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:#5d5c88;font-size:11px;font-weight:600;flex:1}.bottom-navbar .nav-item svg{width:26px;height:26px;fill:#5d5c88;margin-bottom:2px}.bottom-navbar .nav-item.active{color:#6965e8}.bottom-navbar .nav-item.active svg{fill:#6965e8}.bottom-navbar .wheel-item{position:relative;top:-16px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;flex:1.2;text-decoration:none}.bottom-navbar .wheel-wrapper{width:72px;height:72px;position:relative;display:flex;justify-content:center;align-items:center}.bottom-navbar .wheel-wrapper svg{width:100%;height:100%}.bottom-navbar .wheel-label{position:absolute;bottom:-6px;white-space:nowrap;font-size:13px;font-weight:900;color:#ffe600;text-shadow:-1.5px -1.5px 0 #b30000,1.5px -1.5px 0 #b30000,-1.5px 1.5px 0 #b30000,1.5px 1.5px 0 #b30000}.scrollable-content{padding-bottom:90px !important}
        .arpay-banner {
            display: flex; align-items: center; gap: 12px;
            background: var(--bg-card); border-radius: 14px;
            padding: 14px 16px; margin-bottom: 14px;
        }
        .arpay-logo { flex-shrink: 0; display:flex; align-items:center; }
        .arpay-text h4 { color:#fff; font-size:1.05rem; margin:0 0 2px; font-weight:700; }
        .arpay-text p { color:#9b93c9; font-size:.78rem; margin:0; }
        .methods-grid-withdraw {
            display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px;
        }
        .methods-grid-withdraw .method-card {
            background: var(--bg-card); border-radius: 12px; padding: 14px 8px;
            display:flex; flex-direction:column; align-items:center; gap:8px;
            border: 1.5px solid transparent; cursor:pointer;
        }
        .methods-grid-withdraw .method-card.active {
            background: linear-gradient(160deg, #6d5ce7 0%, #4b3bb8 100%);
            border-color: rgba(255,255,255,.15);
            box-shadow: 0 4px 14px rgba(109,92,231,.35);
        }
        .methods-grid-withdraw .method-name { color:#cfc8f5; font-size:.78rem; font-weight:700; }
        .methods-grid-withdraw .method-card.active .method-name { color:#fff; }
        .add-upi-box {
            background: var(--bg-card); border-radius: 14px; padding: 28px 16px;
            display:flex; flex-direction:column; align-items:center; justify-content:center;
            margin-bottom: 14px; cursor:pointer;
        }
        .add-upi-icon {
            width: 48px; height: 48px; border: 2px dashed #7a70bb; border-radius: 10px;
            display:flex; align-items:center; justify-content:center;
            color:#7a70bb; font-size:1.4rem; margin-bottom: 10px;
        }
        .add-upi-text { color:#8c82cb; font-size:1rem; font-weight:700; }
        .amount-input-box {
            display:flex; align-items:center; background: var(--input-dark);
            border-radius: 24px; padding: 4px 16px; margin-bottom: 12px;
            border: 1px solid rgba(255,255,255,.06);
        }
        .amount-input-box .currency-sym { color:#a78bfa; font-size:1.2rem; font-weight:700; margin-right:8px; }
        .amount-input-box input {
            flex:1; background:transparent; border:none; outline:none;
            color:#fff; font-size:1rem; padding:12px 0; font-family:inherit;
        }
        .amount-input-box input::placeholder { color:#6b6399; }
        .withdraw-action-btn {
            width:100%; margin-top:14px; border:none; border-radius:24px;
            padding:14px; font-size:1.05rem; font-weight:700; cursor:pointer;
            background:#c5bfff; color:#6b63a8; font-family:inherit;
        }
        .withdraw-action-btn.ready {
            background: linear-gradient(135deg,#a78bfa,#7c66f6); color:#fff;
        }
        .instruction-section { margin-bottom: 16px; }
        .instruction-inner {
            background: var(--bg-card); border-radius: 14px; padding: 14px 16px;
        }
        .instruction-list { list-style: none; padding:0; margin:0; }
        .instruction-list li {
            position:relative; padding-left: 16px; margin-bottom: 10px;
            color:#9b93c9; font-size:.82rem; line-height:1.45;
        }
        .instruction-list li::before {
            content:"◆"; position:absolute; left:0; top:1px;
            color:#7a70bb; font-size:.55rem;
        }
        .instruction-list .val-red { color:#ff6b6b; font-weight:600; }
        .wd-hist-bar {
            display:flex; align-items:center; gap:10px;
            background: var(--bg-card); border-radius: 12px;
            padding: 14px 16px; margin-bottom: 24px;
            color:#cfc8f5; text-decoration:none; font-weight:700; font-size:.95rem;
        }
        .wd-hist-bar i { color:#8d7ff7; }
        .cs-float {
            position:fixed; right:16px; bottom:90px; width:48px; height:48px;
            border-radius:50%; background:linear-gradient(135deg,#22c55e,#16a34a);
            color:#fff; display:flex; align-items:center; justify-content:center;
            font-size:1.2rem; box-shadow:0 4px 14px rgba(34,197,94,.4); z-index:50;
            cursor:pointer;
        }
</style></head><body><div class="app-container"><div class="app-screen active" id="screen-withdraw">
<div class="header">
<div class="back-btn" onclick="window.location.href='/account'"><i class="fa-solid fa-chevron-left"></i></div>
<div class="title">Withdraw</div>
<a class="history-link" href="/withdraw-history">Withdrawal history</a>
</div>
<div class="scrollable-content withdraw-pad" id="withdraw-scroll-area">

<!-- Available balance -->
<div class="balance-card">
  <div class="balance-label"><i class="fa-solid fa-wallet"></i> Available balance</div>
  <div class="balance-amount">
    <span id="withdraw-balance-val">₹{{ balance }}</span>
    <i class="fa-solid fa-arrows-rotate" id="refresh-withdraw-btn" onclick="refreshMasterBalance()" style="margin-left:8px;cursor:pointer;opacity:.85;"></i>
  </div>
  <div class="dots-bg">**** ****</div>
</div>

<!-- ARPay -->
<div class="arpay-banner">
  <div class="arpay-logo" aria-hidden="true">
    <svg width="28" height="28" viewBox="0 0 40 40" fill="none"><path d="M20 4L36 34H4L20 4Z" fill="#F5C518"/><path d="M20 12L28 28H12L20 12Z" fill="#1a1438"/></svg>
  </div>
  <div class="arpay-text">
    <h4>ARPay</h4>
    <p>Supports UPI for fast payment</p>
  </div>
</div>

<!-- Methods: UPI / BANK CARD / USDT -->
<div class="methods-grid-withdraw">
  <div class="method-card active" id="btn-upi-method" onclick="switchWithdrawChannel('UPI')">
    <div class="method-icon upi-ico">
      <svg width="32" height="32" viewBox="0 0 48 48" fill="none"><rect x="6" y="6" width="36" height="36" rx="8" fill="url(#ug)" stroke="#c4b5fd" stroke-width="1.5"/><text x="24" y="29" text-anchor="middle" fill="#fff" font-size="11" font-weight="700" font-family="Arial">UPI</text><defs><linearGradient id="ug" x1="6" y1="6" x2="42" y2="42"><stop stop-color="#7c3aed"/><stop offset="1" stop-color="#4c1d95"/></linearGradient></defs></svg>
    </div>
    <div class="method-name">UPI</div>
  </div>
  <div class="method-card" id="btn-bank-method" onclick="switchWithdrawChannel('BANK CARD')">
    <div class="method-icon"><i class="fa-solid fa-credit-card" style="color:#7dd3fc;font-size:1.4rem;"></i></div>
    <div class="method-name">BANK CARD</div>
  </div>
  <div class="method-card" id="btn-usdt-method" onclick="switchWithdrawChannel('USDT')">
    <div class="method-icon"><i class="fa-solid fa-t" style="color:#26a17b;font-size:1.35rem;background:#26a17b22;border-radius:50%;width:34px;height:34px;display:flex;align-items:center;justify-content:center;"></i></div>
    <div class="method-name">USDT</div>
  </div>
</div>

<!-- UPI beneficiary / Add UPI -->
<div id="upi-beneficiary-view">
  <div class="add-upi-box" onclick="location.href='/add-bank'">
    <div class="add-upi-icon"><i class="fa-solid fa-plus"></i></div>
    <div class="add-upi-text">Add UPI</div>
  </div>
</div>

<!-- Bank card view -->
<div id="bank-beneficiary-view" style="display:none;">
  <div class="add-upi-box" onclick="location.href='/add-bank'">
    <div class="add-upi-icon"><i class="fa-solid fa-plus"></i></div>
    <div class="add-upi-text">Add Bank Card</div>
  </div>
</div>

<!-- Amount -->
<div class="amount-section" style="background:var(--bg-card);border-radius:14px;padding:14px;margin-bottom:14px;">
  <div class="amount-input-box">
    <div class="currency-sym">₹</div>
    <input id="withdraw-input" type="number" inputmode="decimal" placeholder="Please enter the amount" oninput="onCustomWithdrawAmount(this.value)" value=""/>
  </div>
  <div class="info-row">
    <span>Withdrawable balance <span id="withdrawable-val" style="color:#ff9800;">₹{{ balance }}</span></span>
    <button type="button" class="btn-all-pill" onclick="withdrawAll()">All</button>
  </div>
  <div class="info-row" style="margin-top:10px;">
    <span>Withdrawal amount received</span>
    <span class="received-val" id="received-amount-display">₹0.00</span>
  </div>
  <button type="button" class="withdraw-action-btn" id="submit-withdraw-btn" onclick="handleWithdrawSubmit()">Withdraw</button>
</div>

<!-- Rules -->
<div class="instruction-section">
  <div class="instruction-inner">
    <ul class="instruction-list">
      <li>Need to bet <span class="val-red">₹0.00</span> to be able to withdraw</li>
      <li>Withdraw time <span class="val-red">00:00-23:59</span></li>
      <li>Inday Remaining Withdrawal Times <span class="val-red">3</span></li>
      <li>Withdrawal amount range <span class="val-red">₹100.00-₹50,000.00</span></li>
      <li>Please check your registered bank information again before making a withdrawal. If your registered bank information is incorrect, our company will not be responsible for any losses you may incur.</li>
      <li>If your registered bank information is incorrect, please contact customer service.</li>
    </ul>
  </div>
</div>

<!-- Bottom history link -->
<a href="/withdraw-history" class="wd-hist-bar">
  <i class="fa-solid fa-file-lines"></i> Withdrawal history
</a>

</div>
<div class="cs-float" onclick="location.href='/support'" title="Customer Service"><i class="fa-solid fa-headset"></i></div>
</div>
<div class="app-screen" id="screen-payment-method">
<div class="header">
<div class="back-btn" onclick="showAppScreen('screen-withdraw')"><i class="fa-solid fa-chevron-left"></i></div>
<div class="title">Payment method</div>
<div style="width: 32px;"></div>
</div>
<div class="scrollable-content" style="padding: 16px 14px;">
<div class="pm-account-card">
<div class="pm-card-header-stripe"></div>
<div class="pm-card-body">
<div class="pm-info-row">
                        Account name: <span class="bold-text" id="pm-display-name">Please Add Account</span>
</div>
<div class="pm-info-row">
                        UPI ID: <span class="bold-text" id="pm-display-vpa">Not bound</span>
</div>
<div class="pm-current-tag">
<div class="pm-check-circle"><i class="fa-solid fa-check"></i></div>
<span>Current Payment</span>
</div>
<button onclick="promptEditUpi()" style="display:block;width:100%;margin-top:18px;background:linear-gradient(90deg,#8b5cf6,#7c3aed);color:#fff;border:none;padding:16px;border-radius:30px;font-size:16px;font-weight:800;cursor:pointer;">+ Add / Bind UPI ID</button>
</div>
</div>
</div>
<div class="pm-bottom-bar">
<button class="btn-add-method" onclick="promptEditUpi()">+ Add / Bind UPI ID</button>
</div>
</div><div class="app-screen" id="screen-add-bank">
<div class="header">
<div class="back-btn" onclick="showAppScreen('screen-withdraw')"><i class="fa-solid fa-chevron-left"></i></div>
<div class="title">Add a bank account number</div>
<div style="width: 32px;"></div>
</div>
<div class="scrollable-content" style="padding: 14px 14px 30px 14px;">
<div class="ab-notice-pill">
<i class="fa-solid fa-circle-exclamation"></i>
<span>To ensure the safety of your funds, please bind your bank account</span>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-building-columns"></i> Choose a bank</div>
<div class="ab-select-box" onclick="openBankModal()">
<span id="selected-bank-name">Please select a bank</span>
<i class="fa-solid fa-chevron-right"></i>
</div>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-user"></i> Full recipient's name</div>
<div class="ab-input-box">
<input class="ab-input" id="bank-recipient-name" oninput="validateBankForm()" placeholder="Please enter recipient name" type="text"/>
</div>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-credit-card"></i> Bank account number</div>
<div class="ab-input-box">
<input class="ab-input" id="bank-acc-num" oninput="validateBankForm()" placeholder="Please enter your bank account number" type="number"/>
</div>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-mobile-screen"></i> Phone number</div>
<div class="ab-input-box">
<input class="ab-input" id="bank-phone" maxlength="10" oninput="validateBankForm()" placeholder="Please enter your phone number" type="tel"/>
</div>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-envelope"></i> Mail</div>
<div class="ab-input-box">
<input class="ab-input" id="bank-email" oninput="validateBankForm()" placeholder="please input your email" type="email"/>
</div>
</div>
<div class="ab-form-group">
<div class="ab-label"><i class="fa-solid fa-magnifying-glass"></i> IFSC code</div>
<div class="ab-input-box">
<input class="ab-input" id="bank-ifsc" oninput="validateBankForm()" placeholder="Please enter IFSC code" style="text-transform: uppercase;" type="text"/>
</div>
</div>
</div>
<div class="ab-bottom-bar">
<button class="btn-save-bank" id="btn-save-bank" onclick="saveBankAccount()">Save</button>
</div>
</div><div class="bank-modal" id="bank-modal" onclick="closeBankModal(event)">
<div class="bank-modal-content" onclick="event.stopPropagation()">
<div class="bank-modal-header">
<span>Select Your Bank</span>
<i class="fa-solid fa-xmark" onclick="closeBankModal()" style="cursor: pointer;"></i>
</div>
<div class="bank-list">
<div class="bank-item" onclick="chooseBank('State Bank of India (SBI)')"><i class="fa-solid fa-building-columns"></i> State Bank of India (SBI)</div>
<div class="bank-item" onclick="chooseBank('HDFC Bank')"><i class="fa-solid fa-building-columns"></i> HDFC Bank</div>
<div class="bank-item" onclick="chooseBank('ICICI Bank')"><i class="fa-solid fa-building-columns"></i> ICICI Bank</div>
<div class="bank-item" onclick="chooseBank('Axis Bank')"><i class="fa-solid fa-building-columns"></i> Axis Bank</div>
<div class="bank-item" onclick="chooseBank('Punjab National Bank (PNB)')"><i class="fa-solid fa-building-columns"></i> Punjab National Bank (PNB)</div>
<div class="bank-item" onclick="chooseBank('Bank of Baroda')"><i class="fa-solid fa-building-columns"></i> Bank of Baroda</div>
<div class="bank-item" onclick="chooseBank('Kotak Mahindra Bank')"><i class="fa-solid fa-building-columns"></i> Kotak Mahindra Bank</div>
<div class="bank-item" onclick="chooseBank('Canara Bank')"><i class="fa-solid fa-building-columns"></i> Canara Bank</div>
<div class="bank-item" onclick="chooseBank('Union Bank of India')"><i class="fa-solid fa-building-columns"></i> Union Bank of India</div>
<div class="bank-item" onclick="chooseBank('Paytm Payments Bank')"><i class="fa-solid fa-building-columns"></i> Paytm Payments Bank</div>
<div class="bank-item" onclick="chooseBank('Airtel Payments Bank')"><i class="fa-solid fa-building-columns"></i> Airtel Payments Bank</div>
</div>
</div>
</div></div><script>
function showAppScreen(screenId,anchorId=null){const t=document.getElementById(screenId);if(!t){if(screenId==="screen-account"){window.location.href="/account";}else if(screenId==="screen-deposit"){window.location.href="/deposit";}else if(screenId==="screen-withdraw"){window.location.href="/withdraw";}return;}document.querySelectorAll(".app-screen").forEach(s=>s.classList.remove("active"));t.classList.add("active");const nav=document.querySelector(".bnav");if(nav)nav.style.display=["screen-payment-gateway","screen-payment-method","screen-add-bank","screen-payment"].includes(screenId)?"none":"block";if(anchorId)setTimeout(()=>{const e=document.getElementById(anchorId);if(e)e.scrollIntoView({behavior:"smooth"});},100);}function scrollToAnchor(areaId,anchorId){const e=document.getElementById(anchorId);if(e)e.scrollIntoView({behavior:'smooth'});}
function refreshMasterBalance(){document.querySelectorAll('[data-balance]').forEach(e=>e.innerText='₹{{ balance }}');document.querySelectorAll('#deposit-balance-val,#withdraw-balance-val,#withdrawable-val').forEach(e=>e.innerText='₹{{ balance }}');}
function selectDepositChannel(el){document.querySelectorAll('.channel-card').forEach(c=>c.classList.remove('active'));el.classList.add('active');const o=document.getElementById('selected-method-text');if(o)o.innerText=el.getAttribute('data-channel')||'UPI-QR';}
function onDepositAmountClick(amt){window.selectedDepositAmount=Number(amt)||0;const i=document.getElementById('deposit-input');if(i)i.value=amt;document.querySelectorAll('.amount-grid-deposit .amount-btn').forEach(b=>b.classList.remove('active'));if(typeof event!=='undefined'&&event&&event.currentTarget)event.currentTarget.classList.add('active');}
function getUpiConfig(){return{vpa:'{{ upi_vpa }}',name:'{{ upi_name }}',min:parseFloat('{{ min_deposit }}')||100,max:parseFloat('{{ max_deposit }}')||50000};}
function buildUpiLink(amt,orderId){var cfg=getUpiConfig();var pa=encodeURIComponent(cfg.vpa);var pn=encodeURIComponent(cfg.name||'ShreeWin');var am=encodeURIComponent(Number(amt).toFixed(2));var tn=encodeURIComponent('DEP'+String(orderId||'').slice(-10));return 'upi://pay?pa='+cfg.vpa+'&pn='+encodeURIComponent(cfg.name||'ShreeWin')+'&am='+Number(amt).toFixed(2)+'&cu=INR&tn='+tn;}
function makeOrderId(){return 'SW'+Date.now().toString().slice(-10)+(Math.floor(Math.random()*90)+10);}
function openPaymentGateway(){var cfg=getUpiConfig();var inp=document.getElementById('deposit-input');var amt=(window.selectedDepositAmount!=null&&window.selectedDepositAmount>0)?window.selectedDepositAmount:((inp&&parseFloat(inp.value))||cfg.min);if(!amt||amt<cfg.min){alert('Minimum deposit is Rs.'+cfg.min);return;}if(amt>cfg.max){alert('Maximum deposit is Rs.'+cfg.max);return;}window.selectedDepositAmount=amt;window.depositOrderId=makeOrderId();var el=document.getElementById('gateway-amount-display');if(el)el.innerText='Rs.'+Number(amt).toFixed(2);var upiLink=buildUpiLink(amt,window.depositOrderId);window.currentUpiLink=upiLink;var qr=document.getElementById('dynamic-qr-img');if(qr)qr.src='https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data='+encodeURIComponent(upiLink);var ut=document.getElementById('qr-upi-text');if(ut)ut.innerHTML='UPI ID: '+cfg.vpa+' <i class="fa-regular fa-copy" style="cursor:pointer;margin-left:6px" onclick="copyUpiId()"></i>';document.querySelectorAll('.bnav,.bottom-navbar,.bottom-nav').forEach(function(n){n.style.display='none';});if(typeof startPayCountdown==='function')startPayCountdown(15*60);if(typeof showAppScreen==='function')showAppScreen('screen-payment-gateway');else{var gw=document.getElementById('screen-payment-gateway');var dep=document.getElementById('screen-deposit');if(dep)dep.classList.remove('active');if(gw){gw.classList.add('active');gw.style.display='flex';}}}
function copyUpiId(){var cfg=getUpiConfig();var t=cfg.vpa;if(navigator.clipboard)navigator.clipboard.writeText(t);alert('UPI ID copied: '+t);}
function openAppPay(app){var amt=window.selectedDepositAmount||100;var link=window.currentUpiLink||buildUpiLink(amt,window.depositOrderId||makeOrderId());var encoded=encodeURIComponent(link);var url=link;if(app==='phonepe'){url='phonepe://pay?'+link.split('?')[1];setTimeout(function(){window.location.href=link;},800);}else if(app==='paytm'){url='paytmmp://cash_wallet?pa='+encodeURIComponent(getUpiConfig().vpa)+'&pn='+encodeURIComponent(getUpiConfig().name)+'&am='+Number(amt).toFixed(2)+'&cu=INR&tn=DEP';setTimeout(function(){window.location.href=link;},800);}else if(app==='gpay'){url='tez://upi/pay?'+link.split('?')[1];setTimeout(function(){window.location.href=link;},800);}try{window.location.href=url;}catch(e){window.location.href=link;}}
function startPayCountdown(sec){var el=document.getElementById('pay-countdown');if(!el)return;if(window._payTimer)clearInterval(window._payTimer);var left=sec|0;function tick(){var m=('0'+Math.floor(left/60)).slice(-2);var s=('0'+(left%60)).slice(-2);el.innerText=m+':'+s;if(left<=0){clearInterval(window._payTimer);el.innerText='00:00';return;}left--;}tick();window._payTimer=setInterval(tick,1000);}

function closePaymentGateway(){showAppScreen('screen-deposit');}
function copyAmount(){var el=document.getElementById('gateway-amount-display');var t=(el?el.innerText:'').replace(/[^0-9.]/g,'');if(navigator.clipboard)navigator.clipboard.writeText(t);alert('Amount Copied');} function validateUTR(v){var btn=document.getElementById('submit-utr-btn');if(!btn)return;v=(v||'').replace(/[^0-9]/g,'');if(v.length>=10){btn.innerText='Submit UTR';btn.style.background='#22c55e';btn.style.color='#fff';}else{btn.innerText='Submit (UTR not entered)';btn.style.background='';btn.style.color='';}} function pasteUTR(){if(navigator.clipboard&&navigator.clipboard.readText){navigator.clipboard.readText().then(function(t){var el=document.getElementById('utr-input');if(el){el.value=String(t).replace(/[^0-9]/g,'').slice(0,12);validateUTR(el.value);}});}} function submitUTR(){var el=document.getElementById('utr-input');var utr=el?el.value.trim():'';if(utr.length<10){alert('Enter valid 12-digit UTR');return;}var inp=document.getElementById('deposit-input');var amt=(window.selectedDepositAmount!=null&&window.selectedDepositAmount>0)?window.selectedDepositAmount:((inp&&parseFloat(inp.value))||100);window.location='/submit_utr?amount='+amt+'&utr='+encodeURIComponent(utr);}
let currentWithdrawAmount=100;
function switchWithdrawChannel(method){document.querySelectorAll('.methods-grid-withdraw .method-card').forEach(c=>c.classList.remove('active'));const m={'UPI':'btn-upi-method','BANK CARD':'btn-bank-method','USDT':'btn-usdt-method'};if(m[method])document.getElementById(m[method]).classList.add('active');const u=document.getElementById('upi-beneficiary-view'),b=document.getElementById('bank-beneficiary-view');if(u&&b){u.style.display=method==='BANK CARD'?'none':'block';b.style.display=method==='BANK CARD'?'block':'none';}}
function setWithdrawAmount(amt,el){currentWithdrawAmount=Number(amt)||0;const i=document.getElementById('withdraw-input');if(i)i.value=amt;document.querySelectorAll('.amount-grid-withdraw .amount-btn').forEach(b=>b.classList.remove('active'));if(el)el.classList.add('active');updateReceivedDisplay();}
function onCustomWithdrawAmount(v){currentWithdrawAmount=parseFloat(v)||0;updateReceivedDisplay();var btn=document.getElementById('submit-withdraw-btn');if(btn){if(currentWithdrawAmount>=100)btn.classList.add('ready');else btn.classList.remove('ready');}} function withdrawAll(){var b=parseFloat(String('{{ balance }}').replace(/,/g,''))||0;var el=document.getElementById('withdraw-input');if(el){el.value=b>0?b:'';}onCustomWithdrawAmount(b);}function updateReceivedDisplay(){const e=document.getElementById('received-amount-display');if(e)e.innerText='₹'+Number(typeof currentWithdrawAmount!=='undefined'?currentWithdrawAmount:0).toFixed(2);}function handleWithdrawSubmit(){var amountEl=document.getElementById('withdraw-input');var amount=amountEl?parseFloat(amountEl.value):(typeof currentWithdrawAmount!=='undefined'?currentWithdrawAmount:0);if(!amount||amount<100){alert('Minimum withdrawal is Rs.100');return false;}var form=document.createElement('form');form.method='POST';form.action='/request_withdraw';var inp=document.createElement('input');inp.type='hidden';inp.name='amount';inp.value=amount;form.appendChild(inp);document.body.appendChild(form);form.submit();return false;}
function openBankModal(){const m=document.getElementById('bank-modal');if(m)m.style.display='flex';} function closeBankModal(){const m=document.getElementById('bank-modal');if(m)m.style.display='none';} function chooseBank(n){const e=document.getElementById('selected-bank-name');if(e)e.innerText=n;closeBankModal();} function validateBankForm(){var bank=document.getElementById('selected-bank-name');var name=document.getElementById('bank-recipient-name');var acc=document.getElementById('bank-acc-num');var phone=document.getElementById('bank-phone');var ifsc=document.getElementById('bank-ifsc');var btn=document.getElementById('btn-save-bank');if(!btn)return;var ok=bank&&bank.innerText&&bank.innerText!=='Please select a bank'&&name&&name.value.trim()&&acc&&acc.value.trim()&&ifsc&&ifsc.value.trim().length>=4;btn.disabled=!ok;btn.style.opacity=ok?'1':'0.6';} function saveBankAccount(){var bankEl=document.getElementById('selected-bank-name');var nameEl=document.getElementById('bank-recipient-name');var accEl=document.getElementById('bank-acc-num');var phoneEl=document.getElementById('bank-phone');var ifscEl=document.getElementById('bank-ifsc');var bankName=bankEl?bankEl.innerText.trim():'';var name=nameEl?nameEl.value.trim():'';var account=accEl?accEl.value.trim():'';var phone=phoneEl?phoneEl.value.trim():'';var ifsc=ifscEl?ifscEl.value.trim().toUpperCase():'';if(!bankName||bankName==='Please select a bank'){alert('Please select a bank');return;}if(!name){alert('Please enter recipient name');return;}if(!account){alert('Please enter account number');return;}if(!ifsc||ifsc.length<4){alert('Please enter valid IFSC');return;}var form=document.createElement('form');form.method='POST';form.action='/save_bank';[['type','bank'],['bank',bankName],['name',name],['account',account],['phone',phone],['ifsc',ifsc]].forEach(function(p){var i=document.createElement('input');i.type='hidden';i.name=p[0];i.value=p[1];form.appendChild(i);});document.body.appendChild(form);form.submit();} function promptEditUpi(){var vpa=prompt('Enter UPI ID (example: name@paytm / name@okhdfcbank):');if(!vpa)return;vpa=vpa.trim();if(vpa.indexOf('@')<1){alert('Invalid UPI ID. Must contain @');return;}var namePart=vpa.split('@')[0];var form=document.createElement('form');form.method='POST';form.action='/save_bank';[['type','upi'],['name',namePart],['account',vpa],['upi',vpa]].forEach(function(p){var i=document.createElement('input');i.type='hidden';i.name=p[0];i.value=p[1];form.appendChild(i);});document.body.appendChild(form);form.submit();}
document.addEventListener('DOMContentLoaded',()=>{refreshMasterBalance();updateReceivedDisplay();});
</script>
<!-- Bottom Navigation - New Design -->
<nav class="bottom-navbar">
    <a href="/home" class="nav-item active">
      <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      <span>Home</span>
    </a>
    <a href="/activity" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2zm-7 10.25l-2.61 1.56.69-2.97-2.3-2 3.03-.26L12 7l1.19 2.58 3.03.26-2.3 2 .69 2.97L12 13.25z"/></svg>
      <span>Activity</span>
    </a>
    <a href="/spinwheel" class="wheel-item">
      <div class="wheel-wrapper">
        <svg viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="46" fill="#7522c7" stroke="#9d3efa" stroke-width="2"/>
          <circle cx="50" cy="8" r="2" fill="#ffd700"/>
          <circle cx="80" cy="20" r="2" fill="#ffd700"/>
          <circle cx="92" cy="50" r="2" fill="#ffd700"/>
          <circle cx="80" cy="80" r="2" fill="#ffd700"/>
          <circle cx="20" cy="80" r="2" fill="#ffd700"/>
          <circle cx="8" cy="50" r="2" fill="#ffd700"/>
          <circle cx="20" cy="20" r="2" fill="#ffd700"/>
          <circle cx="50" cy="50" r="40" fill="#b066fe" stroke="#d5a5ff" stroke-width="2"/>
          <path d="M50 50 L50 14 A36 36 0 0 1 81 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L81 32 A36 36 0 0 1 81 68 Z" fill="#c026d3"/>
          <path d="M50 50 L81 68 A36 36 0 0 1 50 86 Z" fill="#00e5ff"/>
          <path d="M50 50 L50 86 A36 36 0 0 1 19 68 Z" fill="#c026d3"/>
          <path d="M50 50 L19 68 A36 36 0 0 1 19 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L19 32 A36 36 0 0 1 50 14 Z" fill="#c026d3"/>
          <circle cx="50" cy="50" r="13" fill="#00b4d8" stroke="#ffffff" stroke-width="1.5"/>
          <text x="50" y="53" fill="#ffffff" font-size="7" font-weight="900" text-anchor="middle" font-family="'Poppins', sans-serif">SPIN</text>
          <polygon points="50,6 45,13 55,13" fill="#60a5fa" stroke="#ffffff" stroke-width="0.8"/>
        </svg>
      </div>
      <span class="wheel-label">Get ₹500</span>
    </a>
    <a href="/promotion" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
      <span>Promotion</span>
    </a>
    <a href="/account" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
      <span>Account</span>
    </a>
</nav>




<script>
(function(){
  window.currentWithdrawAmount = window.currentWithdrawAmount || 100;

  window.setWithdrawAmount = function(amt, el){
    window.currentWithdrawAmount = Number(amt) || 0;
    var i = document.getElementById('withdraw-input');
    if(i) i.value = amt;
    document.querySelectorAll('.amount-grid-withdraw .amount-btn, .amount-btn').forEach(function(b){ b.classList.remove('active'); });
    if(el) el.classList.add('active');
    window.updateReceivedDisplay();
  };

  window.updateReceivedDisplay = function(){
    var e = document.getElementById('received-amount-display');
    if(e) e.innerText = '₹' + Number(window.currentWithdrawAmount || 0).toFixed(2);
  };

  window.onCustomWithdrawAmount = function(v){
    window.currentWithdrawAmount = parseFloat(v) || 0;
    window.updateReceivedDisplay();
  };

  window.withdrawAll = function(){
    var b = parseFloat(String('{{ balance }}').replace(/,/g,'')) || 0;
    window.setWithdrawAmount(b, null);
  };

  window.handleWithdrawSubmit = function(){
    var amountEl = document.getElementById('withdraw-input');
    var amount = amountEl ? parseFloat(amountEl.value) : (window.currentWithdrawAmount || 0);
    if(!amount || amount < 100){ alert('Minimum withdrawal is ₹100'); return false; }
    var form = document.createElement('form');
    form.method = 'POST';
    form.action = '/request_withdraw';
    var inp = document.createElement('input');
    inp.type = 'hidden';
    inp.name = 'amount';
    inp.value = amount;
    form.appendChild(inp);
    document.body.appendChild(form);
    form.submit();
    return false;
  };

  document.addEventListener('DOMContentLoaded', function(){
    // enable scroll on containers
    document.documentElement.style.overflowY = 'auto';
    document.body.style.overflowY = 'auto';
    document.body.style.height = 'auto';
    var app = document.querySelector('.app-container');
    if(app){ app.style.height = 'auto'; app.style.minHeight = '100vh'; app.style.overflowY = 'auto'; }
    var sc = document.querySelector('.scrollable-content');
    if(sc){ sc.style.overflowY = 'auto'; sc.style.webkitOverflowScrolling = 'touch'; sc.style.flex = '1'; }

    document.querySelectorAll('.amount-grid-withdraw .amount-btn, .methods-grid-withdraw ~ * .amount-btn').forEach(function(btn){
      btn.style.cursor = 'pointer';
      btn.style.pointerEvents = 'auto';
      btn.addEventListener('click', function(e){
        e.preventDefault();
        var label = (btn.textContent || '').trim().toUpperCase();
        var amt = 0;
        if(label.indexOf('K') >= 0) amt = parseFloat(label) * 1000;
        else amt = parseFloat(label.replace(/[^0-9.]/g,'')) || 0;
        if(amt > 0) window.setWithdrawAmount(amt, btn);
      });
    });
    // also catch any amount-btn inside withdraw screen
    document.querySelectorAll('#screen-withdraw .amount-btn').forEach(function(btn){
      btn.style.pointerEvents = 'auto';
      btn.addEventListener('click', function(e){
        e.preventDefault();
        var label = (btn.textContent || '').trim().toUpperCase();
        var amt = 0;
        if(label.indexOf('K') >= 0) amt = parseFloat(label) * 1000;
        else amt = parseFloat(label.replace(/[^0-9.]/g,'')) || 0;
        if(amt > 0) window.setWithdrawAmount(amt, btn);
      });
    });

    var wBtn = document.getElementById('submit-withdraw-btn') || document.querySelector('.withdraw-action-btn');
    if(wBtn){
      wBtn.style.pointerEvents = 'auto';
      wBtn.onclick = function(e){ e.preventDefault(); window.handleWithdrawSubmit(); };
    }

    var inp = document.getElementById('withdraw-input');
    if(inp){
      inp.addEventListener('input', function(){ window.onCustomWithdrawAmount(inp.value); });
    }

    window.updateReceivedDisplay();
  });
})();
</script>

</body></html>


"""

add_bank_html = """


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Add Bank Account</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif}
body{background:#0f0c29;min-height:100vh;color:#e0d4ff;padding-bottom:100px}
.topbar{display:flex;align-items:center;padding:14px 16px;background:#1a1440;border-bottom:1px solid #eee}
.topbar .back{font-size:20px;text-decoration:none;color:#d1c4e9;margin-right:12px}
.topbar .title{font-size:17px;font-weight:700}
.warning{margin:16px 14px;background:#fff3e0;border-radius:12px;padding:12px 14px;font-size:13px;color:#e65100}
.form{margin:0 14px}
.field{margin-bottom:18px}
.field label{display:block;font-size:14px;font-weight:600;color:#d1c4e9;margin-bottom:8px}
.field input,.field select{width:100%;padding:14px 16px;border:1px solid #e0e0e0;border-radius:12px;font-size:15px;background:#1a1440;outline:none}
.save-bar{position:fixed;bottom:0;left:0;right:0;background:#1a1440;padding:14px 16px;box-shadow:0 -4px 20px rgba(0,0,0,0.08)}
.save-btn{width:100%;padding:16px;background:#7c4dff;color:#fff;border:none;border-radius:30px;font-size:17px;font-weight:700}
</style>
</head>
<body>
<div class="topbar"><a href="/withdraw" class="back">←</a><div class="title">Add a bank account number</div></div>
<div class="warning">⚠️ To ensure the safety of your funds, please bind your bank account</div>
<form class="form" method="POST" action="/save_bank">
<div class="field"><label>Choose a bank</label>
<select name="bank" required>
<option value="">Please select a bank</option>
<option value="State Bank of India">State Bank of India</option>
<option value="HDFC Bank">HDFC Bank</option>
<option value="ICICI Bank">ICICI Bank</option>
<option value="Axis Bank">Axis Bank</option>
<option value="Punjab National Bank">Punjab National Bank</option>
<option value="Bank of Baroda">Bank of Baroda</option>
<option value="Other">Other</option>
</select></div>
<div class="field"><label>Full recipient's name</label>
<input type="text" name="name" placeholder="Enter full name" required value=""></div>
<div class="field"><label>Bank account number</label>
<input type="text" name="account" placeholder="Account number" required></div>
<div class="field"><label>Phone number</label>
<input type="tel" name="phone" placeholder="Phone number" required></div>
<div class="field"><label>IFSC code</label>
<input type="text" name="ifsc" placeholder="IFSC code" required style="text-transform:uppercase"></div>
<div class="save-bar"><button type="submit" class="save-btn">Save</button></div>
</form>
</body>
</html>


"""

deposit_history_html = """

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Deposit history</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #12183a;
      color: #ffffff;
      min-height: 100vh;
      display: flex;
      justify-content: center;
    }

    .app-container {
      width: 100%;
      max-width: 480px;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      position: relative;
      padding-bottom: 30px;
    }

    /* Top Navbar */
    .header {
      position: sticky;
      top: 0;
      background: #12183a;
      height: 52px;
      display: flex;
      align-items: center;
      padding: 0 16px;
      z-index: 50;
    }

    .back-btn {
      background: none;
      border: none;
      color: #ffffff;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 6px;
      margin-left: -6px;
    }

    .header-title {
      font-size: 19px;
      font-weight: 600;
      letter-spacing: 0.3px;
      margin-left: 12px;
    }

    /* Channel Tabs */
    .tabs-container {
      display: flex;
      gap: 10px;
      padding: 10px 16px;
      overflow-x: auto;
      scrollbar-width: none;
    }
    .tabs-container::-webkit-scrollbar { display: none; }

    .tab-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 10px 20px;
      background: #232c5f;
      color: #9aa8e5;
      border: none;
      border-radius: 10px;
      font-size: 14px;
      font-weight: 500;
      white-space: nowrap;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .tab-btn.active {
      background: linear-gradient(135deg, #7c5cfc, #5b36f5);
      color: #ffffff;
      box-shadow: 0 4px 12px rgba(124, 92, 252, 0.35);
    }

    /* Filter Bar */
    .filter-bar {
      display: flex;
      gap: 12px;
      padding: 8px 16px 14px;
    }

    .filter-box {
      flex: 1;
      position: relative;
    }

    .filter-select, .filter-date-btn {
      width: 100%;
      height: 44px;
      background: #21295b;
      border: none;
      border-radius: 10px;
      color: #b8c4f5;
      font-size: 14px;
      padding: 0 36px 0 14px;
      appearance: none;
      cursor: pointer;
      outline: none;
    }

    .filter-icon {
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
      pointer-events: none;
      color: #7d8bb8;
    }

    /* History List & Cards */
    .history-list {
      padding: 0 16px;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }

    .card {
      background: #1f2756;
      border-radius: 12px;
      padding: 16px 16px 18px;
    }

    .card-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }

    .type-badge {
      background: #00e676;
      color: #0b1f13;
      font-size: 12px;
      font-weight: 700;
      padding: 4px 14px;
      border-radius: 6px;
      text-transform: capitalize;
    }

    .status-text {
      font-size: 14px;
      font-weight: 500;
    }
    .status-text.complete { color: #00e676; }
    .status-text.pending { color: #ffb300; }
    .status-text.failed { color: #ff5252; }

    .data-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 11px;
      font-size: 13.5px;
    }

    .data-row:last-child {
      margin-bottom: 0;
    }

    .data-label {
      color: #8c9ac9;
    }

    .data-value {
      color: #d1dbff;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .amount-val {
      color: #ff9800;
      font-size: 15px;
      font-weight: 700;
    }

    .copy-icon-btn {
      background: none;
      border: none;
      color: #8c9ac9;
      cursor: pointer;
      display: flex;
      align-items: center;
      padding: 2px;
    }
    .copy-icon-btn:active { color: #ffffff; }

    /* No More footer */
    .no-more {
      text-align: center;
      color: #6371a3;
      font-size: 13px;
      margin: 28px 0 10px;
    }

    /* Toast Notification */
    .toast {
      position: fixed;
      bottom: 40px;
      left: 50%;
      transform: translateX(-50%) translateY(20px);
      background: rgba(0, 0, 0, 0.85);
      color: #fff;
      padding: 8px 18px;
      border-radius: 20px;
      font-size: 13px;
      opacity: 0;
      pointer-events: none;
      transition: all 0.25s ease;
      z-index: 100;
    }
    .toast.show {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
  </style>
</head>
<body>

  <div class="app-container">
    <!-- Navbar -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="header-title">Deposit history</span>
    </header>

    <!-- Category Tabs -->
    <div class="tabs-container">
      <button class="tab-btn active" onclick="filterChannel('ALL', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M4 4h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 10h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 16h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4z"/></svg>
        All
      </button>
      <button class="tab-btn" onclick="filterChannel('ArUpi Pay', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
        ArUpi Pay
      </button>
      <button class="tab-btn" onclick="filterChannel('Innate UPI-QR', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M3 3h8v8H3zm2 2v4h4V5zm8-2h8v8h-8zm2 2v4h4V5zM3 13h8v8H3zm2 2v4h4v-4zm13-2h3v2h-3zm-5 0h3v5h-3zm2 5h3v3h-3zm3-3h3v5h-3z"/></svg>
        Innate UPI-QR
      </button>
    </div>

    <!-- Filter Dropdowns -->
    <div class="filter-bar">
      <div class="filter-box">
        <select class="filter-select" id="statusFilter" onchange="renderData()">
          <option value="ALL">All</option>
          <option value="Complete">Complete</option>
          <option value="Pending">Pending</option>
          <option value="Failed">Failed</option>
        </select>
        <svg class="filter-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
      </div>

      <div class="filter-box">
        <input type="date" class="filter-select" id="dateFilter" onchange="renderData()" />
        <svg class="filter-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>

    <!-- Dynamic History Items -->
    <div class="history-list" id="depositList"></div>

    <div class="no-more">No more</div>
  </div>

  <div id="toast" class="toast">Copied to clipboard</div>

  <script>
    // Real dynamic data array (Aap ise API response se replace kar sakte hain)
    let depositRecords = [
      {
        id: "RC20260905213444211101336c",
        typeTag: "Deposit",
        channel: "Innate UPI-QR",
        paymentType: "Phonepe_QR",
        amount: 100.00,
        status: "Complete",
        time: "2026-09-05 21:34:44"
      }
    ];

    let selectedChannel = "ALL";

    function filterChannel(channel, element) {
      document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
      element.classList.add('active');
      selectedChannel = channel;
      renderData();
    }

    function renderData() {
      const container = document.getElementById("depositList");
      const statusFilter = document.getElementById("statusFilter").value;
      const dateFilter = document.getElementById("dateFilter").value;

      let filtered = depositRecords.filter(item => {
        let channelMatch = (selectedChannel === "ALL" || item.channel === selectedChannel);
        let statusMatch = (statusFilter === "ALL" || item.status.toLowerCase() === statusFilter.toLowerCase());
        let dateMatch = !dateFilter || item.time.startsWith(dateFilter);
        return channelMatch && statusMatch && dateMatch;
      });

      if(filtered.length === 0) {
        container.innerHTML = `<div style="text-align:center; padding:40px 0; color:#6371a3;">No records found</div>`;
        return;
      }

      container.innerHTML = filtered.map(item => `
        <div class="card">
          <div class="card-top">
            <span class="type-badge">${item.typeTag}</span>
            <span class="status-text ${item.status.toLowerCase()}">${item.status}</span>
          </div>
          
          <div class="data-row">
            <span class="data-label">Order amount</span>
            <span class="data-value amount-val">₹${item.amount.toFixed(2)}</span>
          </div>
          
          <div class="data-row">
            <span class="data-label">Type</span>
            <span class="data-value">${item.paymentType}</span>
          </div>

          <div class="data-row">
            <span class="data-label">UTR</span>
            <span class="data-value">${item.utr || '-'}</span>
          </div>

          <div class="data-row">
            <span class="data-label">Time</span>
            <span class="data-value">${item.time}</span>
          </div>

          <div class="data-row">
            <span class="data-label">Order number</span>
            <span class="data-value">
              <span>${item.id}</span>
              <button class="copy-icon-btn" onclick="copyText('${item.id}')" title="Copy">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
              </button>
            </span>
          </div>
        </div>
      `).join('');
    }

    function copyText(text) {
      navigator.clipboard.writeText(text).then(() => {
        const toast = document.getElementById("toast");
        toast.classList.add("show");
        setTimeout(() => toast.classList.remove("show"), 1800);
      });
    }

    // Initial render
    window.addEventListener("DOMContentLoaded", renderData);
  </script>
</body>
</html>

"""

withdraw_history_html = """

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Withdrawal history</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #12183a;
      color: #ffffff;
      min-height: 100vh;
      display: flex;
      justify-content: center;
    }

    .app-container {
      width: 100%;
      max-width: 480px;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      position: relative;
      padding-bottom: 50px;
    }

    /* Top Navbar */
    .header {
      position: sticky;
      top: 0;
      background: #12183a;
      height: 52px;
      display: flex;
      align-items: center;
      padding: 0 16px;
      z-index: 50;
    }

    .back-btn {
      background: none;
      border: none;
      color: #ffffff;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 6px;
      margin-left: -6px;
    }

    .header-title {
      font-size: 19px;
      font-weight: 600;
      letter-spacing: 0.3px;
      margin-left: 12px;
    }

    /* Channel Tabs */
    .tabs-container {
      display: flex;
      gap: 10px;
      padding: 10px 16px;
      overflow-x: auto;
      scrollbar-width: none;
    }
    .tabs-container::-webkit-scrollbar { display: none; }

    .tab-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 10px 18px;
      background: #232c5f;
      color: #9aa8e5;
      border: none;
      border-radius: 10px;
      font-size: 14px;
      font-weight: 500;
      white-space: nowrap;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .tab-btn.active {
      background: linear-gradient(135deg, #7c5cfc, #5b36f5);
      color: #ffffff;
      box-shadow: 0 4px 12px rgba(124, 92, 252, 0.35);
    }

    /* Filter Bar */
    .filter-bar {
      display: flex;
      gap: 12px;
      padding: 8px 16px 14px;
    }

    .filter-box {
      flex: 1;
      position: relative;
    }

    .filter-select, .filter-date-btn {
      width: 100%;
      height: 44px;
      background: #21295b;
      border: none;
      border-radius: 10px;
      color: #b8c4f5;
      font-size: 14px;
      padding: 0 36px 0 14px;
      appearance: none;
      cursor: pointer;
      outline: none;
    }

    .filter-icon {
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
      pointer-events: none;
      color: #7d8bb8;
    }

    /* History List & Cards */
    .history-list {
      padding: 0 16px;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }

    .card {
      background: #1f2756;
      border-radius: 12px;
      padding: 16px 16px 18px;
    }

    .card-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }

    /* Withdraw Badge (Red style) */
    .type-badge-withdraw {
      background: #ff3b30;
      color: #ffffff;
      font-size: 12px;
      font-weight: 600;
      padding: 4px 14px;
      border-radius: 6px;
    }

    .status-text {
      font-size: 14px;
      font-weight: 500;
    }
    .status-text.completed { color: #00e676; }
    .status-text.pending { color: #ffb300; }
    .status-text.rejected { color: #ff5252; }

    .data-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 11px;
      font-size: 13.5px;
    }

    .data-row:last-child {
      margin-bottom: 0;
    }

    .data-label {
      color: #8c9ac9;
    }

    .data-value {
      color: #d1dbff;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .amount-val {
      color: #ff9800;
      font-size: 15px;
      font-weight: 700;
    }

    .copy-icon-btn {
      background: none;
      border: none;
      color: #8c9ac9;
      cursor: pointer;
      display: flex;
      align-items: center;
      padding: 2px;
    }
    .copy-icon-btn:active { color: #ffffff; }

    /* No More footer */
    .no-more {
      text-align: center;
      color: #6371a3;
      font-size: 13px;
      margin: 28px 0 10px;
    }

    /* Floating Support Icon */
    .floating-cs {
      position: fixed;
      right: 20px;
      bottom: 40px;
      width: 54px;
      height: 54px;
      background: #0d122e;
      border: 3px solid #00e676;
      box-shadow: 0 0 15px rgba(0, 230, 118, 0.45);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      z-index: 80;
    }

    /* Toast */
    .toast {
      position: fixed;
      bottom: 40px;
      left: 50%;
      transform: translateX(-50%) translateY(20px);
      background: rgba(0, 0, 0, 0.85);
      color: #fff;
      padding: 8px 18px;
      border-radius: 20px;
      font-size: 13px;
      opacity: 0;
      pointer-events: none;
      transition: all 0.25s ease;
      z-index: 100;
    }
    .toast.show {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
  </style>
</head>
<body>

  <div class="app-container">
    <!-- Navbar -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <span class="header-title">Withdrawal history</span>
    </header>

    <!-- Channel Tabs -->
    <div class="tabs-container">
      <button class="tab-btn active" onclick="filterChannel('ALL', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M4 4h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 10h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 16h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4z"/></svg>
        All
      </button>
      <button class="tab-btn" onclick="filterChannel('UPI', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 15h10M7 9h10"/></svg>
        UPI
      </button>
      <button class="tab-btn" onclick="filterChannel('ARPay', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="#ffb300"><path d="M12 2L2 22h20L12 2zm0 4l6.5 13h-13L12 6z"/></svg>
        ARPay
      </button>
      <button class="tab-btn" onclick="filterChannel('BANK CARD', this)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
        BANK CARD
      </button>
    </div>

    <!-- Filter Bar -->
    <div class="filter-bar">
      <div class="filter-box">
        <select class="filter-select" id="statusFilter" onchange="renderData()">
          <option value="ALL">All</option>
          <option value="Completed">Completed</option>
          <option value="Pending">Pending</option>
          <option value="Rejected">Rejected</option>
        </select>
        <svg class="filter-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
      </div>

      <div class="filter-box">
        <input type="date" class="filter-select" id="dateFilter" onchange="renderData()" />
        <svg class="filter-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
      </div>
    </div>

    <!-- Dynamic History Items -->
    <div class="history-list" id="withdrawList"></div>

    <div class="no-more">No more</div>

    <!-- Floating Customer Support Widget -->
    <div class="floating-cs" onclick="window.open('{{ support_url }}','_blank')">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="#00e676"><path d="M12 1a9 9 0 0 0-9 9v7a3 3 0 0 0 3 3h1a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1H5v-3a7 7 0 1 1 14 0v3h-2a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h1a3 3 0 0 0 3-3v-7a9 9 0 0 0-9-9z"/></svg>
    </div>
  </div>

  <div id="toast" class="toast">Copied to clipboard</div>

  <script>
    // Real dynamic data array
    let withdrawRecords = [
      {
        id: "WD20260905214749141101296c",
        typeTag: "Withdraw",
        channel: "BANK CARD",
        paymentType: "BANK CARD",
        amount: 130.00,
        status: "Completed",
        time: "2026-09-05 21:47:49",
        remarks: ""
      }
    ];

    let selectedChannel = "ALL";

    function filterChannel(channel, element) {
      document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
      element.classList.add('active');
      selectedChannel = channel;
      renderData();
    }

    function renderData() {
      const container = document.getElementById("withdrawList");
      const statusFilter = document.getElementById("statusFilter").value;
      const dateFilter = document.getElementById("dateFilter").value;

      let filtered = withdrawRecords.filter(item => {
        let channelMatch = (selectedChannel === "ALL" || item.channel === selectedChannel);
        let statusMatch = (statusFilter === "ALL" || item.status.toLowerCase() === statusFilter.toLowerCase());
        let dateMatch = !dateFilter || item.time.startsWith(dateFilter);
        return channelMatch && statusMatch && dateMatch;
      });

      if(filtered.length === 0) {
        container.innerHTML = `<div style="text-align:center; padding:40px 0; color:#6371a3;">No records found</div>`;
        return;
      }

      container.innerHTML = filtered.map(item => `
        <div class="card">
          <div class="card-top">
            <span class="type-badge-withdraw">${item.typeTag}</span>
            <span class="status-text ${item.status.toLowerCase()}">${item.status}</span>
          </div>
          
          <div class="data-row">
            <span class="data-label">Balance</span>
            <span class="data-value amount-val">₹${item.amount.toFixed(2)}</span>
          </div>
          
          <div class="data-row">
            <span class="data-label">Type</span>
            <span class="data-value">${item.paymentType}</span>
          </div>

          <div class="data-row">
            <span class="data-label">Time</span>
            <span class="data-value">${item.time}</span>
          </div>

          <div class="data-row">
            <span class="data-label">Order number</span>
            <span class="data-value">
              <span>${item.id}</span>
              <button class="copy-icon-btn" onclick="copyText('${item.id}')" title="Copy">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
              </button>
            </span>
          </div>

          <div class="data-row">
            <span class="data-label">Remarks</span>
            <span class="data-value">${item.remarks || ""}</span>
          </div>
        </div>
      `).join('');
    }

    function copyText(text) {
      navigator.clipboard.writeText(text).then(() => {
        const toast = document.getElementById("toast");
        toast.classList.add("show");
        setTimeout(() => toast.classList.remove("show"), 1800);
      });
    }

    // Initial render
    window.addEventListener("DOMContentLoaded", renderData);
  </script>
</body>
</html>

"""

