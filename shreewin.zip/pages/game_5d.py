html_5d = r'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Shree.Win - 5D Lottery</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    :root {
      --bg-main: #191340;
      --bg-darker: #100b2b;
      --card-bg: #221a53;
      --card-inner: #2c2266;
      --text-muted: #958dc2;
      --green-slot: #00b871;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
      user-select: none;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #0d0822;
      display: flex;
      justify-content: center;
      min-height: 100vh;
      color: #fff;
    }

    .app-container {
      width: 100%;
      max-width: 440px;
      background: linear-gradient(180deg, #1b1446 0%, #100b2c 100%);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      padding-bottom: 40px;
      position: relative;
      box-shadow: 0 0 30px rgba(0,0,0,0.9);
    }

    /* Header */
    .top-nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 14px 16px;
      background: #17113f;
    }
    .top-nav .logo {
      font-size: 22px;
      font-weight: 900;
      background: linear-gradient(180deg, #ffe066 0%, #ff8c1a 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      letter-spacing: 0.5px;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .top-icons i {
      font-size: 18px;
      margin-left: 14px;
      color: #b7b0e2;
      cursor: pointer;
    }

    /* Wallet Card */
    .wallet-card {
      margin: 12px 16px;
      background: linear-gradient(135deg, #2d236e 0%, #1f1754 100%);
      border-radius: 18px;
      padding: 16px;
      box-shadow: 0 6px 18px rgba(0,0,0,0.4);
      border: 1px solid rgba(255,255,255,0.05);
    }
    .wallet-header {
      font-size: 13px;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }
    .wallet-balance {
      font-size: 30px;
      font-weight: 800;
      text-align: center;
      margin: 4px 0 14px 0;
      color: #ffffff;
      letter-spacing: 0.5px;
    }
    .wallet-btns { display: flex; gap: 12px; }
    .btn-withdraw {
      flex: 1;
      background: linear-gradient(180deg, #ffc837 0%, #ff8008 100%);
      color: #3b1e00;
      font-weight: 700;
      padding: 11px;
      border-radius: 25px;
      border: none;
      cursor: pointer;
      font-size: 14px;
    }
    .btn-deposit {
      flex: 1;
      background: linear-gradient(180deg, #8a65f8 0%, #5931eb 100%);
      color: #fff;
      font-weight: 700;
      padding: 11px;
      border-radius: 25px;
      border: none;
      cursor: pointer;
      font-size: 14px;
    }

    /* Notice */
    .notice-bar {
      margin: 0 16px 10px 16px;
      background: #1c1549;
      border-radius: 20px;
      padding: 6px 12px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 11px;
      color: var(--text-muted);
    }
    .notice-bar i { color: #ffb703; font-size: 13px; }
    .notice-text { flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

    /* 5D Game Modes */
    .game-mode-tabs {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 8px;
      padding: 0 16px;
      margin-bottom: 12px;
    }
    .mode-tab {
      background: #1d164d;
      border-radius: 14px;
      padding: 10px 4px;
      text-align: center;
      cursor: pointer;
      color: var(--text-muted);
      border: 1px solid rgba(255,255,255,0.03);
    }
    .mode-tab.active {
      background: linear-gradient(180deg, #7c5af8 0%, #532deb 100%);
      color: #fff;
      box-shadow: 0 4px 12px rgba(99, 62, 243, 0.4);
    }
    .mode-tab i { font-size: 18px; margin-bottom: 4px; display: block; }
    .mode-tab span { font-size: 11px; font-weight: 700; display: block; }

    /* Lottery Results Header Banner */
    .lottery-results-banner {
      margin: 0 16px 12px 16px;
      background: #1f184e;
      border-radius: 16px;
      padding: 10px 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border: 1px solid rgba(255,255,255,0.04);
    }
    .lr-title { font-size: 11px; color: var(--text-muted); font-weight: 600; }
    .lr-balls-row { display: flex; align-items: center; gap: 6px; }
    .lr-ball-group { display: flex; flex-direction: column; align-items: center; }
    .lr-ball {
      width: 28px;
      height: 28px;
      background: #50449c;
      border-radius: 50%;
      color: #fff;
      font-size: 12px;
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.3);
    }
    .lr-label { font-size: 9px; color: var(--text-muted); margin-top: 2px; font-weight: 700; }
    .lr-sum-ball {
      width: 32px;
      height: 32px;
      background: #7355f6;
      border-radius: 50%;
      color: #fff;
      font-size: 13px;
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 6px rgba(115, 85, 246, 0.5);
    }

    /* Game Arena */
    .game-arena {
      background: var(--card-bg);
      margin: 0 16px;
      border-radius: 18px;
      padding: 14px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.3);
      border: 1px solid rgba(255,255,255,0.05);
    }
    .arena-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
    }
    .period-title { font-size: 12px; color: var(--text-muted); }
    .period-id { font-size: 14px; font-weight: 800; color: #ffffff; letter-spacing: 0.5px; }

    .timer-wrap { text-align: right; }
    .timer-title { font-size: 10px; color: var(--text-muted); margin-bottom: 2px; }
    .timer-boxes { display: flex; align-items: center; gap: 3px; justify-content: flex-end; }
    .t-box {
      background: #2b216c;
      color: #9f8dfc;
      font-weight: 800;
      font-size: 14px;
      padding: 3px 6px;
      border-radius: 6px;
      min-width: 22px;
      text-align: center;
    }
    .t-box.alert { background: #8e1030; color: #ffb8c9; animation: pulseAlert 0.5s infinite alternate; }
    @keyframes pulseAlert { from { transform: scale(1); } to { transform: scale(1.08); } }

    /* 5D Green Slot Machine (5 Reels: A, B, C, D, E) */
    .slot-5d-machine {
      background: linear-gradient(180deg, #0ec87d 0%, #00995c 100%);
      border-radius: 16px;
      padding: 10px 8px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: inset 0 2px 6px rgba(255,255,255,0.4), 0 6px 14px rgba(0,0,0,0.4);
    }
    .slot-arrow { color: rgba(255,255,255,0.8); font-size: 14px; font-weight: 900; }
    .slot-reels-container {
      display: flex;
      gap: 6px;
      flex: 1;
      justify-content: center;
    }
    .reel-pocket {
      flex: 1;
      height: 80px;
      background: #17113e;
      border-radius: 10px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow: hidden;
      box-shadow: inset 0 3px 6px rgba(0,0,0,0.6);
      border: 1px solid rgba(0,0,0,0.2);
    }
    .reel-disc {
      width: 44px;
      height: 44px;
      background: #e8e6f5;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #5544aa;
      font-size: 22px;
      font-weight: 900;
      box-shadow: 0 4px 8px rgba(0,0,0,0.3);
      transition: transform 0.2s;
    }
    .reel-pocket.active-reel .reel-disc {
      background: #00c875;
      color: #fff;
    }
    .reel-disc.spinning {
      animation: reelSpin 0.3s infinite linear;
    }
    @keyframes reelSpin {
      0% { transform: translateY(-30px) scale(0.8); opacity: 0.5; }
      50% { transform: translateY(0) scale(1.1); opacity: 1; }
      100% { transform: translateY(30px) scale(0.8); opacity: 0.5; }
    }

    /* Position Sub-Tabs (A, B, C, D, E, SUM) */
    .position-tabs-grid {
      display: grid;
      grid-template-columns: repeat(6, 1fr);
      gap: 6px;
      margin: 14px 0 12px 0;
    }
    .pos-tab {
      background: #342875;
      color: #b7aee0;
      text-align: center;
      padding: 10px 0 8px 0;
      font-size: 13px;
      font-weight: 800;
      border-radius: 14px 14px 4px 4px;
      cursor: pointer;
      transition: all 0.2s;
    }
    .pos-tab.active {
      background: linear-gradient(180deg, #9b7bff 0%, #6842f5 100%);
      color: #fff;
      box-shadow: 0 3px 8px rgba(104, 66, 245, 0.4);
      transform: translateY(-2px);
    }

    /* Quick Action Buttons (Big, Small, Odd, Even) */
    .quick-action-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 8px;
      margin-bottom: 14px;
    }
    .q-btn {
      padding: 10px 0;
      border-radius: 12px;
      text-align: center;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      font-size: 13px;
      font-weight: 800;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
      border: 1px solid rgba(255,255,255,0.12);
    }
    .btn-big   { background: linear-gradient(180deg, #ffaf38 0%, #e68500 100%); }
    .btn-small { background: linear-gradient(180deg, #44a6ff 0%, #1e7ada 100%); }
    .btn-odd   { background: linear-gradient(180deg, #ff5252 0%, #d82424 100%); }
    .btn-even  { background: linear-gradient(180deg, #20dc86 0%, #0ca75f 100%); }

    /* 0 to 9 Numbers Matrix */
    .numbers-matrix-5d {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 12px 6px;
      margin-bottom: 8px;
    }
    .num-card-5d {
      display: flex;
      flex-direction: column;
      align-items: center;
      cursor: pointer;
    }
    .num-ring-5d {
      width: 44px;
      height: 44px;
      border: 2px solid #6b55c9;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
      font-weight: 800;
      color: #d1c8f5;
      background: #1e174b;
      box-shadow: 0 3px 8px rgba(0,0,0,0.3);
      transition: transform 0.1s;
    }
    .num-ring-5d:active { transform: scale(0.92); }
    .num-mult-5d {
      font-size: 11px;
      font-weight: 700;
      color: var(--text-muted);
      margin-top: 3px;
    }

    /* Active Bet Notification */
    .active-bet-indicator {
      margin-top: 10px;
      background: #1b1244;
      border: 1px solid #ffcc00;
      padding: 8px;
      border-radius: 10px;
      text-align: center;
      font-size: 12px;
      color: #ffde59;
      display: none;
      font-weight: 600;
    }

    /* History Section */
    .history-card {
      margin: 16px;
      background: var(--card-bg);
      border-radius: 18px;
      padding: 16px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.3);
      border: 1px solid rgba(255,255,255,0.05);
    }
    .history-tabs-row {
      display: flex;
      background: #17113e;
      border-radius: 10px;
      padding: 4px;
      margin-bottom: 14px;
    }
    .h-tab-item {
      flex: 1;
      text-align: center;
      padding: 8px 0;
      font-size: 12px;
      color: var(--text-muted);
      cursor: pointer;
      font-weight: 600;
      border-radius: 8px;
    }
    .h-tab-item.active {
      background: linear-gradient(180deg, #7c5df8 0%, #5835eb 100%);
      color: #fff;
    }

    .history-table-custom { width: 100%; border-collapse: collapse; }
    .history-table-custom th {
      font-size: 11px;
      color: var(--text-muted);
      font-weight: 600;
      padding: 8px 4px;
      text-align: center;
      border-bottom: 1px solid #2e2469;
    }
    .history-table-custom td {
      font-size: 11px;
      padding: 9px 2px;
      text-align: center;
      border-bottom: 1px solid rgba(255,255,255,0.04);
      vertical-align: middle;
    }

    .five-balls-row {
      display: inline-flex;
      gap: 3px;
    }
    .mini-digit-ball {
      width: 17px;
      height: 17px;
      border: 1px solid #5848a6;
      border-radius: 50%;
      background: #201754;
      color: #fff;
      font-size: 10px;
      font-weight: 700;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    .sum-badge-group { display: inline-flex; gap: 3px; }
    .badge-circ {
      width: 17px;
      height: 17px;
      border-radius: 50%;
      color: #fff;
      font-size: 9px;
      font-weight: 800;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .badge-b { background: #ffaf38; }
    .badge-s { background: #44a6ff; }
    .badge-o { background: #ff5252; }
    .badge-e { background: #20dc86; }

    /* Chart Section */
    .chart-box { padding: 10px 0; font-size: 12px; }
    .stat-bar-wrap { margin-bottom: 14px; }
    .stat-label-row { display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 11px; color: var(--text-muted); }
    .progress-track { height: 12px; background: #140e36; border-radius: 6px; overflow: hidden; display: flex; }
    .progress-fill-big { background: #ffaf38; }
    .progress-fill-small { background: #44a6ff; }
    .progress-fill-even { background: #20dc86; }
    .progress-fill-odd { background: #ff5252; }

    /* Drawer Modal */
    .bet-drawer-modal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.75);
      backdrop-filter: blur(4px);
      z-index: 200;
      justify-content: center;
      align-items: flex-end;
    }
    .drawer-body {
      width: 100%;
      max-width: 440px;
      background: #201754;
      border-radius: 24px 24px 0 0;
      padding: 20px;
      box-shadow: 0 -8px 24px rgba(0,0,0,0.6);
      animation: slideUp 0.25s ease-out;
    }
    @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
    .drawer-title {
      font-size: 16px;
      font-weight: 700;
      color: #ffde59;
      margin-bottom: 12px;
      display: flex;
      justify-content: space-between;
    }
    .quick-chips { display: flex; gap: 8px; margin-bottom: 14px; }
    .chip {
      flex: 1;
      padding: 8px 0;
      background: #150f38;
      border: 1px solid #43348f;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 700;
      text-align: center;
      cursor: pointer;
      color: #c9c3ee;
    }
    .chip.selected { background: #7355f6; border-color: #9277ff; color: #fff; }
    .custom-input {
      width: 100%;
      padding: 12px;
      background: #140e36;
      border: 1px solid #5844b5;
      border-radius: 10px;
      color: #fff;
      font-size: 16px;
      font-weight: 700;
      margin-bottom: 16px;
      outline: none;
    }
    .drawer-actions { display: flex; gap: 12px; }
    .drawer-actions button {
      flex: 1;
      padding: 12px;
      border-radius: 12px;
      border: none;
      font-weight: 700;
      font-size: 14px;
      cursor: pointer;
    }
    .btn-cancel-modal { background: #3d346b; color: #fff; }
    .btn-confirm-modal { background: linear-gradient(180deg, #1fdd86 0%, #0ba45e 100%); color: #fff; }
  </style>
</head>
<body>

<div class="app-container">

  <!-- Top Navigation -->
  <div class="top-nav">
    <i class="fa-solid fa-chevron-left"></i>
    <div class="logo"><span>🎲</span> Shree.Win</div>
    <div class="top-icons">
      <i class="fa-solid fa-volume-high" id="soundToggleBtn" onclick="toggleSound()" title="Mute/Unmute"></i>
      <i class="fa-solid fa-rotate-right" onclick="loadBalanceFromServer()" title="Refresh Balance"></i>
    </div>
  </div>

  <!-- Wallet Header -->
  <div class="wallet-card">
    <div class="wallet-header"><i class="fa-solid fa-wallet"></i> Wallet balance</div>
    <div class="wallet-balance" id="balanceDisplay">₹0.00</div>
    <div class="wallet-btns">
      <button class="btn-withdraw" onclick="location.href='/withdraw'">Withdraw</button>
      <button class="btn-deposit" onclick="location.href='/deposit'">+ Deposit</button>
    </div>
  </div>

  <!-- Notice -->
  <div class="notice-bar">
    <i class="fa-solid fa-bullhorn"></i>
    <div class="notice-text">Our Shree.Win Customer Service will never send links directly to members.</div>
  </div>

  <!-- 5D Game Mode Tabs -->
  <div class="game-mode-tabs">
    <div class="mode-tab active" onclick="switchGameMode('1min', this)">
      <i class="fa-regular fa-clock"></i>
      <span>5D 1 Min</span>
    </div>
    <div class="mode-tab" onclick="switchGameMode('3min', this)">
      <i class="fa-regular fa-clock"></i>
      <span>5D 3 Min</span>
    </div>
    <div class="mode-tab" onclick="switchGameMode('5min', this)">
      <i class="fa-regular fa-clock"></i>
      <span>5D 5 Min</span>
    </div>
    <div class="mode-tab" onclick="switchGameMode('10min', this)">
      <i class="fa-regular fa-clock"></i>
      <span>5D 10 Min</span>
    </div>
  </div>

  <!-- Lottery Results Row -->
  <div class="lottery-results-banner">
    <span class="lr-title">Lottery<br/>results</span>
    <div class="lr-balls-row">
      <div class="lr-ball-group"><div class="lr-ball" id="lrA">8</div><span class="lr-label">A</span></div>
      <div class="lr-ball-group"><div class="lr-ball" id="lrB">9</div><span class="lr-label">B</span></div>
      <div class="lr-ball-group"><div class="lr-ball" id="lrC">7</div><span class="lr-label">C</span></div>
      <div class="lr-ball-group"><div class="lr-ball" id="lrD">1</div><span class="lr-label">D</span></div>
      <div class="lr-ball-group"><div class="lr-ball" id="lrE">2</div><span class="lr-label">E</span></div>
      <span style="font-weight:900; color:var(--text-muted); margin:0 2px;">=</span>
      <div class="lr-ball-group"><div class="lr-sum-ball" id="lrSum">27</div><span class="lr-label">Sum</span></div>
    </div>
  </div>

  <!-- Game Arena -->
  <div class="game-arena">
    <div class="arena-top">
      <div>
        <div class="period-title">Period</div>
        <div class="period-id" id="currentPeriodDisplay">20260912102011211</div>
      </div>
      <div class="timer-wrap">
        <div class="timer-title">Time remaining</div>
        <div class="timer-boxes">
          <div class="t-box" id="minTens">0</div>
          <div class="t-box" id="minUnits">0</div>
          <span style="font-weight:900; color:#8575df;">:</span>
          <div class="t-box" id="secTens">6</div>
          <div class="t-box" id="secUnits">0</div>
        </div>
      </div>
    </div>

    <!-- 5D Slot Machine (A, B, C, D, E Reels) -->
    <div class="slot-5d-machine">
      <span class="slot-arrow">&#9664;</span>
      <div class="slot-reels-container">
        <div class="reel-pocket active-reel" id="reelWrap0"><div class="reel-disc" id="reel0">8</div></div>
        <div class="reel-pocket" id="reelWrap1"><div class="reel-disc" id="reel1">9</div></div>
        <div class="reel-pocket" id="reelWrap2"><div class="reel-disc" id="reel2">7</div></div>
        <div class="reel-pocket" id="reelWrap3"><div class="reel-disc" id="reel3">1</div></div>
        <div class="reel-pocket" id="reelWrap4"><div class="reel-disc" id="reel4">2</div></div>
      </div>
      <span class="slot-arrow">&#9654;</span>
    </div>

    <div class="active-bet-indicator" id="activeBetIndicator"></div>

    <!-- Position Tabs (A, B, C, D, E, SUM) -->
    <div class="position-tabs-grid">
      <div class="pos-tab active" onclick="switchPosition('A', 0, this)">A</div>
      <div class="pos-tab" onclick="switchPosition('B', 1, this)">B</div>
      <div class="pos-tab" onclick="switchPosition('C', 2, this)">C</div>
      <div class="pos-tab" onclick="switchPosition('D', 3, this)">D</div>
      <div class="pos-tab" onclick="switchPosition('E', 4, this)">E</div>
      <div class="pos-tab" onclick="switchPosition('SUM', -1, this)">SUM</div>
    </div>

    <!-- Quick Action (Big, Small, Odd, Even) -->
    <div class="quick-action-grid">
      <div class="q-btn btn-big" onclick="openBetDrawer('Big', 2.0)">Big 2X</div>
      <div class="q-btn btn-small" onclick="openBetDrawer('Small', 2.0)">Small 2X</div>
      <div class="q-btn btn-odd" onclick="openBetDrawer('Odd', 2.0)">Odd 2X</div>
      <div class="q-btn btn-even" onclick="openBetDrawer('Even', 2.0)">Even 2X</div>
    </div>

    <!-- Numbers Matrix 0-9 (Only for A, B, C, D, E) -->
    <div id="numbersMatrixContainer">
      <div class="numbers-matrix-5d" id="numbersGrid5D"></div>
    </div>

  </div>

  <!-- History & Analysis -->
  <div class="history-card">
    <div class="history-tabs-row">
      <div class="h-tab-item active" onclick="switchHistoryTab('game', this)">Game history</div>
      <div class="h-tab-item" onclick="switchHistoryTab('chart', this)">Chart</div>
      <div class="h-tab-item" onclick="switchHistoryTab('my', this)">My history</div>
    </div>

    <!-- View 1: Game History -->
    <div id="hview-game">
      <table class="history-table-custom">
        <thead>
          <tr><th>Period</th><th>Result</th><th>Sum</th></tr>
        </thead>
        <tbody id="historyTableBody"></tbody>
      </table>
    </div>

    <!-- View 2: Chart Stats -->
    <div id="hview-chart" style="display:none;" class="chart-box">
      <div class="stat-bar-wrap">
        <div class="stat-label-row">
          <span>Big: <b id="statBigPct">50%</b></span>
          <span>Small: <b id="statSmallPct">50%</b></span>
        </div>
        <div class="progress-track">
          <div class="progress-fill-big" id="barBig" style="width:50%;"></div>
          <div class="progress-fill-small" id="barSmall" style="width:50%;"></div>
        </div>
      </div>
      <div class="stat-bar-wrap">
        <div class="stat-label-row">
          <span>Even: <b id="statEvenPct">50%</b></span>
          <span>Odd: <b id="statOddPct">50%</b></span>
        </div>
        <div class="progress-track">
          <div class="progress-fill-even" id="barEven" style="width:50%;"></div>
          <div class="progress-fill-odd" id="barOdd" style="width:50%;"></div>
        </div>
      </div>
    </div>

    <!-- View 3: My History -->
    <div id="hview-my" style="display:none;">
      <table class="history-table-custom">
        <thead>
          <tr><th>Period</th><th>Bet</th><th>Amount</th><th>Status</th></tr>
        </thead>
        <tbody id="myHistoryTableBody">
          <tr><td colspan="4" style="color:var(--text-muted); padding:16px;">No bets placed yet</td></tr>
        </tbody>
      </table>
    </div>

  </div>

</div>

<!-- Betting Drawer Modal -->
<div class="bet-drawer-modal" id="betDrawerModal">
  <div class="drawer-body">
    <div class="drawer-title">
      <span id="drawerBetLabel">Select Bet</span>
      <span id="drawerBetMult" style="color:#20dc86;">9X</span>
    </div>

    <div class="quick-chips">
      <div class="chip selected" onclick="selectChip(10, this)">₹10</div>
      <div class="chip" onclick="selectChip(50, this)">₹50</div>
      <div class="chip" onclick="selectChip(100, this)">₹100</div>
      <div class="chip" onclick="selectChip(500, this)">₹500</div>
    </div>

    <input type="number" id="drawerAmountInput" class="custom-input" value="10" min="10" step="10" />

    <div class="drawer-actions">
      <button class="btn-cancel-modal" onclick="closeBetDrawer()">Cancel</button>
      <button class="btn-confirm-modal" onclick="confirmPlacedBet()">Confirm</button>
    </div>
  </div>
</div>

<script>
  // Web Audio Synthesizer
  const AudioEngine = {
    ctx: null,
    muted: false,
    init() {
      if (!this.ctx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        this.ctx = new AudioContext();
      }
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
    },
    playTick() {
      if (this.muted) return;
      this.init();
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(900, this.ctx.currentTime);
      gain.gain.setValueAtTime(0.1, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.08);
    },
    playSpin() {
      if (this.muted) return;
      this.init();
      for (let i = 0; i < 6; i++) {
        setTimeout(() => {
          if (this.muted) return;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(250 + Math.random() * 250, this.ctx.currentTime);
          gain.gain.setValueAtTime(0.1, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.05);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start();
          osc.stop(this.ctx.currentTime + 0.05);
        }, i * 60);
      }
    },
    playWin() {
      if (this.muted) return;
      this.init();
      const notes = [523.25, 659.25, 783.99, 1046.50];
      notes.forEach((freq, idx) => {
        setTimeout(() => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
          gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.25);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start();
          osc.stop(this.ctx.currentTime + 0.25);
        }, idx * 100);
      });
    },
    playLoss() {
      if (this.muted) return;
      this.init();
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(250, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(100, this.ctx.currentTime + 0.35);
      gain.gain.setValueAtTime(0.1, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.35);
    }
  };

  function toggleSound() {
    AudioEngine.muted = !AudioEngine.muted;
    const btn = document.getElementById("soundToggleBtn");
    btn.className = AudioEngine.muted ? "fa-solid fa-volume-xmark" : "fa-solid fa-volume-high";
  }

  // 5D State
  let balance = 0.00;
  let currentMode = '1min';
  let activePosition = 'A'; // A, B, C, D, E or SUM
  let activeReelIndex = 0;

  const modeState = {
    '1min':  { duration: 60,  timeLeft: 60,  period: 20260912102011211, activeBet: null, digits: [8, 9, 7, 1, 2] },
    '3min':  { duration: 180, timeLeft: 180, period: 20260912103011082, activeBet: null, digits: [2, 5, 3, 4, 0] },
    '5min':  { duration: 300, timeLeft: 300, period: 20260912105011041, activeBet: null, digits: [6, 4, 5, 1, 9] },
    '10min': { duration: 600, timeLeft: 600, period: 20260912110011020, activeBet: null, digits: [0, 8, 6, 9, 3] }
  };

  let selectedChoice = { position: 'A', label: "", mult: 9 };
  let gameHistoryRecords = JSON.parse(localStorage.getItem("5d_game_history")) || [];
  let myHistoryRecords = JSON.parse(localStorage.getItem("5d_my_history")) || [];

  function init() {
    loadBalanceFromServer();
    renderNumbersGrid5D();
    renderReels();
    updateWalletDisplay();
    startMasterClock();

    if (gameHistoryRecords.length === 0) {
      preloadInitialData();
    } else {
      renderGameHistoryUI();
      updateChartStats();
    }
    renderMyHistoryUI();
    updateModeUI();
  }

  function renderNumbersGrid5D() {
    const container = document.getElementById("numbersGrid5D");
    container.innerHTML = "";
    for (let i = 0; i <= 9; i++) {
      container.innerHTML += `
        <div class="num-card-5d" onclick="openBetDrawer('${i}', 9.0)">
          <div class="num-ring-5d">${i}</div>
          <div class="num-mult-5d">9X</div>
        </div>
      `;
    }
  }

  function renderReels() {
    const curDigits = modeState[currentMode].digits;
    for (let i = 0; i < 5; i++) {
      document.getElementById(`reel${i}`).innerText = curDigits[i];
    }
    // Update Top Banner
    document.getElementById("lrA").innerText = curDigits[0];
    document.getElementById("lrB").innerText = curDigits[1];
    document.getElementById("lrC").innerText = curDigits[2];
    document.getElementById("lrD").innerText = curDigits[3];
    document.getElementById("lrE").innerText = curDigits[4];
    const sum = curDigits.reduce((a, b) => a + b, 0);
    document.getElementById("lrSum").innerText = sum;
  }

  // Fair CSPRNG
  function getRandomDigit() {
    const arr = new Uint32Array(1);
    window.crypto.getRandomValues(arr);
    return arr[0] % 10;
  }

  // Master Clock
  function startMasterClock() {
    setInterval(() => {
      Object.keys(modeState).forEach(mode => {
        const state = modeState[mode];
        if (state.timeLeft > 0) {
          state.timeLeft--;
        } else {
          execute5DDraw(mode);
          state.timeLeft = state.duration;
        }
      });

      const activeState = modeState[currentMode];
      if (activeState.timeLeft <= 5 && activeState.timeLeft > 0) {
        AudioEngine.playTick();
      }

      updateTimerDisplay();
    }, 1000);
  }

  function updateTimerDisplay() {
    const t = modeState[currentMode].timeLeft;
    const mins = Math.floor(t / 60);
    const secs = t % 60;

    const minTens = Math.floor(mins / 10);
    const minUnits = mins % 10;
    const secTens = Math.floor(secs / 10);
    const secUnits = secs % 10;

    const boxes = [
      document.getElementById("minTens"),
      document.getElementById("minUnits"),
      document.getElementById("secTens"),
      document.getElementById("secUnits")
    ];

    boxes[0].innerText = minTens;
    boxes[1].innerText = minUnits;
    boxes[2].innerText = secTens;
    boxes[3].innerText = secUnits;

    if (t <= 5) {
      boxes.forEach(b => b.classList.add("alert"));
    } else {
      boxes.forEach(b => b.classList.remove("alert"));
    }
  }

  // Game Mode Switching
  function switchGameMode(modeKey, elem) {
    document.querySelectorAll(".game-mode-tabs .mode-tab").forEach(tab => tab.classList.remove("active"));
    elem.classList.add("active");
    currentMode = modeKey;
    updateModeUI();
  }

  function updateModeUI() {
    const state = modeState[currentMode];
    document.getElementById("currentPeriodDisplay").innerText = state.period;
    renderReels();
    updateTimerDisplay();

    const indicator = document.getElementById("activeBetIndicator");
    if (state.activeBet) {
      indicator.style.display = "block";
      indicator.innerText = `[${currentMode.toUpperCase()}] Active: ₹${state.activeBet.amount} on Pos ${state.activeBet.position} - ${state.activeBet.label} (${state.activeBet.mult}X)`;
    } else {
      indicator.style.display = "none";
    }
  }

  // Position Switching (A, B, C, D, E, SUM)
  function switchPosition(pos, index, elem) {
    document.querySelectorAll(".position-tabs-grid .pos-tab").forEach(t => t.classList.remove("active"));
    elem.classList.add("active");
    activePosition = pos;
    activeReelIndex = index;

    // Highlight active reel
    document.querySelectorAll(".reel-pocket").forEach((r, idx) => {
      if (idx === index) r.classList.add("active-reel");
      else r.classList.remove("active-reel");
    });

    // Hide 0-9 digits if SUM is active
    document.getElementById("numbersMatrixContainer").style.display = (pos === 'SUM') ? 'none' : 'block';
  }

  // 5D Draw Engine
  function execute5DDraw(modeKey) {
    const state = modeState[modeKey];
    const isCurrentActiveView = (modeKey === currentMode);

    if (isCurrentActiveView) {
      for (let i = 0; i < 5; i++) {
        document.getElementById(`reel${i}`).classList.add("spinning");
      }
      AudioEngine.playSpin();
    }

    setTimeout(() => {
      state.digits = [
        getRandomDigit(),
        getRandomDigit(),
        getRandomDigit(),
        getRandomDigit(),
        getRandomDigit()
      ];

      if (isCurrentActiveView) {
        renderReels();
        for (let i = 0; i < 5; i++) {
          document.getElementById(`reel${i}`).classList.remove("spinning");
        }
      }

      const sum = state.digits.reduce((a, b) => a + b, 0);
      const isSumBig = sum >= 23;
      const isSumEven = (sum % 2 === 0);

      // Settle active bet
      if (state.activeBet) {
        let isWinner = false;
        const b = state.activeBet;

        if (b.position === 'SUM') {
          if (b.label === "Big" && isSumBig) isWinner = true;
          if (b.label === "Small" && !isSumBig) isWinner = true;
          if (b.label === "Even" && isSumEven) isWinner = true;
          if (b.label === "Odd" && !isSumEven) isWinner = true;
        } else {
          const posIdx = { 'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4 }[b.position];
          const drawnVal = state.digits[posIdx];
          const isPosBig = drawnVal >= 5;
          const isPosEven = (drawnVal % 2 === 0);

          if (b.label === "Big" && isPosBig) isWinner = true;
          if (b.label === "Small" && !isPosBig) isWinner = true;
          if (b.label === "Even" && isPosEven) isWinner = true;
          if (b.label === "Odd" && !isPosEven) isWinner = true;
          if (b.label === String(drawnVal)) isWinner = true;
        }

        if (isWinner) {
          const payout = b.amount * b.mult;
          updateServerBalance("add", payout).then(res => {
            if (res.ok) { balance = res.balance; updateWalletDisplay(); }
          });
          if (isCurrentActiveView) AudioEngine.playWin();
          alert(`🎉 [${modeKey.toUpperCase()}] Congratulation! You won ₹${payout.toFixed(2)}`);
          recordMyBet(state.period, `${b.position} - ${b.label}`, b.amount, "WIN", payout);
        } else {
          if (isCurrentActiveView) AudioEngine.playLoss();
          alert(`❌ [${modeKey.toUpperCase()}] Round Ended. Drawn: ${state.digits.join(' ')} (Sum: ${sum})`);
          recordMyBet(state.period, `${b.position} - ${b.label}`, b.amount, "LOSE", 0);
        }

        updateWalletDisplay();
        state.activeBet = null;
        if (isCurrentActiveView) {
          document.getElementById("activeBetIndicator").style.display = "none";
        }
      }

      // Add to History
      const record = {
        p: state.period,
        mode: modeKey,
        digits: [...state.digits],
        sum: sum,
        bs: isSumBig ? "B" : "S",
        oe: isSumEven ? "E" : "O"
      };
      gameHistoryRecords.unshift(record);
      if (gameHistoryRecords.length > 50) gameHistoryRecords.pop();

      localStorage.setItem("5d_game_history", JSON.stringify(gameHistoryRecords));
      renderGameHistoryUI();
      updateChartStats();

      state.period++;
      if (isCurrentActiveView) {
        document.getElementById("currentPeriodDisplay").innerText = state.period;
      }
    }, 800);
  }

  // Drawer Modal
  function openBetDrawer(label, mult) {
    AudioEngine.init();
    if (modeState[currentMode].timeLeft <= 5) {
      alert(`Betting locked for ${currentMode.toUpperCase()}! Please wait for next round.`);
      return;
    }
    selectedChoice = { position: activePosition, label, mult };
    document.getElementById("drawerBetLabel").innerText = `[${activePosition}] Bet: ${label}`;
    document.getElementById("drawerBetMult").innerText = `${mult}X`;
    document.getElementById("betDrawerModal").style.display = "flex";
  }

  function closeBetDrawer() {
    document.getElementById("betDrawerModal").style.display = "none";
  }

  function selectChip(val, elem) {
    document.querySelectorAll(".quick-chips .chip").forEach(c => c.classList.remove("selected"));
    elem.classList.add("selected");
    document.getElementById("drawerAmountInput").value = val;
  }

  async function confirmPlacedBet() {
    const amt = parseFloat(document.getElementById("drawerAmountInput").value);
    if (isNaN(amt) || amt <= 0) {
      alert("Please enter a valid amount!");
      return;
    }
    if (balance <= 0 || amt > balance) {
      alert("⚠️ Insufficient Wallet Balance! Please deposit funds.");
      return;
    }

    const res = await updateServerBalance("subtract", amt);
    if (!res.ok) {
      alert(res.msg || "Insufficient balance");
      await loadBalanceFromServer();
      return;
    }
    balance = res.balance;
    updateWalletDisplay();

    modeState[currentMode].activeBet = {
      position: selectedChoice.position,
      label: selectedChoice.label,
      mult: selectedChoice.mult,
      amount: amt
    };

    const indicator = document.getElementById("activeBetIndicator");
    indicator.style.display = "block";
    indicator.innerText = `[${currentMode.toUpperCase()}] Active: ₹${amt} on Pos ${selectedChoice.position} - ${selectedChoice.label} (${selectedChoice.mult}X)`;

    closeBetDrawer();
  }

  function updateWalletDisplay() {
    document.getElementById("balanceDisplay").innerText = `₹${balance.toFixed(2)}`;
  }

  function loadBalanceFromServer() {
    return fetch('/account_balance').then(r => r.json()).then(data => {
      if (data.ok) {
        balance = data.balance;
        updateWalletDisplay();
      }
    }).catch(() => {});
  }

  function updateServerBalance(action, amount) {
    return fetch('/update_balance', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({action: action, amount: amount})
    }).then(r => r.json());
  }

  // History & Chart UI
  function switchHistoryTab(viewId, elem) {
    document.querySelectorAll(".history-tabs-row .h-tab-item").forEach(b => b.classList.remove("active"));
    elem.classList.add("active");
    document.getElementById("hview-game").style.display = (viewId === 'game') ? 'block' : 'none';
    document.getElementById("hview-chart").style.display = (viewId === 'chart') ? 'block' : 'none';
    document.getElementById("hview-my").style.display = (viewId === 'my') ? 'block' : 'none';
  }

  function renderGameHistoryUI() {
    const tbody = document.getElementById("historyTableBody");
    tbody.innerHTML = "";
    gameHistoryRecords.forEach(r => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td style="font-size:11px; font-weight:600;">${r.p}</td>
        <td>
          <div class="five-balls-row">
            <span class="mini-digit-ball">${r.digits[0]}</span>
            <span class="mini-digit-ball">${r.digits[1]}</span>
            <span class="mini-digit-ball">${r.digits[2]}</span>
            <span class="mini-digit-ball">${r.digits[3]}</span>
            <span class="mini-digit-ball">${r.digits[4]}</span>
          </div>
        </td>
        <td>
          <div class="sum-badge-group">
            <span class="badge-circ ${r.bs === 'B' ? 'badge-b' : 'badge-s'}">${r.bs}</span>
            <span class="badge-circ ${r.oe === 'E' ? 'badge-e' : 'badge-o'}">${r.oe}</span>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  function updateChartStats() {
    if (gameHistoryRecords.length === 0) return;
    const total = gameHistoryRecords.length;
    const bigCount = gameHistoryRecords.filter(x => x.bs === 'B').length;
    const evenCount = gameHistoryRecords.filter(x => x.oe === 'E').length;

    const bigPct = Math.round((bigCount / total) * 100);
    const smallPct = 100 - bigPct;
    const evenPct = Math.round((evenCount / total) * 100);
    const oddPct = 100 - evenPct;

    document.getElementById("statBigPct").innerText = `${bigPct}%`;
    document.getElementById("statSmallPct").innerText = `${smallPct}%`;
    document.getElementById("barBig").style.width = `${bigPct}%`;
    document.getElementById("barSmall").style.width = `${smallPct}%`;

    document.getElementById("statEvenPct").innerText = `${evenPct}%`;
    document.getElementById("statOddPct").innerText = `${oddPct}%`;
    document.getElementById("barEven").style.width = `${evenPct}%`;
    document.getElementById("barOdd").style.width = `${oddPct}%`;
  }

  function recordMyBet(period, choice, amount, status, payout) {
    myHistoryRecords.unshift({ period, choice, amount, status, payout });
    if (myHistoryRecords.length > 30) myHistoryRecords.pop();
    localStorage.setItem("5d_my_history", JSON.stringify(myHistoryRecords));
    renderMyHistoryUI();
  }

  function renderMyHistoryUI() {
    const tbody = document.getElementById("myHistoryTableBody");
    if (myHistoryRecords.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" style="color:var(--text-muted); padding:16px;">No bets placed yet</td></tr>`;
      return;
    }
    tbody.innerHTML = "";
    myHistoryRecords.forEach(item => {
      const isWin = item.status === "WIN";
      tbody.innerHTML += `
        <tr>
          <td>${item.period}</td>
          <td><b>${item.choice}</b></td>
          <td>₹${item.amount.toFixed(2)}</td>
          <td style="font-weight:700; color:${isWin ? '#20dc86' : '#ff5252'}">
            ${isWin ? '+₹' + item.payout.toFixed(2) : '-₹' + item.amount.toFixed(2)}
          </td>
        </tr>
      `;
    });
  }

  function preloadInitialData() {
    gameHistoryRecords = [
      { p: 20260912102011210, mode: '1min', digits: [8, 9, 7, 1, 2], sum: 27, bs: 'B', oe: 'O' },
      { p: 20260912102011209, mode: '1min', digits: [2, 5, 3, 4, 0], sum: 14, bs: 'S', oe: 'E' },
      { p: 20260912102011208, mode: '1min', digits: [8, 1, 0, 8, 4], sum: 21, bs: 'S', oe: 'O' },
      { p: 20260912102011207, mode: '1min', digits: [6, 4, 5, 1, 9], sum: 25, bs: 'B', oe: 'O' }
    ];
    renderGameHistoryUI();
    updateChartStats();
  }

  window.onload = init;
</script>

</body>
</html>'''
