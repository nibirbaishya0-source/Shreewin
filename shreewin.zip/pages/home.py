try:
    from pages.home_assets import inject_assets, HOME_ASSETS
except ImportError:
    from home_assets import inject_assets, HOME_ASSETS

home_html = inject_assets("""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Shree.Win</title>
  <meta name="theme-color" content="#0b0820">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>

/* === OFFICIAL COLOUR MATCH === */
:root{
  --sw-bg:#0d0a1f;
  --sw-bg-deep:#0a0816;
  --sw-surface:#141332;
  --sw-card:#1a1435;
  --sw-card-2:#1e1b4b;
  --sw-border:#26244f;
  --sw-accent:#6965e8;
  --sw-purple:#7c3aed;
  --sw-purple-2:#8b5cf6;
  --sw-text:#ffffff;
  --sw-muted:#9e8fc7;
  --sw-muted-2:#5d5c88;
  --sw-gold:#ffd700;
  --sw-orange:#ff8f00;
  --sw-notice:#1e163a;
}
html,body{
  background:var(--sw-bg)!important;
  color:var(--sw-text)!important;
}
.app,.app-container,.page,.main-wrap{
  background:var(--sw-bg)!important;
}
.section,.section-header h3{color:var(--sw-text)!important}
.section-header .all{
  background:rgba(255,255,255,.08)!important;
  color:var(--sw-muted)!important;
}
.notice-bar,.notice-strip{
  background:linear-gradient(90deg,#1e163a,#2d1b69)!important;
  border-color:rgba(124,77,255,.3)!important;
  color:#d1c4e9!important;
}
.bottom-nav,.bottom-navbar{
  background:var(--sw-surface)!important;
  border-top:1px solid var(--sw-border)!important;
}
.bottom-nav .nav-item,.bottom-navbar .nav-item{
  color:var(--sw-muted-2)!important;
}
.bottom-nav .nav-item.active,.bottom-navbar .nav-item.active{
  color:var(--sw-accent)!important;
}
.bottom-nav .nav-item.active svg,.bottom-navbar .nav-item.active svg{
  fill:var(--sw-accent)!important;
}
.cat-icon.lobby,.cat-icon.minigame{background:linear-gradient(145deg,#5b3fd6,#3a2a9e)!important}
.cat-icon.lottery,.cat-icon.slots{background:linear-gradient(145deg,#6b4ce0,#4a2fc0)!important}
.cat-icon.popular{background:linear-gradient(145deg,#3d8bff,#1a5fd0)!important}
.float-btn{box-shadow:0 4px 12px rgba(0,0,0,.35)!important}
/* === END OFFICIAL COLOUR MATCH === */

/* === BRIGHTNESS + GLOW BOOST === */
:root{
  --sw-bg:#0f0b24 !important;
  --sw-surface:#16123a !important;
  --sw-card:#1c1840 !important;
}
body{background:#0f0b24!important}
.game-card{
  box-shadow:0 4px 18px rgba(105,101,232,.25),0 2px 8px rgba(0,0,0,.4)!important;
  border:1px solid rgba(139,92,246,.15);
}
.cat-icon{
  box-shadow:0 4px 16px rgba(105,101,232,.35)!important;
}
.banner,.banner-track img{
  box-shadow:0 6px 24px rgba(124,77,255,.3);
}
.section-header h3{text-shadow:0 0 12px rgba(167,139,250,.25)}
/* === END BOOST === */


    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: #0d0a1f;
      color: #fff;
      min-height: 100vh;
      overflow-x: hidden;
      padding-bottom: 0;
    }

    .status-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 8px 16px 4px;
      font-size: 13px;
      font-weight: 600;
      background: #0d0a1f;
    }
    .status-bar .right {
      display: flex;
      gap: 6px;
      align-items: center;
      font-size: 12px;
    }

    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 14px 10px;
      background: #0d0a1f;
    }
    .header-left {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .header .close, .header .down {
      width: 28px;
      height: 28px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      color: #aaa;
    }
    .header-title {
      text-align: center;
      flex: 1;
    }
    .header-title h1 {
      font-size: 17px;
      font-weight: 700;
      color: #fff;
    }
    .header-title p {
      font-size: 11px;
      color: #888;
      margin-top: -2px;
    }
    .header-right {
      display: flex;
      gap: 12px;
      align-items: center;
    }
    .header-right span {
      font-size: 18px;
      color: #ccc;
    }

    .banner-wrap {
      padding: 0 12px;
      margin-bottom: 14px;
    }
    .banner {
      position: relative;
      border-radius: 14px;
      overflow: hidden;
      background: linear-gradient(135deg, #2a0a5e 0%, #4b1a9a 40%, #1a0a3e 100%);
      height: 130px;
      display: flex;
      align-items: center;
      padding: 0 16px;
    }
    .banner-content {
      flex: 1;
      z-index: 2;
    }
    .banner-logo {
      font-size: 11px;
      font-weight: 700;
      color: #ffcc00;
      letter-spacing: 1px;
      margin-bottom: 4px;
    }
    .banner h2 {
      font-size: 22px;
      font-weight: 800;
      line-height: 1.15;
      background: linear-gradient(90deg, #ffd700, #ffaa00);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    .banner .date {
      display: inline-block;
      margin-top: 8px;
      background: rgba(0,0,0,0.45);
      border: 1px solid #ffd700;
      border-radius: 20px;
      padding: 3px 12px;
      font-size: 11px;
      color: #ffd700;
    }
    .banner-athletes {
      position: absolute;
      right: 8px;
      bottom: 0;
      height: 100%;
      display: flex;
      align-items: center;
      font-size: 48px;
      opacity: 0.9;
    }
    .banner-dots {
      display: flex;
      justify-content: center;
      gap: 5px;
      margin-top: 8px;
    }
    .banner-dots span {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: #444;
    }
    .banner-dots span.active {
      background: #fff;
      width: 16px;
      border-radius: 4px;
    }

    .categories {
      display: flex;
      justify-content: space-around;
      padding: 8px 8px 16px;
    }
    .cat-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 6px;
      width: 64px;
    }
    .cat-icon {
      width: 52px;
      height: 52px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      position: relative;
      box-shadow: 0 4px 12px rgba(0,0,0,0.4);
    }
    .cat-icon.lobby { background: linear-gradient(145deg, #5b3fd6, #3a2a9e); }
    .cat-icon.lottery { background: linear-gradient(145deg, #6b4ce0, #4a2fc0); }
    .cat-icon.popular { background: linear-gradient(145deg, #3d8bff, #1a5fd0); }
    .cat-icon.minigame { background: linear-gradient(145deg, #5b3fd6, #3a2a9e); }
    .cat-icon.slots { background: linear-gradient(145deg, #6b4ce0, #4a2fc0); }
    .cat-item span {
      font-size: 11px;
      color: #ccc;
      font-weight: 500;
    }
    .badge {
      position: absolute;
      top: -4px;
      right: -4px;
      background: #ff3b5c;
      color: #fff;
      font-size: 9px;
      font-weight: 700;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .section {
      padding: 0 12px 18px;
    }
    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
    }
    .section-header h3 {
      font-size: 15px;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .section-header .all {
      font-size: 12px;
      color: #888;
      background: rgba(255,255,255,0.08);
      padding: 3px 10px;
      border-radius: 12px;
    }

    .games-row {
      display: flex;
      gap: 10px;
      overflow-x: auto;
      padding-bottom: 4px;
      scrollbar-width: none;
    }
    .games-row::-webkit-scrollbar { display: none; }

    .game-card {
      flex-shrink: 0;
      width: 110px;
      height: 130px;
      border-radius: 14px;
      overflow: hidden;
      position: relative;
      background: #1a1435;
      box-shadow: 0 4px 15px rgba(0,0,0,0.35);
    }
    .game-card img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .game-card .label {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      background: linear-gradient(transparent, rgba(0,0,0,0.85));
      padding: 18px 6px 8px;
      text-align: center;
      font-size: 11px;
      font-weight: 600;
      z-index: 2;
      text-transform: uppercase;
    }

    .lottery-card {
      width: 105px;
      height: 95px;
      border-radius: 14px;
      overflow: hidden;
      flex-shrink: 0;
      position: relative;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
    .lottery-card img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .rec-card {
      width: 115px;
      height: 140px;
      border-radius: 14px;
      overflow: hidden;
      position: relative;
      flex-shrink: 0;
      box-shadow: 0 4px 15px rgba(0,0,0,0.4);
    }
    .rec-card img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .rec-card .name {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      text-align: center;
      padding: 10px 4px 8px;
      background: linear-gradient(transparent, rgba(0,0,0,0.9));
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.3px;
      text-transform: uppercase;
    }
    .rec-card .tag {
      position: absolute;
      top: 6px;
      right: 6px;
      background: rgba(0,0,0,0.65);
      color: #ffd700;
      font-size: 9px;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: 8px;
      z-index: 2;
    }
    .spin-btn .wheel {
      font-size: 28px;
      line-height: 1;
    }
    .spin-btn .text {
      font-size: 9px;
      font-weight: 700;
      color: #ffd700;
      margin-top: -2px;
    }

    .float-right {
      position: fixed;
      right: 8px;
      bottom: 160px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      z-index: 90;
    }
    .float-btn {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: linear-gradient(145deg, #5b3fd6, #3a2a9e);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.4);
      border: 2px solid rgba(255,255,255,0.15);
    }
    .float-btn.gift {
      background: linear-gradient(145deg, #ff6b3d, #e03a1a);
    }
    .float-btn.dragon {
      background: linear-gradient(145deg, #2a9e5a, #1a6e3a);
    }

    .jackpot-section {
      background: linear-gradient(180deg, #1a1435 0%, #0d0a1f 100%);
      border-radius: 16px;
      padding: 14px;
      margin: 0 12px 18px;
    }
    .jackpot-title {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 15px;
      font-weight: 600;
      margin-bottom: 6px;
    }
    .jackpot-desc {
      font-size: 11px;
      color: #aaa;
      margin-bottom: 12px;
      line-height: 1.4;
    }
    .jackpot-cards {
      display: flex;
      gap: 10px;
      overflow-x: auto;
      scrollbar-width: none;
    }
    .jackpot-cards::-webkit-scrollbar { display: none; }
    .jp-card {
      flex-shrink: 0;
      width: 120px;
      border-radius: 12px;
      overflow: hidden;
      background: #1a1435;
      text-align: center;
      position: relative;
    }
    .jp-card img {
      width: 100%;
      height: 110px;
      object-fit: cover;
      display: block;
    }
    .jp-card .mult {
      position: absolute;
      top: 6px;
      left: 6px;
      background: #7b4dff;
      color: #fff;
      font-size: 11px;
      font-weight: 700;
      padding: 2px 8px;
      border-radius: 8px;
    }
    .jp-card .name {
      font-size: 12px;
      font-weight: 700;
      padding: 6px 4px 2px;
    }
    .jp-card .bonus {
      font-size: 10px;
      color: #aaa;
      padding-bottom: 8px;
    }

    .win-info {
      padding: 0 12px 18px;
    }
    .win-cards {
      display: flex;
      gap: 8px;
      overflow-x: auto;
      scrollbar-width: none;
    }
    .win-cards::-webkit-scrollbar { display: none; }
    .win-card {
      flex-shrink: 0;
      width: 85px;
      background: linear-gradient(145deg, #2a1a5e, #1a0a3e);
      border-radius: 12px;
      padding: 10px 6px;
      text-align: center;
    }
    .win-card .ball {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: linear-gradient(145deg, #4a9eff, #1a5fd0);
      margin: 0 auto 6px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      font-weight: 800;
      position: relative;
      box-shadow: 0 3px 8px rgba(0,0,0,0.3);
    }
    .win-card .ball::after {
      content: '👑';
      position: absolute;
      top: -10px;
      font-size: 14px;
    }
    .win-card .game-name {
      font-size: 11px;
      font-weight: 600;
      margin-bottom: 4px;
    }
    .win-card .user {
      font-size: 10px;
      color: #aaa;
    }
    .win-card .amount {
      font-size: 12px;
      font-weight: 700;
      color: #ffd700;
      margin-top: 2px;
    }

    .earnings {
      padding: 0 12px 20px;
    }
    .earnings-list {
      background: #1a1435;
      border-radius: 14px;
      overflow: hidden;
    }
    .earn-item {
      display: flex;
      align-items: center;
      padding: 12px 14px;
      border-bottom: 1px solid rgba(255,255,255,0.05);
      gap: 10px;
    }
    .earn-item:last-child { border-bottom: none; }
    .earn-rank {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: #2a1a5e;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: 700;
      flex-shrink: 0;
    }
    .earn-rank.top1 { background: linear-gradient(145deg, #ffd700, #ffaa00); color: #000; }
    .earn-rank.top2 { background: linear-gradient(145deg, #c0c0c0, #888); color: #000; }
    .earn-rank.top3 { background: linear-gradient(145deg, #cd7f32, #8b5a2b); color: #fff; }
    .earn-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: #3a2a6e;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      flex-shrink: 0;
    }
    .earn-name {
      flex: 1;
      font-size: 13px;
      font-weight: 500;
    }
    .earn-amount {
      font-size: 13px;
      font-weight: 700;
      color: #ffd700;
    }

    .footer-text {
      text-align: center;
      padding: 10px 20px 20px;
      font-size: 11px;
      color: #666;
      line-height: 1.5;
    }
  
    /* Clean mobile presentation */
    body{
      background:#0b0820;
      padding-bottom:0;
      -webkit-font-smoothing:antialiased;
    }
    .clean-header{
      min-height:62px;
      padding:5px 14px;
      background:linear-gradient(180deg,#17103a 0%,#100b29 100%);
      border-bottom:1px solid rgba(255,255,255,.07);
      position:sticky;
      top:0;
      z-index:80;
    }
    .brand-wrap{display:flex;align-items:center;gap:8px;min-width:0}
    .brand-logo{
      width:150px!important;
      height:52px!important;
      object-fit:contain!important;
      display:block;
      max-width:58vw;
    }
    .header-actions{display:flex;align-items:center;gap:15px;color:#d9d4ff;font-size:21px}
    .banner-wrap{padding:12px 12px 0;margin-bottom:14px}
    .banner{border-radius:16px!important}
    .banner img{width:100%!important;height:auto!important;display:block!important;object-fit:cover!important}
    .categories{padding:10px 8px 20px;gap:4px}
    .cat-item{width:68px;gap:7px}
    .cat-icon{width:58px;height:58px;border-radius:18px;font-size:27px}
    .cat-item span{font-size:11px}
    .section{padding:0 12px 22px}
    .section-header{margin-bottom:12px}
    .section-header h3{font-size:17px}
    .section-header .all{font-size:12px;padding:5px 11px}
    .games-row{gap:12px;overflow-x:auto;padding-bottom:5px;scroll-snap-type:x proximity}
    .games-row>*{scroll-snap-align:start}
    .lottery-card{
      width:148px;
      height:126px;
      border-radius:16px;
    }
    .lottery-card img{object-fit:cover}
    .game-card{
      width:150px;
      height:158px;
      border-radius:16px;
    }
    .game-card .label{font-size:12px;padding:24px 7px 9px}
    .rec-card{
      width:150px;
      height:174px;
      border-radius:16px;
    }
    .rec-card .name{font-size:12px}
    .jackpot-section{margin:0 12px 20px;border-radius:16px}
    .float-right{right:8px;bottom:154px}
    .float-btn{width:46px;height:46px}
    .nav-item{font-size:10px}
    .spin-btn{width:68px;height:68px;top:-24px}
    @media (min-width:600px){
      .brand-logo{max-width:260px}
      .lottery-card{width:190px;height:150px}
      .rec-card{width:190px;height:210px}
      .game-card{width:190px;height:190px}
    }

    /* Exact screenshot-matching clean mobile layout */
    html, body { width:100%; min-width:0; }
    body { background:#0b0820; overflow-x:hidden; padding:0 !important; }
    .clean-header {
      position:relative !important;
      top:auto !important;
      min-height:158px !important;
      height:158px !important;
      padding:16px 26px 10px !important;
      background:#19133e !important;
      border-bottom:1px solid rgba(255,255,255,.08) !important;
      display:flex !important;
      align-items:center !important;
      justify-content:space-between !important;
    }
    .brand-wrap { flex:1; min-width:0; height:100%; display:flex; align-items:center; }
    .brand-logo {
      width:355px !important;
      height:125px !important;
      max-width:72vw !important;
      object-fit:fill !important;
      display:block !important;
      border:0 !important;
    }
    .header-actions { gap:20px !important; font-size:29px !important; padding-right:3px; }
    .notice-strip { width:calc(100% - 52px); margin:0 26px 26px; overflow:hidden; border-radius:16px; }
    .notice-strip img { width:100%; height:auto; display:block; }
    .banner-wrap { padding:0 26px !important; margin:0 0 28px !important; }
    .banner { height:auto !important; padding:0 !important; border-radius:18px !important; }
    .banner img { width:100% !important; height:auto !important; border-radius:18px !important; object-fit:cover !important; display:block !important; }
    .banner-dots { margin-top:10px !important; gap:10px !important; }
    .banner-dots span { width:11px !important; height:11px !important; }
    .banner-dots span.active { width:34px !important; border-radius:7px !important; }
    .categories { padding:0 30px 40px !important; gap:22px !important; justify-content:space-between !important; overflow:hidden !important; }
    .cat-item { width:120px !important; flex:0 0 120px !important; gap:10px !important; }
    .cat-icon { width:120px !important; height:120px !important; border-radius:34px !important; font-size:44px !important; }
    .cat-item span { font-size:18px !important; color:#ddd !important; white-space:nowrap; }
    .badge { width:31px !important; height:31px !important; font-size:17px !important; top:-4px !important; right:-4px !important; }
    .section { padding:0 26px 36px !important; }
    .section-header { margin-bottom:22px !important; }
    .section-header h3 { font-size:31px !important; font-weight:700 !important; gap:10px !important; }
    .section-header .all { font-size:22px !important; padding:10px 18px !important; border-radius:18px !important; }
    .games-row { gap:18px !important; padding-bottom:5px !important; }
    .lottery-card { width:248px !important; height:178px !important; border-radius:18px !important; }
    .game-card { width:248px !important; height:205px !important; border-radius:18px !important; }
    .game-card .label { font-size:18px !important; padding:30px 8px 11px !important; }
    .rec-card { width:248px !important; height:205px !important; border-radius:18px !important; }
    .rec-card .name { font-size:17px !important; padding:12px 5px 10px !important; }
    .float-right { right:15px !important; bottom:42px !important; gap:14px !important; z-index:90 !important; }
    .float-btn { width:78px !important; height:78px !important; font-size:35px !important; border-width:2px !important; }
    .footer-text { padding-bottom:30px !important; }
    @media (max-width:600px) {
      .clean-header { min-height:118px !important; height:118px !important; padding:8px 18px !important; }
      .brand-logo { width:230px !important; height:92px !important; max-width:68vw !important; }
      .header-actions { font-size:23px !important; gap:14px !important; }
      .notice-strip { width:calc(100% - 36px); margin:0 18px 18px; }
      .banner-wrap { padding:0 18px !important; margin-bottom:20px !important; }
      .categories { padding:0 18px 28px !important; gap:12px !important; }
      .cat-item { width:72px !important; flex-basis:72px !important; gap:7px !important; }
      .cat-icon { width:72px !important; height:72px !important; border-radius:23px !important; font-size:30px !important; }
      .cat-item span { font-size:12px !important; }
      .badge { width:20px !important; height:20px !important; font-size:11px !important; }
      .section { padding:0 18px 28px !important; }
      .section-header { margin-bottom:14px !important; }
      .section-header h3 { font-size:22px !important; }
      .section-header .all { font-size:15px !important; padding:7px 13px !important; }
      .games-row { gap:14px !important; }
      .lottery-card { width:248px !important; height:178px !important; }
      .rec-card { width:248px !important; height:205px !important; }
      .game-card { width:248px !important; height:205px !important; }
      .float-btn { width:58px !important; height:58px !important; font-size:26px !important; }
      .float-right { right:8px !important; bottom:14px !important; gap:8px !important; }
    }

  
    /* Official top logo + auth */
    .top-logo-bar, .auth-btns { display: none !important; }
    .top-logo-bar {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 10px 14px 4px;
      background: #0d0a1f;
      position: relative;
    }
    .top-logo {
      font-weight: 900;
      font-size: 24px;
      letter-spacing: -0.5px;
      display: flex;
      align-items: center;
      gap: 4px;
    }
    .top-logo .dice { font-size: 20px; }
    .top-logo .s {
      background: linear-gradient(90deg,#ffd54f,#ff8a65,#e040fb);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .top-logo .w {
      background: linear-gradient(90deg,#4fc3f7,#29b6f6);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .auth-btns {
      display: flex;
      gap: 10px;
      padding: 6px 14px 12px;
      justify-content: center;
    }
    .auth-btns a {
      flex: 1;
      max-width: 160px;
      height: 42px;
      border-radius: 22px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 14px;
      text-decoration: none;
      transition: transform .15s;
    }
    .auth-btns a:active { transform: scale(.96); }
    .btn-login {
      background: linear-gradient(180deg,#ffb300 0%,#ff8f00 100%);
      color: #fff;
      box-shadow: 0 4px 12px rgba(255,143,0,.35);
    }
    .btn-register {
      background: linear-gradient(180deg,#a78bfa 0%,#7c3aed 100%);
      color: #fff;
      box-shadow: 0 4px 12px rgba(124,58,237,.35);
    }
    .notice-bar {
      margin: 0 12px 12px;
      background: linear-gradient(90deg,#1e163a,#2d1b69);
      border-radius: 12px;
      padding: 9px 12px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      color: #d1c4e9;
      border: 1px solid rgba(124,77,255,.3);
    }
    .notice-bar .txt {
      flex: 1;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .notice-bar .detail {
      background: #7c4dff;
      color: #fff;
      padding: 5px 14px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 700;
      flex-shrink: 0;
      text-decoration: none;
    }

    /* Official bottom nav */
    body { padding-bottom: 90px !important; }
    .bottom-nav {
      position: fixed;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 100%;
      max-width: 480px;
      height: 68px;
      background: #141332;
      border-top: 1px solid #26244f;
      display: flex;
      justify-content: space-around;
      align-items: center;
      z-index: 1000;
      padding-bottom: env(safe-area-inset-bottom, 4px);
      box-sizing: border-box;
    }
    .bottom-nav .nav-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-decoration: none;
      color: #5d5c88;
      font-size: 11px;
      font-weight: 600;
      flex: 1;
      gap: 2px;
    }
    .bottom-nav .nav-item svg {
      width: 24px;
      height: 24px;
      fill: #5d5c88;
    }
    .bottom-nav .nav-item.active { color: #6965e8; }
    .bottom-nav .nav-item.active svg { fill: #6965e8; }
    .bottom-nav .wheel-item {
      position: relative;
      top: -18px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1.15;
      text-decoration: none;
    }
    .bottom-nav .wheel-circle {
      width: 64px;
      height: 64px;
      border-radius: 50%;
      background: radial-gradient(circle at 35% 30%, #d4a5ff, #7522c7 55%, #4a0e8f);
      border: 3px solid #9d3efa;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 16px rgba(117,34,199,.55);
    }
    .bottom-nav .wheel-circle span {
      font-size: 22px;
      line-height: 1;
    }
    .bottom-nav .wheel-label {
      margin-top: 2px;
      font-size: 11px;
      font-weight: 900;
      color: #ffe600;
      text-shadow: -1px -1px 0 #b30000, 1px -1px 0 #b30000, -1px 1px 0 #b30000, 1px 1px 0 #b30000;
    }

    a.game-card, a.lottery-card, a.rec-card {
      text-decoration: none;
      color: inherit;
      display: block;
    }

  
.cat-icon{width:56px!important;height:56px!important;border-radius:16px!important}
.cat-icon img{width:100%!important;height:100%!important;object-fit:contain!important}
.banner-track::-webkit-scrollbar{display:none}


/* Official banner size */
.banner-wrap{padding:0 12px!important;margin:10px 0 6px!important}
.banner-track{display:flex!important;overflow-x:auto!important;scroll-snap-type:x mandatory!important;gap:0!important;scrollbar-width:none!important;-webkit-overflow-scrolling:touch}
.banner-track::-webkit-scrollbar{display:none!important}
.banner-slide{flex:0 0 100%!important;scroll-snap-align:start!important;padding:0!important;box-sizing:border-box!important}
.banner-slide img,.banner-wrap img{
  width:100%!important;
  height:148px!important;
  object-fit:cover!important;
  border-radius:12px!important;
  display:block!important;
}
.banner-dots{display:flex!important;justify-content:center!important;gap:5px!important;margin-top:8px!important}
/* Category icons official */
.categories{display:flex!important;justify-content:space-between!important;padding:8px 14px 6px!important;gap:4px!important}
.cat-item{display:flex!important;flex-direction:column!important;align-items:center!important;gap:6px!important;flex:1!important}
.cat-icon{
  width:58px!important;height:58px!important;
  border-radius:18px!important;
  background:transparent!important;
  box-shadow:none!important;
  padding:0!important;
  overflow:hidden!important;
  display:flex!important;align-items:center!important;justify-content:center!important;
  position:relative!important;
}
.cat-icon img{width:100%!important;height:100%!important;object-fit:contain!important}
.cat-item span{font-size:11px!important;color:#c4b5fd!important;font-weight:500!important}
.cat-icon .badge{
  position:absolute!important;top:-2px!important;right:-2px!important;
  background:#ef4444!important;color:#fff!important;
  font-size:10px!important;min-width:16px!important;height:16px!important;
  border-radius:8px!important;display:flex!important;align-items:center!important;justify-content:center!important;
  font-weight:700!important;z-index:2!important;
}


.sw-header{background:transparent!important}
.notice-bar{
  margin:6px 12px 8px!important;
  padding:8px 10px!important;
  border-radius:20px!important;
  background:linear-gradient(90deg,#3d2d7a,#2a2150)!important;
  display:flex!important;align-items:center!important;gap:8px!important;
  font-size:12px!important;color:#e8e0ff!important;
  border:1px solid rgba(124,77,255,.25)!important;
}


.banner-wrap{padding:0 12px!important;margin:8px 0 4px!important}
.banner-track{display:flex!important;overflow-x:auto!important;scroll-snap-type:x mandatory!important;scrollbar-width:none!important}
.banner-track::-webkit-scrollbar{display:none!important}
.banner-slide{flex:0 0 100%!important;scroll-snap-align:start!important}
.banner-slide img{width:100%!important;height:148px!important;object-fit:cover!important;border-radius:12px!important;display:block!important}
.banner-dots{display:flex!important;justify-content:center!important;gap:5px!important;margin:8px 0 4px!important}
.banner-dots span{width:6px;height:6px;border-radius:50%;background:#444;display:inline-block}
.banner-dots span.active{width:16px;border-radius:4px;background:#fff}


/* Official logo size */
.logo-img, .app-header img, img[alt*="Shree"], img[alt*="shree"],
.header-logo img, .top-logo img {
  height: 44px !important;
  width: auto !important;
  max-width: 180px !important;
  object-fit: contain !important;
}
/* logo row spacing */
.app-header, .header-logo, .top-logo {
  padding: 12px 14px 6px !important;
  text-align: left !important;
}


.brand-logo, .logo-img, img.brand-logo {
  height: 48px !important;
  width: auto !important;
  max-width: 200px !important;
  object-fit: contain !important;
}
.clean-header, .header.clean-header {
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  padding: 12px 14px 8px !important;
}
.brand-wrap { display:flex; align-items:center; }


.notice-bar{
  margin: 6px 12px 10px !important;
  padding: 9px 12px !important;
  border-radius: 20px !important;
  background: linear-gradient(90deg, #3d2d7a, #2a2150) !important;
  display: flex !important;
  align-items: center !important;
  gap: 8px !important;
  border: 1px solid rgba(124,77,255,.28) !important;
}
.notice-icon{font-size:15px;flex-shrink:0}
.notice-text{
  flex:1;font-size:11.5px;color:#e8e0ff;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}
.notice-detail{
  background:#6d5dfc;color:#fff;padding:5px 12px;border-radius:14px;
  font-size:11px;font-weight:600;text-decoration:none;flex-shrink:0;
}
.banner-wrap{padding:0 12px!important;margin:0 0 8px!important}
.banner-slide img{
  width:100%!important;
  height:150px!important;
  object-fit:cover!important;
  border-radius:12px!important;
  display:block!important;
}
.banner-dots{margin:8px 0 10px!important}
.categories{padding:4px 12px 10px!important}
.header.clean-header{padding:10px 14px 4px!important}
.brand-logo{height:48px!important}


.lottery-card img, .rec-card img, .game-card img{
  width:100%!important;height:100%!important;
  object-fit:cover!important;border-radius:12px!important;display:block!important;
}
.lottery-card, .rec-card, .game-card{
  overflow:hidden!important;
}
.games-row.auto-slide, .banner-track{
  scroll-behavior:smooth;
}

</style>

<style>
/* FINAL MOBILE PROPORTIONS — matched to the supplied reference screenshot */
html,body{width:100%;min-width:0;overflow-x:hidden}
body{background:#0b0820!important;padding:0!important}
.clean-header{
  position:relative!important; height:78px!important; min-height:78px!important;
  padding:5px 18px!important; background:#19133e!important;
  display:flex!important; align-items:center!important; justify-content:space-between!important;
}
.brand-wrap{height:100%!important;flex:1;display:flex!important;align-items:center!important}
.brand-logo{
  width:72px!important;height:auto!important;max-width:none!important;
  object-fit:contain!important;display:block!important;
}
.header-actions{gap:14px!important;font-size:21px!important;padding-right:0!important}
.notice-strip{width:calc(100% - 22px)!important;margin:0 11px 12px!important;border-radius:12px!important}
.notice-strip img{width:100%!important;height:auto!important;display:block!important}
.banner-wrap{padding:0 11px!important;margin:0 0 14px!important}
.banner{border-radius:14px!important;overflow:hidden!important}
.banner img{width:100%!important;height:auto!important;border-radius:14px!important;display:block!important}
.banner-dots{margin-top:7px!important;gap:7px!important}
.banner-dots span{width:7px!important;height:7px!important}
.banner-dots span.active{width:22px!important;border-radius:5px!important}
.categories{
  padding:0 11px 24px!important;gap:7px!important;
  justify-content:space-between!important;overflow:hidden!important;
}
.cat-item{width:52px!important;flex:0 0 52px!important;gap:5px!important}
.cat-icon{width:52px!important;height:52px!important;border-radius:16px!important;font-size:24px!important}
.cat-item span{font-size:10px!important;line-height:1.15!important;color:#ddd!important;white-space:nowrap}
.badge{width:16px!important;height:16px!important;font-size:9px!important;top:-2px!important;right:-2px!important}
.section{padding:0 11px 25px!important}
.section-header{margin-bottom:11px!important}
.section-header h3{font-size:19px!important;font-weight:700!important;gap:7px!important}
.section-header .all{font-size:12px!important;padding:6px 11px!important;border-radius:12px!important}
.games-row{gap:12px!important;overflow-x:auto!important;padding-bottom:3px!important}
.lottery-card,.game-card,.rec-card{
  flex:0 0 calc((100vw - 22px)*.3175)!important;
  width:calc((100vw - 22px)*.3175)!important;
  max-width:248px!important;border-radius:13px!important;
}
.lottery-card{height:auto!important;aspect-ratio:1.395!important}
.lottery-card img{width:100%!important;height:100%!important;object-fit:cover!important;border-radius:13px!important}
.game-card{height:auto!important;aspect-ratio:1.32!important}
.game-card .label{font-size:12px!important;padding:18px 5px 7px!important}
.rec-card{height:auto!important;aspect-ratio:1.315!important}
.rec-card img{width:100%!important;height:100%!important;object-fit:cover!important;border-radius:13px!important}
.rec-card .name{font-size:11px!important;padding:7px 4px!important}
.float-right{right:7px!important;bottom:100px!important;gap:7px!important;z-index:90!important}
.float-btn{width:48px!important;height:48px!important;font-size:22px!important}
.footer-text{display:none!important}
.nav{display:none!important}/* bottom-nav visible */
@media (min-width:600px){
  .clean-header{height:118px!important;min-height:118px!important;padding:8px 26px!important}
  .brand-logo{width:150px!important}
  .notice-strip{width:calc(100% - 52px)!important;margin:0 26px 18px!important}
  .banner-wrap{padding:0 26px!important}
  .categories{padding:0 30px 40px!important;gap:22px!important}
  .cat-item{width:120px!important;flex-basis:120px!important}.cat-icon{width:120px!important;height:120px!important}
  .section{padding:0 26px 36px!important}.section-header h3{font-size:31px!important}
  .lottery-card,.game-card,.rec-card{max-width:248px!important}
}
</style>
<style>.status-bar{display:none!important}.header-title{display:none!important}.clean-header .close,.clean-header .down{display:none!important}


/* === OFFICIAL CARD SIZES (user exact) === */
.games-row{
  gap: 8px !important;
  overflow-x: auto !important;
  padding-bottom: 4px !important;
}
/* Lottery only */
.lottery-card,
a.lottery-card{
  width: 112px !important;
  min-width: 112px !important;
  max-width: 112px !important;
  height: 110px !important;
  min-height: 110px !important;
  max-height: 110px !important;
  aspect-ratio: unset !important;
  border-radius: 12px !important;
  overflow: hidden !important;
  flex-shrink: 0 !important;
}
.lottery-card img,
a.lottery-card img{
  width: 100% !important;
  height: 100% !important;
  object-fit: cover !important;
  border-radius: 12px !important;
  display: block !important;
}
/* All other cards: Recommended, Mini, Slots, game-card, rec-card */
.game-card,
a.game-card,
.rec-card,
a.rec-card{
  width: 112px !important;
  min-width: 112px !important;
  max-width: 112px !important;
  height: 130px !important;
  min-height: 130px !important;
  max-height: 130px !important;
  aspect-ratio: unset !important;
  border-radius: 12px !important;
  overflow: hidden !important;
  flex-shrink: 0 !important;
}
.game-card img,
a.game-card img,
.rec-card img,
a.rec-card img{
  width: 100% !important;
  height: 100% !important;
  object-fit: cover !important;
  border-radius: 12px !important;
  display: block !important;
}
.section .games-row > div,
.section .games-row > a{
  flex-shrink: 0 !important;
}

.bottom-navbar{position:fixed;bottom:0;left:0;width:100%;height:65px;background:#141332;border-top:1px solid #26244f;display:flex;justify-content:space-around;align-items:center;z-index:1000;padding-bottom:5px;font-family:Poppins,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}
.nav-item{display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:#5d5c88;font-size:11px;font-weight:600;transition:all .2s ease;cursor:pointer;flex:1}
.nav-item svg{width:26px;height:26px;fill:#5d5c88;margin-bottom:2px;transition:all .2s ease}
.nav-item.active{color:#6965e8}
.nav-item.active svg{fill:#6965e8;filter:drop-shadow(0 0 8px rgba(105,101,232,.4))}
.wheel-item{position:relative;top:-16px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;flex:1.2;text-decoration:none}
.wheel-wrapper{width:72px;height:72px;position:relative;display:flex;justify-content:center;align-items:center;filter:drop-shadow(0 4px 10px rgba(0,0,0,.6))}
.wheel-wrapper svg{width:100%;height:100%}
.wheel-label{position:absolute;bottom:-6px;white-space:nowrap;font-size:13px;font-weight:900;color:#ffe600;text-shadow:-1.5px -1.5px 0 #b30000,1.5px -1.5px 0 #b30000,-1.5px 1.5px 0 #b30000,1.5px 1.5px 0 #b30000,0 2px 4px rgba(0,0,0,.8);letter-spacing:-.2px}
body{padding-bottom:85px !important;}

</style>
</head>
<body>
<div class="header clean-header">
    <div class="brand-wrap">
      <img class="brand-logo" src="__HOME_ASSET_0__" alt="Shree.Win" style="height:48px;width:48px;border-radius:50%;object-fit:cover">
    </div>
    <div class="header-actions" aria-hidden="true">
      <span>💬</span>
      <span>⋮</span>
    </div>
  </div>

  
  
  <div class="notice-bar">
    <span class="notice-icon">🔊</span>
    <div class="notice-text">Welcome to the Shree.Win Platform! Enjoy an exciting gaming experience with a wide selection of games.</div>
    <a class="notice-detail" href="#">Detail</a>
  </div>
<div class="banner-wrap" id="bannerSlider">
    <div class="banner-track">

      <div class="banner-slide">
        <img style="height:44px;width:auto;object-fit:contain" src="__HOME_ASSET_1__" alt="Banner 1">
      </div>
      <div class="banner-slide">
        <img src="__HOME_ASSET_2__" alt="Banner 2">
      </div>
      <div class="banner-slide">
        <img style="height:44px;width:auto;object-fit:contain" src="__HOME_ASSET_3__" alt="Banner 3">
      </div>
      <div class="banner-slide">
        <img src="__HOME_ASSET_4__" alt="Banner 4">
      </div>
    </div>
    <div class="banner-dots">
      <span class="active"></span><span></span><span></span><span></span>
    </div>
  </div>
<div class="categories">
    <div class="cat-item">
      <div class="cat-icon lobby">
        <img src="__HOME_ASSET_5__" alt="Lobby">
      </div>
      <span>Lobby</span>
    </div>
    <div class="cat-item">
      <div class="cat-icon lottery">
        <img src="__HOME_ASSET_6__" alt="Lottery">
        <div class="badge">1</div>
      </div>
      <span>Lottery</span>
    </div>
    <div class="cat-item">
      <div class="cat-icon popular">
        <img src="__HOME_ASSET_7__" alt="Popular">
      </div>
      <span>Popular</span>
    </div>
    <div class="cat-item">
      <div class="cat-icon minigame">
        <img src="__HOME_ASSET_8__" alt="Mini Game">
      </div>
      <span>Mini Game</span>
    </div>
    <div class="cat-item">
      <div class="cat-icon slots">
        <img src="__HOME_ASSET_9__" alt="Slots">
      </div>
      <span>Slots</span>
    </div>
  </div>
<!-- Lottery -->
  
  
  
  <div class="section">
    <div class="section-header">
      <h3>🎱 Lottery</h3>
      <span class="all">All</span>
    </div>
    <div class="games-row auto-slide" data-slide="1">
      <a href="/wingo" class="lottery-card"><img src="__HOME_ASSET_10__" alt="Trx Wingo"></a>
      <a href="/wingo" class="lottery-card"><img src="__HOME_ASSET_11__" alt="MotoRace"></a>
      <a href="/wingo" class="lottery-card"><img src="__HOME_ASSET_12__" alt="Win go"></a>
      <a href="/k3" class="lottery-card"><img src="__HOME_ASSET_13__" alt="K3"></a>
      <a href="/5d" class="lottery-card"><img src="__HOME_ASSET_14__" alt="5D"></a>
    </div>
  </div>
<!-- Recommended Games -->
  <div class="section">
    <div class="section-header">
      <h3>⭐ Recommended Games</h3>
      <span class="all">All</span>
    </div>
    <div class="games-row">
      <div class="rec-card">
        <img src="__HOME_ASSET_15__" alt="Cricket">
      </div>
      <div class="rec-card">
        <img src="__HOME_ASSET_16__" alt="PUBG 1MIN">
      </div>
      <div class="rec-card">
        <img src="__HOME_ASSET_17__" alt="Power of the Kraken">
      </div>
      <div class="rec-card">
        <div style="width:100%;height:100%;background:linear-gradient(145deg,#1a1a2e,#0a0a1a);display:flex;align-items:center;justify-content:center;font-size:48px;">✈️</div>
        <div class="name">AVIATOR</div>
      </div>
      <div class="rec-card">
        <img src="__HOME_ASSET_18__" alt="Vortex">
      </div>
    </div>
  </div>

  <!-- Mini Games -->
  <div class="section">
    <div class="section-header">
      <h3>🎮 Mini games</h3>
      <span class="all">All</span>
    </div>
    <div class="games-row">
      <div class="game-card">
        <img src="__HOME_ASSET_19__" alt="Dragon Tiger">
      </div>
      <div class="game-card">
        <img src="__HOME_ASSET_20__" alt="Goal">
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#1a5e8a,#0a3e6a);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:36px;">⭐</div>
        <div class="label">COIN FLIP</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#6b3fd6,#3a1a8e);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:36px;">🎲</div>
        <div class="label">DICE</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#2a2a4a,#1a1a2e);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:36px;">₿</div>
        <div class="label">CRYPTOS</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#1a6e3a,#0a4e2a);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:36px;">🥅</div>
        <div class="label">GOAL WAVE</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#e03a1a,#9e1a0a);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:36px;">🚀</div>
        <div class="label">ROCKET</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#1a6e3a,#0a4e2a);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:36px;">🃏</div>
        <div class="label">ANDAR BAHAR</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#1a5e3a,#0a3e2a);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:36px;">🐍</div>
        <div class="label">SNAKES</div>
      </div>
    </div>
  </div>

  <!-- Slots -->
  <div class="section">
    <div class="section-header">
      <h3>7️⃣ Slots</h3>
      <span class="all">All</span>
    </div>
    <div class="games-row">
      <div class="game-card">
        <img src="__HOME_ASSET_21__" alt="Evolution">
      </div>
      <div class="game-card">
        <img src="__HOME_ASSET_22__" alt="Yggdrasil">
      </div>
      <div class="game-card">
        <img src="__HOME_ASSET_23__" alt="New Gaming">
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#5e1a0a,#3e0a0a);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:42px;">🧧</div>
        <div class="label">CQ9 GAME</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#2a1a4a,#1a0a2e);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:42px;">👑</div>
        <div class="label">B GAMING</div>
      </div>
    </div>
  </div>

  <!-- Fishing -->
  <div class="section">
    <div class="section-header">
      <h3>🐟 Fishing</h3>
      <span class="all">All</span>
    </div>
    <div class="games-row">
      <div class="game-card">
        <img src="__HOME_ASSET_24__" alt="Fishing Yilufa">
      </div>
      <div class="game-card">
        <img src="__HOME_ASSET_25__" alt="Dragon Master">
      </div>
      <div class="game-card">
        <img src="__HOME_ASSET_26__" alt="Fishing Disco">
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#5e1a0a,#3e0a0a);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:36px;">🐉</div>
        <div class="label">ONESHOT FISHING</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#0a4a6e,#0a2a4e);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:36px;">🐠</div>
        <div class="label">Lucky Fishing</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#3a1a0a,#2a0a0a);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:36px;">🐲</div>
        <div class="label">DRAGON FISHING</div>
      </div>
    </div>
  </div>

  <!-- Rummy -->
  <div class="section">
    <div class="section-header">
      <h3>🃏 Rummy</h3>
      <span class="all">All</span>
    </div>
    <div class="games-row">
      <div class="game-card">
        <img src="__HOME_ASSET_27__" alt="V8 Poker">
      </div>
      <div class="game-card">
        <img src="__HOME_ASSET_28__" alt="365">
      </div>
      <div class="game-card">
        <img src="__HOME_ASSET_29__" alt="Koolbet">
      </div>
    </div>
  </div>

  <!-- Casino -->
  <div class="section">
    <div class="section-header">
      <h3>👩 Casino</h3>
      <span class="all">All</span>
    </div>
    <div class="games-row">
      <div class="game-card">
        <img src="__HOME_ASSET_30__" alt="Evo">
      </div>
      <div class="game-card">
        <img src="__HOME_ASSET_31__" alt="Sexy">
      </div>
      <div class="game-card">
        <img src="__HOME_ASSET_32__" alt="Live Casino">
      </div>
    </div>
  </div>

  <!-- Sports -->
  <div class="section">
    <div class="section-header">
      <h3>⚽ Sports</h3>
      <span class="all">All</span>
    </div>
    <div class="games-row">
      <div class="game-card" style="background:linear-gradient(145deg,#e07a2a,#c04a10);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:42px;">⚽</div>
        <div class="label">SABA</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#1a6e3a,#0a4e2a);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:42px;">🏏</div>
        <div class="label">ARBET</div>
      </div>
      <div class="game-card" style="background:linear-gradient(145deg,#1a3a6e,#0a1a4e);display:flex;align-items:center;justify-content:center;flex-direction:column;">
        <div style="font-size:42px;">🏆</div>
        <div class="label">CMD</div>
      </div>
    </div>
  </div>

  <!-- Super Jackpot -->
  <div class="jackpot-section">
    <div class="jackpot-title">🏆 Super Jackpot</div>
    <div class="jackpot-desc">When you win a super jackpot, you will receive additional rewards Maximum bonus ₹355.00</div>
    <div class="jackpot-cards">
      <div class="jp-card">
        <div style="height:110px;background:linear-gradient(145deg,#2a6ae0,#1a3a9e);display:flex;align-items:center;justify-content:center;font-size:48px;">✈️</div>
        <div class="mult">14.03X</div>
        <div class="name">AVIATOR</div>
        <div class="bonus">Bonus extra ₹35.00</div>
      </div>
      <div class="jp-card">
        <img src="__HOME_ASSET_33__" alt="Mjolnir">
        <div class="mult">20.7X</div>
        <div class="name">MJOLNIR</div>
        <div class="bonus">Bonus extra ₹55.00</div>
      </div>
      <div class="jp-card">
        <img src="__HOME_ASSET_33__" alt="Mjolnir">
        <div class="mult">10.96X</div>
        <div class="name">MJOLNIR</div>
        <div class="bonus">Bonus extra ₹35.00</div>
      </div>
    </div>
  </div>

  <!-- Winning Information -->
  <div class="win-info">
    <div class="section-header">
      <h3>🎟 Winning information</h3>
    </div>
    <div class="win-cards">
      <div class="win-card">
        <div class="ball">1</div>
        <div class="game-name">Win go</div>
        <div class="user">👤 ***GRK</div>
        <div class="amount">₹19.60</div>
      </div>
      <div class="win-card">
        <div class="ball">1</div>
        <div class="game-name">Win go</div>
        <div class="user">👤 ***SKC</div>
        <div class="amount">₹98.00</div>
      </div>
      <div class="win-card">
        <div class="ball">1</div>
        <div class="game-name">Win go</div>
        <div class="user">👤 ***HFL</div>
        <div class="amount">₹176.40</div>
      </div>
      <div class="win-card">
        <div class="ball">1</div>
        <div class="game-name">Win go</div>
        <div class="user">👤 ***NCE</div>
        <div class="amount">₹980.00</div>
      </div>
    </div>
  </div>

  <!-- Today's earnings -->
  <div class="earnings">
    <div class="section-header">
      <h3>📊 Today's earnings chart</h3>
    </div>
    <div class="earnings-list">
      <div class="earn-item">
        <div class="earn-rank top1">01</div>
        <div class="earn-avatar">👨</div>
        <div class="earn-name">Mem***UJT</div>
        <div class="earn-amount">₹6,225,600,918.04</div>
      </div>
      <div class="earn-item">
        <div class="earn-rank top2">02</div>
        <div class="earn-avatar">👩</div>
        <div class="earn-name">Mem***XKI</div>
        <div class="earn-amount">₹59,542,765.03</div>
      </div>
      <div class="earn-item">
        <div class="earn-rank top3">03</div>
        <div class="earn-avatar">👩</div>
        <div class="earn-name">Mem***S19</div>
        <div class="earn-amount">₹14,843,189.76</div>
      </div>
      <div class="earn-item">
        <div class="earn-rank">4</div>
        <div class="earn-avatar">👩</div>
        <div class="earn-name">Mem***BHW</div>
        <div class="earn-amount">₹4,990,356.00</div>
      </div>
      <div class="earn-item">
        <div class="earn-rank">5</div>
        <div class="earn-avatar">👩</div>
        <div class="earn-name">Mem***62H</div>
        <div class="earn-amount">₹4,187,169.56</div>
      </div>
      <div class="earn-item">
        <div class="earn-rank">6</div>
        <div class="earn-avatar">👩</div>
        <div class="earn-name">Mem***TGZ</div>
        <div class="earn-amount">₹1,827,347.20</div>
      </div>
      <div class="earn-item">
        <div class="earn-rank">7</div>
        <div class="earn-avatar">👩</div>
        <div class="earn-name">Mem***KEW</div>
        <div class="earn-amount">₹1,712,611.74</div>
      </div>
      <div class="earn-item">
        <div class="earn-rank">8</div>
        <div class="earn-avatar">👩</div>
        <div class="earn-name">Mem***HYU</div>
        <div class="earn-amount">₹1,591,936.50</div>
      </div>
    </div>
  </div>

  <div class="footer-text">
    The Shree.Win platform advocates fairness, justice, and openness. We mainly operate fair lottery, blockchain games, live casino and slot machine.
  </div>

  <div class="float-right">
    <div class="float-btn gift">🎁</div>
    <div class="float-btn">🎡</div>
    <div class="float-btn dragon">🐉</div>
    <div class="float-btn">💬</div>
  </div>

<nav class="bottom-navbar">
    <a href="/home" class="nav-item active">
      <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      <span>Home</span>
    </a>
    <a href="/activity" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2zm-7 10.25l-2.61 1.56.69-2.97-2.3-2 3.03-.26L12 7l1.19 2.58 3.03.26-2.3 2 .69 2.97L12 13.25z"/></svg>
      <span>Activity</span>
    </a>
    <a href="/spinwheel" class="wheel-item">
      <div class="wheel-wrapper">
        <img src="__HOME_ASSET_34__" alt="Spin" style="width:72px;height:72px;object-fit:contain;border-radius:50%;">
      </div>
      <span class="wheel-label">Get ₹500</span>
    </a>
    <a href="/promotion" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
      <span>Promotion</span>
    </a>
    <a href="/account" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
      <span>Account</span>
    </a>
</nav>

<script>
(function(){
  function autoSlide(el, stepPx, loop){
    if(!el) return;
    var paused = false;
    el.addEventListener('touchstart', function(){ paused = true; }, {passive:true});
    el.addEventListener('touchend', function(){ setTimeout(function(){ paused = false; }, 3000); }, {passive:true});
    setInterval(function(){
      if(paused) return;
      var max = el.scrollWidth - el.clientWidth;
      if(max <= 8) return;
      var step = stepPx || Math.max(100, Math.floor(el.clientWidth * 0.75));
      if(el.scrollLeft >= max - 6){
        if(loop){
          el.scrollTo({left: 0, behavior: "smooth"});
        }
        // else stop at end (slide off)
        return;
      }
      el.scrollBy({left: step, behavior:"smooth"});
    }, 2500);
  }
  document.addEventListener("DOMContentLoaded", function(){
    // Banner loops like official
    var banner = document.querySelector(".banner-track");
    autoSlide(banner, null, true);
    // Game card rows: stop when cards end
    document.querySelectorAll(".games-row").forEach(function(row){
      autoSlide(row, 120, false);
    });
  });
})();
</script>

</body>
</html>
""")
