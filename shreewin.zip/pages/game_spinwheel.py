html_spinwheel = r'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Invite Wheel</title>
  <!-- Google Fonts & Font Awesome Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Poppins:wght@500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #1a0505;
      display: flex;
      justify-content: center;
      min-height: 100vh;
      color: #fff;
    }

    .app-container {
      width: 100%;
      max-width: 420px;
      min-height: 100vh;
      background: radial-gradient(circle at 50% 30%, #ff5238 0%, #e61d2b 55%, #c80d19 100%);
      display: flex;
      flex-direction: column;
      position: relative;
      overflow-x: hidden;
      box-shadow: 0 0 30px rgba(0,0,0,0.5);
    }

    /* Top Navigation Bar */
    .top-navbar {
      height: 52px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 16px;
      background: transparent;
      z-index: 10;
    }

    .nav-btn {
      color: #ffffff;
      font-size: 20px;
      cursor: pointer;
      text-decoration: none;
    }

    .header-title {
      font-family: 'Fredoka One', cursive;
      font-size: 21px;
      letter-spacing: 0.5px;
      color: #fff;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }

    .header-icons {
      display: flex;
      gap: 14px;
      font-size: 19px;
    }

    .header-icons i {
      cursor: pointer;
    }

    /* Amount Section */
    .amount-section {
      text-align: center;
      margin-top: 10px;
      z-index: 5;
    }

    .amount-label {
      font-family: 'Fredoka One', cursive;
      font-size: 15px;
      color: #fff;
      letter-spacing: 0.5px;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }

    .amount-val {
      font-family: 'Fredoka One', cursive;
      font-size: 42px;
      color: #ffde43;
      text-shadow: 0 2px 8px rgba(0, 0, 0, 0.4), 0 0 15px rgba(255, 222, 67, 0.5);
      margin: 2px 0 8px 0;
    }

    .btn-cashout {
      background: linear-gradient(180deg, #ffc938 0%, #ff9800 100%);
      color: #fff;
      font-family: 'Fredoka One', cursive;
      font-size: 16px;
      padding: 6px 36px;
      border-radius: 20px;
      border: 2px solid #ffe685;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3), inset 0 2px 4px rgba(255,255,255,0.6);
      cursor: pointer;
      display: inline-block;
      transition: transform 0.1s;
    }

    .btn-cashout:active {
      transform: scale(0.96);
    }

    /* Wheel Container & Stand */
    .wheel-outer-wrapper {
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 15px;
      width: 100%;
    }

    .wheel-stand {
      position: absolute;
      bottom: -32px;
      width: 250px;
      height: 90px;
      background: linear-gradient(180deg, #e5283b 0%, #ab0c1c 100%);
      clip-path: polygon(22% 0%, 78% 0%, 100% 100%, 0% 100%);
      border-bottom: 8px solid #840511;
      z-index: 1;
    }

    .wheel-box {
      position: relative;
      width: 320px;
      height: 320px;
      border-radius: 50%;
      background: #ffb100;
      box-shadow: 0 10px 25px rgba(0,0,0,0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 2;
    }

    /* Outer Bulb Ring */
    .bulb-ring {
      position: absolute;
      width: 310px;
      height: 310px;
      border-radius: 50%;
      background: #e21829;
      border: 4px solid #ffda44;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .bulb {
      position: absolute;
      width: 8px;
      height: 8px;
      background: #fff;
      border-radius: 50%;
      box-shadow: 0 0 6px #fff;
    }

    /* Rotating Wheel Canvas */
    #wheelCanvas {
      width: 276px;
      height: 276px;
      border-radius: 50%;
      transition: transform 4.5s cubic-bezier(0.12, 0.8, 0.15, 1);
    }

    /* Center Free Spin Button */
    .center-pin {
      position: absolute;
      width: 84px;
      height: 84px;
      background: radial-gradient(circle, #fff7d6 0%, #ffd063 100%);
      border: 4px solid #e52335;
      border-radius: 50%;
      box-shadow: 0 4px 10px rgba(0,0,0,0.4), inset 0 2px 4px #fff;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      z-index: 4;
      transition: transform 0.1s;
    }

    .center-pin:active {
      transform: scale(0.94);
    }

    .center-spin-count {
      font-family: 'Fredoka One', cursive;
      font-size: 26px;
      color: #e52335;
      line-height: 1;
    }

    .center-spin-text {
      font-size: 9px;
      font-weight: 800;
      color: #e52335;
      letter-spacing: 0.5px;
    }

    /* Top Pointer */
    .top-pointer {
      position: absolute;
      top: -2px;
      width: 58px;
      height: 52px;
      background: #ffe375;
      border: 3px solid #ff9d00;
      clip-path: polygon(15% 0%, 85% 0%, 50% 100%);
      border-radius: 6px;
      z-index: 5;
      box-shadow: 0 4px 6px rgba(0,0,0,0.3);
    }

    /* Decorative 3D Gold Coins */
    .deco-coin {
      position: absolute;
      background: linear-gradient(135deg, #ffe566 0%, #f59f00 100%);
      border-radius: 50%;
      border: 4px solid #ffe97d;
      box-shadow: 0 8px 15px rgba(0,0,0,0.4), inset 0 3px 6px #fff;
      z-index: 3;
    }

    .coin-left {
      width: 76px;
      height: 38px;
      bottom: -15px;
      left: 10px;
      transform: rotate(-15deg);
    }

    .coin-right {
      width: 68px;
      height: 34px;
      bottom: -10px;
      right: 15px;
      transform: rotate(10deg);
    }

    /* Bottom Actions Section */
    .bottom-section {
      margin-top: 55px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      padding: 0 20px 20px 20px;
      z-index: 5;
    }

    .btn-invite {
      width: 85%;
      height: 48px;
      background: linear-gradient(180deg, #ffc83b 0%, #ff8e02 100%);
      color: #fff;
      font-family: 'Fredoka One', cursive;
      font-size: 16px;
      border-radius: 24px;
      border: 2px solid #ffea8b;
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.35), inset 0 2px 4px #fff;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      letter-spacing: 0.5px;
      transition: transform 0.15s;
    }

    .btn-invite:active {
      transform: scale(0.96);
    }

    .info-text {
      font-size: 13px;
      font-weight: 600;
      color: #ffffff;
      text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }

    .footer-row {
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 10px;
      padding: 0 10px;
    }

    .record-btn {
      font-family: 'Fredoka One', cursive;
      font-size: 17px;
      color: #ffffff;
      cursor: pointer;
      text-shadow: 0 2px 4px rgba(0,0,0,0.4);
    }

    .chat-btn {
      width: 44px;
      height: 44px;
      background: #00d284;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-size: 20px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
      cursor: pointer;
    }

    /* Modal Popup */
    .popup-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.7);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 100;
    }

    .popup-card {
      width: 80%;
      max-width: 320px;
      background: #fff;
      border-radius: 20px;
      padding: 24px 20px;
      text-align: center;
      color: #333;
      box-shadow: 0 10px 25px rgba(0,0,0,0.4);
      animation: popIn 0.3s ease-out;
    }

    @keyframes popIn {
      0% { transform: scale(0.6); opacity: 0; }
      100% { transform: scale(1); opacity: 1; }
    }

    .popup-card h2 {
      font-family: 'Fredoka One', cursive;
      color: #e52335;
      font-size: 24px;
    }

    .popup-card .prize-amount {
      font-family: 'Fredoka One', cursive;
      font-size: 34px;
      color: #ff9800;
      margin: 12px 0;
    }

    .popup-card button {
      background: #e52335;
      color: #fff;
      border: none;
      padding: 10px 24px;
      border-radius: 20px;
      font-weight: 700;
      font-size: 15px;
      cursor: pointer;
    }
  </style>
</head>
<body>

  <div class="app-container">
    
    <!-- Top Navigation Bar -->
    <div class="top-navbar">
      <a href="index.html" class="nav-btn"><i class="fa-solid fa-chevron-left"></i></a>
      <div class="header-title">Invite Wheel</div>
      <div class="header-icons">
        <i class="fa-regular fa-circle-question"></i>
        <i class="fa-regular fa-rectangle-list"></i>
      </div>
    </div>

    <!-- Amount Balance Info -->
    <div class="amount-section">
      <div class="amount-label">My Amount(<span id="timerText">00:00:00</span>)</div>
      <div class="amount-val" id="myAmount">₹0.00</div>
      <button class="btn-cashout" onclick="handleCashOut()">CASH OUT</button>
    </div>

    <!-- Wheel Section -->
    <div class="wheel-outer-wrapper">
      <div class="wheel-stand"></div>

      <div class="wheel-box">
        <div class="top-pointer"></div>
        <div class="bulb-ring" id="bulbRing"></div>
        <canvas id="wheelCanvas" width="550" height="550"></canvas>

        <!-- Center Spin Button -->
        <div class="center-pin" onclick="spinWheel()">
          <div class="center-spin-count" id="spinCount">X1</div>
          <div class="center-spin-text">FREE SPIN</div>
        </div>
      </div>

      <div class="deco-coin coin-left"></div>
      <div class="deco-coin coin-right"></div>
    </div>

    <!-- Bottom Actions -->
    <div class="bottom-section">
      <button class="btn-invite" onclick="addFreeSpins()">INVITE FRIENDS TO GET SPIN</button>
      <div class="info-text" id="prizeRemainingText">Only ₹500.00 left to get prize ₹500.00</div>

      <div class="footer-row">
        <div class="record-btn">Record</div>
        <div class="chat-btn"><i class="fa-solid fa-headset"></i></div>
      </div>
    </div>

  </div>

  <!-- Prize Win Modal -->
  <div class="popup-overlay" id="prizePopup">
    <div class="popup-card">
      <h2>🎉 Congratulations!</h2>
      <p>You have won</p>
      <div class="prize-amount" id="popupPrize">₹1.50</div>
      <button onclick="closePopup()">Collect Prize</button>
    </div>
  </div>

  <script>
    // Prizes and Wheel Segments Config
    // Index 5 is "₹1-20"
    const prizes = [
      { text: "₹45", icon: "💵" },    // 0
      { text: "₹40", icon: "💵" },    // 1
      { text: "₹25", icon: "🪙" },    // 2
      { text: "₹30", icon: "🪙" },    // 3
      { text: "₹35", icon: "💵" },    // 4
      { text: "₹1-20", icon: "🪙" },  // 5 (Fixed target segment)
      { text: "₹10", icon: "🪙" },    // 6
      { text: "₹20", icon: "🪙" }     // 7
    ];

    const numSegments = prizes.length;
    const arcSize = (2 * Math.PI) / numSegments;
    const canvas = document.getElementById('wheelCanvas');
    const ctx = canvas.getContext('2d');
    
    let currentRotation = 0;
    let isSpinning = false;
    let spinsLeft = 1;
    let totalAmount = 0;

    // Draw the 8 Segments Wheel
    function drawWheel() {
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const radius = canvas.width / 2;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (let i = 0; i < numSegments; i++) {
        const angle = i * arcSize;

        ctx.beginPath();
        ctx.fillStyle = (i % 2 === 0) ? '#ffffff' : '#ffea9f';
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, radius, angle, angle + arcSize);
        ctx.lineTo(centerX, centerY);
        ctx.fill();
        ctx.strokeStyle = "#ffcc33";
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(angle + arcSize / 2);
        ctx.textAlign = "center";

        // Prize Amount Text
        ctx.fillStyle = "#d81d2a";
        ctx.font = "bold 32px 'Poppins'";
        ctx.fillText(prizes[i].text, radius * 0.65, 10);

        // Icon
        ctx.font = "40px sans-serif";
        ctx.fillText(prizes[i].icon, radius * 0.40, 14);

        ctx.restore();
      }
    }

    // Outer Light Bulbs
    function setupBulbs() {
      const bulbRing = document.getElementById('bulbRing');
      const totalBulbs = 16;
      const r = 145;
      for (let i = 0; i < totalBulbs; i++) {
        const angle = (i / totalBulbs) * 2 * Math.PI;
        const x = 155 + r * Math.cos(angle) - 4;
        const y = 155 + r * Math.sin(angle) - 4;
        const bulb = document.createElement('div');
        bulb.className = 'bulb';
        bulb.style.left = `${x}px`;
        bulb.style.top = `${y}px`;
        bulbRing.appendChild(bulb);
      }
    }

    // Rigged Spin Function (Always stops at index 5: "₹1-20" with max ₹2 reward)
    function spinWheel() {
      if (isSpinning) return;
      if (spinsLeft <= 0) {
        alert("Free spins finished! Click 'INVITE FRIENDS' to get more spins.");
        return;
      }

      isSpinning = true;
      spinsLeft--;
      document.getElementById('spinCount').innerText = `X${spinsLeft}`;

      // Hamesha index 5 (₹1-20) par hi rukega
      const winningIndex = 5; 

      // Random reward maximum 2 rupees (₹1.00 se ₹2.00 ke beech)
      const wonReward = +(1 + Math.random()).toFixed(2); 
      
      const segmentDeg = 360 / numSegments;
      const randomExtraRounds = 360 * 6; // 6 full rotations
      const prizeCenterAngle = (winningIndex * segmentDeg) + (segmentDeg / 2);
      
      // Calculate rotation taaki pointer exact ₹1-20 pe ruke
      currentRotation += randomExtraRounds + (360 - (currentRotation % 360)) + (270 - prizeCenterAngle);

      canvas.style.transform = `rotate(${currentRotation}deg)`;

      // Spin complete hone par
      setTimeout(() => {
        isSpinning = false;
        totalAmount += wonReward;
        
        // Credit real wallet
        creditPrizeToServer(wonReward);

        document.getElementById('myAmount').innerText = `₹${totalAmount.toFixed(2)}`;
        const remaining = Math.max(0, 500 - totalAmount);
        document.getElementById('prizeRemainingText').innerText = `Only ₹${remaining.toFixed(2)} left to get prize ₹500.00`;

        // Show Popup with won amount
        document.getElementById('popupPrize').innerText = `₹${wonReward.toFixed(2)}`;
        document.getElementById('prizePopup').style.display = 'flex';
      }, 4500);
    }

    function addFreeSpins() {
      spinsLeft += 1;
      document.getElementById('spinCount').innerText = `X${spinsLeft}`;
      alert("🎉 You received 1 Extra Free Spin! Invite more friends for more spins.");
    }

    function closePopup() {
      document.getElementById('prizePopup').style.display = 'none';
    }

    function creditPrizeToServer(amount) {
      fetch('/update_balance', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({action: 'add', amount: amount})
      }).then(r => r.json()).then(res => {
        if (res.ok) {
          // also refresh display from server
          fetch('/account_balance').then(r2 => r2.json()).then(d => {
            if (d.ok) {
              totalAmount = d.balance;
              document.getElementById('myAmount').innerText = `₹${totalAmount.toFixed(2)}`;
            }
          });
        }
      });
    }

    function handleCashOut() {
      if (totalAmount <= 0) {
        alert("No balance to withdraw.");
        return;
      }
      location.href = '/withdraw';
    }

    function loadBalanceFromServer() {
      fetch('/account_balance').then(r => r.json()).then(data => {
        if (data.ok) {
          totalAmount = data.balance;
          document.getElementById('myAmount').innerText = `₹${totalAmount.toFixed(2)}`;
          const remaining = Math.max(0, 500 - totalAmount);
          document.getElementById('prizeRemainingText').innerText = `Only ₹${remaining.toFixed(2)} left to get prize ₹500.00`;
        }
      }).catch(() => {});
    }

    drawWheel();
    setupBulbs();
    loadBalanceFromServer();
  </script>

</body>
</html>'''
