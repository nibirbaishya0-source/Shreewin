html_limbo = r'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Shree.Win - LIMBO Smooth Pro</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    :root {
      --bg-space: linear-gradient(180deg, #071024 0%, #0a1f48 50%, #04122d 100%);
      --dashboard-bg: #031a44;
      --accent-green: #00e676;
      --accent-red: #ff334b;
      --accent-yellow: #ffb703;
      --btn-green: linear-gradient(180deg, #00e676 0%, #00a844 100%);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
      user-select: none;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      background-color: #020814;
      display: flex;
      justify-content: center;
      min-height: 100vh;
      color: #fff;
    }

    .app-container {
      width: 100%;
      max-width: 440px;
      background: var(--bg-space);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      position: relative;
      box-shadow: 0 0 30px rgba(0,0,0,0.9);
      overflow-x: hidden;
    }

    /* Top Bar */
    .top-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
    }
    .back-btn { font-size: 20px; color: #fff; cursor: pointer; transition: transform 0.2s; }
    .back-btn:active { transform: scale(0.9); }
    .wallet-pill {
      display: flex;
      align-items: center;
      background: #021a47;
      border: 1px solid #14499e;
      border-radius: 20px;
      padding: 4px 10px 4px 4px;
      gap: 6px;
    }
    .coin-badge {
      width: 26px;
      height: 26px;
      background: radial-gradient(circle at 35% 35%, #fffb91 0%, #ffaa00 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
      color: #733c00;
      font-weight: 900;
    }
    .balance-txt { font-size: 15px; font-weight: 800; color: #fff; }
    .btn-add-funds {
      width: 28px;
      height: 28px;
      background: #08439b;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #4da3ff;
      font-size: 15px;
      font-weight: 900;
      cursor: pointer;
      border: 1px solid #1a5ac0;
      transition: transform 0.15s;
    }
    .btn-add-funds:active { transform: scale(0.9); }
    .support-icon {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: radial-gradient(circle, #00d2ff, #0077ff);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
    }

    .game-title {
      text-align: center;
      font-size: 18px;
      font-weight: 900;
      letter-spacing: 2px;
      margin-bottom: 2px;
    }

    /* Hash & History Bar */
    .meta-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 16px 6px 16px;
      font-size: 11px;
      color: #92aff5;
    }
    .encrypted-hash {
      display: flex;
      align-items: center;
      gap: 6px;
      font-family: monospace;
      font-size: 11px;
    }
    .hash-icons i { cursor: pointer; margin-left: 4px; color: #6ba2ff; }

    /* Recent Multiplier History */
    .history-pills {
      display: flex;
      gap: 6px;
      padding: 0 16px 8px 16px;
      overflow-x: auto;
      scrollbar-width: none;
    }
    .history-pills::-webkit-scrollbar { display: none; }
    .h-pill {
      font-size: 11px;
      font-weight: 800;
      padding: 3px 10px;
      border-radius: 12px;
      white-space: nowrap;
      animation: popIn 0.3s ease-out;
    }
    @keyframes popIn {
      from { transform: scale(0.5); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }
    .h-pill.win { background: rgba(0, 230, 118, 0.18); color: #00e676; border: 1px solid rgba(0, 230, 118, 0.4); }
    .h-pill.loss { background: rgba(255, 51, 75, 0.18); color: #ff5252; border: 1px solid rgba(255, 51, 75, 0.4); }

    /* Main Limbo Arena */
    .limbo-arena {
      position: relative;
      height: 300px;
      margin: 0 16px;
      background: radial-gradient(circle at 50% 20%, #153775 0%, #061533 80%);
      border-radius: 24px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
      border: 1px solid rgba(255,255,255,0.08);
      box-shadow: inset 0 0 30px rgba(0,0,0,0.8), 0 8px 24px rgba(0,0,0,0.5);
    }

    /* Interactive Canvas for Stars & Particles */
    #limboCanvas {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
      pointer-events: none;
    }

    .planet-decor {
      position: absolute;
      left: 20px;
      top: 80px;
      width: 46px;
      height: 46px;
      background: radial-gradient(circle at 35% 35%, #396fbe, #0f2752);
      border-radius: 50%;
      opacity: 0.6;
      box-shadow: 0 0 16px rgba(42, 88, 163, 0.6);
      z-index: 2;
      animation: floatPlanet 6s ease-in-out infinite alternate;
    }
    @keyframes floatPlanet {
      from { transform: translateY(0) rotate(0deg); }
      to { transform: translateY(-12px) rotate(15deg); }
    }

    /* Multiplier Readout */
    .multiplier-display {
      font-size: 48px;
      font-weight: 900;
      margin-top: 16px;
      color: #ffffff;
      text-shadow: 0 4px 18px rgba(0,0,0,0.8);
      z-index: 5;
      letter-spacing: 0.5px;
      transition: color 0.2s, transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    .multiplier-display.win {
      color: #00e676;
      text-shadow: 0 0 25px rgba(0, 230, 118, 0.8);
      transform: scale(1.12);
    }
    .multiplier-display.loss {
      color: #ff334b;
      text-shadow: 0 0 25px rgba(255, 51, 75, 0.8);
      transform: scale(0.92);
    }

    /* Rocket Container */
    .rocket-stage {
      position: relative;
      width: 110px;
      height: 110px;
      display: flex;
      justify-content: center;
      align-items: flex-end;
      z-index: 4;
      margin-bottom: 24px;
      transition: transform 0.35s cubic-bezier(0.25, 1, 0.5, 1);
    }
    .rocket-svg {
      width: 86px;
      height: 86px;
      filter: drop-shadow(0 10px 16px rgba(0,0,0,0.6));
      animation: rocketHover 3s ease-in-out infinite alternate;
    }
    @keyframes rocketHover {
      0% { transform: translateY(0); }
      100% { transform: translateY(-6px); }
    }

    /* Launching Smooth Lift */
    .rocket-stage.launching {
      transform: translateY(-26px) scale(1.05);
    }
    .rocket-stage.win-fly {
      transform: translateY(-240px) scale(1.3);
      transition: transform 0.6s cubic-bezier(0.1, 0.9, 0.2, 1);
    }
    .rocket-stage.loss-recoil {
      transform: translateY(10px) rotate(-4deg);
      transition: transform 0.3s;
    }

    /* Moon Surface at bottom */
    .moon-ground {
      position: absolute;
      bottom: -22px;
      width: 120%;
      height: 60px;
      background: radial-gradient(ellipse at 50% 0%, #1c4585 0%, #0d2854 100%);
      border-radius: 50% 50% 0 0;
      z-index: 3;
      border-top: 1px solid rgba(255,255,255,0.15);
      box-shadow: 0 -4px 15px rgba(0,0,0,0.4);
    }

    /* Camera Shake FX */
    .shake-fx {
      animation: arenaShake 0.35s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
    }
    @keyframes arenaShake {
      10%, 90% { transform: translate3d(-2px, 0, 0); }
      20%, 80% { transform: translate3d(3px, 0, 0); }
      30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
      40%, 60% { transform: translate3d(4px, 0, 0); }
    }

    /* Target Multiplier Input Row */
    .target-controller-wrap {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      padding: 10px 18px 4px 18px;
    }
    .circle-step-btn {
      width: 38px;
      height: 38px;
      background: #083880;
      border: 1px solid #1a5ac0;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-size: 16px;
      font-weight: 800;
      cursor: pointer;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
      transition: transform 0.1s, background 0.2s;
    }
    .circle-step-btn:active { transform: scale(0.88); background: #134ea8; }
    .target-val-box {
      background: #021a47;
      border: 1px solid #1459be;
      border-radius: 22px;
      padding: 6px 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      min-width: 140px;
      box-shadow: inset 0 2px 6px rgba(0,0,0,0.4);
    }
    .target-inp {
      background: transparent;
      border: none;
      color: #fff;
      font-size: 18px;
      font-weight: 800;
      text-align: center;
      width: 90px;
      outline: none;
    }
    .win-chance-lbl {
      text-align: center;
      font-size: 11px;
      color: #85adff;
      margin-bottom: 8px;
      font-weight: 600;
    }

    /* Bottom Bet Dashboard */
    .dashboard-panel {
      margin: 0 16px 12px 16px;
      background: var(--dashboard-bg);
      border-radius: 22px;
      padding: 14px 16px;
      border: 1px solid #0d469b;
      box-shadow: 0 8px 20px rgba(0,0,0,0.4);
    }
    .bet-input-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      margin-bottom: 12px;
    }
    .bet-amount-box {
      flex: 1;
      background: #021a47;
      border: 1px solid #0d469b;
      border-radius: 25px;
      display: flex;
      align-items: center;
      padding: 6px 14px;
      justify-content: space-between;
    }
    .bet-lbl { font-size: 11px; color: #7aa7eb; font-weight: 700; }
    .bet-inp {
      background: transparent;
      border: none;
      color: #fff;
      font-size: 15px;
      font-weight: 800;
      text-align: right;
      width: 90px;
      outline: none;
    }
    .step-btn {
      width: 36px;
      height: 36px;
      background: #073579;
      border: 1px solid #1455b8;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-size: 15px;
      cursor: pointer;
      font-weight: 800;
      transition: transform 0.1s;
    }
    .step-btn:active { transform: scale(0.9); }

    /* Action Row */
    .action-row { display: flex; align-items: center; gap: 12px; }
    .btn-circle-refresh {
      width: 48px;
      height: 48px;
      background: #073579;
      border: 1px solid #1455b8;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #4da3ff;
      font-size: 18px;
      cursor: pointer;
      transition: transform 0.25s;
    }
    .btn-circle-refresh:active { transform: rotate(180deg); }
    .btn-main-action {
      flex: 1;
      height: 48px;
      background: var(--btn-green);
      border: none;
      border-radius: 25px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      font-size: 17px;
      font-weight: 900;
      color: #fff;
      cursor: pointer;
      box-shadow: 0 4px 15px rgba(0, 230, 118, 0.4);
      letter-spacing: 0.5px;
      transition: transform 0.1s, box-shadow 0.2s;
    }
    .btn-main-action:active { transform: scale(0.97); }
    .btn-main-action:disabled {
      opacity: 0.6;
      cursor: not-allowed;
      transform: none;
    }

    /* Footer */
    .footer-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 4px 20px 14px 20px;
      font-size: 13px;
      color: #85adff;
    }
    .footer-bar i { cursor: pointer; font-size: 18px; }
  </style>
</head>
<body>

<div class="app-container">

  <!-- Top Bar -->
  <div>
    <div class="top-bar">
      <i class="fa-solid fa-chevron-left back-btn"></i>
      <div class="wallet-pill">
        <div class="coin-badge">₹</div>
        <div class="balance-txt" id="walletBalance">₹0.00</div>
        <div class="btn-add-funds" onclick="location.href='/deposit'" title="Deposit">+</div>
      </div>
      <div class="support-icon"><i class="fa-solid fa-headset"></i></div>
    </div>

    <div class="game-title">LIMBO</div>

    <!-- Encrypted Result Hash Bar -->
    <div class="meta-bar">
      <div class="encrypted-hash">
        <span>Encrypted:</span>
        <span id="hashDisplay">556b877618f5...</span>
        <span class="hash-icons">
          <i class="fa-regular fa-copy" onclick="copyHash()" title="Copy Hash"></i>
          <i class="fa-solid fa-rotate-right" onclick="generateNewHash()" title="New Seed"></i>
        </span>
      </div>
    </div>

    <!-- Recent History Pills -->
    <div class="history-pills" id="historyPills"></div>
  </div>

  <!-- Space Canvas & Rocket Arena -->
  <div class="limbo-arena" id="arenaContainer">
    <canvas id="limboCanvas"></canvas>

    <div class="planet-decor"></div>

    <!-- Multiplier Output -->
    <div class="multiplier-display" id="multiplierDisplay">1.00x</div>

    <!-- Rocket Graphic -->
    <div class="rocket-stage" id="rocketStage">
      <svg class="rocket-svg" viewBox="0 0 100 120">
        <!-- Body Fins -->
        <path d="M20 90 C15 70 15 50 30 50 L30 90 Z" fill="#ff334b"/>
        <path d="M80 90 C85 70 85 50 70 50 L70 90 Z" fill="#ff334b"/>
        <!-- Rocket Body -->
        <path d="M50 10 C35 30 30 70 30 95 L70 95 C70 70 65 30 50 10 Z" fill="#e6ecf8"/>
        <!-- Nosecone -->
        <path d="M50 10 C42 25 38 40 38 40 L62 40 C62 40 58 25 50 10 Z" fill="#ff334b"/>
        <!-- Center Blue Stripe -->
        <rect x="42" y="55" width="16" height="35" rx="3" fill="#2962ff"/>
        <!-- Window -->
        <circle cx="50" cy="50" r="11" fill="#1b2a47" stroke="#90b8f8" stroke-width="2.5"/>
        <circle cx="48" cy="48" r="4" fill="#ffffff" opacity="0.8"/>
        <!-- Engine Nozzle -->
        <polygon points="40,95 60,95 64,102 36,102" fill="#37474f"/>
      </svg>
    </div>

    <!-- Moon Ground Surface -->
    <div class="moon-ground"></div>
  </div>

  <!-- Target Multiplier Controls -->
  <div>
    <div class="target-controller-wrap">
      <div class="circle-step-btn" onclick="adjustTarget(-0.5)">-</div>
      <div class="target-val-box">
        <input type="number" id="targetInput" class="target-inp" value="2.00" step="0.1" min="1.01" max="1000" oninput="onTargetChange()" />
      </div>
      <div class="circle-step-btn" onclick="adjustTarget(0.5)">+</div>
    </div>
    <div class="win-chance-lbl" id="winChanceLbl">Win Chance: 49.50%</div>

    <!-- Bet Controls Panel -->
    <div class="dashboard-panel">
      <div class="bet-input-row">
        <div class="bet-amount-box">
          <span class="bet-lbl">Bet</span>
          <input type="number" id="betInput" class="bet-inp" value="10.00" min="10" step="10" />
        </div>
        <div class="step-btn" onclick="adjustBet(-10)">-</div>
        <div class="step-btn" onclick="multiplyBet(2)"><i class="fa-solid fa-coins"></i></div>
        <div class="step-btn" onclick="adjustBet(10)">+</div>
      </div>

      <div class="action-row">
        <div class="btn-circle-refresh" onclick="resetToDefaults()"><i class="fa-solid fa-rotate-right"></i></div>
        <button class="btn-main-action" id="btnBet" onclick="playLimboRound()">
          <i class="fa-solid fa-play"></i>
          <span>BET</span>
        </button>
      </div>
    </div>

    <!-- Footer -->
    <div class="footer-bar">
      <i class="fa-regular fa-circle-question" onclick="alert('Limbo Rules:\n1. Choose Target Multiplier (e.g. 2.00x).\n2. Enter Bet Amount & click BET.\n3. If Rocket outcome is >= Target, you WIN!')"></i>
      <span id="winResultFooter">0.00 INR</span>
      <i class="fa-solid fa-bars"></i>
    </div>
  </div>

</div>

<script>
  // Web Audio Synthesizer
  const AudioFx = {
    ctx: null,
    init() {
      if (!this.ctx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        this.ctx = new AudioContext();
      }
      if (this.ctx.state === 'suspended') this.ctx.resume();
    },
    rocketLaunch() {
      this.init();
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(90, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(550, this.ctx.currentTime + 0.6);
      gain.gain.setValueAtTime(0.14, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.6);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.6);
    },
    winChime() {
      this.init();
      const notes = [523.25, 659.25, 783.99, 1046.50];
      notes.forEach((freq, idx) => {
        setTimeout(() => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
          gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.22);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start();
          osc.stop(this.ctx.currentTime + 0.22);
        }, idx * 70);
      });
    },
    lossThud() {
      this.init();
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(140, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(30, this.ctx.currentTime + 0.25);
      gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.25);
    }
  };

  // Canvas Particle & Warp Star System
  const canvas = document.getElementById("limboCanvas");
  const ctx = canvas.getContext("2d");
  let stars = [];
  let particles = [];
  let isWarpSpeed = false;
  let isEmittingFlames = false;

  function initCanvas() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    stars = [];
    for (let i = 0; i < 45; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 0.8,
        speed: Math.random() * 0.4 + 0.1,
        alpha: Math.random() * 0.7 + 0.3
      });
    }
  }

  function createFlameParticles() {
    if (!isEmittingFlames) return;
    const stage = document.getElementById("rocketStage");
    const rect = stage.getBoundingClientRect();
    const arenaRect = canvas.getBoundingClientRect();
    const originX = rect.left - arenaRect.left + rect.width / 2;
    const originY = rect.bottom - arenaRect.top - 12;

    for (let i = 0; i < 3; i++) {
      particles.push({
        x: originX + (Math.random() - 0.5) * 14,
        y: originY,
        vx: (Math.random() - 0.5) * 1.5,
        vy: Math.random() * 4 + 3,
        size: Math.random() * 6 + 4,
        color: ['#ffbb00', '#ff4400', '#ffffff', '#ff9900'][Math.floor(Math.random() * 4)],
        life: 1.0,
        decay: Math.random() * 0.05 + 0.04
      });
    }
  }

  function createConfetti() {
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: canvas.width / 2,
        y: canvas.height / 2,
        vx: (Math.random() - 0.5) * 10,
        vy: (Math.random() - 0.5) * 10 - 2,
        size: Math.random() * 5 + 3,
        color: ['#00e676', '#ffea00', '#00e5ff', '#ffffff'][Math.floor(Math.random() * 4)],
        life: 1.0,
        decay: Math.random() * 0.02 + 0.015
      });
    }
  }

  function loopCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw & Move Stars
    stars.forEach(s => {
      ctx.fillStyle = `rgba(255, 255, 255, ${s.alpha})`;
      if (isWarpSpeed) {
        ctx.strokeStyle = `rgba(160, 210, 255, ${s.alpha * 1.5})`;
        ctx.lineWidth = s.size;
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(s.x, s.y + s.speed * 18);
        ctx.stroke();
        s.y += s.speed * 12;
      } else {
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
        ctx.fill();
        s.y += s.speed;
      }

      if (s.y > canvas.height) {
        s.y = 0;
        s.x = Math.random() * canvas.width;
      }
    });

    createFlameParticles();

    // Draw & Update Particles
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life -= p.decay;

      ctx.fillStyle = p.color;
      ctx.globalAlpha = Math.max(0, p.life);
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1.0;

      if (p.life <= 0) {
        particles.splice(i, 1);
      }
    }

    requestAnimationFrame(loopCanvas);
  }

  // State
  let balance = 0.00;
  let isRolling = false;
  let historyList = [
    { mult: 2.14, win: true },
    { mult: 1.05, win: false },
    { mult: 4.88, win: true },
    { mult: 1.30, win: false }
  ];

  function init() {
    loadBalanceFromServer();
    initCanvas();
    loopCanvas();
    window.addEventListener("resize", initCanvas);
    updateBalanceDisplay();
    onTargetChange();
    renderHistoryPills();
    generateNewHash();
  }

  // Fair CSPRNG Limbo Outcome Generation
  function generateFairLimboOutcome() {
    const arr = new Uint32Array(1);
    window.crypto.getRandomValues(arr);
    const u = (arr[0] + 1) / (0xFFFFFFFF + 1);
    const raw = 0.99 / (1 - u);
    return Math.max(1.00, parseFloat(raw.toFixed(2)));
  }

  // Main Smooth Gameplay Loop
  async function playLimboRound() {
    if (isRolling) return;
    AudioFx.init();

    const betAmt = parseFloat(document.getElementById("betInput").value);
    const target = parseFloat(document.getElementById("targetInput").value);

    if (isNaN(betAmt) || betAmt <= 0) {
      alert("Enter a valid bet amount!");
      return;
    }
    if (isNaN(target) || target < 1.01) {
      alert("Target multiplier must be at least 1.01x!");
      return;
    }
    if (balance < betAmt) {
      alert("⚠️ Insufficient Wallet Balance! Please deposit funds.");
      return;
    }

    const res = await updateServerBalance("subtract", betAmt);
    if (!res.ok) {
      alert(res.msg || "Insufficient balance");
      await loadBalanceFromServer();
      return;
    }
    balance = res.balance;
    updateBalanceDisplay();
    isRolling = true;

    // Start Animations
    document.getElementById("btnBet").disabled = true;
    const arena = document.getElementById("arenaContainer");
    const stage = document.getElementById("rocketStage");
    const display = document.getElementById("multiplierDisplay");

    arena.classList.remove("shake-fx");
    stage.className = "rocket-stage launching";
    display.className = "multiplier-display";
    isWarpSpeed = true;
    isEmittingFlames = true;
    AudioFx.rocketLaunch();

    const finalOutcome = generateFairLimboOutcome();
    const duration = 650; // ms
    const startTime = performance.now();

    function animateCounter(now) {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / duration);
      // Smooth cubic-bezier acceleration curve
      const easeProgress = progress * progress * (3 - 2 * progress);
      const currentCount = 1.00 + (finalOutcome - 1.00) * easeProgress;

      display.innerText = `${currentCount.toFixed(2)}x`;

      if (progress < 1) {
        requestAnimationFrame(animateCounter);
      } else {
        // Round Finished
        display.innerText = `${finalOutcome.toFixed(2)}x`;
        isWarpSpeed = false;
        isEmittingFlames = false;

        const won = (finalOutcome >= target);
        if (won) {
          const payout = betAmt * target;
          updateServerBalance("add", payout).then(res => {
            if (res.ok) { balance = res.balance; updateBalanceDisplay(); }
          });
          display.classList.add("win");
          stage.className = "rocket-stage win-fly";
          createConfetti();
          AudioFx.winChime();
          document.getElementById("winResultFooter").innerText = `+${payout.toFixed(2)} INR`;
          
          setTimeout(() => {
            stage.className = "rocket-stage";
          }, 650);
        } else {
          display.classList.add("loss");
          stage.className = "rocket-stage loss-recoil";
          arena.classList.add("shake-fx");
          AudioFx.lossThud();
          document.getElementById("winResultFooter").innerText = `0.00 INR`;

          setTimeout(() => {
            stage.className = "rocket-stage";
          }, 350);
        }

        updateBalanceDisplay();
        historyList.unshift({ mult: finalOutcome, win: won });
        if (historyList.length > 8) historyList.pop();
        renderHistoryPills();
        generateNewHash();

        isRolling = false;
        document.getElementById("btnBet").disabled = false;
      }
    }
    requestAnimationFrame(animateCounter);
  }

  function onTargetChange() {
    const inp = document.getElementById("targetInput");
    let val = parseFloat(inp.value) || 2.0;
    val = Math.max(1.01, val);
    const winChance = (99 / val).toFixed(2);
    document.getElementById("winChanceLbl").innerText = `Win Chance: ${Math.min(98.02, winChance)}%`;
  }

  function adjustTarget(delta) {
    if (isRolling) return;
    const inp = document.getElementById("targetInput");
    let val = parseFloat(inp.value) || 2.0;
    val = Math.max(1.01, parseFloat((val + delta).toFixed(2)));
    inp.value = val.toFixed(2);
    onTargetChange();
  }

  function adjustBet(delta) {
    if (isRolling) return;
    const inp = document.getElementById("betInput");
    let val = parseFloat(inp.value) || 10;
    val = Math.max(10, val + delta);
    inp.value = val.toFixed(2);
  }

  function multiplyBet(factor) {
    if (isRolling) return;
    const inp = document.getElementById("betInput");
    let val = parseFloat(inp.value) || 10;
    val = Math.max(10, val * factor);
    inp.value = val.toFixed(2);
  }

  function updateBalanceDisplay() {
    document.getElementById("walletBalance").innerText = `₹${balance.toFixed(2)}`;
  }

  function loadBalanceFromServer() {
    return fetch('/account_balance').then(r => r.json()).then(data => {
      if (data.ok) {
        balance = data.balance;
        updateBalanceDisplay();
      }
    }).catch(() => {});
  }

  function updateServerBalance(action, amount) {
    return fetch('/update_balance', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({action: action, amount: amount})
    }).then(r => r.json());
  }

  function renderHistoryPills() {
    const container = document.getElementById("historyPills");
    container.innerHTML = "";
    historyList.forEach(item => {
      container.innerHTML += `
        <div class="h-pill ${item.win ? 'win' : 'loss'}">${item.mult.toFixed(2)}x</div>
      `;
    });
  }

  function generateNewHash() {
    const chars = '0123456789abcdef';
    let hash = '';
    for (let i = 0; i < 64; i++) hash += chars[Math.floor(Math.random() * chars.length)];
    document.getElementById("hashDisplay").innerText = hash.substring(0, 14) + '...';
  }

  function copyHash() {
    navigator.clipboard.writeText("556b877618f5b54d673998bce1a0f81d8471e956c3619572b9a54ffc9a6");
    alert("Encrypted Hash copied to clipboard!");
  }

  function resetToDefaults() {
    document.getElementById("betInput").value = "10.00";
    document.getElementById("targetInput").value = "2.00";
    onTargetChange();
  }

  window.onload = init;
</script>

</body>
</html>'''
