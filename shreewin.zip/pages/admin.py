admin_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Shree.Win - Master Fintech & Support Admin Panel</title>
    <!-- FontAwesome 6 Pro Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg-body: #090d16;
            --bg-sidebar: #0f172a;
            --bg-surface: #131d33;
            --bg-surface-elevated: #1a2642;
            --bg-input: #0c1322;
            --border-subtle: rgba(255, 255, 255, 0.08);
            --border-focus: #6366f1;
            
            --primary: #6366f1;
            --primary-hover: #4f46e5;
            --primary-gradient: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            --accent-green: #10b981;
            --accent-green-glow: rgba(16, 185, 129, 0.2);
            --accent-red: #f43f5e;
            --accent-red-glow: rgba(244, 63, 94, 0.2);
            --accent-amber: #f59e0b;
            --accent-amber-glow: rgba(245, 158, 11, 0.2);
            --accent-cyan: #06b6d4;
            --accent-gold: #fbbf24;

            --text-primary: #f8fafc;
            --text-secondary: #94a3b8;
            --text-muted: #64748b;

            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --shadow-card: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            overflow-x: hidden;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 270px;
            background: var(--bg-sidebar);
            border-right: 1px solid var(--border-subtle);
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .sidebar-brand {
            padding: 20px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--border-subtle);
        }

        .brand-wrapper {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-icon {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-md);
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            color: white;
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.35);
        }

        .brand-title {
            font-size: 1.15rem;
            font-weight: 800;
            letter-spacing: -0.5px;
            display: flex;
            flex-direction: column;
        }

        .brand-title span {
            font-size: 0.65rem;
            font-weight: 700;
            color: var(--accent-green);
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }

        .sidebar-close-btn {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid var(--border-subtle);
            color: var(--text-secondary);
            width: 36px;
            height: 36px;
            border-radius: var(--radius-sm);
            display: none;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 1.1rem;
        }

        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(4px);
            z-index: 95;
            display: none;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .sidebar-overlay.active {
            display: block;
            opacity: 1;
        }

        .nav-section {
            padding: 16px 14px;
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 4px;
            overflow-y: auto;
        }

        .nav-label {
            font-size: 0.68rem;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 1.2px;
            padding: 10px 12px 4px 12px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 11px 14px;
            color: var(--text-secondary);
            border-radius: var(--radius-md);
            text-decoration: none;
            font-size: 0.88rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .nav-link i {
            font-size: 1.05rem;
            width: 22px;
            text-align: center;
        }

        .nav-link:hover {
            background-color: var(--bg-surface);
            color: var(--text-primary);
        }

        .nav-link.active {
            background: var(--primary-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.25);
        }

        .badge-count {
            margin-left: auto;
            background-color: var(--accent-amber);
            color: #000;
            font-size: 0.7rem;
            font-weight: 800;
            padding: 2px 7px;
            border-radius: 20px;
        }

        .sidebar-footer {
            padding: 16px 20px;
            border-top: 1px solid var(--border-subtle);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .admin-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 0.95rem;
        }

        .admin-info { display: flex; flex-direction: column; overflow: hidden; }
        .admin-name { font-size: 0.88rem; font-weight: 700; }
        .admin-role { font-size: 0.72rem; color: var(--text-muted); }

        /* Workspace */
        .workspace {
            flex: 1;
            margin-left: 270px;
            padding: 24px 32px;
            min-height: 100vh;
            max-width: calc(100vw - 270px);
            display: flex;
            flex-direction: column;
        }

        /* Topbar */
        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            gap: 15px;
        }

        .mobile-toggle {
            display: none;
            background: var(--bg-surface);
            border: 1px solid var(--border-subtle);
            color: white;
            width: 42px;
            height: 42px;
            border-radius: var(--radius-md);
            cursor: pointer;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }

        .page-header h1 {
            font-size: 1.4rem;
            font-weight: 800;
            letter-spacing: -0.5px;
        }

        .page-header p {
            color: var(--text-secondary);
            font-size: 0.82rem;
            margin-top: 2px;
        }

        .topbar-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .btn-topbar {
            background-color: var(--bg-surface);
            border: 1px solid var(--border-subtle);
            color: var(--text-primary);
            padding: 9px 16px;
            border-radius: var(--radius-md);
            font-size: 0.82rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-topbar.primary {
            background: var(--primary-gradient);
            border: none;
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3);
        }

        /* Metrics */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }

        .metric-card {
            background: var(--bg-surface);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-lg);
            padding: 18px;
            box-shadow: var(--shadow-card);
            position: relative;
            overflow: hidden;
        }

        .metric-card.green { border-top: 3px solid var(--accent-green); }
        .metric-card.amber { border-top: 3px solid var(--accent-amber); }
        .metric-card.purple { border-top: 3px solid var(--primary); }
        .metric-card.gold { border-top: 3px solid var(--accent-gold); }

        .metric-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .metric-title {
            color: var(--text-secondary);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .metric-icon-box {
            width: 32px;
            height: 32px;
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.95rem;
        }

        .metric-card.green .metric-icon-box { background: var(--accent-green-glow); color: var(--accent-green); }
        .metric-card.amber .metric-icon-box { background: var(--accent-amber-glow); color: var(--accent-amber); }
        .metric-card.purple .metric-icon-box { background: rgba(99, 102, 241, 0.15); color: var(--primary); }
        .metric-card.gold .metric-icon-box { background: rgba(245, 158, 11, 0.15); color: var(--accent-gold); }

        .metric-value {
            font-size: 1.5rem;
            font-weight: 800;
            letter-spacing: -0.5px;
            line-height: 1.1;
            margin-bottom: 4px;
        }

        .metric-sub { font-size: 0.72rem; color: var(--text-muted); }

        /* Dashboard Content Card */
        .dashboard-section {
            background: var(--bg-surface);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-lg);
            padding: 20px;
            box-shadow: var(--shadow-card);
            margin-bottom: 24px;
        }

        .table-toolbar {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            width: 100%;
            justify-content: space-between;
            margin-bottom: 18px;
        }

        .search-box {
            position: relative;
            flex: 1;
            min-width: 200px;
        }

        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 0.85rem;
        }

        .search-box input {
            width: 100%;
            background: var(--bg-input);
            border: 1px solid var(--border-subtle);
            padding: 9px 12px 9px 36px;
            border-radius: var(--radius-md);
            color: var(--text-primary);
            font-size: 0.85rem;
            outline: none;
        }

        .filter-tab-group {
            display: flex;
            background: var(--bg-input);
            padding: 3px;
            border-radius: var(--radius-md);
            border: 1px solid var(--border-subtle);
            overflow-x: auto;
        }

        .filter-pill {
            background: transparent;
            border: none;
            color: var(--text-muted);
            padding: 6px 12px;
            border-radius: var(--radius-sm);
            font-size: 0.78rem;
            font-weight: 700;
            cursor: pointer;
            white-space: nowrap;
        }

        .filter-pill.active {
            background: var(--primary);
            color: white;
        }

        /* Table */
        .table-container {
            overflow-x: auto;
            border-radius: var(--radius-md);
            border: 1px solid var(--border-subtle);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            font-size: 0.85rem;
            min-width: 800px;
        }

        thead { background: var(--bg-surface-elevated); }

        th {
            padding: 12px 14px;
            color: var(--text-secondary);
            font-weight: 700;
            font-size: 0.75rem;
            text-transform: uppercase;
            border-bottom: 1px solid var(--border-subtle);
        }

        td {
            padding: 14px;
            border-bottom: 1px solid var(--border-subtle);
            vertical-align: middle;
        }

        .amount-text {
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.95rem;
            font-weight: 700;
            color: var(--accent-green);
        }

        .amount-payout {
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.95rem;
            font-weight: 700;
            color: #ffb800;
        }

        .data-chip {
            font-family: 'JetBrains Mono', monospace;
            background: #111a2e;
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 0.8rem;
            color: #c7d2fe;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .data-chip i { cursor: pointer; color: var(--text-muted); }
        .data-chip i:hover { color: #fff; }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 0.72rem;
            font-weight: 700;
        }

        .status-badge.pending { background: var(--accent-amber-glow); color: var(--accent-amber); border: 1px solid rgba(245, 158, 11, 0.3); }
        .status-badge.approved { background: var(--accent-green-glow); color: var(--accent-green); border: 1px solid rgba(16, 185, 129, 0.3); }
        .status-badge.rejected { background: var(--accent-red-glow); color: var(--accent-red); border: 1px solid rgba(244, 63, 94, 0.3); }

        .actions-group {
            display: flex;
            align-items: center;
            gap: 6px;
            justify-content: flex-end;
        }

        .btn-action-sm {
            padding: 6px 12px;
            border-radius: var(--radius-sm);
            border: none;
            font-size: 0.78rem;
            font-weight: 700;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .btn-action-sm.approve { background: var(--accent-green); color: #042f1a; }
        .btn-action-sm.reject { background: rgba(244, 63, 94, 0.15); color: var(--accent-red); border: 1px solid rgba(244, 63, 94, 0.3); }

        .empty-log-box {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-muted);
        }
        .empty-log-box i { font-size: 3rem; margin-bottom: 10px; opacity: 0.3; }

        /* Gateway Form */
        .gateway-layout {
            display: grid;
            grid-template-columns: 1fr 300px;
            gap: 20px;
        }
        .form-grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .input-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .input-group.full { grid-column: span 2; }
        .input-group label { font-size: 0.8rem; font-weight: 700; color: var(--text-secondary); }
        .input-control {
            background: var(--bg-input);
            border: 1px solid var(--border-subtle);
            padding: 10px 14px;
            border-radius: var(--radius-md);
            color: var(--text-primary);
            font-size: 0.9rem;
            outline: none;
        }
        .qr-live-preview-card {
            background: var(--bg-surface-elevated);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border-subtle);
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }
        .qr-frame {
            background: white;
            padding: 10px;
            border-radius: var(--radius-md);
            margin-bottom: 10px;
        }
        .qr-frame img { width: 160px; height: 160px; display: block; }

        /* Wallet Tab */
        .wallet-manager-box {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .quick-amount-chips {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 10px;
        }
        .chip-add {
            background: var(--bg-input);
            border: 1px solid var(--border-subtle);
            color: var(--text-primary);
            padding: 6px 12px;
            border-radius: var(--radius-sm);
            font-weight: 700;
            font-size: 0.8rem;
            cursor: pointer;
        }

        /* ================= LIVE SUPPORT CHAT MODULE STYLES ================= */
        .support-workspace {
            display: flex;
            height: calc(100vh - 180px);
            min-height: 520px;
            background: var(--bg-surface);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-lg);
            overflow: hidden;
            box-shadow: var(--shadow-card);
            position: relative;
        }

        .chat-sidebar {
            width: 320px;
            background: var(--bg-surface-elevated);
            border-right: 1px solid var(--border-subtle);
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
            transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s ease;
            overflow: hidden;
        }

        .chat-sidebar.collapsed {
            width: 0 !important;
            opacity: 0;
            pointer-events: none;
            border-right: none;
        }

        .chat-user-list {
            flex: 1;
            overflow-y: auto;
            min-width: 320px;
        }

        .chat-user-item {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-subtle);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background 0.15s;
        }

        .chat-user-item:hover { background: rgba(255, 255, 255, 0.04); }
        .chat-user-item.active {
            background: rgba(99, 102, 241, 0.15);
            border-left: 3px solid var(--primary);
        }

        .chat-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--bg-input);
            border: 1px solid var(--border-subtle);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
            color: #38bdf8;
            position: relative;
            flex-shrink: 0;
        }

        .chat-status-dot {
            width: 9px;
            height: 9px;
            background-color: var(--accent-green);
            border-radius: 50%;
            border: 2px solid var(--bg-surface);
            position: absolute;
            bottom: 0;
            right: 0;
        }

        .chat-main-view {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: #0b0f19;
            position: relative;
            min-width: 0;
        }

        .chat-main-header {
            height: 60px;
            background: var(--bg-surface-elevated);
            border-bottom: 1px solid var(--border-subtle);
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .chat-viewport {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .chat-bubble-row {
            display: flex;
            gap: 10px;
            max-width: 70%;
        }

        .row-user { align-self: flex-start; }
        .row-admin { align-self: flex-end; flex-direction: row-reverse; }

        .bubble-content {
            padding: 10px 14px;
            border-radius: var(--radius-md);
            font-size: 0.85rem;
            line-height: 1.45;
            word-break: break-word;
        }

        .bubble-user {
            background: var(--bg-surface-elevated);
            color: #fff;
            border: 1px solid var(--border-subtle);
            border-top-left-radius: 2px;
        }

        .bubble-admin {
            background: var(--primary-gradient);
            color: #fff;
            border-top-right-radius: 2px;
        }

        .bubble-meta {
            font-size: 0.65rem;
            color: rgba(255, 255, 255, 0.6);
            margin-top: 4px;
            display: flex;
            justify-content: space-between;
            gap: 8px;
        }

        .quick-replies-bar {
            padding: 8px 16px;
            background: rgba(15, 23, 42, 0.95);
            border-top: 1px solid var(--border-subtle);
            display: flex;
            gap: 8px;
            overflow-x: auto;
        }

        .quick-chip {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border-subtle);
            color: #cbd5e1;
            padding: 4px 10px;
            border-radius: 14px;
            font-size: 0.72rem;
            font-weight: 600;
            white-space: nowrap;
            cursor: pointer;
            transition: all 0.2s;
        }

        .quick-chip:hover {
            background: var(--primary);
            border-color: var(--primary);
            color: #fff;
        }

        .chat-composer {
            padding: 12px 18px;
            background: var(--bg-surface-elevated);
            border-top: 1px solid var(--border-subtle);
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .composer-input {
            flex: 1;
            background: var(--bg-input);
            border: 1px solid var(--border-subtle);
            color: #fff;
            padding: 10px 16px;
            border-radius: var(--radius-md);
            font-size: 0.88rem;
            outline: none;
        }

        .composer-input:focus { border-color: var(--primary); }

        /* Modal Styles */
        .modal-backdrop {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.8);
            backdrop-filter: blur(6px);
            z-index: 200;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .modal-card {
            background: var(--bg-surface);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-lg);
            width: 100%;
            max-width: 580px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6);
            display: flex;
            flex-direction: column;
        }

        .modal-header {
            padding: 18px 24px;
            border-bottom: 1px solid var(--border-subtle);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .modal-body {
            padding: 24px;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .modal-footer {
            padding: 18px 24px;
            border-top: 1px solid var(--border-subtle);
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }

        .conditions-box {
            background: var(--bg-surface-elevated);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-md);
            padding: 16px;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .cond-toggle-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
        }

        .cond-toggle-left {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .cond-toggle-left i { color: var(--accent-gold); width: 16px; }

        .cond-input-sm {
            width: 130px;
            background: var(--bg-input);
            border: 1px solid var(--border-subtle);
            padding: 6px 10px;
            border-radius: 6px;
            color: white;
            font-size: 0.82rem;
            outline: none;
            font-family: 'JetBrains Mono', monospace;
        }

        .cond-pill {
            background: #0f182c;
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 2px 7px;
            border-radius: 4px;
            font-size: 0.72rem;
            color: #cbd5e1;
        }
        .cond-pill i { color: var(--accent-gold); margin-right: 3px; }

        /* Toast Notifications */
        #toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            z-index: 1000;
        }
        .toast-msg {
            background: var(--bg-surface-elevated);
            color: white;
            border-left: 4px solid var(--primary);
            border-radius: var(--radius-md);
            padding: 12px 16px;
            font-size: 0.85rem;
            font-weight: 600;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .toast-msg.success { border-left-color: var(--accent-green); }
        .toast-msg.danger { border-left-color: var(--accent-red); }
        .toast-msg.warning { border-left-color: var(--accent-amber); }

        /* Responsive */
        @media (max-width: 1200px) {
            .metrics-grid { grid-template-columns: repeat(2, 1fr); }
            .gateway-layout { grid-template-columns: 1fr; }
            .wallet-manager-box { grid-template-columns: 1fr; }
        }

        @media (max-width: 900px) {
            .sidebar { transform: translateX(-100%); width: 280px; box-shadow: 0 0 30px rgba(0,0,0,0.9); }
            .sidebar.mobile-open { transform: translateX(0); }
            .sidebar-close-btn { display: flex; }
            .workspace { margin-left: 0; max-width: 100vw; padding: 16px; }
            .mobile-toggle { display: flex; }
            .form-grid-2 { grid-template-columns: 1fr; }
            .input-group.full { grid-column: span 1; }
            .chat-sidebar { position: absolute; left: 0; top: 0; bottom: 0; z-index: 50; width: 280px; }
        }
    </style>
</head>
<body>

    <!-- Sidebar Navigation -->
    <aside class="sidebar" id="main-sidebar">
        <div class="sidebar-brand">
            <div class="brand-wrapper">
                <div class="brand-icon"><i class="fa-solid fa-crown"></i></div>
                <div class="brand-title">
                    Shree.Win
                    <span><i class="fa-solid fa-shield-halved"></i> Master Control</span>
                </div>
            </div>
            <button class="sidebar-close-btn" onclick="toggleSidebar()"><i class="fa-solid fa-xmark"></i></button>
        </div>

        <div class="nav-section">
            <span class="nav-label">Finance Modules</span>
            <div class="nav-link active" onclick="switchTab('deposits', this)">
                <i class="fa-solid fa-wallet" style="color: var(--accent-green);"></i>
                <span>Deposit Orders</span>
                <span class="badge-count" id="sidebar-dep-badge">0</span>
            </div>
            <div class="nav-link" onclick="switchTab('withdrawals', this)">
                <i class="fa-solid fa-money-bill-transfer" style="color: var(--accent-amber);"></i>
                <span>Withdrawal Payouts</span>
                <span class="badge-count" id="sidebar-with-badge">0</span>
            </div>
            <div class="nav-link" onclick="switchTab('gifts', this)">
                <i class="fa-solid fa-gift" style="color: var(--accent-gold);"></i>
                <span>Gift Code Engine</span>
            </div>

            <span class="nav-label" style="margin-top: 10px;">Support & CRM</span>
            <!-- Live Support Tab -->
            <div class="nav-link" onclick="switchTab('support', this)">
                <i class="fa-solid fa-headset" style="color: #38bdf8;"></i>
                <span>Live Support Desk</span>
                <span class="badge-count" id="sidebar-support-badge" style="background-color: #38bdf8;">0</span>
            </div>

            <span class="nav-label" style="margin-top: 10px;">Configuration</span>
            <div class="nav-link" onclick="switchTab('gateway', this)">
                <i class="fa-solid fa-qrcode"></i>
                <span>UPI & QR Settings</span>
            </div>
            <div class="nav-link" onclick="switchTab('wallets', this)">
                <i class="fa-solid fa-vault"></i>
                <span>User Balances</span>
            </div>

            <span class="nav-label" style="margin-top: 10px;">User Apps</span>
            <a href="customer support.html" target="_blank" class="nav-link"><i class="fa-solid fa-arrow-up-right-from-square"></i><span>Customer Support View</span></a>
            <a href="deposit.html" target="_blank" class="nav-link"><i class="fa-solid fa-arrow-up-right-from-square"></i><span>Open Deposit Screen</span></a>
            <a href="withdraw.html" target="_blank" class="nav-link"><i class="fa-solid fa-arrow-up-right-from-square"></i><span>Open Withdraw Screen</span></a>
        </div>

        <div class="sidebar-footer">
            <div class="admin-avatar">M</div>
            <div class="admin-info">
                <span class="admin-name">Master Admin</span>
                <span class="admin-role">Super Access</span>
            </div>
        </div>
    </aside>

    <div class="sidebar-overlay" id="sidebar-overlay" onclick="toggleSidebar()"></div>

    <!-- Main Workspace -->
    <main class="workspace">
        
        <!-- Top Navbar -->
        <header class="topbar">
            <div style="display: flex; align-items: center; gap: 12px;">
                <button class="mobile-toggle" onclick="toggleSidebar()"><i class="fa-solid fa-bars"></i></button>
                <div class="page-header">
                    <h1 id="page-heading">Deposit Management</h1>
                    <p id="page-subheading">Live UTR Verification, Payment Approvals & Gateway Operations</p>
                </div>
            </div>

            <div class="topbar-actions">
                <button class="btn-topbar primary" id="topbar-action-btn" onclick="openCreateGiftModal()">
                    <i class="fa-solid fa-gift"></i> Create Gift Code
                </button>
                <button class="btn-topbar" onclick="clearPendingDeposits()" style="background:#b91c1c;"><i class="fa-solid fa-trash"></i> Clear Pending</button>
                <button class="btn-topbar" onclick="exportActiveCSV()"><i class="fa-solid fa-file-export"></i> Export CSV</button>
            </div>
        </header>

        <!-- KPI Metrics Grid -->
        <section class="metrics-grid">
            <div class="metric-card green">
                <div class="metric-header">
                    <span class="metric-title">Total Approved Deposits</span>
                    <div class="metric-icon-box"><i class="fa-solid fa-circle-check"></i></div>
                </div>
                <div class="metric-value" id="kpi-total-deposits">₹0.00</div>
                <div class="metric-sub">Total money credited</div>
            </div>

            <div class="metric-card amber">
                <div class="metric-header">
                    <span class="metric-title">Pending Tasks</span>
                    <div class="metric-icon-box"><i class="fa-solid fa-hourglass-half"></i></div>
                </div>
                <div class="metric-value" id="kpi-pending-total">0</div>
                <div class="metric-sub"><span id="kpi-pending-breakdown" style="color: var(--accent-amber);">0 Dep / 0 With</span></div>
            </div>

            <div class="metric-card gold">
                <div class="metric-header">
                    <span class="metric-title">Total Disbursed Payouts</span>
                    <div class="metric-icon-box"><i class="fa-solid fa-money-bill-transfer"></i></div>
                </div>
                <div class="metric-value" id="kpi-total-payouts">₹0.00</div>
                <div class="metric-sub">Settled to user bank/UPI</div>
            </div>

            <div class="metric-card purple">
                <div class="metric-header">
                    <span class="metric-title">User Wallet Balance</span>
                    <div class="metric-icon-box"><i class="fa-solid fa-vault"></i></div>
                </div>
                <div class="metric-value" id="kpi-user-wallet">₹0.00</div>
                <div class="metric-sub">Active wallet liquidity</div>
            </div>
        </section>

        <!-- ================= 1. DEPOSIT ORDERS TAB ================= -->
        <div id="tab-deposits" class="tab-pane">
            <div class="dashboard-section">
                <div class="table-toolbar">
                    <div class="search-box">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input type="text" id="dep-search" placeholder="Search by UTR, Order ID, User ID..." oninput="handleSearch('dep', this.value)">
                    </div>

                    <div class="filter-tab-group">
                        <button class="filter-pill active" onclick="setFilter('dep', 'all', this)">All (<span id="f-dep-all">0</span>)</button>
                        <button class="filter-pill" onclick="setFilter('dep', 'pending', this)">Pending (<span id="f-dep-pending">0</span>)</button>
                        <button class="filter-pill" onclick="setFilter('dep', 'approved', this)">Approved (<span id="f-dep-approved">0</span>)</button>
                        <button class="filter-pill" onclick="setFilter('dep', 'rejected', this)">Rejected (<span id="f-dep-rejected">0</span>)</button>
                    </div>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>User Account</th>
                                <th>Amount</th>
                                <th>Channel</th>
                                <th>12-Digit UTR</th>
                                <th>Date & Time</th>
                                <th>Status</th>
                                <th style="text-align: right;">Action</th>
                            </tr>
                        </thead>
                        <tbody id="deposit-tbody"></tbody>
                    </table>
                </div>
                <div id="empty-dep-view" class="empty-log-box" style="display: none;"><i class="fa-solid fa-file-invoice-dollar"></i><p>No deposit requests found</p></div>
            </div>
        </div>

        <!-- ================= 2. WITHDRAWAL PAYOUTS TAB ================= -->
        <div id="tab-withdrawals" class="tab-pane" style="display: none;">
            <div class="dashboard-section">
                <div class="table-toolbar">
                    <div class="search-box">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input type="text" id="with-search" placeholder="Search by Payout ID, Bank, UPI, Name..." oninput="handleSearch('with', this.value)">
                    </div>

                    <div class="filter-tab-group">
                        <button class="filter-pill active" onclick="setFilter('with', 'all', this)">All (<span id="f-with-all">0</span>)</button>
                        <button class="filter-pill" onclick="setFilter('with', 'pending', this)">Pending (<span id="f-with-pending">0</span>)</button>
                        <button class="filter-pill" onclick="setFilter('with', 'approved', this)">Approved (<span id="f-with-approved">0</span>)</button>
                        <button class="filter-pill" onclick="setFilter('with', 'rejected', this)">Rejected (<span id="f-with-rejected">0</span>)</button>
                    </div>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Payout ID</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Beneficiary / Payout Destination</th>
                                <th>Requested Time</th>
                                <th>Status</th>
                                <th style="text-align: right;">Action</th>
                            </tr>
                        </thead>
                        <tbody id="withdraw-tbody"></tbody>
                    </table>
                </div>
                <div id="empty-with-view" class="empty-log-box" style="display: none;"><i class="fa-solid fa-receipt"></i><p>No withdrawal requests found</p></div>
            </div>
        </div>

        <!-- ================= 3. GIFT CODE ENGINE TAB ================= -->
        <div id="tab-gifts" class="tab-pane" style="display: none;">
            <div class="dashboard-section">
                <div class="table-toolbar">
                    <div class="search-box">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input type="text" id="gift-search" placeholder="Search gift codes or rules..." oninput="handleSearch('gift', this.value)">
                    </div>
                    <button class="btn-topbar primary" onclick="openCreateGiftModal()"><i class="fa-solid fa-plus"></i> Generate Gift Code</button>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Gift Code</th>
                                <th>Bonus (₹)</th>
                                <th>Conditions / Restrictions</th>
                                <th>Claim Progress</th>
                                <th>Valid Until</th>
                                <th>Status</th>
                                <th style="text-align: right;">Action</th>
                            </tr>
                        </thead>
                        <tbody id="gift-tbody"></tbody>
                    </table>
                </div>
                <div id="empty-gift-view" class="empty-log-box" style="display: none;"><i class="fa-solid fa-gift"></i><p>No gift codes created yet</p></div>
            </div>
        </div>

        <!-- ================= 4. LIVE SUPPORT DESK (MERGED MODULE) ================= -->
        <div id="tab-support" class="tab-pane" style="display: none;">
            <div class="support-workspace">
                
                <!-- Chat Left Sidebar (Users & Search) -->
                <div class="chat-sidebar" id="supportChatSidebar">
                    <div style="padding: 12px; border-bottom: 1px solid var(--border-subtle); display: flex; gap: 8px;">
                        <div class="search-box" style="min-width: 0; flex: 1;">
                            <i class="fa-solid fa-magnifying-glass"></i>
                            <input type="text" id="supportSearchInput" placeholder="Search UID..." onkeyup="refreshSupportUserList()" style="padding: 7px 10px 7px 32px; font-size: 0.8rem;">
                        </div>
                        <button class="btn-topbar" onclick="toggleSupportSound()" style="padding: 6px 10px;" title="Notification Sound">
                            <i class="fa-solid fa-volume-high" id="suppSoundIcon"></i>
                        </button>
                    </div>

                    <div class="chat-user-list" id="supportUserListContainer">
                        <!-- Loaded dynamically -->
                    </div>
                </div>

                <!-- Chat Main Canvas -->
                <div class="chat-main-view">
                    
                    <!-- Empty State -->
                    <div id="supportEmptyState" style="flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; color: var(--text-muted); gap: 12px;">
                        <i class="fa-solid fa-headset" style="font-size: 40px; color: var(--border-subtle);"></i>
                        <p style="font-size: 0.88rem;">Select an active user UID from the list to start live support</p>
                    </div>

                    <!-- Active Chat Area -->
                    <div id="supportActiveChatWrapper" style="display: none; flex-direction: column; height: 100%;">
                        
                        <!-- Header -->
                        <div class="chat-main-header">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <button class="btn-action-sm" onclick="toggleSupportChatSidebar()" style="background: rgba(255,255,255,0.08); color:#fff;">
                                    <i class="fa-solid fa-bars-staggered"></i>
                                </button>
                                <div class="chat-avatar">
                                    <i class="fa-solid fa-user"></i>
                                    <div class="chat-status-dot"></div>
                                </div>
                                <div>
                                    <div style="font-size: 0.92rem; font-weight: 800; color: #fff;" id="activeSupportUid">UID: -</div>
                                    <small style="color: var(--accent-green); font-size: 0.68rem;">● Online User</small>
                                </div>
                            </div>

                            <div style="display: flex; gap: 8px;">
                                <button class="btn-action-sm" onclick="copyActiveSupportUid()" style="background: rgba(255,255,255,0.08); color:#fff;"><i class="fa-regular fa-copy"></i> Copy UID</button>
                                <button class="btn-action-sm" onclick="exportSupportChat()" style="background: rgba(255,255,255,0.08); color:#fff;"><i class="fa-solid fa-download"></i> Export</button>
                            </div>
                        </div>

                        <!-- Chat Message Viewport -->
                        <div class="chat-viewport" id="supportChatViewport"></div>

                        <!-- Canned Quick Replies -->
                        <div class="quick-replies-bar">
                            <span style="font-size: 0.7rem; color: var(--text-muted); align-self: center;">Quick Reply:</span>
                            <div class="quick-chip" onclick="insertSupportQuickReply('Hello! How can I assist you with your UID account today?')">👋 Greeting</div>
                            <div class="quick-chip" onclick="insertSupportQuickReply('Please share your Deposit UTR No. and Screenshot for verification.')">💳 UTR Request</div>
                            <div class="quick-chip" onclick="insertSupportQuickReply('Your withdrawal request is currently under review by our banking team.')">⏳ Withdrawal Info</div>
                            <div class="quick-chip" onclick="insertSupportQuickReply('Your issue has been resolved. Please check your game balance.')">✅ Issue Resolved</div>
                        </div>

                        <!-- Input Composer -->
                        <div class="chat-composer">
                            <input type="text" id="supportAdminInput" class="composer-input" placeholder="Type your reply to user... (Press Enter to send)" onkeypress="if(event.key==='Enter') sendSupportAdminMessage()">
                            <button class="btn-topbar primary" onclick="sendSupportAdminMessage()" style="padding: 10px 18px;">
                                <span>Send</span> <i class="fa-solid fa-paper-plane"></i>
                            </button>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- ================= 5. UPI & GATEWAY CONFIG TAB ================= -->
        <div id="tab-gateway" class="tab-pane" style="display: none;">
            <div class="dashboard-section">
                <div class="gateway-layout">
                    <div>
                        <div class="form-grid-2">
                            <div class="input-group">
                                <label>Merchant Payee Name</label>
                                <input type="text" id="cfg-upi-name" class="input-control" value="Jatin Baishya" oninput="updateQrLivePreview()">
                            </div>
                            <div class="input-group">
                                <label>Merchant UPI ID (VPA)</label>
                                <input type="text" id="cfg-upi-id" class="input-control" value="jatinbaishya260@okhdfcbank" oninput="updateQrLivePreview()">
                            </div>
                            <div class="input-group full">
                                <label>Demo Amount for QR (₹)</label>
                                <input type="number" id="cfg-demo-amount" class="input-control" value="100.00" oninput="updateQrLivePreview()">
                            </div>
                        </div>

                        <button class="btn-topbar primary" style="margin-top: 20px; padding: 10px 24px;" onclick="saveGatewayConfig()">
                            <i class="fa-solid fa-floppy-disk"></i> Save & Deploy UPI Gateway
                        </button>
                    </div>

                    <div class="qr-live-preview-card">
                        <span style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); margin-bottom: 10px; text-transform: uppercase;">Live QR Output</span>
                        <div class="qr-frame">
                            <img id="admin-live-qr" src="" alt="Live QR">
                        </div>
                        <span id="preview-payee-name" style="font-weight: 700; font-size: 0.9rem;">Jatin Baishya</span>
                        <span id="preview-payee-vpa" style="font-size: 0.78rem; color: var(--text-muted); font-family: 'JetBrains Mono', monospace;">jatinbaishya260@okhdfcbank</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- ================= 6. USER WALLETS TAB ================= -->
        <div id="tab-wallets" class="tab-pane" style="display: none;">
            <div class="dashboard-section">
                <div class="wallet-manager-box">
                    <div style="background: var(--bg-surface-elevated); padding: 20px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
                        <label style="font-size: 0.82rem; font-weight: 700; color: var(--text-secondary);">Direct Wallet Balance Adjustment (₹)</label>
                        <input type="number" id="wallet-direct-input" class="input-control" style="font-size: 1.3rem; font-weight: 800; margin: 10px 0; width: 100%;" value="0.00">
                        
                        <div class="quick-amount-chips">
                            <button class="chip-add" onclick="quickAddBalance(100)">+ ₹100</button>
                            <button class="chip-add" onclick="quickAddBalance(500)">+ ₹500</button>
                            <button class="chip-add" onclick="quickAddBalance(1000)">+ ₹1,000</button>
                            <button class="chip-add" style="border-color: var(--accent-red); color: var(--accent-red);" onclick="resetUserWallet()">Reset to 0</button>
                        </div>

                        <button class="btn-topbar primary" style="margin-top: 18px; width: 100%; justify-content: center; padding: 11px;" onclick="saveDirectBalance()">
                            <i class="fa-solid fa-check-double"></i> Update Wallet Balance
                        </button>
                    </div>

                    <div style="display: flex; flex-direction: column; justify-content: center; background: var(--bg-surface-elevated); padding: 20px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
                        <h3 style="font-size: 0.95rem; margin-bottom: 6px;"><i class="fa-solid fa-shield-halved" style="color: var(--accent-green);"></i> Real-Time Sync Engine:</h3>
                        <p style="color: var(--text-secondary); font-size: 0.82rem; line-height: 1.5;">
                            Is Master Admin Panel me kiya gaya koi bhi change (Deposit Approve, Withdrawal Refund, Gift Code Claim) turant user ke <code style="color: #c7d2fe;">customer support.html</code>, <code style="color: #c7d2fe;">deposit.html</code> aur <code style="color: #c7d2fe;">withdraw.html</code> me sync ho jayega.
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </main>

    <!-- CREATE GIFT CODE MODAL -->
    <div class="modal-backdrop" id="gift-modal">
        <div class="modal-card">
            <div class="modal-header">
                <h3 style="font-size: 1.15rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-gift" style="color: var(--accent-gold);"></i> Create New Conditional Gift Code
                </h3>
                <i class="fa-solid fa-xmark" style="cursor: pointer; font-size: 1.2rem; color: var(--text-muted);" onclick="closeCreateGiftModal()"></i>
            </div>

            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="input-group">
                        <label>Gift Code String</label>
                        <div style="display: flex; gap: 6px;">
                            <input type="text" id="modal-code-str" class="input-control" style="text-transform: uppercase; font-family: 'JetBrains Mono', monospace;" placeholder="e.g. BONUS500">
                            <button class="btn-topbar" type="button" title="Random Code" onclick="generateRandomCode()"><i class="fa-solid fa-dice"></i></button>
                        </div>
                    </div>
                    <div class="input-group">
                        <label>Bonus Reward Amount (₹)</label>
                        <input type="number" id="modal-reward-amount" class="input-control" value="100">
                    </div>
                </div>

                <div class="form-grid-2">
                    <div class="input-group">
                        <label>Total Max Claims / People</label>
                        <input type="number" id="modal-max-claims" class="input-control" value="50">
                    </div>
                    <div class="input-group">
                        <label>Valid Until Date</label>
                        <input type="date" id="modal-expiry-date" class="input-control">
                    </div>
                </div>

                <div class="input-group">
                    <label style="color: var(--accent-gold);"><i class="fa-solid fa-sliders"></i> Eligibility Conditions & Restrictions</label>
                    <div class="conditions-box">
                        <div class="cond-toggle-row">
                            <div class="cond-toggle-left"><i class="fa-solid fa-wallet"></i><span>Min Total Deposit Required (₹)</span></div>
                            <input type="number" id="cond-min-deposit" class="cond-input-sm" value="0">
                        </div>
                        <div class="cond-toggle-row">
                            <div class="cond-toggle-left"><i class="fa-solid fa-gamepad"></i><span>Min Betting Turnover (₹)</span></div>
                            <input type="number" id="cond-min-turnover" class="cond-input-sm" value="0">
                        </div>
                        <div class="cond-toggle-row">
                            <div class="cond-toggle-left"><i class="fa-solid fa-crown"></i><span>Required VIP Level</span></div>
                            <select id="cond-vip-level" class="cond-input-sm">
                                <option value="0">All Players (VIP 0+)</option>
                                <option value="1">VIP 1 & Above</option>
                                <option value="2">VIP 2 & Above</option>
                                <option value="5">VIP 5+ High Rollers</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button class="btn-topbar" onclick="closeCreateGiftModal()">Cancel</button>
                <button class="btn-topbar primary" onclick="saveNewGiftCode()"><i class="fa-solid fa-check"></i> Deploy Gift Code</button>
            </div>
        </div>
    </div>

    <div id="toast-container"></div>

    <!-- JavaScript Data Logic - Backend Connected -->
    <script>
        const ADMIN_KEY = "shreewin_admin_2024";
        const API = { headers: { "Content-Type": "application/json", "X-Admin-Key": ADMIN_KEY } };
        let currentTab = 'deposits';
        let depFilter = 'all', withFilter = 'all';
        let depSearchQuery = '', withSearchQuery = '';
        let dashboardData = { deposits: [], withdrawals: [], support: [], balances: {} };
        let selectedSupportUid = null;

        function showToast(title, type = 'success') {
            const container = document.getElementById('toast-container');
            const toast = document.createElement('div');
            toast.className = `toast-msg ${type}`;
            let icon = type === 'success' ? 'fa-circle-check' : (type === 'danger' ? 'fa-triangle-exclamation' : 'fa-bell');
            toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${title}</span>`;
            container.appendChild(toast);
            setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 3000);
        }
        function copyText(txt) { navigator.clipboard.writeText(txt).then(() => showToast(`Copied: ${txt}`, 'warning')); }
        function toggleSidebar() {
            document.getElementById('main-sidebar').classList.toggle('mobile-open');
            document.getElementById('sidebar-overlay').classList.toggle('active');
        }

        async function clearPendingDeposits(){
            if(!confirm('Delete ALL pending deposits? This cannot be undone.')) return;
            try{
                const res = await fetch('/api/admin/deposit/clear_pending?key=' + ADMIN_KEY, {method:'POST', headers: API.headers});
                const data = await res.json();
                if(data.ok){ showToast(data.msg || 'Cleared', 'success'); loadDashboard(); }
                else showToast(data.msg || 'Failed', 'danger');
            }catch(e){ showToast('Network error', 'danger'); }
        }
        async function loadDashboard() {
            try {
                const res = await fetch('/api/admin/dashboard?key=' + ADMIN_KEY, { headers: API.headers });
                const data = await res.json();
                if (!data.ok) { showToast(data.msg || 'Failed to load', 'danger'); return; }
                dashboardData = data;
                renderMasterDashboard();
            } catch (e) { console.error(e); showToast('Server connection failed', 'danger'); }
        }

        function renderMasterDashboard() {
            const deposits = dashboardData.deposits || [];
            const withdrawals = dashboardData.withdrawals || [];
            const supportList = dashboardData.support || [];
            const balances = dashboardData.balances || {};

            let totalDepositsSum = 0, depPending = 0, depApproved = 0, depRejected = 0;
            deposits.forEach(d => {
                const amt = parseFloat(d.amount) || 0;
                if (d.status === 'pending') depPending++;
                if (d.status === 'approved') { depApproved++; totalDepositsSum += amt; }
                if (d.status === 'rejected') depRejected++;
            });
            let totalPayoutsSum = 0, withPending = 0, withApproved = 0, withRejected = 0;
            withdrawals.forEach(w => {
                const amt = parseFloat(w.amount) || 0;
                if (w.status === 'pending') withPending++;
                if (w.status === 'approved') { withApproved++; totalPayoutsSum += amt; }
                if (w.status === 'rejected') withRejected++;
            });
            const totalBal = Object.values(balances).reduce((a, b) => a + parseFloat(b || 0), 0);

            document.getElementById('kpi-total-deposits').innerText = `₹${totalDepositsSum.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
            document.getElementById('kpi-total-payouts').innerText = `₹${totalPayoutsSum.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
            document.getElementById('kpi-pending-total').innerText = depPending + withPending;
            document.getElementById('kpi-pending-breakdown').innerText = `${depPending} Dep / ${withPending} With`;
            document.getElementById('kpi-user-wallet').innerText = `₹${totalBal.toLocaleString('en-IN', {minimumFractionDigits: 2})}`;
            document.getElementById('sidebar-dep-badge').innerText = depPending;
            document.getElementById('sidebar-with-badge').innerText = withPending;
            document.getElementById('sidebar-support-badge').innerText = [...new Set(supportList.map(m => m.uid))].length;
            document.getElementById('f-dep-all').innerText = deposits.length;
            document.getElementById('f-dep-pending').innerText = depPending;
            document.getElementById('f-dep-approved').innerText = depApproved;
            document.getElementById('f-dep-rejected').innerText = depRejected;
            document.getElementById('f-with-all').innerText = withdrawals.length;
            document.getElementById('f-with-pending').innerText = withPending;
            document.getElementById('f-with-approved').innerText = withApproved;
            document.getElementById('f-with-rejected').innerText = withRejected;

            renderDepositTable(deposits);
            renderWithdrawalTable(withdrawals);
            renderSupportList(supportList);
            renderGiftTable();
        }

        function renderDepositTable(deposits) {
            const tbody = document.getElementById('deposit-tbody');
            tbody.innerHTML = '';
            const filtered = deposits.filter(item => {
                const matchesFilter = depFilter === 'all' || item.status === depFilter;
                const searchStr = `${item.orderId} ${item.utr} ${item.uid || ''} ${item.amount}`.toLowerCase();
                return matchesFilter && searchStr.includes(depSearchQuery.toLowerCase());
            });
            document.getElementById('empty-dep-view').style.display = filtered.length === 0 ? 'block' : 'none';
            filtered.forEach(order => {
                const tr = document.createElement('tr');
                let statusHtml = order.status === 'pending' ? '<span class="status-badge pending">Pending</span>' :
                    (order.status === 'approved' ? '<span class="status-badge approved">Approved</span>' : '<span class="status-badge rejected">Rejected</span>');
                const st = String(order.status || '').toLowerCase();
                let actionHtml = (st === 'pending' || st === 'processing') ? `
                    <div class="actions-group">
                        <button class="btn-action-sm approve" onclick="approveDeposit(${order.raw_index}, '${String(order.utr||'').replace(/'/g,"\\'")}', '${order.id}')"><i class="fa-solid fa-check"></i> Approve</button>
                        <button class="btn-action-sm reject" onclick="rejectDeposit(${order.raw_index}, '${String(order.utr||'').replace(/'/g,"\\'")}', '${order.id}')"><i class="fa-solid fa-xmark"></i></button>
                    </div>` : `<span style="color: var(--text-muted); font-size: 0.78rem;">Settled</span>`;
                if (st === 'approved') {
                    statusHtml = '<span class="status-badge approved">Approved</span>';
                } else if (st === 'rejected') {
                    statusHtml = '<span class="status-badge rejected">Rejected</span>';
                } else if (st === 'pending' || st === 'processing') {
                    statusHtml = '<span class="status-badge pending">Pending</span>';
                }
                tr.innerHTML = `
                    <td style="font-family: 'JetBrains Mono'; font-weight: 700; color: #a5b4fc;">#${order.orderId}</td>
                    <td>${order.uid || '-'}</td>
                    <td><span class="amount-text">₹${parseFloat(order.amount).toFixed(2)}</span></td>
                    <td><span style="background: rgba(255,255,255,0.06); padding: 3px 8px; border-radius: 4px; font-size: 0.75rem;">${order.method || 'UPI-QR'}</span></td>
                    <td><div class="data-chip"><span>${order.utr}</span><i class="fa-regular fa-copy" onclick="copyText('${order.utr}')"></i></div></td>
                    <td style="color: var(--text-secondary); font-size: 0.78rem;">${order.timestamp}</td>
                    <td>${statusHtml}</td>
                    <td style="text-align: right;">${actionHtml}</td>`;
                tbody.appendChild(tr);
            });
        }

        function renderWithdrawalTable(withdrawals) {
            const tbody = document.getElementById('withdraw-tbody');
            tbody.innerHTML = '';
            const filtered = withdrawals.filter(item => {
                const matchesFilter = withFilter === 'all' || item.status === withFilter;
                const searchStr = `${item.id} ${item.vpa || ''} ${item.name || ''} ${item.uid || ''} ${item.amount}`.toLowerCase();
                return matchesFilter && searchStr.includes(withSearchQuery.toLowerCase());
            });
            document.getElementById('empty-with-view').style.display = filtered.length === 0 ? 'block' : 'none';
            filtered.forEach(order => {
                const tr = document.createElement('tr');
                let statusHtml = order.status === 'pending' ? '<span class="status-badge pending">Pending</span>' :
                    (order.status === 'approved' ? '<span class="status-badge approved">Paid Out</span>' : '<span class="status-badge rejected">Refunded</span>');
                let actionHtml = order.status === 'pending' ? `
                    <div class="actions-group">
                        <button class="btn-action-sm approve" onclick="approveWithdrawal(${order.raw_index}, '${order.id}')"><i class="fa-solid fa-check"></i> Paid</button>
                        <button class="btn-action-sm reject" onclick="rejectWithdrawal(${order.raw_index}, '${order.id}')"><i class="fa-solid fa-xmark"></i> Refund</button>
                    </div>` : `<span style="color: var(--text-muted); font-size: 0.78rem;">Completed</span>`;
                tr.innerHTML = `
                    <td style="font-family: 'JetBrains Mono'; font-weight: 700; color: #a5b4fc;">#${order.id}</td>
                    <td><span class="amount-payout">₹${parseFloat(order.amount).toFixed(2)}</span></td>
                    <td><span style="background: rgba(255,255,255,0.06); padding: 3px 8px; border-radius: 4px; font-size: 0.75rem;">${order.method || 'Bank'}</span></td>
                    <td>
                        <div style="display:flex; flex-direction:column; gap:2px;">
                            <span style="font-weight:700; color:white; font-size:0.85rem;">${order.name || 'Recipient'} (UID: ${order.uid})</span>
                            <div class="data-chip"><span>${order.account || order.vpa}</span><i class="fa-regular fa-copy" onclick="copyText('${order.account || order.vpa}')"></i></div>
                            <small style="color:var(--text-muted)">${order.bank || ''} ${order.ifsc || ''}</small>
                        </div>
                    </td>
                    <td style="color: var(--text-secondary); font-size: 0.78rem;">${order.timestamp}</td>
                    <td>${statusHtml}</td>
                    <td style="text-align: right;">${actionHtml}</td>`;
                tbody.appendChild(tr);
            });
        }

        async function approveDeposit(rawIndex, utr, id) {
            if (!confirm(`Approve deposit UTR: ${utr}?`)) return;
            try {
                const res = await fetch('/api/admin/deposit/approve', { method: 'POST', headers: API.headers, body: JSON.stringify({ raw_index: rawIndex, utr: utr, id: id }) });
                const data = await res.json();
                if (data.ok) { showToast(data.msg || 'Deposit marked as Approved', 'success'); await loadDashboard(); } else showToast(data.msg || 'Failed', 'danger');
            } catch(e) { showToast('Network error', 'danger'); }
        }
        async function rejectDeposit(rawIndex, utr, id) {
            if (!confirm(`Reject deposit UTR: ${utr}?`)) return;
            try {
                const res = await fetch('/api/admin/deposit/reject', { method: 'POST', headers: API.headers, body: JSON.stringify({ raw_index: rawIndex, utr: utr, id: id }) });
                const data = await res.json();
                if (data.ok) { showToast(data.msg || 'Deposit rejected', 'danger'); await loadDashboard(); } else showToast(data.msg || 'Failed', 'danger');
            } catch(e) { showToast('Network error', 'danger'); }
        }
        async function approveWithdrawal(rawIndex, id) {
            if (!confirm(`Mark payout ${id} as Paid?`)) return;
            try {
                const res = await fetch('/api/admin/withdraw/approve', { method: 'POST', headers: API.headers, body: JSON.stringify({ raw_index: rawIndex, id: id }) });
                const data = await res.json();
                if (data.ok) { showToast(data.msg, 'success'); loadDashboard(); } else showToast(data.msg || 'Failed', 'danger');
            } catch(e) { showToast('Network error', 'danger'); }
        }
        async function rejectWithdrawal(rawIndex, id) {
            if (!confirm(`Reject this withdrawal?`)) return;
            try {
                const res = await fetch('/api/admin/withdraw/reject', { method: 'POST', headers: API.headers, body: JSON.stringify({ raw_index: rawIndex, id: id }) });
                const data = await res.json();
                if (data.ok) { showToast(data.msg, 'danger'); loadDashboard(); } else showToast(data.msg || 'Failed', 'danger');
            } catch(e) { showToast('Network error', 'danger'); }
        }

        function renderSupportList(supportList) {
            const container = document.getElementById('supportUserListContainer');
            if (!container) return;
            const uniqueUids = [...new Set(supportList.map(m => m.uid))];
            container.innerHTML = '';
            if (uniqueUids.length === 0) {
                container.innerHTML = `<div style="padding:20px; text-align:center; color:var(--text-muted); font-size:0.8rem;">No active user queries</div>`;
                return;
            }
            uniqueUids.forEach(uid => {
                const userMsgs = supportList.filter(m => m.uid === uid);
                const lastMsg = userMsgs[0];
                const item = document.createElement('div');
                item.className = `chat-user-item ${selectedSupportUid === uid ? 'active' : ''}`;
                item.onclick = () => selectSupportUser(uid);
                item.innerHTML = `
                    <div class="chat-avatar"><i class="fa-solid fa-user"></i><div class="chat-status-dot"></div></div>
                    <div style="flex:1; min-width:0;">
                        <div style="display:flex; justify-content:space-between;">
                            <span style="font-size:0.85rem; font-weight:700; color:#fff;">UID: ${uid}</span>
                            <span style="font-size:0.7rem; color:var(--text-muted);">${lastMsg ? lastMsg.time : ''}</span>
                        </div>
                        <div style="font-size:0.75rem; color:var(--text-muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${lastMsg ? lastMsg.message : 'Connected'}</div>
                    </div>`;
                container.appendChild(item);
            });
        }
        function selectSupportUser(uid) {
            selectedSupportUid = uid;
            document.getElementById('supportEmptyState').style.display = 'none';
            document.getElementById('supportActiveChatWrapper').style.display = 'flex';
            document.getElementById('activeSupportUid').innerText = `UID: ${uid}`;
            renderActiveSupportChat();
        }
        function renderActiveSupportChat() {
            if (!selectedSupportUid) return;
            const chats = (dashboardData.support || []).filter(m => m.uid === selectedSupportUid);
            const viewport = document.getElementById('supportChatViewport');
            viewport.innerHTML = '';
            chats.slice().reverse().forEach(m => {
                const row = document.createElement('div');
                row.className = 'chat-bubble-row row-user';
                row.innerHTML = `<div class="chat-avatar" style="width:30px;height:30px;"><i class="fa-solid fa-user" style="font-size:12px;"></i></div>
                    <div class="bubble-content bubble-user">${m.message}<div class="bubble-meta"><span>UID: ${m.uid}</span><span>${m.time}</span></div></div>`;
                viewport.appendChild(row);
                if (m.reply) {
                    const replyRow = document.createElement('div');
                    replyRow.className = 'chat-bubble-row row-admin';
                    replyRow.innerHTML = `<div class="chat-avatar" style="background:#6366f1;color:#fff;width:30px;height:30px;"><i class="fa-solid fa-headset" style="font-size:12px;"></i></div>
                        <div class="bubble-content bubble-admin">${m.reply}<div class="bubble-meta"><span>Support Agent</span><span>Replied</span></div></div>`;
                    viewport.appendChild(replyRow);
                }
            });
            viewport.scrollTop = viewport.scrollHeight;
        }
        async function sendSupportAdminMessage() {
            const input = document.getElementById('supportAdminInput');
            const text = input.value.trim();
            if (!text || !selectedSupportUid) return;
            const msgs = (dashboardData.support || []).filter(m => m.uid === selectedSupportUid && !m.reply);
            if (msgs.length === 0) { showToast('No open message to reply', 'warning'); return; }
            try {
                const res = await fetch('/api/admin/support/reply', { method: 'POST', headers: API.headers, body: JSON.stringify({ id: msgs[0].id, reply: text }) });
                const data = await res.json();
                if (data.ok) { input.value = ''; showToast('Reply sent', 'success'); loadDashboard(); }
                else showToast(data.msg || 'Failed', 'danger');
            } catch(e) { showToast('Network error', 'danger'); }
        }
        function insertSupportQuickReply(text) { document.getElementById('supportAdminInput').value = text; document.getElementById('supportAdminInput').focus(); }
        function copyActiveSupportUid() { if (selectedSupportUid) copyText(selectedSupportUid); }
        function exportSupportChat() {}
        function toggleSupportChatSidebar() { document.getElementById('supportChatSidebar').classList.toggle('collapsed'); }
        function toggleSupportSound() {}

        function switchTab(tabId, el) {
            currentTab = tabId;
            document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
            if (el) el.classList.add('active');
            ['deposits','withdrawals','gifts','support','gateway','wallets'].forEach(t => {
                const el = document.getElementById('tab-' + t);
                if (el) el.style.display = (t === tabId) ? 'block' : 'none';
            });
            const heading = document.getElementById('page-heading');
            const sub = document.getElementById('page-subheading');
            const actionBtn = document.getElementById('topbar-action-btn');
            if (tabId === 'deposits') { heading.innerText = 'Deposit Management'; sub.innerText = 'Live UTR Verification (Backend)'; if (actionBtn) actionBtn.style.display = 'none'; }
            else if (tabId === 'withdrawals') { heading.innerText = 'Withdrawal Payouts'; sub.innerText = 'Live Payout Settlements (Backend)'; if (actionBtn) actionBtn.style.display = 'none'; }
            else if (tabId === 'gifts') { heading.innerText = 'Gift Code Engine'; sub.innerText = 'Create & manage redeem codes'; if (actionBtn) actionBtn.style.display = 'flex'; renderGiftTable(); }
            else if (tabId === 'support') { heading.innerText = 'Live Support CRM'; sub.innerText = 'Customer Queries (Backend)'; if (actionBtn) actionBtn.style.display = 'none'; renderSupportList(dashboardData.support || []); }
            else if (tabId === 'gateway') { heading.innerText = 'UPI & Gateway Settings'; sub.innerText = 'Merchant UPI & QR'; if (actionBtn) actionBtn.style.display = 'none'; updateQrLivePreview(); }
            else if (tabId === 'wallets') { heading.innerText = 'User Balances'; sub.innerText = 'Direct Balance Adjustment'; if (actionBtn) actionBtn.style.display = 'none'; }
            if (window.innerWidth <= 900) { document.getElementById('main-sidebar').classList.remove('mobile-open'); document.getElementById('sidebar-overlay').classList.remove('active'); }
        }
        function handleSearch(type, val) { if (type === 'dep') depSearchQuery = val; if (type === 'with') withSearchQuery = val; renderMasterDashboard(); }
        function setFilter(type, f, btn) { if (type === 'dep') depFilter = f; if (type === 'with') withFilter = f; btn.parentElement.querySelectorAll('.filter-pill').forEach(b => b.classList.remove('active')); btn.classList.add('active'); renderMasterDashboard(); }

        function updateQrLivePreview() {
            const nameEl = document.getElementById('cfg-upi-name'); if (!nameEl) return;
            const name = nameEl.value || 'Jatin Baishya';
            const vpa = document.getElementById('cfg-upi-id').value || 'jatinbaishya260@okhdfcbank';
            const amt = parseFloat(document.getElementById('cfg-demo-amount').value) || 100.00;
            document.getElementById('preview-payee-name').innerText = name;
            document.getElementById('preview-payee-vpa').innerText = vpa;
            document.getElementById('admin-live-qr').src = `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent('upi://pay?pa='+encodeURIComponent(vpa)+'&pn='+encodeURIComponent(name)+'&am='+amt.toFixed(2)+'&cu=INR')}`;
        }
        function saveGatewayConfig() {
            localStorage.setItem('admin_upi_name', document.getElementById('cfg-upi-name').value.trim());
            localStorage.setItem('admin_upi_id', document.getElementById('cfg-upi-id').value.trim());
            showToast('UPI Gateway updated', 'success');
        }
        function quickAddBalance(addAmt) { let c = parseFloat(document.getElementById('wallet-direct-input').value) || 0; document.getElementById('wallet-direct-input').value = (c + addAmt).toFixed(2); }
        function resetUserWallet() { document.getElementById('wallet-direct-input').value = "0.00"; }
        async function saveDirectBalance() {
            const uid = prompt("Enter User UID:"); if (!uid) return;
            const val = parseFloat(document.getElementById('wallet-direct-input').value) || 0;
            try {
                const res = await fetch('/api/admin/balance', { method: 'POST', headers: API.headers, body: JSON.stringify({ uid: uid.trim(), amount: val }) });
                const data = await res.json();
                if (data.ok) { showToast(data.msg, 'success'); loadDashboard(); } else showToast(data.msg || 'Failed', 'danger');
            } catch(e) { showToast('Network error', 'danger'); }
        }
        function openCreateGiftModal() { document.getElementById('gift-modal').style.display = 'flex'; }
        function closeCreateGiftModal() { document.getElementById('gift-modal').style.display = 'none'; }
        function generateRandomCode() { document.getElementById('modal-code-str').value = 'SHREE-' + Math.random().toString(36).substring(2,6).toUpperCase() + '-' + Math.random().toString(36).substring(2,6).toUpperCase(); }
        async function saveNewGiftCode() {
            const code = (document.getElementById('modal-code-str')?.value || '').trim().toUpperCase();
            const amount = parseFloat(document.getElementById('modal-reward-amount')?.value || 0);
            const maxUses = parseInt(document.getElementById('modal-max-claims')?.value || 1, 10);
            const minDeposit = parseFloat(document.getElementById('cond-min-deposit')?.value || 0);
            const minTurnover = parseFloat(document.getElementById('cond-min-turnover')?.value || 0);
            if (!code) { showToast('Enter gift code', 'warning'); return; }
            if (!amount || amount <= 0) { showToast('Enter valid amount', 'warning'); return; }
            try {
                const res = await fetch('/api/admin/gift/create', {
                    method: 'POST',
                    headers: API.headers,
                    body: JSON.stringify({ code, amount, max_uses: maxUses, min_deposit: minDeposit, min_turnover: minTurnover })
                });
                const data = await res.json();
                if (!data.ok) { showToast(data.msg || 'Failed', 'danger'); return; }
                showToast(data.msg || 'Gift code created', 'success');
                closeCreateGiftModal();
                await loadDashboard();
                renderGiftTable();
            } catch (e) {
                console.error(e);
                showToast('Server error', 'danger');
            }
        }
        async function deleteGiftCode(code, id) {
            if (!confirm('Delete gift code ' + (code || '') + '?')) return;
            try {
                const res = await fetch('/api/admin/gift/delete', {
                    method: 'POST',
                    headers: API.headers,
                    body: JSON.stringify({ code, id })
                });
                const data = await res.json();
                if (!data.ok) { showToast(data.msg || 'Failed', 'danger'); return; }
                showToast('Deleted', 'success');
                await loadDashboard();
                renderGiftTable();
            } catch (e) {
                showToast('Server error', 'danger');
            }
        }
        function renderGiftTable() {
            const tbody = document.getElementById('gift-tbody');
            const empty = document.getElementById('empty-gift-view');
            if (!tbody) return;
            const gifts = dashboardData.gifts || [];
            if (!gifts.length) {
                tbody.innerHTML = '';
                if (empty) empty.style.display = 'flex';
                return;
            }
            if (empty) empty.style.display = 'none';
            tbody.innerHTML = gifts.map(g => {
                const used = g.used_count || 0;
                const maxu = g.max_uses || 1;
                const active = g.active !== false;
                const status = active ? (used >= maxu ? 'Exhausted' : 'Active') : 'Off';
                const statusColor = status === 'Active' ? '#22c55e' : (status === 'Exhausted' ? '#f59e0b' : '#94a3b8');
                return `<tr>
                    <td style="font-family:monospace;font-weight:700;">${g.code}</td>
                    <td>₹${Number(g.amount).toFixed(0)}</td>
                    <td style="color:var(--text-muted);font-size:0.8rem;">${(g.min_deposit>0)?('Min dep ₹'+Number(g.min_deposit).toFixed(0)):'No min deposit'}</td>
                    <td>${used} / ${maxu}</td>
                    <td>${g.created_at || '—'}</td>
                    <td><span style="color:${statusColor};font-weight:700;">${status}</span></td>
                    <td style="text-align:right;">
                        <button class="btn-topbar" style="padding:4px 10px;font-size:0.75rem;" onclick="deleteGiftCode('${g.code}', ${g.id})"><i class="fa-solid fa-trash"></i></button>
                    </td>
                </tr>`;
            }).join('');
        }
        function exportActiveCSV() {
            let csv = "data:text/csv;charset=utf-8,Type,ID,Amount,Status,Timestamp\\n";
            if (currentTab === 'deposits') (dashboardData.deposits || []).forEach(r => csv += `Deposit,${r.orderId},${r.amount},${r.status},"${r.timestamp}"\\n`);
            else (dashboardData.withdrawals || []).forEach(r => csv += `Withdraw,${r.id},${r.amount},${r.status},"${r.timestamp}"\\n`);
            const a = document.createElement('a'); a.href = encodeURI(csv); a.download = `Report_${currentTab}.csv`; a.click();
        }

        loadDashboard();
        setInterval(loadDashboard, 8000);
        updateQrLivePreview();
        switchTab('deposits');
    </script>
</body>
</html>"""
