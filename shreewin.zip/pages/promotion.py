promotion_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shree.Win - Full Agency App</title>
    <!-- FontAwesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts for stylish text -->
    <link href="https://fonts.googleapis.com/css2?family=Delius&family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    
    <style>

/* === OFFICIAL COLOUR MATCH === */
:root{
  --sw-bg:#0d0a1f;
  --sw-bg-deep:#0a0816;
  --sw-surface:#141332;
  --sw-card:#1a1435;
  --sw-card-2:#1e1b4b;
  --sw-border:#26244f;
  --sw-accent:#6965e8;
  --sw-purple:#7c3aed;
  --sw-purple-2:#8b5cf6;
  --sw-text:#ffffff;
  --sw-muted:#9e8fc7;
  --sw-muted-2:#5d5c88;
  --sw-gold:#ffd700;
  --sw-orange:#ff8f00;
  --sw-notice:#1e163a;
}
html,body{
  background:var(--sw-bg)!important;
  color:var(--sw-text)!important;
}
.app,.app-container,.page,.main-wrap{
  background:var(--sw-bg)!important;
}
.section,.section-header h3{color:var(--sw-text)!important}
.section-header .all{
  background:rgba(255,255,255,.08)!important;
  color:var(--sw-muted)!important;
}
.notice-bar,.notice-strip{
  background:linear-gradient(90deg,#1e163a,#2d1b69)!important;
  border-color:rgba(124,77,255,.3)!important;
  color:#d1c4e9!important;
}
.bottom-nav,.bottom-navbar{
  background:var(--sw-surface)!important;
  border-top:1px solid var(--sw-border)!important;
}
.bottom-nav .nav-item,.bottom-navbar .nav-item{
  color:var(--sw-muted-2)!important;
}
.bottom-nav .nav-item.active,.bottom-navbar .nav-item.active{
  color:var(--sw-accent)!important;
}
.bottom-nav .nav-item.active svg,.bottom-navbar .nav-item.active svg{
  fill:var(--sw-accent)!important;
}
.cat-icon.lobby,.cat-icon.minigame{background:linear-gradient(145deg,#5b3fd6,#3a2a9e)!important}
.cat-icon.lottery,.cat-icon.slots{background:linear-gradient(145deg,#6b4ce0,#4a2fc0)!important}
.cat-icon.popular{background:linear-gradient(145deg,#3d8bff,#1a5fd0)!important}
.float-btn{box-shadow:0 4px 12px rgba(0,0,0,.35)!important}
/* === END OFFICIAL COLOUR MATCH === */

        :root {
            --bg-dark: #1e1b4b;
            --bg-card: #2e2a5f;
            --bg-card-dark: #1c1840;
            --btn-purple: #8167ff;
            --text-light: #c7c5df;
            --text-white: #ffffff;
            --color-green: #00e676;
            --color-orange: #ff9800;
            --color-red: #ff4d4f;
            --poster-blue-top: #00d2ff;
            --poster-blue-bottom: #0083b0;
            --table-dark: #161a42;
            --table-row-1: #383276;
            --table-row-2: #433d8c;
            --sub-card-bg: #8d85f8;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Delius', 'Nunito', sans-serif;
        }

        body {
            background-color: #000;
            display: flex;
            justify-content: center;
            height: 100vh;
        }

        /* Mobile Frame Container */
        .app-container { padding-bottom: 80px;
            width: 100%;
            max-width: 400px;
            height: 100vh;
            background-color: var(--bg-dark);
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
            box-shadow: 0 0 20px rgba(255,255,255,0.1);
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            color: var(--text-white);
            font-size: 1.2rem;
            background-color: var(--bg-dark);
            z-index: 10;
        }
        .header .title { flex: 1; text-align: center; font-weight: bold; }
        .header i { cursor: pointer; }

        /* Scrollable Area */
        .scrollable-content {
            flex: 1;
            overflow-y: auto;
            padding: 10px 15px 20px 15px;
            scrollbar-width: none;
        }
        .scrollable-content::-webkit-scrollbar { display: none; }

        /* --- AGENCY SCREEN CSS --- */
        .top-section { background: linear-gradient(180deg, #9b8dff 0%, var(--bg-dark) 100%); border-radius: 15px; padding: 20px; text-align: center; color: var(--text-white); margin-bottom: -20px; }
        .top-section h1 { font-size: 2.5rem; margin-bottom: 5px; }
        .commission-pill { background-color: rgba(0,0,0,0.3); display: inline-block; padding: 5px 15px; border-radius: 20px; font-size: 0.8rem; margin-bottom: 10px; }
        .upgrade-text { font-size: 0.8rem; color: #d1ccff; margin-bottom: 30px; }

        .stats-table { background-color: var(--bg-card); border-radius: 12px; overflow: hidden; margin-bottom: 15px; position: relative; z-index: 2; }
        .stats-header { display: flex; background-color: var(--bg-card-dark); padding: 12px 0; }
        .stats-header div { flex: 1; text-align: center; color: var(--text-white); font-size: 0.9rem; font-weight: bold; }
        .stats-body { display: flex; padding: 15px 0; }
        .stats-col { flex: 1; text-align: center; border-right: 1px solid rgba(255,255,255,0.05); }
        .stats-col:last-child { border-right: none; }
        .stat-item { margin-bottom: 15px; }
        .stat-val { font-size: 1.1rem; font-weight: bold; margin-bottom: 2px; }
        .stat-label { font-size: 0.75rem; color: var(--text-light); }
        .val-white { color: var(--text-white); }
        .val-green { color: var(--color-green); }
        .val-orange { color: var(--color-orange); }

        .invite-btn { width: 100%; background-color: var(--btn-purple); color: white; border: none; padding: 15px; border-radius: 30px; font-size: 1rem; font-weight: bold; letter-spacing: 1px; margin-bottom: 15px; cursor: pointer; }

        .menu-list { display: flex; flex-direction: column; gap: 10px; margin-bottom: 15px; }
        .menu-item { background-color: var(--bg-card); border-radius: 10px; padding: 15px; display: flex; align-items: center; color: var(--text-white); text-decoration: none; cursor: pointer; }
        .menu-icon { width: 35px; height: 35px; background-color: rgba(255,255,255,0.1); border-radius: 8px; display: flex; justify-content: center; align-items: center; margin-right: 15px; font-size: 1.1rem; }
        .menu-text { flex: 1; font-size: 0.95rem; }
        .menu-right { color: var(--text-light); display: flex; align-items: center; gap: 10px; }

        .promo-data { background-color: var(--bg-card); border-radius: 12px; padding: 15px; margin-bottom: 15px; }
        .promo-header { display: flex; align-items: center; color: var(--text-white); margin-bottom: 15px; font-size: 0.95rem; }
        .promo-header i { margin-right: 10px; }
        .promo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px 10px; text-align: center; }

        /* Hidden Screens */
        #invite-screen, #partner-screen, #subordinate-screen { display: none; }

        /* --- INVITE SCREEN CSS --- */
        .swipe-text { text-align: center; color: #a4a0c9; font-size: 0.9rem; margin-bottom: 15px; }
        .poster-carousel { display: flex; overflow-x: auto; scroll-snap-type: x mandatory; gap: 15px; padding-bottom: 10px; scrollbar-width: none; }
        .poster-card { flex: 0 0 85%; scroll-snap-align: center; background: linear-gradient(180deg, var(--poster-blue-top) 0%, var(--poster-blue-bottom) 100%); border-radius: 15px; padding: 20px 15px; text-align: center; }
        .poster-badges { display: flex; justify-content: center; gap: 10px; margin-bottom: 15px; }
        .badge { background-color: #ffda75; color: var(--color-red); font-size: 0.8rem; font-weight: bold; padding: 5px 10px; border-radius: 5px; transform: skewX(-10deg); }
        .badge span { display: block; transform: skewX(10deg); }
        .poster-title { color: white; font-size: 1.1rem; margin-bottom: 15px; font-weight: bold; }
        .poster-features { display: flex; justify-content: center; gap: 10px; margin-bottom: 20px; }
        .feature-box { border: 1px solid rgba(255, 255, 255, 0.4); border-radius: 5px; padding: 10px; color: white; flex: 1; }
        .commission-text { color: white; font-size: 1.1rem; margin-bottom: 15px; font-weight: bold; }
        .qr-box { background: white; padding: 10px; display: inline-block; border-radius: 5px; margin-bottom: 10px; }
        .qr-box img { width: 120px; height: 120px; }
        .income-text { text-align: center; color: white; font-size: 1.1rem; margin: 20px 0; }
        .highlight-red { color: var(--color-red); font-weight: bold; }
        .action-btns { display: flex; flex-direction: column; gap: 15px; padding: 0 10px; }
        .btn-download { background-color: #8167ff; color: white; border: none; padding: 15px; border-radius: 30px; font-size: 1rem; font-weight: bold; }
        .btn-copy { background-color: transparent; color: #a593ff; border: 1px solid #8167ff; padding: 15px; border-radius: 30px; font-size: 1rem; font-weight: bold; }
        .share-section { text-align: center; margin-top: 30px; }
        .social-icons { display: flex; justify-content: space-around; padding: 0 10px; }
        .social-item { display: flex; flex-direction: column; align-items: center; gap: 8px; color: #a4a0c9; font-size: 0.8rem; }
        .icon-circle { width: 50px; height: 50px; border-radius: 50%; display: flex; justify-content: center; align-items: center; color: white; font-size: 1.8rem; }
        .whatsapp { background-color: #25D366; } .telegram { background-color: #0088cc; } .facebook { background-color: #1877F2; } .twitter { background-color: #000; border: 1px solid #333; }

        /* --- PARTNER REWARDS CSS --- */
        .pr-banner {
            background: linear-gradient(90deg, #ffdf8e 0%, #ffb347 100%);
            border-radius: 10px;
            padding: 15px;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            margin-bottom: 15px;
            height: 120px;
            position: relative;
            overflow: hidden;
        }
        .pr-banner::before {
            content: '\\f091';
            font-family: "Font Awesome 6 Free";
            font-weight: 900;
            position: absolute;
            left: 20px;
            font-size: 5rem;
            color: rgba(255, 255, 255, 0.4);
        }
        .pr-banner-text { text-align: right; z-index: 1; }
        .pr-banner-text p { color: #5a3d00; font-weight: bold; font-size: 1rem; margin-bottom: 8px; line-height: 1.2; }
        .pr-banner-text .pill { background: #ff9100; color: white; padding: 5px 15px; border-radius: 20px; font-weight: bold; display: inline-block; font-family: 'Nunito', sans-serif;}

        .pr-stat { background-color: var(--bg-card); border-radius: 8px; padding: 15px; display: flex; justify-content: space-between; margin-bottom: 10px; color: var(--text-light); font-size: 0.95rem; }
        .pr-stat .val-green { color: var(--color-green); font-weight: bold; }
        .pr-stat .val-red { color: var(--color-red); font-weight: bold; }
        .pr-stat .val-white { color: white; font-weight: bold; }

        .pr-record-link { text-align: center; margin: 15px 0; color: var(--text-white); font-size: 0.9rem; }
        .pr-record-link span { color: var(--text-light); }

        .pr-link-title { color: white; font-weight: bold; font-size: 1.1rem; margin-bottom: 10px; border-left: 3px solid white; padding-left: 10px; }
        .pr-link-box { display: flex; background: var(--bg-card); border-radius: 30px; overflow: hidden; margin-bottom: 20px; }
        .pr-link-input { flex: 1; padding: 15px; color: white; font-family: 'Nunito', sans-serif; font-size: 0.9rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: flex; align-items: center; }
        .pr-link-btn { background: #a491ff; color: white; padding: 15px 25px; display: flex; justify-content: center; align-items: center; font-size: 1.2rem; cursor: pointer; border-left: 2px solid var(--bg-dark); transform: skewX(-20deg); margin-right: -10px; }
        .pr-link-btn i { transform: skewX(20deg); }

        .pr-rules-box { background-color: var(--bg-card); border-radius: 10px; padding: 15px; margin-bottom: 15px; }
        .pr-rules-title { color: white; font-size: 1.1rem; margin-bottom: 10px; display: flex; align-items: center; gap: 10px; }
        .pr-rules-sub { color: white; font-size: 0.9rem; margin-bottom: 15px; }
        
        .pr-table { width: 100%; border-collapse: collapse; font-family: 'Nunito', sans-serif; font-size: 0.75rem; text-align: center; border-radius: 8px; overflow: hidden; margin-bottom: 20px;}
        .pr-table th, .pr-table td { border: 1px solid rgba(255,255,255,0.1); padding: 8px 4px; }
        .pr-table th { background-color: var(--table-dark); color: white; font-weight: bold; padding: 12px 5px; font-family: 'Delius', sans-serif;}
        .pr-table .col-dep { width: 20%; background-color: var(--table-row-1); color: white; font-family: 'Delius', sans-serif;}
        .pr-table .col-cond { width: 55%; color: #c7c5df; }
        .pr-table .col-bonus { width: 25%; color: var(--color-red); font-weight: bold; font-size: 0.85rem;}
        
        .pr-table tr.r1 { background-color: var(--table-row-1); }
        .pr-table tr.r2 { background-color: var(--table-row-2); }

        .pr-footer-alert { color: var(--color-red); font-size: 0.85rem; font-weight: bold; margin-bottom: 15px; }
        .pr-footer-bullets { color: #a4a0c9; font-size: 0.8rem; line-height: 1.5; padding-left: 15px; }
        .pr-footer-bullets li { list-style-type: square; margin-bottom: 10px; }
        .pr-footer-bullets .hl { color: var(--color-red); }

        /* --- SUBORDINATE DATA SCREEN CSS --- */
        .sub-search-box {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 6px 6px 6px 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 12px;
        }
        .sub-search-input {
            background: transparent;
            border: none;
            outline: none;
            color: #b7b0ee;
            font-size: 1rem;
            width: 100%;
            font-family: 'Delius', sans-serif;
        }
        .sub-search-input::placeholder {
            color: #8c85c7;
        }
        .sub-search-btn {
            background-color: #8d85f8;
            border: none;
            color: #1e1b4b;
            padding: 10px 20px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .sub-filters-row {
            display: flex;
            gap: 12px;
            margin-bottom: 15px;
        }
        .sub-dropdown {
            background-color: var(--bg-card);
            border-radius: 10px;
            padding: 12px 16px;
            color: #ffffff;
            font-size: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            user-select: none;
        }
        .sub-dropdown.filter-type {
            flex: 0.9;
        }
        .sub-dropdown.filter-date {
            flex: 1.1;
        }
        .sub-dropdown i {
            font-size: 0.8rem;
            color: #a4a0c9;
        }

        .sub-stats-card {
            background-color: var(--sub-card-bg);
            border-radius: 14px;
            padding: 20px 10px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            row-gap: 22px;
            column-gap: 10px;
            text-align: center;
            position: relative;
            margin-bottom: 35px;
        }
        /* Divider line in middle */
        .sub-stats-card::before {
            content: '';
            position: absolute;
            top: 15px;
            bottom: 15px;
            left: 50%;
            width: 1px;
            background-color: rgba(255, 255, 255, 0.25);
        }
        .sub-stat-item h2 {
            font-size: 1.6rem;
            color: #ffffff;
            font-weight: bold;
            margin-bottom: 4px;
            line-height: 1;
        }
        .sub-stat-item p {
            color: #ffffff;
            font-size: 0.85rem;
            line-height: 1.2;
            padding: 0 4px;
        }

        .sub-no-data-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin-top: 15px;
        }
        .sub-no-data-icon {
            width: 170px;
            height: 120px;
            opacity: 0.85;
            margin-bottom: 10px;
        }
        .sub-no-data-text {
            color: #ffffff;
            font-size: 1.15rem;
            letter-spacing: 0.5px;
            font-weight: 500;
        }

        /* Floating Actions on Subordinate Screen */
        .sub-fab-left {
            position: absolute;
            bottom: 20px;
            left: 20px;
            width: 44px;
            height: 44px;
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            font-size: 1.1rem;
            cursor: pointer;
            backdrop-filter: blur(5px);
        }
        .sub-fab-right {
            position: absolute;
            bottom: 60px;
            right: 20px;
            width: 58px;
            height: 58px;
            border-radius: 50%;
            background: radial-gradient(circle, #00f5a0 0%, #00d9e9 100%);
            box-shadow: 0 0 15px rgba(0, 245, 160, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: 3px solid rgba(255, 255, 255, 0.4);
        }
        .sub-fab-right i {
            color: #1e1b4b;
            font-size: 1.6rem;
        }

    </style>
<style>.bottom-navbar{position:fixed;bottom:0;left:0;width:100%;height:65px;background:#141332;border-top:1px solid #26244f;display:flex;justify-content:space-around;align-items:center;z-index:1000;padding-bottom:5px;font-family:Poppins,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}
.nav-item{display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;color:#5d5c88;font-size:11px;font-weight:600;transition:all .2s ease;cursor:pointer;flex:1}
.nav-item svg{width:26px;height:26px;fill:#5d5c88;margin-bottom:2px;transition:all .2s ease}
.nav-item.active{color:#6965e8}
.nav-item.active svg{fill:#6965e8;filter:drop-shadow(0 0 8px rgba(105,101,232,.4))}
.wheel-item{position:relative;top:-16px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;flex:1.2;text-decoration:none}
.wheel-wrapper{width:72px;height:72px;position:relative;display:flex;justify-content:center;align-items:center;filter:drop-shadow(0 4px 10px rgba(0,0,0,.6))}
.wheel-wrapper svg{width:100%;height:100%}
.wheel-label{position:absolute;bottom:-6px;white-space:nowrap;font-size:13px;font-weight:900;color:#ffe600;text-shadow:-1.5px -1.5px 0 #b30000,1.5px -1.5px 0 #b30000,-1.5px 1.5px 0 #b30000,1.5px 1.5px 0 #b30000,0 2px 4px rgba(0,0,0,.8);letter-spacing:-.2px}
body{padding-bottom:85px !important;}.sw-toast{position:fixed;top:70px;left:50%;transform:translateX(-50%) translateY(-20px);background:linear-gradient(135deg,#7c3aed,#5b21b6);color:#fff;padding:14px 22px;border-radius:50px;font-size:14px;font-weight:600;z-index:99999;box-shadow:0 8px 25px rgba(124,58,237,.45);display:flex;align-items:center;gap:10px;opacity:0;pointer-events:none;transition:all .35s;white-space:nowrap;max-width:90vw}.sw-toast.show{opacity:1;transform:translateX(-50%) translateY(0)}.sw-toast .toast-icon{width:22px;height:22px;background:#22c55e;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px}</style></head>
<body>

<!-- 1. AGENCY SCREEN -->
<div class="app-container" id="agency-screen">
    <div class="header">
        <div style="width: 24px;"></div>
        <div class="title">Agency</div>
        <i class="fa-solid fa-file-invoice" style="color: #a099cc;"></i>
    </div>

    <div class="scrollable-content">
        <div class="top-section">
            <h1>0</h1>
            <div class="commission-pill">Yesterday's total commission</div>
            <div class="upgrade-text">Upgrade the level to increase commission income</div>
        </div>

        <div class="stats-table">
            <div class="stats-header"><div>Direct subordinates</div><div>Team subordinates</div></div>
            <div class="stats-body">
                <div class="stats-col">
                    <div class="stat-item"><div class="stat-val val-white">0</div><div class="stat-label">Number of register</div></div>
                    <div class="stat-item"><div class="stat-val val-green">0</div><div class="stat-label">Deposit number</div></div>
                    <div class="stat-item"><div class="stat-val val-orange">0</div><div class="stat-label">Deposit amount</div></div>
                    <div class="stat-item"><div class="stat-val val-white">0</div><div class="stat-label">Number of people making<br>first deposit</div></div>
                </div>
                <div class="stats-col">
                    <div class="stat-item"><div class="stat-val val-white">0</div><div class="stat-label">Number of register</div></div>
                    <div class="stat-item"><div class="stat-val val-green">0</div><div class="stat-label">Deposit number</div></div>
                    <div class="stat-item"><div class="stat-val val-orange">0</div><div class="stat-label">Deposit amount</div></div>
                    <div class="stat-item"><div class="stat-val val-white">0</div><div class="stat-label">Number of people making<br>first deposit</div></div>
                </div>
            </div>
        </div>

        <button class="invite-btn" id="open-invite-btn">INVITATION LINK</button>

        <div class="menu-list">
            <a class="menu-item" id="open-partner-btn">
                <div class="menu-icon"><i class="fa-solid fa-user-group"></i></div>
                <div class="menu-text">Partner rewards</div>
                <div class="menu-right"><i class="fa-solid fa-chevron-right"></i></div>
            </a>
            <a href="javascript:void(0)" class="menu-item" onclick="copyInviteCode()" style="align-items:center;">
                <div class="menu-icon"><i class="fa-solid fa-envelope"></i></div>
                <div class="menu-text">Copy invitation code<br><span id="user-invite-code" class="copy-code" style="display:inline-block;margin-top:6px;padding:6px 12px;background:#2d275e;border-radius:10px;color:#ffd700;font-size:16px;font-weight:800;letter-spacing:2px;font-family:monospace;border:1px solid #5b4fcf;">{{ invite_code }}</span></div>
                <div class="menu-right"><i class="fa-regular fa-copy" style="color:#a78bfa;font-size:18px;"></i></div>
            </a>
            
            <!-- SUBORDINATE DATA CLICK BUTTON -->
            <a class="menu-item" id="open-subordinate-btn">
                <div class="menu-icon"><i class="fa-regular fa-calendar-alt"></i></div>
                <div class="menu-text">Subordinate data</div>
                <div class="menu-right"><i class="fa-solid fa-chevron-right"></i></div>
            </a>

            <a href="#" class="menu-item"><div class="menu-icon"><i class="fa-solid fa-dollar-sign"></i></div><div class="menu-text">Commission detail</div><div class="menu-right"><i class="fa-solid fa-chevron-right"></i></div></a>
            <a href="#" class="menu-item"><div class="menu-icon"><i class="fa-solid fa-book"></i></div><div class="menu-text">Invitation rules</div><div class="menu-right"><i class="fa-solid fa-chevron-right"></i></div></a>
            <a href="#" class="menu-item"><div class="menu-icon"><i class="fa-solid fa-headset"></i></div><div class="menu-text">Agent line customer service</div><div class="menu-right"><i class="fa-solid fa-chevron-right"></i></div></a>
            <a href="#" class="menu-item"><div class="menu-icon"><i class="fa-solid fa-sack-dollar"></i></div><div class="menu-text">Rebate ratio</div><div class="menu-right"><i class="fa-solid fa-chevron-right"></i></div></a>
        </div>

        <div class="promo-data">
            <div class="promo-header"><i class="fa-solid fa-money-bill-transfer"></i> Promotion data</div>
            <div class="promo-grid">
                <div class="stat-item"><div class="stat-val val-white">0</div><div class="stat-label">This Week</div></div>
                <div class="stat-item"><div class="stat-val val-white">0</div><div class="stat-label">Total commission</div></div>
                <div class="stat-item"><div class="stat-val val-white">0</div><div class="stat-label">Direct Subordinate</div></div>
                <div class="stat-item"><div class="stat-val val-white">0</div><div class="stat-label">Total number of<br>subordinates in the team</div></div>
            </div>
        </div>
    </div>
</div>


<!-- 2. INVITE SCREEN -->
<div class="app-container" id="invite-screen">
    <div class="header">
        <i class="fa-solid fa-chevron-left" id="back-from-invite" style="padding: 10px;"></i>
        <div class="title">Invite</div>
        <div style="width: 34px;"></div>
    </div>
    <div class="scrollable-content">
        <p class="swipe-text">Please swipe left - right to choose your favorite poster</p>
        <div class="poster-carousel">
            <div class="poster-card">
                <div class="poster-badges"><div class="badge"><span>Fair and<br>justice</span></div><div class="badge"><span>Open and<br>transparent</span></div></div>
                <div class="poster-title">Full Odds Bonus Rate</div>
                <div class="poster-features"><div class="feature-box"><i class="fa-solid fa-building-columns"></i><span>Financial security</span></div><div class="feature-box"><i class="fa-solid fa-truck-fast"></i><span>Quick withdrawal</span></div></div>
                <div class="commission-text">Permanent commission up<br>to 85%</div>
                <div class="qr-box"><img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://shree.win" alt="QR"></div>
            </div>
            <div class="poster-card">
                <div class="poster-badges"><div class="badge"><span>Fair and<br>justice</span></div><div class="badge"><span>Open and<br>transparent</span></div></div>
                <div class="poster-title">Full Odds Bonus Rate</div>
                <div class="poster-features"><div class="feature-box"><i class="fa-solid fa-building-columns"></i><span>Financial security</span></div><div class="feature-box"><i class="fa-solid fa-truck-fast"></i><span>Quick withdrawal</span></div></div>
                <div class="commission-text">Permanent commission up<br>to 85%</div>
                <div class="qr-box"><img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://shree.win/invite" alt="QR"></div>
            </div>
        </div>
        <div class="income-text">Invite friends<br>Income <span class="highlight-red">10 billion</span> Commission</div>
        <div class="action-btns">
            <button class="btn-download">DOWNLOAD QR CODE</button>
            <button class="btn-copy">Copy invitation link</button>
        </div>
        <div class="share-section">
            <p class="share-text">Share to other apps to invite friend</p>
            <div class="social-icons">
                <div class="social-item"><div class="icon-circle whatsapp"><i class="fa-brands fa-whatsapp"></i></div><span>WhatsApp</span></div>
                <div class="social-item"><div class="icon-circle telegram"><i class="fa-brands fa-telegram"></i></div><span>Telegram</span></div>
                <div class="social-item"><div class="icon-circle facebook"><i class="fa-brands fa-facebook-f"></i></div><span>Facebook</span></div>
                <div class="social-item"><div class="icon-circle twitter"><i class="fa-brands fa-x-twitter"></i></div><span>Twitter</span></div>
            </div>
        </div>
    </div>
</div>


<!-- 3. PARTNER REWARDS SCREEN -->
<div class="app-container" id="partner-screen">
    <div class="header">
        <i class="fa-solid fa-chevron-left" id="back-from-partner" style="padding: 10px;"></i>
        <div class="title">Partner rewards</div>
        <div style="width: 34px;"></div>
    </div>

    <div class="scrollable-content">
        <div class="pr-banner">
            <div class="pr-banner-text">
                <p>Invite friends to get<br>max rewards</p>
                <div class="pill">₹388.00</div>
            </div>
        </div>

        <div class="pr-stat">
            <span>Invitation count</span>
            <span class="val-white">0</span>
        </div>
        <div class="pr-stat">
            <span>Effective Invitation count</span>
            <span class="val-green">0</span>
        </div>
        <div class="pr-stat">
            <span>Invitation total bonus</span>
            <span class="val-red">₹0.00</span>
        </div>

        <div class="pr-record-link">
            Invitation record <span style="font-family: sans-serif;">»</span>
        </div>

        <div class="pr-link-title">| INVITATION LINK</div>
        <div class="pr-link-box">
            <div class="pr-link-input" id="dynamic-invite-link">Loading...</div>
            <div class="pr-link-btn" onclick="copyDynamicLink()">
                <i class="fa-regular fa-copy"></i>
            </div>
        </div>

        <div class="pr-rules-box">
            <div class="pr-rules-title">
                <i class="fa-solid fa-book" style="color: #a4a0c9;"></i> Invitation rules
            </div>
            <div class="pr-rules-sub">
                If you invites player A, with in <span class="val-red">7</span> Day
            </div>

            <table class="pr-table">
                <thead>
                    <tr>
                        <th colspan="2">When Player A</th>
                        <th>You get bonus</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="r1">
                        <td rowspan="5" class="col-dep">1st<br>deposit</td>
                        <td class="col-cond">₹200 ≤ Amount<₹500<br>and Turnover ≥ ₹1,000</td>
                        <td class="col-bonus">₹38</td>
                    </tr>
                    <tr class="r2">
                        <td class="col-cond">₹500 ≤ Amount<₹1,000<br>and Turnover ≥ ₹2,500</td>
                        <td class="col-bonus">₹88</td>
                    </tr>
                    <tr class="r1">
                        <td class="col-cond">₹1,000 ≤ Amount<₹2,500<br>and Turnover ≥ ₹5,000</td>
                        <td class="col-bonus">₹128</td>
                    </tr>
                    <tr class="r2">
                        <td class="col-cond">₹2,500 ≤ Amount<₹5,000<br>and Turnover ≥ ₹12,500</td>
                        <td class="col-bonus">₹188</td>
                    </tr>
                    <tr class="r1">
                        <td class="col-cond">Amount ≥ ₹5,000<br>and Turnover ≥ ₹25,000</td>
                        <td class="col-bonus">₹388</td>
                    </tr>

                    <tr class="r2">
                        <td rowspan="5" class="col-dep">2nd<br>deposit</td>
                        <td class="col-cond">₹300 ≤ Amount<₹1,000<br>and Turnover ≥ ₹1,000</td>
                        <td class="col-bonus">₹38</td>
                    </tr>
                    <tr class="r1">
                        <td class="col-cond">₹1,000 ≤ Amount<₹2,500<br>and Turnover ≥ ₹2,500</td>
                        <td class="col-bonus">₹88</td>
                    </tr>
                    <tr class="r2">
                        <td class="col-cond">₹2,500 ≤ Amount<₹5,000<br>and Turnover ≥ ₹5,000</td>
                        <td class="col-bonus">₹128</td>
                    </tr>
                    <tr class="r1">
                        <td class="col-cond">₹5,000 ≤ Amount<₹10,000<br>and Turnover ≥ ₹12,500</td>
                        <td class="col-bonus">₹188</td>
                    </tr>
                    <tr class="r2">
                        <td class="col-cond">Amount ≥ ₹10,000<br>and Turnover ≥ ₹25,000</td>
                        <td class="col-bonus">₹388</td>
                    </tr>

                    <tr class="r1">
                        <td rowspan="5" class="col-dep">3rd<br>deposit</td>
                        <td class="col-cond">₹1,000 ≤ Amount<₹2,500<br>and Turnover ≥ ₹5,000</td>
                        <td class="col-bonus">₹38</td>
                    </tr>
                    <tr class="r2">
                        <td class="col-cond">₹2,500 ≤ Amount<₹5,000<br>and Turnover ≥ ₹12,500</td>
                        <td class="col-bonus">₹88</td>
                    </tr>
                    <tr class="r1">
                        <td class="col-cond">₹5,000 ≤ Amount<₹10,000<br>and Turnover ≥ ₹25,000</td>
                        <td class="col-bonus">₹128</td>
                    </tr>
                    <tr class="r2">
                        <td class="col-cond">₹10,000 ≤ Amount<₹20,000<br>and Turnover ≥ ₹50,000</td>
                        <td class="col-bonus">₹188</td>
                    </tr>
                    <tr class="r1">
                        <td class="col-cond">Amount ≥ ₹20,000<br>and Turnover ≥ ₹100,000</td>
                        <td class="col-bonus">₹388</td>
                    </tr>
                </tbody>
            </table>

            <div class="pr-footer-alert">Each deposit is eligible for only one bonus.</div>
            <ul class="pr-footer-bullets">
                <li>eg: <br>Player A 1st deposit <span class="hl">₹199.00</span> and turnover <span class="hl">₹1,000.00</span>, you can't get bonus</li>
                <li>the reward has no limitation, the more you invited the more rewards you will get it</li>
                <li>If the conditions are met the rewards will be automatically credited to player's balance</li>
            </ul>
        </div>
    </div>
</div>


<!-- 4. SUBORDINATE DATA SCREEN (MATCHING SCREENSHOT) -->
<div class="app-container" id="subordinate-screen">
    <!-- Header -->
    <div class="header">
        <i class="fa-solid fa-chevron-left" id="back-from-subordinate" style="padding: 10px;"></i>
        <div class="title">Subordinate data</div>
        <div style="width: 34px;"></div>
    </div>

    <div class="scrollable-content">
        <!-- Search Bar -->
        <div class="sub-search-box">
            <input type="text" class="sub-search-input" placeholder="Search subordinate UID">
            <button class="sub-search-btn">
                <i class="fa-solid fa-magnifying-glass"></i>
            </button>
        </div>

        <!-- Filters Row -->
        <div class="sub-filters-row">
            <div class="sub-dropdown filter-type">
                <span>All</span>
                <i class="fa-solid fa-chevron-down"></i>
            </div>
            <div class="sub-dropdown filter-date">
                <span id="sub-current-date">2026-09-09</span>
                <i class="fa-solid fa-chevron-down"></i>
            </div>
        </div>

        <!-- 6-Grid Stats Card -->
        <div class="sub-stats-card">
            <div class="sub-stat-item">
                <h2>0</h2>
                <p>Deposit number</p>
            </div>
            <div class="sub-stat-item">
                <h2>0</h2>
                <p>Deposit amount</p>
            </div>
            <div class="sub-stat-item">
                <h2>0</h2>
                <p>Number of bettors</p>
            </div>
            <div class="sub-stat-item">
                <h2>0</h2>
                <p>Total bet</p>
            </div>
            <div class="sub-stat-item">
                <h2>0</h2>
                <p>Number of people making first deposit</p>
            </div>
            <div class="sub-stat-item">
                <h2>0</h2>
                <p>First deposit amount</p>
            </div>
        </div>

        <!-- No Data Illustration -->
        <div class="sub-no-data-area">
            <svg class="sub-no-data-icon" viewBox="0 0 200 150" fill="none" xmlns="http://www.w3.org/2000/svg">
                <!-- Background clouds/hills -->
                <path d="M20 100 Q 60 70 100 95 Q 150 75 180 105 L 180 140 L 20 140 Z" fill="#2a245c" />
                <path d="M50 110 Q 90 85 130 110 Q 165 95 190 120 L 190 140 L 50 140 Z" fill="#363073" />
                <!-- Tree on left -->
                <path d="M35 125 C 28 115 28 100 35 90 C 42 100 42 115 35 125 Z" fill="#6d65b5" />
                <rect x="34" y="125" width="2" height="10" fill="#4d478a"/>
                <!-- Tree on right -->
                <path d="M165 130 C 160 122 160 112 165 105 C 170 112 170 122 165 130 Z" fill="#6d65b5" />
                <rect x="164.5" y="130" width="1" height="8" fill="#4d478a"/>
                <!-- Paper Scroll -->
                <rect x="90" y="45" width="50" height="75" rx="4" fill="#756bbd" />
                <rect x="95" y="40" width="45" height="12" rx="3" fill="#8d84d6" />
                <rect x="80" y="120" width="55" height="12" rx="4" fill="#8d84d6" />
                <!-- Paper fold sheet -->
                <rect x="90" y="55" width="55" height="65" fill="#857ccf" opacity="0.9"/>
                <!-- Small side card -->
                <rect x="140" y="105" width="20" height="20" rx="3" fill="#645ca3" />
            </svg>
            <div class="sub-no-data-text">No data</div>
        </div>
    </div>

    <!-- Floating Buttons from Screenshot -->
    <div class="sub-fab-left">
        <i class="fa-solid fa-layer-group"></i>
    </div>
    <div class="sub-fab-right">
        <i class="fa-solid fa-headset"></i>
    </div>
</div>


<!-- JavaScript Logic -->
<script>
    // Screen Elements
    const agencyScreen = document.getElementById('agency-screen');
    const inviteScreen = document.getElementById('invite-screen');
    const partnerScreen = document.getElementById('partner-screen');
    const subordinateScreen = document.getElementById('subordinate-screen');

    // Navigation Open Buttons
    const openInviteBtn = document.getElementById('open-invite-btn');
    const openPartnerBtn = document.getElementById('open-partner-btn');
    const openSubordinateBtn = document.getElementById('open-subordinate-btn');

    // Back Buttons
    const backFromInviteBtn = document.getElementById('back-from-invite');
    const backFromPartnerBtn = document.getElementById('back-from-partner');
    const backFromSubordinateBtn = document.getElementById('back-from-subordinate');
    
    // Dynamic Invitation URL
    const dynamicLinkText = document.getElementById('dynamic-invite-link');
    const currentUrl = window.location.href;
    var _invCode = (document.getElementById("user-invite-code") && document.getElementById("user-invite-code").innerText.trim()) || "{{ invite_code }}";
    dynamicLinkText.innerText = currentUrl + (currentUrl.includes('?') ? '&' : '?') + "invite=" + _invCode;

    // Set today's date on Subordinate screen filter dynamically (YYYY-MM-DD)
    const dateSpan = document.getElementById('sub-current-date');
    if(dateSpan) {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        dateSpan.innerText = `${yyyy}-${mm}-${dd}`;
    }

    // Navigation Events
    openInviteBtn.addEventListener('click', () => {
        agencyScreen.style.display = 'none';
        inviteScreen.style.display = 'flex';
    });
    
    openPartnerBtn.addEventListener('click', () => {
        agencyScreen.style.display = 'none';
        partnerScreen.style.display = 'flex';
    });

    openSubordinateBtn.addEventListener('click', () => {
        agencyScreen.style.display = 'none';
        subordinateScreen.style.display = 'flex';
    });

    backFromInviteBtn.addEventListener('click', () => {
        inviteScreen.style.display = 'none';
        agencyScreen.style.display = 'flex';
    });

    backFromPartnerBtn.addEventListener('click', () => {
        partnerScreen.style.display = 'none';
        agencyScreen.style.display = 'flex';
    });

    backFromSubordinateBtn.addEventListener('click', () => {
        subordinateScreen.style.display = 'none';
        agencyScreen.style.display = 'flex';
    });

    // Copy Function
    function showToast(msg){var t=document.getElementById("sw-toast"),x=document.getElementById("sw-toast-text");if(!t||!x)return;x.innerText=msg||"Link Copied!";t.classList.add("show");setTimeout(function(){t.classList.remove("show");},2200);}
    function copyInviteCode(){
        var t=document.getElementById("user-invite-code");
        var c=t?t.innerText.trim():"{{ invite_code }}";
        if(!c){showToast("Code not ready");return;}
        function done(){showToast("Invitation code copied!");}
        if(navigator.clipboard&&navigator.clipboard.writeText){
            navigator.clipboard.writeText(c).then(done).catch(function(){
                var i=document.createElement("input");i.value=c;document.body.appendChild(i);i.select();document.execCommand("copy");document.body.removeChild(i);done();
            });
        }else{
            var i=document.createElement("input");i.value=c;document.body.appendChild(i);i.select();document.execCommand("copy");document.body.removeChild(i);done();
        }
    }
    function copyDynamicLink() {
        const textToCopy = dynamicLinkText.innerText;
        navigator.clipboard.writeText(textToCopy).then(() => {
            showToast("Link Copied Successfully!");
        }).catch(err => {
            console.error('Error in copying text: ', err);
        });
    }
</script>

<div id="sw-toast" class="sw-toast"><div class="toast-icon">OK</div><span id="sw-toast-text">Link Copied!</span></div><!-- Bottom Navigation - New Design -->
<nav class="bottom-navbar">
    <a href="/home" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
      <span>Home</span>
    </a>
    <a href="/activity" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2zm-7 10.25l-2.61 1.56.69-2.97-2.3-2 3.03-.26L12 7l1.19 2.58 3.03.26-2.3 2 .69 2.97L12 13.25z"/></svg>
      <span>Activity</span>
    </a>
    <a href="/spinwheel" class="wheel-item">
      <div class="wheel-wrapper">
        <svg viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="46" fill="#7522c7" stroke="#9d3efa" stroke-width="2"/>
          <circle cx="50" cy="8" r="2" fill="#ffd700"/>
          <circle cx="80" cy="20" r="2" fill="#ffd700"/>
          <circle cx="92" cy="50" r="2" fill="#ffd700"/>
          <circle cx="80" cy="80" r="2" fill="#ffd700"/>
          <circle cx="20" cy="80" r="2" fill="#ffd700"/>
          <circle cx="8" cy="50" r="2" fill="#ffd700"/>
          <circle cx="20" cy="20" r="2" fill="#ffd700"/>
          <circle cx="50" cy="50" r="40" fill="#b066fe" stroke="#d5a5ff" stroke-width="2"/>
          <path d="M50 50 L50 14 A36 36 0 0 1 81 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L81 32 A36 36 0 0 1 81 68 Z" fill="#c026d3"/>
          <path d="M50 50 L81 68 A36 36 0 0 1 50 86 Z" fill="#00e5ff"/>
          <path d="M50 50 L50 86 A36 36 0 0 1 19 68 Z" fill="#c026d3"/>
          <path d="M50 50 L19 68 A36 36 0 0 1 19 32 Z" fill="#00e5ff"/>
          <path d="M50 50 L19 32 A36 36 0 0 1 50 14 Z" fill="#c026d3"/>
          <circle cx="50" cy="50" r="13" fill="#00b4d8" stroke="#ffffff" stroke-width="1.5"/>
          <text x="50" y="53" fill="#ffffff" font-size="7" font-weight="900" text-anchor="middle" font-family="'Poppins', sans-serif">SPIN</text>
          <polygon points="50,6 45,13 55,13" fill="#60a5fa" stroke="#ffffff" stroke-width="0.8"/>
        </svg>
      </div>
      <span class="wheel-label">Get ₹500</span>
    </a>
    <a href="/promotion" class="nav-item active">
      <svg viewBox="0 0 24 24"><path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
      <span>Promotion</span>
    </a>
    <a href="/account" class="nav-item">
      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
      <span>Account</span>
    </a>
</nav>

<script>document.addEventListener("DOMContentLoaded",function(){var a=document.getElementById("agency-screen");if(a)a.style.display="flex";["invite-screen","partner-screen","subordinate-screen"].forEach(function(id){var e=document.getElementById(id);if(e)e.style.display="none";});});</script></body>
</html>"""
